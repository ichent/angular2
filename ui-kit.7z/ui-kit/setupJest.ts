import 'jest-preset-angular';
import '@testing-library/jest-dom/extend-expect';
import './test-extends/jest-array-matcher';

// Mock for document.execCommand
Object.defineProperty(document, 'execCommand', {
    value: () => {},
});

Object.defineProperty(window, 'DragEvent', {
    value: class DragEvent {}
});

Object.defineProperty(window, 'getComputedStyle', {
    value: () => ({
        getPropertyValue: (prop) => {
            return '';
        }
    })
});

Object.defineProperty(global, 'Promise', { writable: false, value: global.Promise });

setupIntersectionObserverMock();

export function setupIntersectionObserverMock({
    observe = () => null,
    unobserve = () => null,
  }: any = {}): void {
    class IntersectionObserver {
      observe = observe;
      unobserve = unobserve;
    }
    Object.defineProperty(
      window,
      'IntersectionObserver',
      { writable: true, configurable: true, value: IntersectionObserver }
    );
    Object.defineProperty(
      global,
      'IntersectionObserver',
      { writable: true, configurable: true, value: IntersectionObserver }
    );
  }
