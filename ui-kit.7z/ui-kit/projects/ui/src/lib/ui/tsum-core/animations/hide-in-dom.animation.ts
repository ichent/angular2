import { trigger, transition, query, animateChild } from '@angular/animations';

export const HideInDomAnimation = trigger('hideInDomAnimation', [
    transition('* => void', [
        query('@*', [animateChild()], { optional: true })
    ]),
]);
