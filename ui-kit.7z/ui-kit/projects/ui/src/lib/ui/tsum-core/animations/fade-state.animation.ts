import { trigger, transition, style, animate, state } from '@angular/animations';
const animationTime = 100;

export type FadeState = 'true' | 'false';

export const FadeSateAnimation = trigger('fadeAnimation', [
    state('true', style({
        opacity: 1,
        transform: 'translateX(0)',
    })),
    state('false', style({
        opacity: 0,
        transform: 'translateX(8px)',
    })),
    transition('true <=> false', [
        animate(animationTime),
    ]),
]);
