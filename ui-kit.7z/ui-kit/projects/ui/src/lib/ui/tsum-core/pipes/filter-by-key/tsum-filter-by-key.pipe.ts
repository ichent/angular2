import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'tsumFilterByKey',
    pure: false,
})
export class TsumFilterByKeyPipe implements PipeTransform {
    transform(
        items: any[],
        filterValue: string,
        keys: string[] = ['name'],
        minimumSymbolsToFilter: number = 3,
    ): any[] {
        if (!Array.isArray(items)
            || items.length === 0
            || !items
            || !filterValue
            || filterValue.length < minimumSymbolsToFilter
        ) {
            return items;
        }

        return items.filter((item: any) => {
            const currentText: string = filterValue.toLowerCase();

            let isFoundText: boolean = false;

            keys.forEach((currentKey: string) => {
                const lowerCaseKey = item[currentKey].toLowerCase();

                if (lowerCaseKey.indexOf(currentText) > -1) {
                    isFoundText = true;
                }
            });

            return isFoundText;
        });
    }
}
