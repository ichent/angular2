import { trigger, transition, style, animate, query } from '@angular/animations';

export const FadeInOutAnimation = trigger('fadeInOutAnimation', [
    transition('* => *', [
        query(':enter', [
            style({ opacity: 0, transform: 'translateX(16px)' }),
            animate('0.150s', style({ opacity: 1, transform: 'translateX(0)' }))
        ], { optional: true }),
    ]),
]);
