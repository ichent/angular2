import { trigger, transition, style, animate, state } from '@angular/animations';
import { TsumAnimation } from './animation.namespace';

export const SlideToShowAnimation = trigger('slideToShowAnimation', [
    state(TsumAnimation.State.In, style({ opacity: '1', transform: 'translateX(0)' })),
    state(`${TsumAnimation.State.Out}, ${TsumAnimation.State.Void}`, style({ opacity: '0', transform: 'translateX(32px)' })),
    transition(`${TsumAnimation.State.In} => ${TsumAnimation.State.Out}`, animate('100ms ease-out')),
    transition(`${TsumAnimation.State.Void} => ${TsumAnimation.State.In}`, animate('100ms ease-out')),
    transition(`${TsumAnimation.State.Out} => ${TsumAnimation.State.In}`, animate('100ms ease-in')),
]);

export const SlideToShowAnimation200 = trigger('slideToShowAnimation', [
    state(TsumAnimation.State.In, style({ opacity: '1', transform: 'translateX(0)' })),
    state(`${TsumAnimation.State.Out}, ${TsumAnimation.State.Void}`, style({ opacity: '0', transform: 'translateX(32px)' })),
    transition(`${TsumAnimation.State.In} => ${TsumAnimation.State.Out}`, animate('200ms ease-out')),
    transition(`${TsumAnimation.State.Void} => ${TsumAnimation.State.In}`, animate('200ms ease-out')),
    transition(`${TsumAnimation.State.Out} => ${TsumAnimation.State.In}`, animate('200ms ease-in')),
]);
