export namespace TsumAnimation {
    export enum State {
        In = 'in',
        Out = 'out',
        Void = 'void',
    }
}
