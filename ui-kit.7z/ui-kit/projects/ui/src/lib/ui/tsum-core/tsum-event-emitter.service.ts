import { DOCUMENT } from '@angular/common';
import {
    Injectable, Inject, Optional,
} from '@angular/core';
import { fromEvent, BehaviorSubject, combineLatest, Observable } from 'rxjs';
import { debounceTime, skip } from 'rxjs/operators';

export interface ScrollEvent {
    scrollTop: number;
    width: number;
    height: number;
}

/**
 * @description This service uses for global emitters, like resize, scroll etc
 * @example tsumEventEmitterService.scrolled$.subscribe(x => console.log('scrolled', x));
 */
@Injectable({
    providedIn: 'root',
})
export class TsumEventEmitterService {
    public scrolled$: BehaviorSubject<ScrollEvent> = new BehaviorSubject<ScrollEvent>(null);
    public resized$: BehaviorSubject<void> = new BehaviorSubject<void>(null);

    public resizeAndScrolled$: Observable<[ScrollEvent, void]> = combineLatest([
        this.scrolled$,
        this.resized$,
    ]);

    constructor(
        @Optional() @Inject(DOCUMENT) private document: any,
    ) {
        if (this.document && window) {
            fromEvent(this.document, 'scroll')
                .pipe(
                    skip(1),
                    debounceTime(200),
                )
                .subscribe((e: Event) => {
                    const boundingClientRect: DOMRect = this.document.body.getBoundingClientRect() as DOMRect;

                    this.scrolled$.next({
                        scrollTop: boundingClientRect.top,
                        width: boundingClientRect.width,
                        height: boundingClientRect.height,
                    });
                });

            fromEvent(window, 'resize')
                .pipe(
                    skip(1),
                    debounceTime(200),
                )
                .subscribe(() => {
                    this.resized$.next();
                });
        }
    }
}
