import {
    Directive,
    ElementRef,
    EventEmitter,
    Input,
    Output,
    OnDestroy,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';
import { fromEvent, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

/**
 * @description Directive helper for detect click outside of element
 * @description Use this directive when you need hide something when click not in your element
 * @description For example, modal, autocomplete
 * @description Also you can handle this click, just use as output
 * @description Has input 'skipFirstClickOutside' - it's mean skip first click and not emit
 * @example <div (tsumClickOutside)="handleClick()">click</div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-click-out-side--default}
 */
@Directive({
    selector: '[tsumClickOutside]'
})
export class TsumClickOutsideDirective implements OnDestroy {
    @TsumInputBoolean()
    @Input()
    public skipFirstClickOutside: boolean = true;

    @Output('tsumClickOutside')
    public clickOutside$: EventEmitter<Event> = new EventEmitter();

    private countClicks: number = 0;

    private destroyed$ = new Subject<void>();

    constructor(
        private elementRef: ElementRef,
    ) {
        const click$ = fromEvent(document, 'click');

        click$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((event: Event) => {
                this.handleClickOutside(event);
            });
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private handleClickOutside(event: Event): void {
        const nativeElement: HTMLElement = this.elementRef.nativeElement;

        if (event.composedPath().indexOf(nativeElement) === -1 && (!this.skipFirstClickOutside || this.countClicks > 0)) {
            this.clickOutside$.emit(event);
        }

        this.countClicks++;
    }
}
