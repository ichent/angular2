export * from './tsum-icon-socials.component';
