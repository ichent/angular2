import { Pipe, PipeTransform } from '@angular/core';

/**
 * @description Word ending for Russian language
 * @example: {{ count | tsumWordEndings: ['товар', 'товара', 'товаров'] }}
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-word-endings--default}
 */
@Pipe({
    name: 'tsumWordEndings',
})
export class TsumWordEndingsPipe implements PipeTransform {
    public transform(count: string | number, wordForms: string[], withCounter: boolean = true): string {
        let currentCount = 0;

        if (count == null) {
            return '';
        }

        if (typeof count === 'string') {
            currentCount = Number(count.replace(/\D+/g, ''));
        } else if (typeof count === 'number') {
            currentCount = count;
        }

        if (!isNaN(currentCount) && wordForms && wordForms.length === 3) {
            return `${withCounter ? count : ''} ${chooseWordForm(currentCount, wordForms)}`.trim();
        }

        return `${count}`;
    }
}

function chooseWordForm(count: number, wordForms: string[]): string {
    const absNumber: number = Math.abs(count);
    const cases: number[] = [2, 0, 1, 1, 1, 2];

    return wordForms[
        (absNumber % 100 > 4 && absNumber % 100 < 20)
            ? 2
            : cases[(absNumber % 10 < 5) ? absNumber % 10 : 5]
        ];
}
