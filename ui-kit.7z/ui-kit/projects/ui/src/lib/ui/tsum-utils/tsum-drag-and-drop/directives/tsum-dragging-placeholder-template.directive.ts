import { Directive, EmbeddedViewRef, TemplateRef, ViewContainerRef } from '@angular/core';

/**
 * Используется в DraggableDirective для отображения шаблона плейсхолдера в месте перемещаемого компонента
 */
@Directive({
    selector: '[tsumDraggingPlaceholderTemplate]'
})
export class TsumDraggingPlaceholderTemplateDirective {

    private placeholderViewRef: EmbeddedViewRef<void>;

    constructor(
        private templateRef: TemplateRef<void>,
        private viewRef: ViewContainerRef,
    ) {}

    public createPlaceholderView(): void {
        if (!this.templateRef) {
            return;
        }

        this.placeholderViewRef = this.viewRef.createEmbeddedView(this.templateRef);
    }

    public deletePlaceholderView(): void {
        if (!this.placeholderViewRef) {
            return;
        }

        const viewRefIndex: number = this.viewRef.indexOf(this.placeholderViewRef);

        if (viewRefIndex > -1) {
            this.viewRef.remove(viewRefIndex);
        }
    }

}
