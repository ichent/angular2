import { Attribute, Directive, ElementRef } from '@angular/core';
import { TsumDroppableDirective } from './tsum-droppable.directive';

/**
 * Область, относительно которой, расчитываются координаты для droppable директивы (использовать опционально)
 */
@Directive({
    selector: '[tsumDroppableTarget]',
})
export class TsumDroppableTargetDirective {

    constructor(
        private el: ElementRef,
        private droppableDirective: TsumDroppableDirective,
        @Attribute('tsumDroppableTarget') private areaId: string,
    ) {
        this.droppableDirective.registerTargetArea(el, areaId || null);
    }

}
