export namespace TsumScrollRotate {
    export type RotateDirection = 'vertical' | 'horizontal';
}
