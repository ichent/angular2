import { Directive, Input, ElementRef, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';

/**
 * Директива для установки нативных css переменных
 * @example Для работы необходимо прокинуть директиву со значениями
 * [tsumCssProps]="['--count', count]"
 * Передавать необходимо массив. Первое значение ключ переменной, второе - значение
 * @description Больше информации {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-css-property--default}
 */
@Directive({
    selector: '[tsumCssProps]',
})
export class TsumCssPropsDirective implements OnChanges {
    @Input() tsumCssProps: any;

    constructor(private elementRef: ElementRef) {
    }

    public ngOnChanges(changes: SimpleChanges): void {
        const cssProps: SimpleChange = changes.tsumCssProps;
        const cssValue: string[] = cssProps.currentValue;

        if (cssProps && Array.isArray(cssValue) && cssValue.length === 2 && cssValue[0].indexOf('--') > -1) {
            const { style } = this.elementRef.nativeElement;

            style.setProperty(cssValue[0], cssValue[1]);
        }
    }
}
