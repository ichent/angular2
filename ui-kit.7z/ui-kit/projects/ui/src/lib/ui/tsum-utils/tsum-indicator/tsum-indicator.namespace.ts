export namespace TsumIndicator {
    export type Type = 'danger' | 'warning' | 'info' | 'success' | 'primary' | 'primary-active' | 'secondary' | 'white' | 'not-active';
}
