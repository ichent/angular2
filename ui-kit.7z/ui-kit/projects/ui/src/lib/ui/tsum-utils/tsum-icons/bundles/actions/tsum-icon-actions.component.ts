import { Component } from '@angular/core';

@Component({
    selector: 'tsum-icon-actions',
    templateUrl: './tsum-icon-actions.component.html',
})
export class TsumIconActionsComponent {}
