import { Component, Input, HostBinding, ElementRef } from '@angular/core';

const DEFAULT_SIZE = 24;

/**
 * @description Component for icons
 * @description For use just add input 'name' and set icon name
 * @description Icon name you can find in TsumIcon namespace
 * @description Inputs:
 * @description name - name of icon, can find in TsumIcon namespace
 * @description width/height - width/height of icon
 * @description fill/stroke - color of icon, fill and stroke
 * @description size - combine of width and height
 * @description color - color of icon
 * @example <tsum-icon name="navigation-apps"></tsum-icon>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-icons--list}
 */
@Component({
    selector: 'tsum-icon',
    templateUrl: './tsum-icon.component.html',
    styleUrls: ['./tsum-icon.component.styl']
})
export class TsumIconComponent {
    /**
     * @description Icon name you can find in TsumIcon namespace
     */
    @Input() name: string;

    /**
     * @description With of icon
     */
    @Input()
    public width: number;

    /**
     * @description Height of icon
     */
    @Input()
    public height: number;

    /**
     * @description Fill color of icon
     */
    @HostBinding('style.fill')
    @HostBinding('style.color')
    @Input()
    public fill: string;

    /**
     * @description Stroke color of icon
     */
    @HostBinding('style.stroke')
    @Input()
    public stroke: string;

    /**
     * @description Combine of width and height
     */
    @Input()
    public set size(size: number) {
        if (size && size !== DEFAULT_SIZE) {
            this.width = size;
            this.height = size;
        }
    }

    /**
     * @description Color of icon
     */
    @HostBinding('style.color')
    @Input()
    public color: string;

    @HostBinding('style.width.px')
    public get innerWidth(): number {
        if (this.width) {
            return this.width;
        }

        return null;
    }

    @HostBinding('style.height.px')
    public get innerHeight(): number {
        if (this.height) {
            return this.height;
        }

        return null;
    }

    constructor(
        public el: ElementRef,
    ) {}

    public get absUrl(): string {
        return window.location.href;
    }
}
