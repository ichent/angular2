import { Directive, ElementRef } from '@angular/core';
import { TsumDraggableDirective } from './tsum-draggable.directive';

/**
 * Ручка для drag элемента, за которую его можно перемещать.
 * Если не указана, элемент может быть перемещён за любую его часть.
 */
@Directive({
    selector: '[tsumDraggingHandle]'
})
export class TsumDraggingHandleDirective {

    constructor(
        private draggableDirective: TsumDraggableDirective,
        private el: ElementRef,
    ) {
        draggableDirective.registerHandle(el);
    }

}
