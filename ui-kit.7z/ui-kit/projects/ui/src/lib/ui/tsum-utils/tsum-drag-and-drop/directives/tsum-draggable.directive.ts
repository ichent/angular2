import {
    ContentChild,
    Directive,
    ElementRef,
    Inject,
    Input,
    OnDestroy,
    OnInit,
    Optional,
    Renderer2,
    TemplateRef,
    Output,
    EventEmitter,
} from '@angular/core';
import { DOCUMENT } from '@angular/common';

import { filter, first, mapTo, switchMap, takeUntil, tap } from 'rxjs/operators';
import { fromEvent, NEVER, Subject } from 'rxjs';

import { TsumDragAndDropDirective } from './tsum-drag-and-drop.directive';
import { TsumDraggingTemplateDirective } from './tsum-dragging-template.directive';
import { TsumDraggingPlaceholderTemplateDirective } from './tsum-dragging-placeholder-template.directive';
import { TsumDnD } from '../namespace/tsum-dnd.namespace';

const DEFAULT_DRAGGING_CLASS = 'tsum-dragging-active';
const DRAGGING_THRESHOLD = 2;
const LEFT_BUTTON_MOUSE = 0;

/**
 * Помечает передвигаемые элементы
 */
@Directive({
    selector: '[tsumDraggable]',
})
export class TsumDraggableDirective implements OnInit, OnDestroy {

    @Input('tsumDraggable')
    public value: string;

    @Input('tsumDraggableEnabled')
    public active: boolean = true;

    @Input()
    public draggingClass: string = DEFAULT_DRAGGING_CLASS;

    @Output('dragged')
    public dragged$ = new EventEmitter<boolean>();

    @ContentChild(TsumDraggingTemplateDirective)
    public draggingTemplateDirective: TsumDraggingTemplateDirective;

    @ContentChild(TsumDraggingPlaceholderTemplateDirective)
    public draggingPlaceholderTemplateDirective: TsumDraggingPlaceholderTemplateDirective;

    public get draggingTemplate(): TemplateRef<any> {
        return this.draggingTemplateDirective && this.draggingTemplateDirective.templateRef;
    }

    private handle: ElementRef;

    private destroyed$ = new Subject<void>();

    constructor(
        private el: ElementRef,
        private renderer: Renderer2,
        @Inject(DOCUMENT) private document: any,
        @Optional() private dragAndDropDirective: TsumDragAndDropDirective,
    ) { }

    public ngOnInit(): void {
        const handleEl: ElementRef = this.handle || this.el;
        fromEvent(handleEl.nativeElement, 'mousedown')
            .pipe(
                filter((event: MouseEvent) => event.button === LEFT_BUTTON_MOUSE), // только левая кнопка
                tap((event: MouseEvent) => event.preventDefault()), // отмена выделения текста
                // инициируем drag лишь при минимальном смещении в 2px
                switchMap((initialEvent: MouseEvent) => fromEvent(handleEl.nativeElement, 'mousemove')
                    .pipe(
                        tap((moveEvent: MouseEvent) => moveEvent.preventDefault()),
                        first((moveEvent: MouseEvent) => {
                            const differenceClientX = initialEvent.clientX - moveEvent.clientX;
                            const differenceClientY = initialEvent.clientY - moveEvent.clientY;

                            return Math.pow(differenceClientX, 2)
                                + Math.pow(differenceClientY, 2)
                                > Math.pow(DRAGGING_THRESHOLD, 2);
                        }
                        ),
                        mapTo(initialEvent),
                        takeUntil(fromEvent(this.document, 'mouseup')),
                    ),
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe((event: MouseEvent) => this.drag(event));

        this.dragAndDropDirective?.draggableValue$
            .pipe(
                switchMap((value: string) => value === this.value
                    ? this.dragAndDropDirective.isDragging$
                    : NEVER,
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe((isDragging: boolean) => {
                if (isDragging) {
                    this.addDraggingClass();
                    this.createPlaceholder();
                    this.dragged$.emit();
                } else {
                    this.removeDraggingClass();
                    this.removePlaceholder();
                    this.dragged$.emit();
                }
            });
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    public registerHandle(handle: ElementRef): void {
        this.handle = handle;
    }

    public drag(event: MouseEvent): void {
        if (this.dragAndDropDirective && this.active) {
            const elRect: ClientRect = this.el.nativeElement.getBoundingClientRect();
            const cursor: TsumDnD.Coordinates = { top: event.clientY, left: event.clientX };
            this.dragAndDropDirective.onDrag(this.value, this.draggingTemplate, elRect, cursor);
        }
    }

    private addDraggingClass(): void {
        this.renderer.addClass(this.el.nativeElement, this.draggingClass);
    }

    private removeDraggingClass(): void {
        this.renderer.removeClass(this.el.nativeElement, this.draggingClass);
    }

    private createPlaceholder(): void {
        if (this.draggingPlaceholderTemplateDirective) {
            this.draggingPlaceholderTemplateDirective.createPlaceholderView();
        }
    }

    private removePlaceholder(): void {
        if (this.draggingPlaceholderTemplateDirective) {
            this.draggingPlaceholderTemplateDirective.deletePlaceholderView();
        }
    }
}
