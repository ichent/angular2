import {
    Input,
    ElementRef,
    ViewContainerRef,
    Directive,
    ComponentRef,
    OnInit,
    OnDestroy,
    Output,
    EventEmitter,
    OnChanges,
    SimpleChanges,
} from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { TsumInputBoolean, TsumDynamicComponentsService } from '@tsum/utils';

import { TsumCopyToClipboardComponent } from './tsum-copy-to-clipboard.component';
import { TsumIcon } from '../tsum-icons/tsum-icon.namespace';

/**
 * @description Copy directive
 * @description Add this directive if you need copy text
 * @description When add this directive, this make current element relative position
 * @description By default copy icon move to top 16px and right 16px
 * @description After copy icon change to success icon, and return to default icon when timeout out
 * @description Should send copied text
 * @example <div tsumCopy="text"></div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-copy--default}
 */
@Directive({
    selector: '[tsumCopy]',
})
export class TsumCopyDirective implements OnInit, OnDestroy, OnChanges {
    /**
     * @description Copy text
     */
    @Input('tsumCopy')
    public copiedText: string;

    /**
     * @description You can change default icon of copy, just pass icon name
     */
    @Input()
    public tsumCopyIcon: string = 'actions-copy';

    /**
     * @description You can change size of copy icon
     */
    @Input()
    public tsumCopySize: number = 14;

    /**
     * @description Width of copy icon
     */
    @Input()
    public tsumCopyWidth: number;

    /**
     * @description Height of copy icon
     */
    @Input()
    public tsumCopyHeight: number;

    /**
     * @description Color of copy icon
     */
    @Input()
    public tsumCopyColor: string = TsumIcon.Color.Secondary;

    /**
     * @description Right position of copy icon
     */
    @Input()
    public tsumCopyRight;

    /**
     * @description Left position of copy icon
     */
    @Input()
    public tsumCopyLeft: number;

    /**
     * @description Top position of copy icon
     */
    @Input()
    public tsumCopyTop: number = 16;

    /**
     * @description Default state
     */
    @TsumInputBoolean()
    @Input()
    public tsumNormalCopy: boolean;

    /**
     * @description Timeout to hide success copy
     */
    @Input()
    public hideTimeout: number = 5000;

    /**
     * @description Emit when click to copy
     */
    @Output('handleCopy')
    public handleCopy$: EventEmitter<void> = new EventEmitter<void>();

    private copyComponentRef: ComponentRef<TsumCopyToClipboardComponent> = null;
    private destroyed$: Subject<void> = new Subject<void>();

    constructor(
        private el: ElementRef,
        private viewContainer: ViewContainerRef,
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
    ) { }

    public ngOnInit(): void {
        if (!this.copiedText) {
            return;
        }

        this.copyComponentRef = this.tsumDynamicComponentsService.createChildComponent(
            TsumCopyToClipboardComponent,
            this.viewContainer,
        );

        const tsumCopyToClipboardComponent: TsumCopyToClipboardComponent = this.copyComponentRef.instance;

        tsumCopyToClipboardComponent.copiedText = this.copiedText;
        tsumCopyToClipboardComponent.tsumCopyIconSize = this.tsumCopySize;
        tsumCopyToClipboardComponent.tsumCopyIcon = this.tsumCopyIcon;
        tsumCopyToClipboardComponent.tsumNormalCopy = this.tsumNormalCopy;
        tsumCopyToClipboardComponent.tsumCopyWidth = this.tsumCopyWidth;
        tsumCopyToClipboardComponent.tsumCopyHeight = this.tsumCopyHeight;
        tsumCopyToClipboardComponent.tsumCopyColor = this.tsumCopyColor;
        tsumCopyToClipboardComponent.hideTimeout = this.hideTimeout;
        tsumCopyToClipboardComponent.tsumCopyTop = this.tsumCopyTop;
        tsumCopyToClipboardComponent.tsumCopyRight = this.tsumCopyRight;
        tsumCopyToClipboardComponent.tsumCopyLeft = this.tsumCopyLeft;

        tsumCopyToClipboardComponent.isCopied$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.handleCopy$.next());

        this.el.nativeElement.style.position = 'relative';
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (this.copyComponentRef && changes?.copiedText?.currentValue) {
            this.copyComponentRef.instance.copiedText = changes.copiedText.currentValue;
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();

        this.tsumDynamicComponentsService.deleteComponent(this.copyComponentRef);
    }
}
