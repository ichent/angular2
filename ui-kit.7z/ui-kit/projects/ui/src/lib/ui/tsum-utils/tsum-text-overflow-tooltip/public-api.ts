export * from './tsum-text-overflow-tooltip.directive';
export * from './tsum-text-overflow-tooltip.module';
