export * from './tsum-css-property.module';
export * from './css-property.directive';
