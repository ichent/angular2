import {
    Directive,
    ElementRef,
} from '@angular/core';

@Directive({
    selector: '[tsumIntersectionContainer]',
})
export class TsumIntersectionContainerDirective {

    constructor(
        public el: ElementRef,
    ) {}

}
