import {
    Component,
    ChangeDetectionStrategy,
    HostBinding,
    ElementRef,
    ViewChild,
    ViewContainerRef,
} from '@angular/core';

@Component({
    selector: 'app-dragging-view',
    template: `<ng-container #viewContainer></ng-container>`,
    styleUrls: ['./tsum-dragging-view.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class TsumDraggingViewComponent {

    @HostBinding('style.top.px')
    public top = 0;

    @HostBinding('style.left.px')
    public left = 0;

    @HostBinding('style.position')
    public position = 'absolute';

    @ViewChild('viewContainer', { read: ViewContainerRef, static: true })
    public viewContainer: ViewContainerRef;

    public get height(): number {
        return this.el.nativeElement.clientHeight;
    }

    public get width(): number {
        return this.el.nativeElement.clientWidth;
    }

    constructor(
        public el: ElementRef<HTMLElement>,
    ) {}

}
