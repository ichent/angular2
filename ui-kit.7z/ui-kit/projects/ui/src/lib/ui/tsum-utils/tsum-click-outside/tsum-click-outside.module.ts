import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumClickOutsideDirective } from './tsum-click-outside.directive';

const DIRECTIVES = [
    TsumClickOutsideDirective,
];

/**
 * @description Directive helper for detect click outside of element
 * @description Use this directive when you need hide something when click not in your element
 * @description For example, modal, autocomplete
 * @description Also you can handle this click, just use as output
 * @description Has input 'skipFirstClickOutside' - it's mean skip first click and not emit
 * @example <div (tsumClickOutside)="handleClick()">click</div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-click-out-side--default}
 */
@NgModule({
    declarations: DIRECTIVES,
    imports: [
        CommonModule,
    ],
    exports: DIRECTIVES,
})
export class TsumClickOutsideModule {

}
