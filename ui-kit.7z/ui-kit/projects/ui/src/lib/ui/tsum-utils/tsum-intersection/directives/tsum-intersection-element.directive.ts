import {
    Directive,
    ElementRef,
    EventEmitter,
    Input,
    OnDestroy,
    Optional,
    Output,
} from '@angular/core';
import { TsumIntersectionContainerDirective } from './tsum-intersection-container.directive';

@Directive({
    selector: '[tsumIntersectionElement]',
})
export class TsumIntersectionElementDirective implements OnDestroy {

    @Input()
    public hideOnPartialIntersection = true;

    @Output('isIntersecting')
    public isIntersecting$ = new EventEmitter<boolean>();

    public get element(): HTMLElement {
        return this.elementRef.nativeElement;
    }

    public get container(): HTMLElement {
        return this.intersectionContainerDirective && this.intersectionContainerDirective.el.nativeElement;
    }

    private observer: IntersectionObserver;

    constructor(
        private elementRef: ElementRef,
        @Optional() private intersectionContainerDirective: TsumIntersectionContainerDirective,
    ) {}

    public startObserving(): void {
        if (!this.intersectionContainerDirective) {
            return;
        }

        this.removeObserver();
        this.createObserver();
        this.observer.observe(this.element);
    }

    public stopObserving(): void {
        if (!this.intersectionContainerDirective) {
            return;
        }

        this.removeObserver();
    }

    public ngOnDestroy(): void {
        this.removeObserver();
     }

    private createObserver(): void {
        this.observer = new IntersectionObserver(
            (entries: IntersectionObserverEntry[]) => {
                entries.forEach((entry: IntersectionObserverEntry) => {
                    this.isIntersecting$.emit(entry.isIntersecting);
                });
            },
            {
                root: this.container,
                threshold: this.hideOnPartialIntersection ? 1 : 0
            }
        );
    }

    private removeObserver(): void {
        if (!this.observer) {
            return;
        }

        this.observer.unobserve(this.element);
        this.observer.disconnect();
    }
}
