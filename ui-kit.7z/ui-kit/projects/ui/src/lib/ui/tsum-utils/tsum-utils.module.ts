import { NgModule } from '@angular/core';
import { TsumSpinnerModule } from '../tsum-common/tsum-spinner/tsum-spinner.module';
import { TsumCopyToClipboardModule } from './tsum-copy-clipboard/tsum-copy-to-clipboard.module';
import { TsumIconsModule } from './tsum-icons/tsum-icons.module';

@NgModule({
    imports: [
        TsumSpinnerModule,
        TsumCopyToClipboardModule,
        TsumIconsModule,
    ]
})
export class TsumUtilsModule {}
