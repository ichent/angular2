export * from './tsum-word-endings.module';
export * from './tsum-word-endings.pipe';
