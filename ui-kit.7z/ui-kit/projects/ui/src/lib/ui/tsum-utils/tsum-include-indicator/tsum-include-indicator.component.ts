import { Component, HostBinding, Input, ElementRef, ChangeDetectionStrategy } from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

@Component({
    selector: 'tsum-include-indicator',
    templateUrl: './tsum-include-indicator.component.html',
    styleUrls: ['./tsum-include-indicator.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumIncludeIndicatorComponent {
    @TsumInputBoolean()
    @HostBinding('class.tsum-include-indicator_active')
    @Input()
    public isActive = false;

    constructor(
        public el: ElementRef,
    ) { }
}
