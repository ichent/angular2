import { Component, OnInit, Input, HostBinding, ChangeDetectionStrategy } from '@angular/core';
import { TsumIndicator } from './tsum-indicator.namespace';

@Component({
    selector: 'tsum-indicator',
    templateUrl: './tsum-indicator.component.html',
    styleUrls: ['./tsum-indicator.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumIndicatorComponent implements OnInit {
    @Input() public type: TsumIndicator.Type = 'danger';

    @HostBinding('style.top.px')
    @Input()
    public top: number = 2;

    @HostBinding('style.left.px')
    @Input()
    public left: number = 2;

    @HostBinding('style.right.px')
    @Input()
    public right: number = 2;

    @Input()
    public size: number = 8;

    constructor() { }

    public ngOnInit(): void {
    }
}
