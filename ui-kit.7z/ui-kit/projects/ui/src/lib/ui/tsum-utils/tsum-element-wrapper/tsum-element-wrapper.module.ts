import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumWrapperDirective } from './tsum-element-wrapper.directive';

const DIRECTIVES = [
    TsumWrapperDirective,
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        DIRECTIVES,
    ],
    exports: [
        DIRECTIVES,
    ],
})
export class TsumElementWrapperModule {}
