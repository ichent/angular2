import { Component } from '@angular/core';

@Component({
    selector: 'tsum-icon-socials',
    templateUrl: './tsum-icon-socials.component.html',
})
export class TsumIconSocialsComponent {}
