import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumCssPropsDirective } from './css-property.directive';

const DIRECTIVES = [
    TsumCssPropsDirective,
];

/**
 * Директива для установки нативных css переменных
 * @example Для работы необходимо прокинуть директиву со значениями
 * [tsumCssProps]="['--count', count]"
 * Передавать необходимо массив. Первое значение ключ переменной, второе - значение
 * @description Больше информации {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-css-property--default}
 */
@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        DIRECTIVES,
    ],
    exports: [
        DIRECTIVES,
    ],
})
export class TsumCssPropertyModule {}
