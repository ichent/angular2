import { Component, Input } from '@angular/core';

@Component({
    selector: 'tsum-icon-definitions',
    templateUrl: './tsum-icon-definitions.component.html',
    styleUrls: ['./tsum-icon-definitions.component.styl'],
})
export class TsumIconDefinitionsComponent {
    @Input() public width: number;
    @Input() public height: number;
}
