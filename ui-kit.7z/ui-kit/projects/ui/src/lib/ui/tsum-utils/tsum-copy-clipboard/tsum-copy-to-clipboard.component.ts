import { Component, ElementRef, ChangeDetectionStrategy, ChangeDetectorRef, EventEmitter } from '@angular/core';
import { TsumIcon } from '../tsum-icons/tsum-icon.namespace';

@Component({
    selector: 'tsum-copy-to-clipboard',
    templateUrl: './tsum-copy-to-clipboard.component.html',
    styleUrls: ['./tsum-copy-to-clipboard.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumCopyToClipboardComponent {
    public copiedText: string = '';
    public tsumCopyIcon: string;
    public tsumCopyIconSize: number;
    public tsumCopyWidth: number;
    public tsumCopyHeight: number;
    public tsumNormalCopy: boolean;
    public successColor: string;
    public tsumCopyColor: string;
    public color = TsumIcon.Color;
    public hideTimeout: number = 5000;
    public tsumCopyTop: number;
    public tsumCopyRight: number;
    public tsumCopyLeft: number;

    public isCopied = false;

    public isCopied$ = new EventEmitter<boolean>();

    constructor(
        public el: ElementRef,
        private changeDetectorRef: ChangeDetectorRef,
    ) {
        this.isCopied$.subscribe((isCopied: boolean) => {
            this.isCopied = isCopied;

            if (!this.changeDetectorRef['destroyed']) {
                this.changeDetectorRef.detectChanges();
            }
        });
    }

    public copyToClipboard(): void {
        if (!this.copyText) {
            return;
        }

        this.isCopied$.next(true);

        setTimeout(() => {
            this.isCopied$.next(false);

            if (!this.changeDetectorRef['destroyed']) {
                this.changeDetectorRef.detectChanges();
            }
        }, this.hideTimeout);

        this.copyText(this.copiedText);
    }

    private copyText(value: string): void {
        const selBox = document.createElement('textarea');

        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = value;

        document.body.appendChild(selBox);

        selBox.focus();
        selBox.select();

        document.execCommand('copy');

        document.body.removeChild(selBox);
    }
}
