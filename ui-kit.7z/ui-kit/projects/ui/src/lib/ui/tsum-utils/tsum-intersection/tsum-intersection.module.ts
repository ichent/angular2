import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumIntersectionElementDirective } from './directives/tsum-intersection-element.directive';
import { TsumIntersectionContainerDirective } from './directives/tsum-intersection-container.directive';

const DIRECTIVES = [
    TsumIntersectionElementDirective,
    TsumIntersectionContainerDirective,
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: DIRECTIVES,
    exports: DIRECTIVES,
})
export class TsumIntersectionModule {

}
