import { Component } from '@angular/core';

@Component({
    selector: 'tsum-icon-navigation',
    templateUrl: './tsum-icon-navigation.component.html',
})
export class TsumIconNavigationComponent {}
