import { Directive, ElementRef, Renderer2, OnInit, Input } from '@angular/core';

@Directive({
    selector: '[tsumElementWrapper]'
})
export class TsumWrapperDirective implements OnInit {
    @Input() public tsumElementWrapper: string = 'div';

    constructor(
        private el: ElementRef,
        private renderer: Renderer2) {
    }

    public ngOnInit(): void {
        const parent = this.el.nativeElement.parentNode;
        const element = this.renderer.createElement(this.tsumElementWrapper);

        this.renderer.insertBefore(parent, element, this.el.nativeElement);
        this.renderer.removeChild(parent, this.el.nativeElement);

        this.renderer.removeAttribute(this.el.nativeElement, 'tsumElementWrapper');

        this.renderer.appendChild(element, this.el.nativeElement);
    }
}
