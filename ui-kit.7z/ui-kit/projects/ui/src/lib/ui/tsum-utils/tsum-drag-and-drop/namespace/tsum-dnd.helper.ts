import { TsumDnD } from './tsum-dnd.namespace';

export namespace TsumDnDHelper {

    interface SizePlace {
        width: number;
        height: number;
    }

    interface PositionParams {
        scaleX: number;
        scaleY: number;
        width: number;
        height: number;
        top: number;
        left: number;
    }

    /**
     * Считает заступы для каждой из сторон element в area
     *
     * @param fromArea - отсутпы element относительно area
     * @param area - область, для которой считаеся overflows
     * @param element - проверяемый элемент
     */
    export function calculateOverflow(
        fromArea: TsumDnD.Coordinates,
        area: SizePlace,
        element: SizePlace,
    ): TsumDnD.Overflows {
        const offsetTop: number = fromArea.top;
        const offsetRight: number = area.width - (fromArea.left + element.width);
        const offsetBottom: number = area.height - (fromArea.top + element.height);
        const offsetLeft: number = fromArea.left;

        const normalizeOffset = (offset: number) => offset < 0 ? Math.abs(offset) : 0;

        return {
            top: normalizeOffset(offsetTop),
            right: normalizeOffset(offsetRight),
            bottom: normalizeOffset(offsetBottom),
            left: normalizeOffset(offsetLeft),
        };
    }

    /**
     * Проверяет расположен ли element в area
     *
     * @param overflows - заступы для каждой из сторон element в area
     * @param maxOverflow - допустимые заступы
     */
    export function isElementInArea(overflows: TsumDnD.Overflows, maxOverflow?: TsumDnD.Overflows): boolean {
        for (const key in overflows) {
            if (overflows.hasOwnProperty(key)) {
                if (overflows[key] > (maxOverflow && maxOverflow[key] || 0)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Получание координат при выравнивании элемента, если он заступает за граница drop зоны.
     * Если элемент не выступает за границы, то они будут равны обычным.
     * @param coordinates текущие
     * @param overflows заступ
     */
    export function normalizeCoordinates(
            coordinates: TsumDnD.Coordinates,
            overflows: TsumDnD.Overflows
        ): TsumDnD.Coordinates {
        return {
            left: roundNumber(coordinates.left + overflows.left - overflows.right),
            top: roundNumber(coordinates.top + overflows.top - overflows.bottom),
        };
    }

    /**
     * Расчет заступов с каждой стороны для элемента.
     * Заступы всегда положительное число.
     */
    export function getOverflows(areaRect: ClientRect, elementSize: TsumDnD.Size, newCoords: TsumDnD.Coordinates): TsumDnD.Overflows {
        const elementRelativeTop: number = newCoords.top - areaRect.top;
        const elementRelativeLeft: number = newCoords.left - areaRect.left;

        return calculateOverflow(
            { top: elementRelativeTop, left: elementRelativeLeft },
            { width: areaRect.width, height: areaRect.height },
            { width: elementSize.width, height: elementSize.height },
        );
    }

    /**
     * Генерация финального события отпускания drag элемента в drop область
     */
    export function getDropEvent(
        areaId: string,
        areaRect: ClientRect,
        scrollOffset: TsumDnD.Coordinates,
        dragFinishedEvent: TsumDnD.DragFinishedEvent,
        mainDropEvent?: TsumDnD.DropToAreaEvent, // Если есть target area
    ): TsumDnD.DropToAreaEvent {
        const elementWidth: number = dragFinishedEvent.element.width;
        const elementHeight: number = dragFinishedEvent.element.height;
        const elementRelativeTop: number = dragFinishedEvent.element.top - areaRect.top - scrollOffset.top;
        const elementRelativeLeft: number = dragFinishedEvent.element.left - areaRect.left - scrollOffset.left;

        const elementOverflows: TsumDnD.Overflows = calculateOverflow(
            { top: elementRelativeTop, left: elementRelativeLeft },
            { width: areaRect.width, height: areaRect.height },
            { width: elementWidth, height: elementHeight },
        );

        const overflows: TsumDnD.DroppableAreasOverflows = {
            main: mainDropEvent && mainDropEvent.overflows.main || elementOverflows,
            target: elementOverflows,
        };

        const targetArea: TsumDnD.DropArea = { id: areaId, width: areaRect.width, height: areaRect.height };

        const areas: TsumDnD.DroppableAreas = {
            main: (mainDropEvent ? mainDropEvent.areas.main : targetArea),
            target: targetArea,
        };

        const normalizedCoords: TsumDnD.Coordinates = normalizeCoordinates(
            {
                top: elementRelativeTop,
                left: elementRelativeLeft,
            },
            overflows.main,
        );

        return {
            areas,
            element: {
                value: dragFinishedEvent.value,
                width: elementWidth,
                height: elementHeight,
                top: {
                    area: elementRelativeTop,
                    window: elementHeight,
                    normalized: normalizedCoords.top,
                },
                left: {
                    area: elementRelativeLeft,
                    window: elementWidth,
                    normalized: normalizedCoords.left,
                },
            },
            overflows,
        };
    }

    /**
     * Проверка попал ли курсор мыши в drop область
     */
    export function isCursorInArea(areaRect: ClientRect, cursorCoords: TsumDnD.Coordinates): boolean {
        const overflows: TsumDnD.Overflows = calculateOverflow(
            {
                top: cursorCoords.top - areaRect.top,
                left: cursorCoords.left - areaRect.left
            },
            {
                width: areaRect.width,
                height: areaRect.height
            },
            {
                width: 1,
                height: 1
            },
        );

        return isElementInArea(overflows);
    }

    /**
     * @description Используется для преобразования координат товара на холсте, тк на стороне Back-End
     * позиционирование идет относительно фотографии
     */
    export function transformPosition<T extends PositionParams>(
        outerRatio: number,
        innerRatio: number,
        initialParams: T,
        inside: boolean = true
    ): T {

        let width: number;
        let height: number;
        let dx = 0;
        let dy = 0;

        if (innerRatio > outerRatio) {
            width = initialParams.width;
            height = width / (inside ? innerRatio : outerRatio);
            dy = (initialParams.height - height) * initialParams.scaleY / 2;
        } else {
            height = initialParams.height;
            width = height * (inside ? innerRatio : outerRatio);
            dx = (initialParams.width - width) * initialParams.scaleX / 2;
        }

        return {
            ...initialParams,
            width: roundNumber(width),
            height: roundNumber(height),
            top: roundNumber(initialParams.top + dy),
            left: roundNumber(initialParams.left + dx),
        };
    }

    function roundNumber(value: number, digitsAfterComma: number = 2): number {
        return value ? Number(value.toFixed(digitsAfterComma)) : 0;
    }
}


