import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumCopyToClipboardComponent } from './tsum-copy-to-clipboard.component';
import { TsumCopyDirective } from './tsum-copy-to-clipboard.directive';
import { TsumIconsModule } from '../tsum-icons/tsum-icons.module';

const COMPONENTS = [
    TsumCopyToClipboardComponent,
];

const DIRECTIVES = [
    TsumCopyDirective,
];

/**
 * Copy directive
 * Add this directive if you need copy text
 * When add this directive, this make current element relative position
 * By default copy icon move to top 16px and right 16px
 * After copy icon change to success icon, and return to default icon when timeout out
 * Should send copied text
 * @example <div tsumCopy="text"></div>
 * More info {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-copy--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
    ],
    declarations: [
        COMPONENTS,
        DIRECTIVES,
    ],
    exports: [
        COMPONENTS,
        DIRECTIVES,
    ],
    entryComponents: [
        COMPONENTS,
    ],
    providers: [
        TsumDynamicComponentsService,
    ],
})
export class TsumCopyToClipboardModule { }
