import { NgModule } from '@angular/core';
import { TsumWordEndingsPipe } from './tsum-word-endings.pipe';

const PIPES = [
    TsumWordEndingsPipe,
];

/**
 * @description Word ending for Russian language
 * @example: {{ count | tsumWordEndings: ['товар', 'товара', 'товаров'] }}
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/utils-word-endings--default}
 */
@NgModule({
    imports: [],
    declarations: [
        PIPES,
    ],
    exports: [
        PIPES,
    ],
})
export class TsumWordEndingsModule {}
