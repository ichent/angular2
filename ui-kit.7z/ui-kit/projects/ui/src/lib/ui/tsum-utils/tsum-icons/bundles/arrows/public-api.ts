export * from './tsum-icon-arrows.component';
