import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumScrollRotateDirective } from './tsum-scroll-rotate.directive';

const DIRECTIVES = [
    TsumScrollRotateDirective,
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        DIRECTIVES,
    ],
    exports: [
        DIRECTIVES,
    ],
})
export class TsumScrollRotateModule { }
