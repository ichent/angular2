import { Directive, Input, OnDestroy, ElementRef, OnInit, NgZone, PLATFORM_ID, Inject } from '@angular/core';

import { TsumScrollRotate } from './tsum-scroll-rotate.namespace';
import { fromEvent, Subject } from 'rxjs';
import { tap, map, takeUntil } from 'rxjs/operators';
import { TsumUserAgentService } from '@tsum/utils';
import { isPlatformBrowser } from '@angular/common';

/**
 * Директива для изменения направления скролла
 * Передаем tsumScrollRotate="horizontal" и при вертикальном скролле у нас будет горизонтальный
 * @example
 * <div class="w-50-p">
 *       <div class="h2 mb-md">Горизонтальный скролл</div>
 *       <div class="h-240 d-flex o-hidden">
 *           <tsum-scroll class="w-100-p right">
 *               <div tsumScrollRotate="horizontal" class="w-1000 h-240 bg"></div>
 *           </tsum-scroll>
 *       </div>
 *   </div>
 * Применяется как с нативным скроллом, так и с tsum-scroll
 */
// @dynamic
@Directive({
    selector: '[tsumScrollRotate]',
})
export class TsumScrollRotateDirective implements OnDestroy, OnInit {
    @Input()
    public tsumScrollRotate: TsumScrollRotate.RotateDirection = 'vertical';

    @Input()
    public scrollableElement: Element;

    private destroyed$ = new Subject<void>();

    constructor(
        private elementRef: ElementRef,
        private ngZone: NgZone,
        private tsumUserAgentService: TsumUserAgentService,
        @Inject(PLATFORM_ID) private platformId: object,
    ) {}

    public ngOnInit(): void {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }

        if (this.tsumScrollRotate === 'horizontal') {
            this.ngZone.runOutsideAngular(() => {
                fromEvent(this.elementRef.nativeElement, 'wheel')
                    .pipe(
                        takeUntil(this.destroyed$),
                        tap((event: WheelEvent) => event.preventDefault()),
                        map((event: WheelEvent) => event.deltaY),
                    )
                    .subscribe((deltaY: number) => {
                        const element: Element = this.elementRef.nativeElement;

                        let parent: Element = element.parentElement;

                        /** Обработка для tsum-scroll */
                        if (element.parentElement.classList.contains('content-wrapper')) {
                            parent = parent.parentElement;
                        }

                        /** Переопределяем родителя, если передали элемент, который необходимо скролить */
                        if (this.scrollableElement) {
                            parent = this.scrollableElement;
                        }

                        /**
                         * В windows обычно крутят колесо вниз и контент уходит вниз
                         * В нашем случае контент должен уходить вправо при кручении колеса вниз
                         * Для Мака ситуация инвертируется
                         */
                        if (this.tsumUserAgentService.os.isMacOs()) {
                            parent.scrollLeft += deltaY;
                        } else {
                            parent.scrollLeft -= deltaY;
                        }
                    });
            });
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
