import { Directive, Input, forwardRef, ElementRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

/**
 * Директива создана для изменения видимого значения в input, при этом не меняя значение в форме
 * @example <input [tsumInputTitle]="dateControl.value | date : 'dd/MM/yyyy'" [formControl]="dateControl" />
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/input-title--default}
 */
@Directive({
    selector: '[tsumInputTitle]',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TsumInputTitleDirective),
            multi: true,
        },
    ],
})
export class TsumInputTitleDirective implements ControlValueAccessor {
    @Input('tsumInputTitle')
    public title: string;

    constructor(
        private elementRef: ElementRef,
    ) {}

    public writeValue(title: string): void {
        if (!title) {
            return;
        }

        const element: HTMLInputElement = this.elementRef.nativeElement;

        setTimeout(() => {
            element.value = this.title;
        }, 0);
    }

    public registerOnTouched(fn: () => void): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: () => void): void {
        this.onChange = fn;
    }

    private onChange = (value: string, options: object) => {};
    private onTouched = () => {};
}
