export namespace TsumDnD {
    export interface Overflows {
        top: number;
        right: number;
        bottom: number;
        left: number;
    }

    export interface Coordinates {
        top: number;
        left: number;
    }

    export interface DragFinishedEvent {
        value: string; // Значение переданное в drag директиву (например hash или id)
        element: DragElement;
        cursor: TsumDnD.Coordinates;
    }

    export interface DropToAreaEvent {
        areas: DroppableAreas;
        element: DropElement;
        overflows: DroppableAreasOverflows;
    }

    export interface DragElement {
        top: number;
        left: number;
        width: number;
        height: number;
    }

    export interface Size {
        width: number;
        height: number;
    }

    export interface DropArea {
        id: string;
        width: number;
        height: number;
    }

    export interface DropElement {
        value: string;
        width: number;
        height: number;
        top: DropElementCoords;
        left: DropElementCoords;
    }

    export interface DropElementCoords {
        area: number;
        window: number;
        normalized: number; // с учетом overflow
    }

    export interface DroppableAreasOverflows {
        main: Overflows;
        target: Overflows;
    }

    export interface DroppableAreas {
        main: DropArea;
        target: DropArea;
    }

}
