import { Component } from '@angular/core';

@Component({
    selector: 'tsum-icon-arrows',
    templateUrl: './tsum-icon-arrows.component.html',
})
export class TsumIconArrowsComponent {}
