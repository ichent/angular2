import { Directive, TemplateRef } from '@angular/core';

/**
 * Используется в DraggableDirective для сссылки на шаблона перемещаемого элемента
 */
@Directive({
    selector: '[tsumDraggingTemplate]'
})
export class TsumDraggingTemplateDirective {

    constructor(
        public templateRef: TemplateRef<any>,
    ) {}

}
