import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'tsum-icon-indicator',
    templateUrl: './tsum-icon-indicator.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumIconIndicatorComponent {}
