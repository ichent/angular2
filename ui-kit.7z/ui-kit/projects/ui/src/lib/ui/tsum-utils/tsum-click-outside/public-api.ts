export * from './tsum-click-outside.directive';
export * from './tsum-click-outside.module';
