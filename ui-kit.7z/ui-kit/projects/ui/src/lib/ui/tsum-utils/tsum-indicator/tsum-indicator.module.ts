import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumIndicatorComponent } from './tsum-indicator.component';
import { TsumIconsModule } from '../tsum-icons/tsum-icons.module';

const COMPONENTS = [
    TsumIndicatorComponent,
];

/**
 * @description tsum-indicator component, uses for indicate new/require/info state
 * @example <tsum-indicator></tsum-indicator>
 * @example <tsum-indicator type="info"></tsum-indicator>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-selector--component}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumIndicatorModule { }
