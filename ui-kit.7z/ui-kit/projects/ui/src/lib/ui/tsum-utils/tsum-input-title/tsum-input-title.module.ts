import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TsumInputTitleDirective } from './tsum-input-title.directive';

const DIRECTIVES = [
    TsumInputTitleDirective,
];

/**
 * Директива создана для изменения видимого значения в input, при этом не меняя значение в форме
 * @example <input [tsumInputTitle]="dateControl.value | date : 'dd/MM/yyyy'" [formControl]="dateControl" />
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/input-title--default}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    declarations: [
        DIRECTIVES,
    ],
    exports: [
        DIRECTIVES,
    ],
})
export class TsumInputTitleModule {}
