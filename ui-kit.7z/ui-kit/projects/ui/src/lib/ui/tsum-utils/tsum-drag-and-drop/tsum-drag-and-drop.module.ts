import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumDraggableDirective } from './directives/tsum-draggable.directive';
import { TsumDroppableDirective } from './directives/tsum-droppable.directive';
import { TsumDragAndDropDirective } from './directives/tsum-drag-and-drop.directive';
import { TsumDraggingTemplateDirective } from './directives/tsum-dragging-template.directive';
import { TsumDraggingPlaceholderTemplateDirective } from './directives/tsum-dragging-placeholder-template.directive';
import { TsumDroppableTargetDirective } from './directives/tsum-droppable-target.directive';
import { TsumDraggingHandleDirective } from './directives/tsum-dragging-handle.directive';
import { TsumDraggingViewComponent } from './dragging-view/tsum-dragging-view.component';

const DIRECTIVES = [
    TsumDraggableDirective,
    TsumDroppableDirective,
    TsumDragAndDropDirective,
    TsumDraggingTemplateDirective,
    TsumDraggingPlaceholderTemplateDirective,
    TsumDroppableTargetDirective,
    TsumDraggingHandleDirective,
];

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        DIRECTIVES,
        TsumDraggingViewComponent,
    ],
    exports: [
        DIRECTIVES,
    ],
    entryComponents: [
        TsumDraggingViewComponent,
    ]
})
export class TsumDragAndDropModule {

}
