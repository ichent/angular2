import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumIncludeIndicatorComponent } from './tsum-include-indicator.component';

const COMPONENTS = [
    TsumIncludeIndicatorComponent,
];

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumIncludeIndicatorModule { }
