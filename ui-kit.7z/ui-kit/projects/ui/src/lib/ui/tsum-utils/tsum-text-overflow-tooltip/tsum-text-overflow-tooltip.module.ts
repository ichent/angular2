import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumTooltipModule } from '../../tsum-notifications/tsum-tooltip/tsum-tooltip.module';
import { TextOverflowTooltipDirective } from './tsum-text-overflow-tooltip.directive';

const DIRECTIVES = [
    TextOverflowTooltipDirective,
];

@NgModule({
    imports: [
        CommonModule,
        TsumTooltipModule,
    ],
    declarations: [
        DIRECTIVES,
    ],
    exports: [
        DIRECTIVES,
        TsumTooltipModule,
    ],
})
export class TsumTextOverflowTooltipModule {}
