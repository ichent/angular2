import {
    Directive,
    ElementRef,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Optional,
    Output,
    Inject,
} from '@angular/core';
import { takeUntil, tap } from 'rxjs/operators';
import { Subject, fromEvent } from 'rxjs';

import { TsumDragAndDropDirective } from './tsum-drag-and-drop.directive';
import { TsumDnD } from '../namespace/tsum-dnd.namespace';
import { TsumDnDHelper } from '../namespace/tsum-dnd.helper';
import { DOCUMENT } from '@angular/common';

/**
 * Помечает зону дропа элемента
 */
@Directive({
    selector: '[tsumDroppable]',
})
export class TsumDroppableDirective implements OnInit, OnDestroy {

    @Input('tsumDroppable')
    public areaId: string;

    @Output('dropToArea')
    public dropToArea$ = new EventEmitter<TsumDnD.DropToAreaEvent>();

    @Output('moveOnArea')
    public moveOnArea$ = new EventEmitter<any>();

    private destroyed$ = new Subject();

    private targetArea: ElementRef = null;
    private targetAreaId: string = null;

    constructor(
        public el: ElementRef<HTMLElement>,
        @Inject(DOCUMENT) private document: any,
        @Optional() private dragAndDropDirective: TsumDragAndDropDirective,
    ) { }

    public ngOnInit(): void {
        if (this.dragAndDropDirective) {
            this.dragAndDropDirective.registerArea(this.el);
            this.mouseMoveOnArea();

            this.dragAndDropDirective.dragFinished$
                .pipe(
                    takeUntil(this.destroyed$),
                )
                .subscribe((dragFinishedEvent: TsumDnD.DragFinishedEvent) => {
                    const droppableAreaRect: ClientRect = this.el.nativeElement.getBoundingClientRect();

                    if (
                        this.dragAndDropDirective.checkCursorInArea
                        && !TsumDnDHelper.isCursorInArea(droppableAreaRect, dragFinishedEvent.cursor)
                    ) {
                        return;
                    }

                    const scrollOffset: TsumDnD.Coordinates = this.dragAndDropDirective.getScrollOffset();
                    const mainAreaDropEvent: TsumDnD.DropToAreaEvent = TsumDnDHelper.getDropEvent(
                        this.areaId || null,
                        droppableAreaRect,
                        scrollOffset,
                        dragFinishedEvent
                    );

                    if (this.checkDroppedToArea(mainAreaDropEvent)) {
                        let dropEvent: TsumDnD.DropToAreaEvent = mainAreaDropEvent;

                        if (this.targetArea) {
                            const targetAreaRect: ClientRect = this.targetArea.nativeElement.getBoundingClientRect();
                            dropEvent = TsumDnDHelper.getDropEvent(
                                this.targetAreaId,
                                targetAreaRect,
                                scrollOffset,
                                dragFinishedEvent,
                                mainAreaDropEvent,
                            );
                        }

                        this.dropToArea$.emit(dropEvent);
                        this.dragAndDropDirective.onDropToArea(dropEvent);
                    }
                });
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    public registerTargetArea(targetAreaRef: ElementRef, targetAreaId: string): void {
        this.targetArea = targetAreaRef;
        this.targetAreaId = targetAreaId;
    }

    private checkDroppedToArea(dropEvent: TsumDnD.DropToAreaEvent): boolean {
        return TsumDnDHelper.isElementInArea(
            dropEvent.overflows.main,
            {
                top: dropEvent.element.height,
                right: dropEvent.element.width,
                bottom: dropEvent.element.height,
                left: dropEvent.element.width,
            },
        );
    }

    private mouseMoveOnArea(): void {
        fromEvent(this.document, 'mousemove').pipe(
            tap((event: MouseEvent) => {
                const droppableAreaRect: ClientRect = this.el.nativeElement.getBoundingClientRect();
                const cursor = {
                    top: event.clientY,
                    left: event.clientX
                };


                this.moveOnArea$.next(TsumDnDHelper.isCursorInArea(droppableAreaRect, cursor));

            }),
            takeUntil(this.destroyed$),
        ).subscribe();
    }
}
