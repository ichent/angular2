import {
    Directive,
    ElementRef,
    AfterViewInit,
    Optional,
    Renderer2,
    Input,
} from '@angular/core';
import { ResizeObserver } from 'resize-observer';

import { TsumTooltipDirective } from '../../tsum-notifications/tsum-tooltip/tsum-tooltip.directive';

export type OverflowType = 'row' | 'column';

@Directive({
    selector: '[tsumTextOverflowTooltip]'
})
export class TextOverflowTooltipDirective implements AfterViewInit {

    @Input('tsumTextOverflowTooltip')
    public tsumTextOverflowTooltip: OverflowType;

    constructor(
        private elRef: ElementRef,
        private renderer: Renderer2,
        @Optional() private tsumTooltipDirective: TsumTooltipDirective,
    ) {}

    public ngAfterViewInit(): void {
        const nativeElement: HTMLElement = this.elRef.nativeElement;

        const resizeObserver = new ResizeObserver(() => {
            this.setParams(nativeElement);
        });

        resizeObserver.observe(nativeElement);

        this.renderer.setStyle(nativeElement, 'overflow', 'hidden');

        if (!this.tsumTextOverflowTooltip) {
            this.tsumTextOverflowTooltip = 'row';
        }

        this.setParams(nativeElement);

    }

    private setParams(nativeElement: HTMLElement): void {
        if (this.tsumTextOverflowTooltip === 'row') {
            this.renderer.setStyle(nativeElement, 'text-overflow', 'ellipsis');
            this.renderer.setStyle(nativeElement, 'white-space', 'nowrap');

            if (nativeElement.offsetWidth < nativeElement.scrollWidth) {
                this.setTooltipParams(nativeElement);
            }
        }

        if (this.tsumTextOverflowTooltip === 'column') {
            this.renderer.setStyle(nativeElement, 'word-break', 'break-word');

            if (nativeElement.offsetHeight < nativeElement.scrollHeight) {
                this.setTooltipParams(nativeElement);
            }
        }
    }

    private setTooltipParams(nativeElement: HTMLElement): void {
        if (this.tsumTooltipDirective) {
            this.tsumTooltipDirective.delay = 200;
            this.tsumTooltipDirective.tsumTooltip = nativeElement.innerText;
        }
    }
}
