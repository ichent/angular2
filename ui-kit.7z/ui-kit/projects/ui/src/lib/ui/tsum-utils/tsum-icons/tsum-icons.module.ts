import { NgModule } from '@angular/core';
import { TsumIconComponent } from './tsum-icon.component';
import { TsumIconDefinitionsComponent } from './tsum-icon-definitions.component';
import { TsumIconActionsComponent } from './bundles/actions/tsum-icon-actions.component';
import { TsumIconArrowsComponent } from './bundles/arrows/tsum-icon-arrows.component';
import { TsumIconNavigationComponent } from './bundles/navigation/tsum-icon-navigation.component';
import { TsumIconNotificationComponent } from './bundles/notification/tsum-icon-notification.component';
import { TsumIconSocialsComponent } from './bundles/socials/tsum-icon-socials.component';
import { TsumIconIndicatorComponent } from './bundles/indicator/tsum-icon-indicator.component';

const COMPONENTS = [
    TsumIconComponent,
    TsumIconDefinitionsComponent,
];

const INNER_COMPONENTS = [
    TsumIconActionsComponent,
    TsumIconArrowsComponent,
    TsumIconNavigationComponent,
    TsumIconNotificationComponent,
    TsumIconSocialsComponent,
    TsumIconIndicatorComponent,
];

/**
 * @description Component for icons
 * @description For use just add input 'name' and set icon name
 * @description Icon name you can find in TsumIcon namespace
 * @description Inputs:
 * @description name - name of icon, can find in TsumIcon namespace
 * @description width/height - width/height of icon
 * @description fill/stroke - color of icon, fill and stroke
 * @description size - combine of width and height
 * @description color - color of icon
 * @example <tsum-icon name="navigation-apps"></tsum-icon>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-icons--list}
 */
@NgModule({
    declarations: [
        COMPONENTS,
        INNER_COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
    entryComponents: [
        TsumIconComponent,
    ]
})
export class TsumIconsModule {}
