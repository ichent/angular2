import { Component } from '@angular/core';

@Component({
    selector: 'tsum-icon-notification',
    templateUrl: './tsum-icon-notification.component.html',
})
export class TsumIconNotificationComponent {}
