import {
    ComponentRef,
    Directive,
    ElementRef,
    EventEmitter,
    Inject,
    Input,
    OnDestroy,
    OnInit,
    Output,
    TemplateRef,
} from '@angular/core';
import { DOCUMENT } from '@angular/common';

import { BehaviorSubject, fromEvent, NEVER, Observable, Subject } from 'rxjs';
import { debounceTime, map, switchMap, takeUntil, tap } from 'rxjs/operators';

import { TsumInputBoolean, TsumDynamicComponentsService } from '@tsum/utils';

import { TsumDraggingViewComponent } from '../dragging-view/tsum-dragging-view.component';
import { TsumDnD } from '../namespace/tsum-dnd.namespace';
import { TsumDnDHelper } from '../namespace/tsum-dnd.helper';

/**
 * Размечает зону, в рамках которой будет осуществляться контроль и перемещение элементов
 */
@Directive({
    selector: '[tsumDragAndDrop]',
})
export class TsumDragAndDropDirective implements OnInit, OnDestroy {

    /**
     * Позиционирование левого верхнего угла перемещаемого объекта к курсору
     */
    @TsumInputBoolean()
    @Input()
    public originToCursor = false;

    /**
     * Ограничение области перемещения drag элемента drop областью
     */
    @TsumInputBoolean()
    @Input()
    public restrictByArea = false;

    /**
     * Позиционирование перемешаемого элемента в fixed position (иначе будет absolute)
     */
    @TsumInputBoolean()
    @Input()
    public fixedDraggingElementPosition = false;

    /**
     * Отменяет перемещение элемента, если курсор мыши, в момент отпускания, находился вне drop области
     */
    @TsumInputBoolean()
    @Input()
    public checkCursorInArea = false;

    @Output('dragFinished')
    public dragFinished$ = new EventEmitter<TsumDnD.DragFinishedEvent>();

    @Output('dropToArea')
    public dropToArea$ = new EventEmitter<TsumDnD.DropToAreaEvent>();

    @Output('dragged')
    public dragged$ = new EventEmitter<boolean>();

    public get draggingComponentRef(): ComponentRef<TsumDraggingViewComponent> {
        return this.draggingComponentRefSubject$.value;
    }

    public get draggingComponent(): TsumDraggingViewComponent {
        return this.draggingComponentRef && this.draggingComponentRef.instance;
    }

    private draggingComponentRefSubject$ = new BehaviorSubject<ComponentRef<TsumDraggingViewComponent>>(null);
    // tslint:disable-next-line:member-ordering
    public isDragging$: Observable<boolean> = this.draggingComponentRefSubject$.pipe(map(Boolean));

    private draggableValueSubject$ = new BehaviorSubject<string>(null);
    // tslint:disable-next-line:member-ordering
    public draggableValue$: Observable<string> = this.draggableValueSubject$.asObservable();

    private mouseup$: Observable<MouseEvent> = fromEvent(this.document, 'mouseup');
    private mousemove$: Observable<MouseEvent> = fromEvent(this.document, 'mousemove');

    private area: ElementRef;

    private destroyed$ = new Subject<void>();

    constructor(
        private dynamicComponentsService: TsumDynamicComponentsService,
        @Inject(DOCUMENT) private document: any,
    ) {}

    public ngOnInit(): void {
        this.isDragging$
            .pipe(
                tap((isDragged: boolean) => this.dragged$.emit(isDragged)),
                switchMap((isComponentCreated: boolean) => isComponentCreated ? this.mouseup$ : NEVER),
                debounceTime(0),
                takeUntil(this.destroyed$),
            )
            .subscribe((event: MouseEvent) => {
                this.dragFinished$.next({
                    value: this.draggableValueSubject$.value,
                    element: {
                        top: this.draggingComponent.top,
                        left: this.draggingComponent.left,
                        width: this.draggingComponent.width,
                        height: this.draggingComponent.height,
                    },
                    cursor: {
                        top: event.clientY,
                        left: event.clientX,
                    },
                });

                this.deleteDraggingComponent();
                this.draggableValueSubject$.next(null);
            });
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();

        if (this.draggingComponentRef) {
            this.dynamicComponentsService.deleteComponent(this.draggingComponentRef);
        }
    }

    public registerArea(area: ElementRef): void {
        this.area = area;
    }

    public onDrag(value: string, template: TemplateRef<any>, elRect: ClientRect, cursor: TsumDnD.Coordinates): void {
        const scrollOffsets: TsumDnD.Coordinates = this.getScrollOffset();
        const deltaTop: number = cursor.top - elRect.top - scrollOffsets.top;
        const deltaLeft: number = cursor.left - elRect.left - scrollOffsets.left;

        this.mousemove$
            .pipe(
                takeUntil(this.mouseup$),
            )
            .subscribe((mouseEvent: MouseEvent) => {
                if (!this.draggingComponent) {
                    this.createDraggingComponent(template);
                    this.draggableValueSubject$.next(value);
                }
                requestAnimationFrame(() => {
                    this.setComponentCoords(this.defineCoordinates(
                        mouseEvent.clientY,
                        mouseEvent.clientX,
                        deltaTop,
                        deltaLeft,
                    ));
                });
            });
    }

    public onDropToArea(dropToArea: TsumDnD.DropToAreaEvent): void {
        this.dropToArea$.next(dropToArea);
    }

    public getScrollOffset(): TsumDnD.Coordinates {
        return this.fixedDraggingElementPosition || !window
            ? { top: 0, left: 0 }
            : { top: window.scrollY, left: window.scrollX };
    }

    private defineCoordinates(cursorTop: number, cursorLeft: number, deltaTop: number, deltaLeft: number): TsumDnD.Coordinates {
        const newCoordinates: TsumDnD.Coordinates = {
            top: this.originToCursor ? cursorTop : cursorTop - deltaTop,
            left: this.originToCursor ? cursorLeft : cursorLeft - deltaLeft,
        };

        if (this.restrictByArea) {
            const overflows = TsumDnDHelper.getOverflows(
                this.area.nativeElement.getBoundingClientRect(),
                this.draggingComponent,
                newCoordinates,
            );

            return TsumDnDHelper.normalizeCoordinates(newCoordinates, overflows);
        }

        return newCoordinates;
    }

    private createDraggingComponent(template: TemplateRef<unknown>): void {
        this.draggingComponentRefSubject$.next(this.dynamicComponentsService.createComponent(TsumDraggingViewComponent));

        if (this.fixedDraggingElementPosition) {
            this.draggingComponent.position = 'fixed';
        }

        this.draggingComponent.viewContainer.createEmbeddedView(template);
    }

    private deleteDraggingComponent(): void {
        if (!this.draggingComponentRef) {
            return;
        }

        this.dynamicComponentsService.deleteComponent(this.draggingComponentRef);
        this.draggingComponentRefSubject$.next(null);
    }

    private setComponentCoords(coordinates: TsumDnD.Coordinates): void {
        if (this.draggingComponent) {
            this.draggingComponent.top = coordinates.top || 0;
            this.draggingComponent.left = coordinates.left || 0;
        }
    }
}
