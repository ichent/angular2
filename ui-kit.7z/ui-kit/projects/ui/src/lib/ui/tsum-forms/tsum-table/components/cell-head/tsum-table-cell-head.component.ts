import {
    Component,
    ChangeDetectionStrategy,
    Input,
    HostBinding,
    AfterViewInit,
    ElementRef,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';
import { tsumTableInitSticky } from '../../tsum-table.helper';

/**
 * @description Заголовок для таблицы
 * @example
 * <table tsumTable>
 *   <tr tsumTableRow>
 *     <th tsumTableCellHead>Name</th>
 *     <th tsumTableCellHead>Surname</th>
 *   </tr>
 *   <tr tsumTableRow>
 *     <td tsumTableCell>Alex</td>
 *     <td tsumTableCell>Dadigin</td>
 *   </tr>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-table--as-native-table}
 */
@Component({
    selector: 'th[tsumTableCellHead]',
    templateUrl: './tsum-table-cell-head.component.html',
    styleUrls: ['./tsum-table-cell-head.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class.sheets-header-left]': 'true',
    },
})
export class TsumTableCellHeadComponent implements AfterViewInit {
    @TsumInputBoolean()
    @HostBinding('class._sticky')
    @Input()
    public sticky = false;

    @TsumInputBoolean()
    @HostBinding('class._right-sticky')
    @Input()
    public rightSticky = false;

    constructor(
        private elementRef: ElementRef,
    ) {}

    public ngAfterViewInit(): void {
        tsumTableInitSticky(this.elementRef.nativeElement);
    }
}
