import {
    Component,
    ChangeDetectionStrategy,
    Input,
    forwardRef,
    OnDestroy,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, FormControl } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { TsumRadioGroupOption } from './tsum-radio-group.interface';
import { TsumSelect } from '../../tsum-selectors/tsum-select.namespace';


/**
 * Группа радио кнопок
 * Принимает инпут list, в котором передаем массив key value
 * Далее берем форму и подписываемся на изменения
 * * Принимает input type - тип возвращаемых данных и поведение, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-radio-group [list]="list" [form]="form"></tsum-radio-group>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-radio--radio-group}
 */
@Component({
    selector: 'tsum-radio-group',
    templateUrl: './tsum-radio-group.component.html',
    styleUrls: ['./tsum-radio-group.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TsumRadioGroupComponent),
            multi: true,
        },
    ],
})
export class TsumRadioGroupComponent implements ControlValueAccessor, OnDestroy {
    @Input()
    public type: TsumSelect.SelectType = 'radioArray';

    @Input()
    public list: TsumRadioGroupOption<any>[] = [];

    public form = new FormControl();

    private destroyed$ = new Subject<void>();

    constructor() {
        this.form.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((selected: string[]) => {
                this.onChange(selected);
            });
    }

    public writeValue(result: string[]): void {
        if (!result) {
            return;
        }

        this.form.setValue(result);
    }

    public registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onChange = (value: string[]) => {};
    private onTouched = () => {};
}
