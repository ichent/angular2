import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TsumPreviewCardCustomerSelectorComponent } from './tsum-pc-customer-selector.component';
import { TsumSelectorModule } from '../tsum-selector.module';
import { TsumPreviewCardCustomerModule } from '../../../tsum-common/tsum-preview-card/tsum-preview-card-customer/tsum-preview-card-customer.module';

const COMPONENTS = [
    TsumPreviewCardCustomerSelectorComponent,
];

/**
 * Группа preview card customer
 * Принимает инпут list, в котором передаем массив TsumPreviewCardCustomerOption
 * Далее берем форму и подписываемся на изменения
 * Принимает input type - тип возвращаемых данных и поведение, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-preview-card-customer-selector [list]="list" [formControl]="form"></tsum-preview-card-customer-selector>
 * More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-selector--preview-card-customer}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TsumSelectorModule,
        TsumPreviewCardCustomerModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumPreviewCardCustomerSelectorModule { }
