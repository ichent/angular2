import { NgModule } from '@angular/core';
import { TsumButtonModule } from './tsum-button/tsum-button.module';
import { TsumCheckboxModule } from './tsum-checkbox/tsum-checkbox.module';
import { TsumTableModule } from './tsum-table/tsum-table.module';
import { TsumRangeModule } from './tsum-range/tsum-range.module';

@NgModule({
    imports: [
        TsumButtonModule,
        TsumCheckboxModule,
        TsumTableModule,
        TsumRangeModule,
    ],
})
export class TsumFormsModule {}
