import { Component, ChangeDetectionStrategy, ElementRef, OnDestroy, ChangeDetectorRef } from '@angular/core';
import {
    BehaviorSubject,
    Observable,
    Subject,
    EMPTY,
} from 'rxjs';
import { TsumIcon } from '../../../../tsum-utils/tsum-icons/tsum-icon.namespace';
import { map, takeUntil, filter } from 'rxjs/operators';
import { TsumPositioning } from '@tsum/utils';

import { TsumPopover } from '../../../../tsum-common/tsum-popover/tsum-popover.namespace';
import { TsumButton } from '../../tsum-button.namespace';
import { TsumPrimaryRubricator } from '../../../../tsum-common/tsum-primary-rubricator/tsum-primary-rubricator.namespace';
import { TsumPopoverComponent } from '../../../../tsum-common/tsum-popover/tsum-popover.component';
import { TsumPositioningPopup } from '../../../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.namespace';

@Component({
    selector: 'tsum-button-actions',
    templateUrl: './tsum-button-actions.component.html',
    styleUrls: ['./tsum-button-actions.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumButtonActionsComponent implements OnDestroy {
    public dragable = false;
    public isExpanded = false;
    public inMoreClicked$: BehaviorSubject<string> = new BehaviorSubject<string>(null);

    private actionsSubject$ = new BehaviorSubject<TsumButton.Action[] | TsumPrimaryRubricator.Action[]>([]);
    private destroyed$ = new Subject<void>();

    public get actions$(): Observable<TsumButton.Action[]> {
        return this.actionsSubject$.asObservable().pipe(
            filter(Boolean),
            map((actions: TsumButton.Action[]) =>
                actions.filter((action: TsumButton.Action) => action.type !== 'in-more'),
            ),
        );
    }

    private get morePopover$(): Observable<TsumPositioningPopup.Config<TsumPopoverComponent<string>>> {
        return this.actionsSubject$.asObservable().pipe(
            filter(Boolean),
            map((actions: TsumButton.Action[]) =>
                actions.filter((action: TsumButton.Action) => action.type === 'in-more'),
            ),
            map((actions: TsumButton.Action[]) => {
                const popovers: TsumPopover.Popover<string>[] = actions.map((action: TsumButton.Action): TsumPopover.Popover<string> => {
                    return {
                        name: action.title,
                        type: action.type,
                        id: action.id,
                    };
                });

                const config: TsumPositioningPopup.Config<TsumPopoverComponent<string>> = {};

                config.props = {};
                config.preferablePositions = [TsumPositioning.Direction.RightCorner];
                config.alignType = 'fixed';
                config.props.popovers = popovers;
                config.isHoverable = true;

                return config;
            }),
        );
    }

    constructor(
        public el: ElementRef,
        public changeDetectorRef: ChangeDetectorRef,
    ) {
        this.morePopover$.pipe(takeUntil(this.destroyed$)).subscribe();
    }

    public setActions(actions: TsumButton.Action[] | TsumPrimaryRubricator.Action[]): void {
        this.actionsSubject$.next(actions);

        if (!this.changeDetectorRef['destroyed']) {
            this.changeDetectorRef.detectChanges();
        }
    }

    public getIconName(action: TsumButton.Action): string {
        if (action.icon) {
            return action.icon;
        }

        switch (action.type) {
            case 'expander':
                return this.isExpanded ? TsumIcon.Arrows.ListUp : TsumIcon.Arrows.ListDown;

            case 'more':
                return TsumIcon.Actions.MoreHorizontal;

            case 'select-all':
                return TsumIcon.Actions.ParentList;

            default:
                return null;
        }
    }

    public isActive(action: TsumButton.Action): boolean {
        if (action.type === 'expander' || action.type === 'more') {
            return false;
        }

        return action.state === 'active';
    }

    public initCallback(event: Event, action: TsumButton.Action): void {
        if (action.type === 'more') {
            return;
        }

        event.stopPropagation();

        if (action.type === 'in-more') {
            this.inMoreClicked$.next(action.id);
        }

        action.callback();
    }

    public getPopover$(action: TsumButton.Action): Observable<TsumPositioningPopup.Config<TsumPopoverComponent<string>>> {
        if (action.type === 'more') {
            return this.morePopover$;
        }

        return EMPTY;
    }

    public onSelectPopover(popover: TsumPopover.Popover<string>, action: TsumButton.Action): void {
        if (action.type === 'more') {
            this.actionsSubject$.getValue().forEach((innerAction: TsumButton.Action | TsumPrimaryRubricator.Action) => {
                if (innerAction.id === popover.id) {
                    innerAction.callback();
                }
            });
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.complete();
        this.destroyed$.next();
    }
}
