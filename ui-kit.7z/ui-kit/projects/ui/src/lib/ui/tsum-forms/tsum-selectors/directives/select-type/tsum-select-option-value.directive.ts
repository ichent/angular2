import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { TsumSelect } from '../../tsum-select.namespace';
import OptionValueType = TsumSelect.OptionValueType;
import { TsumInputBoolean } from '@tsum/utils';

@Directive({
    selector: '[tsumSelectOptionValue]',
})
export class TsumSelectOptionValueDirective {

    @Input('tsumSelectOptionValue')
    public value: OptionValueType;

    @TsumInputBoolean()
    @Input()
    public set disabled(disabled: boolean) {
        this.isDisabledSubject$.next(disabled);

        disabled
            ? this.renderer.addClass(this.el.nativeElement, TsumSelect.disabledClassName)
            : this.renderer.removeClass(this.el.nativeElement, TsumSelect.disabledClassName);
    }

    public get disabled(): boolean {
        return this.isDisabledSubject$.value;
    }

    public disabled$: Observable<boolean>;
    public selected$: Observable<boolean>;

    private isDisabledSubject$ = new BehaviorSubject<boolean>(false);

    /** выбрана ли опция или нет */
    private selectedSubject$ = new BehaviorSubject<boolean>(false);

    public set selected(isActive: boolean) {
        this.selectedSubject$.next(isActive);
    }

    public get selected(): boolean {
        return this.selectedSubject$.value;
    }

    constructor(
        public el: ElementRef,
        private renderer: Renderer2,
    ) {
        this.disabled$ = this.isDisabledSubject$.pipe(distinctUntilChanged());
        this.selected$ = this.selectedSubject$.pipe(distinctUntilChanged());
    }

}
