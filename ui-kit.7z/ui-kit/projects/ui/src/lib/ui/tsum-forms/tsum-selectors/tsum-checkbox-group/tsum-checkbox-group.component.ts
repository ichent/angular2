import {
    Component,
    ChangeDetectionStrategy,
    Input,
    forwardRef,
    OnDestroy,
    ChangeDetectorRef,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, FormControl } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

import { CheckboxGroupList } from './tsum-checkbox-group.interface';
import { TsumSelect } from '../tsum-select.namespace';


/**
 * Группа чекбоксов
 * Принимает инпут list, в котором передаем массив key value
 * Далее берем форму и подписываемся на изменения
 * Принимает input type - тип возвращаемых данных и поведение, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-checkbox-group [list]="list" [form]="form">test checkbox</tsum-checkbox-group>
 * More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-checkbox--checkbox-group}
 */
@Component({
    selector: 'tsum-checkbox-group',
    templateUrl: './tsum-checkbox-group.component.html',
    styleUrls: ['./tsum-checkbox-group.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CheckboxGroupComponent),
            multi: true,
        },
    ],
})
export class CheckboxGroupComponent implements ControlValueAccessor, OnDestroy {
    @Input()
    public type: TsumSelect.SelectType = 'multiple';

    @Input()
    public list: CheckboxGroupList[] = [];

    public form = new FormControl();

    private destroyed$ = new Subject<void>();

    constructor(
        private changeDetectorRef: ChangeDetectorRef,
    ) {
        this.form.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((selected: string[]) => {
                this.onChange(selected);

                this.changeDetectorRef.detectChanges();
            });
    }

    public writeValue(result: string[]): void {
        if (!result) {
            return;
        }

        this.form.setValue(result);
    }

    public registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public isChecked(checkbox: CheckboxGroupList): boolean {
        return this.form?.value?.includes(checkbox.value);
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onChange = (value: string[]) => {};
    private onTouched = () => {};
}
