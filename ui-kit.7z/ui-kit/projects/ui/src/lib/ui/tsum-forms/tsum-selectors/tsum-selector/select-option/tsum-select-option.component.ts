import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ElementRef,
    HostListener,
    ViewChild,
    HostBinding,
} from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import OptionValueType = TsumSelect.OptionValueType;
import { TsumSelect } from '../../tsum-select.namespace';
import { TsumSelectOptionValueDirective } from '../../directives/select-type/tsum-select-option-value.directive';
import { TsumSelectTypeDirective } from '../../directives/select-type/tsum-select-type.directive';
import { TsumInputBoolean } from '@tsum/utils';

@Component({
    selector: 'tsum-select-option',
    templateUrl: './tsum-select-option.component.html',
    styleUrls: ['./tsum-select-option.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class TsumSelectOptionComponent {
    @Input('tsumSelectOptionValue')
    public value: OptionValueType;

    @Input('tsumSelectOptionTitle')
    public title: string;

    @HostBinding('class._centered')
    @TsumInputBoolean()
    @Input()
    public centered: string | boolean;

    @ViewChild('content')
    public content: ElementRef;

    public isChecked$: Observable<boolean>;

    private isCheckedSubject$ = new BehaviorSubject(false);

    // выбрана опция или нет (может отличаться от действующего значения)
    public get isChecked(): boolean {
        return this.isCheckedSubject$.value;
    }

    public get isDisabled(): boolean {
        return this.tsumSelectOptionValueDirective.disabled;
    }

    public get isMultiple(): boolean {
        return this.tsumSelectTypeDirective.selectType === 'multiple';
    }

    constructor(
        private tsumSelectOptionValueDirective: TsumSelectOptionValueDirective,
        private tsumSelectTypeDirective: TsumSelectTypeDirective,
    ) {
        this.isChecked$ = this.isCheckedSubject$.asObservable();
    }

    @HostListener('click')
    public onClick(): void {
        if (!this.isDisabled && this.isMultiple) {
            this.isCheckedSubject$.next(!this.isCheckedSubject$.value);
        }
    }

    // переопределяет текущее состояние на действующее значение
    public resetValue(): void {
        this.isCheckedSubject$.next(this.tsumSelectOptionValueDirective.selected);
    }
}
