import {
    Component,
    ChangeDetectionStrategy,
} from '@angular/core';

/**
 * @description Колонка для таблицы
 * <table tsumTable>
 *   <tr tsumTableRow>
 *     <th tsumTableCellHead>Name</th>
 *     <th tsumTableCellHead>Surname</th>
 *   </tr>
 *   <tr tsumTableRow>
 *     <th tsumTableCell>Alex</th>
 *     <th tsumTableCell>Dadigin</th>
 *   </tr>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-table--as-native-table}
 */
@Component({
    selector: 'tr[tsumTableRow]',
    templateUrl: './tsum-table-row.component.html',
    styleUrls: ['./tsum-table-row.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumTableRowComponent {

}
