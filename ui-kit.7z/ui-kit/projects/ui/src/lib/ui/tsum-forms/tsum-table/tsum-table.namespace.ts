import { TemplateRef } from '@angular/core';

export namespace TsumTable {
    export interface Table {
        title: string;
        data: TableData;
        aspectRatios?: string[];
    }

    export interface TableData {
        headers: string[];
        columns: string[][];
    }

    /**
     * @description render means show value in cell
     * @description width might be in percent or pixels
     * @description sticky - left sticky, attach to left direction
     * @description rightSticky - right sticky, attach to right direction
     */
    export interface Column<T> {
        title: string;
        name?: keyof T;
        template?: TemplateRef<void>;
        render: (row: object) => string | number | boolean;
        width?: string;
        sticky?: boolean;
        rightSticky?: boolean;
    }

    export interface Pagination {
        currentPage: number;
        perPage: number;
        totalCount: number;
    }
}
