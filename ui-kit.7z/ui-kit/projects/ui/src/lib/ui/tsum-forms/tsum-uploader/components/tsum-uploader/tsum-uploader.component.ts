import {
    Component,
    ElementRef,
    EventEmitter,
    Input,
    Output,
    ChangeDetectionStrategy,
    forwardRef,
    ChangeDetectorRef,
    Host,
    Optional,
} from '@angular/core';
import {
    ValidationErrors,
    Validator,
    NG_VALIDATORS,
} from '@angular/forms';
import { Subject } from 'rxjs';

import { TsumUploader } from '../../tsum-uploader.namespace';
import { TsumDynamicBaseComponent } from '../../../../tsum-base/tsum-dynamic-base/tsum-dynamic-base.component';
import { TsumNotification } from '../../../../tsum-notifications/tsum-air-message/tsum-air-message.namespace';
import { TsumNotificationService } from '../../../../tsum-notifications/tsum-air-message/services/tsum-notification.service';
import { TsumClickOutsideDirective } from '../../../../tsum-utils/tsum-click-outside/tsum-click-outside.directive';

@Component({
    selector: 'tsum-uploader',
    templateUrl: './tsum-uploader.component.html',
    styleUrls: ['./tsum-uploader.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALIDATORS,
            useExisting: forwardRef(() => TsumUploaderComponent),
            multi: true,
        },
        TsumClickOutsideDirective,
    ],
})
export class TsumUploaderComponent extends TsumDynamicBaseComponent<TsumUploader.FileLoaded[]> implements Validator {
    @Input()
    public acceptFilesTypes: string[] = [];

    @Input()
    public sizeLimit: number = TsumUploader.DEFAULT_SIZE_LIMIT;

    @Input()
    public countLimit = TsumUploader.DEFAULT_COUNT_LIMIT;

    @Input('submited$')
    public set submited$(observable: Subject<void>) {
        if (observable) {
            observable.subscribe(() => this.submit());
        }
    }

    @Input()
    public dropzoneDescription: string = 'Перетащите файлы сюда<br> или воспользуйтесь <br> кнопкой «Выберите файл»';

    @Input()
    public visibleBtnControl = true;

    @Input()
    public set loadedFiles(value: TsumUploader.FileLoaded[]) {
        this.innerLoadedFiles = value;
        this.innerLoadedFiles = value.filter((file: TsumUploader.FileLoaded) => {
            const validType = !this.unacceptable(file.type);

            if (!validType) {
                this.sendNotification(
                    'error',
                    `${file.name} имеет неверное разрешение. Допустимы документы с разрешением ${this.acceptFilesTypes.join(',')}`
                );
            }

            return validType;
        });

        this.validate();
    }

    public get loadedFiles(): TsumUploader.FileLoaded[] {
        return this.innerLoadedFiles;
    }

    @Output('uploaded')
    uploaded$ = new EventEmitter<TsumUploader.FileLoaded[]>();

    public errors: TsumUploader.ErrorList;

    public idForm = new Date().getMilliseconds();

    private innerLoadedFiles: TsumUploader.FileLoaded[] = [];

    constructor(
        private tsumNotificationService: TsumNotificationService,
        public el: ElementRef,
        @Host() public tsumClickOutsideDirective: TsumClickOutsideDirective,
    ) {
        super(el, tsumClickOutsideDirective);
    }

    public loadFile(fileList: FileList): void {
        const unique = this.uniqueLoaded(Array.from(fileList));
        unique.forEach((file: File) => this.fileWrite(file));
    }

    public submit(): void {
        if (this.hasError()) {
            this.sendNotification('error', 'Добавлены невалидные документы.');

            return;
        }

        this.uploaded$.emit(this.loadedFiles);
        this.closeComponentSubject$.next(this.loadedFiles);
        this.loadedFiles = [];
    }

    public validate(): ValidationErrors | null {
        const isSizeError = this.isSizeLimit();
        const isCountError = this.loadedFiles.length >= this.countLimit;

        this.errors = {
            size: isSizeError ? `Добавленные документы превышают размер ${this.sizeLimit}mb` : null,
            count: isCountError ? `Можно добавить не более ${this.countLimit}` : null
        };

        return isSizeError || isCountError
            ? this.errors
            : null;
    }

    public hasError(): boolean {
        const isSizeError = this.isSizeLimit();
        const isCountError = this.loadedFiles.length > this.countLimit;

        return isSizeError || isCountError;
    }

    public disabled(): boolean {
        const isSizeError = this.getCombinedSize() / TsumUploader.ONE_MB >= this.sizeLimit;
        const isCountError = this.loadedFiles.length >= this.countLimit;

        return isSizeError || isCountError;
    }

    public detachedFile(indexFile: number): void {
        this.loadedFiles.splice(indexFile, 1);
        this.validate();
    }

    public close(): void {
        this.loadedFiles = [];
        this.closeComponentSubject$.next();
    }

    public getAcceptedFormat(): string {
        return this.acceptFilesTypes.map((type: string) => TsumUploader.DEFAULT_ACCEPT_TYPES[type.replace('.', '')]).join(',');
    }

    public sendNotification(type: TsumNotification.Type, title: string): void {
        this.tsumNotificationService.pushNotifications([
            {
                type,
                title,
                timeoutClose: TsumNotification.Timeout.Medium,
            },
        ]);
    }

    public onLoad(file: File, reader: FileReader): void {
        if (this.unacceptable(file.type)) {
            this.sendNotification('error', `Загружаемый документ должен быть формата ${this.acceptFilesTypes.join(',')}`);

            return;
        }

        this.loadedFiles.push({
            type: file.type,
            body: reader.result,
            name: file.name,
            size: file.size,
        });

        this.validate();
    }

    public fileWrite(file: File): void {
        const reader = new FileReader();

        reader.onerror = (err: ProgressEvent<FileReader>) => {
            this.sendNotification('error', 'Ошибка загрузки документов');
            throw new Error(`Ошибка чтения документа ${err}`);
        };
        reader.onabort = (error: ProgressEvent<FileReader>) => this.sendNotification('warning', 'Отмена загрузки документов');
        reader.onload = () => this.onLoad(file, reader);
        reader.readAsDataURL(file);
    }

    private uniqueLoaded(list: File[]): File[] {
        if (this.loadedFiles.length === 0) {
            return list;
        }

        return list.filter((file: File) => {
            return !Boolean(this.loadedFiles.find((loadedFile: TsumUploader.FileLoaded) => file.name === loadedFile.name));
        });
    }

    private isSizeLimit(): boolean {
        return this.getCombinedSize() / TsumUploader.ONE_MB > this.sizeLimit;
    }

    private getCombinedSize(): number {
        return this.loadedFiles.reduce((combineSize: number, current: TsumUploader.FileLoaded) => {
            return combineSize + current.size;
        }, 0);
    }

    private getType(type: string): string {
        return type.split('/')[1];
    }

    private unacceptable(type: string): boolean {
        return this.acceptFilesTypes.length > 0
            ? !this.acceptFilesTypes.includes(this.getType(type))
            : !TsumUploader.DEFAULT_ACCEPT_TYPES[this.getType(type)];
    }
}
