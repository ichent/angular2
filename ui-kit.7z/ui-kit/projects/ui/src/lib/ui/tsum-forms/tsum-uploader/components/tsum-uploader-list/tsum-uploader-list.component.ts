import { Component, Input, Output, EventEmitter } from '@angular/core';
import { TsumUploader } from '../../tsum-uploader.namespace';

@Component({
    selector: 'tsum-uploader-list',
    templateUrl: './tsum-uploader-list.component.html',
    styleUrls: ['./tsum-uploader-list.component.styl']
})
export class TsumUploaderListComponent {
    @Input()
    public loadedFiles: TsumUploader.FileLoaded[] = [];

    @Output()
    public detachedFile$ = new EventEmitter<number>();

    public detachFile(index: number): void {
        this.detachedFile$.next(index);
    }
}
