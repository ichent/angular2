import { Subject, combineLatest } from 'rxjs';
import {
    Component,
    ContentChild,
    AfterViewInit,
    OnDestroy,
    ViewContainerRef,
    Renderer2,
    ElementRef,
    ViewChild,
    HostBinding,
    Input,
} from '@angular/core';
import { NgControl } from '@angular/forms';
import { takeUntil, distinctUntilChanged } from 'rxjs/operators';
import { TsumInputComponent } from '../tsum-input/tsum-input.component';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * @description Its wrapper for tsumInput directive
 * @description Just wrap tsumInput directive component into <tsum-form-field>
 * @example <tsum-form-field class="w-320 mt-lg mb-lg d-block test">
 * @example <tsum-icon color="black" name="navigation-search" before></tsum-icon>
 * @example <input
 * @example [formControl]="form"
 * @example tsumInput
 * @example placeholder="Dynamic error message"
 * @example required />
 * @example <tsum-icon name="actions-close" after></tsum-icon>
 * @example </tsum-form-field>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-input--default}
 */
@Component({
    selector: 'tsum-form-field',
    templateUrl: './tsum-form-field.component.html',
    styleUrls: ['./tsum-form-field.component.styl'],
})
export class TsumFormFieldComponent implements AfterViewInit, OnDestroy {
    /** @description dragging state for input */
    @TsumInputBoolean()
    @Input()
    public dragging: boolean = false;

    @ContentChild(TsumInputComponent, { static: false }) public tsumInput: TsumInputComponent;

    @ViewChild('centerInput', { static: false }) public centerInput: ElementRef;
    @ViewChild('field', { static: false }) public formField: ElementRef;

    private destroyed$: Subject<void> = new Subject<void>();

    public get currentForm(): NgControl {
        return this.tsumInput.formControl;
    }

    public get isRequired(): boolean {
        return this.tsumInput.required && !this.tsumInput.disabled && !this.tsumInput.isTextArea();
    }

    constructor(
        public viewContainerRef: ViewContainerRef,
        public el: ElementRef,
        private renderer: Renderer2,
    ) {}

    public ngAfterViewInit(): void {
        if (!this.tsumInput) {
            throw Error('TsumInput directive is not added to input in tsum-form-field');
        }

        this.initInputHandlers();

        if (this.tsumInput.isTextArea()) {
            this.renderer.addClass(this.formField.nativeElement, 'tsum-form-field__textarea');
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private initInputHandlers(): void {
        this.tsumInput.onBlur$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => {
                this.tsumInput.inputActive = Boolean(this.tsumInput.inputValue) || this.tsumInput.inputValue === '0';
            });

        this.tsumInput.disabled$
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
            )
            .subscribe((disabled: boolean) => {
                this.tsumInput.inputDisabled = disabled;

                disabled
                    ? this.renderer.addClass(this.formField.nativeElement, 'tsum-form-field__disabled')
                    : this.renderer.removeClass(this.formField.nativeElement, 'tsum-form-field__disabled');
            });

        this.tsumInput.setActiveHandle$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((isActive: boolean) => {
                this.tsumInput.inputActive = isActive || this.tsumInput.inputValue === '0';

                isActive
                    ? this.tsumInput.el.nativeElement.setAttribute('active', '')
                    : this.tsumInput.el.nativeElement.removeAttribute('active');

                isActive
                    ? this.renderer.addClass(this.formField.nativeElement, 'tsum-form-field__active')
                    : this.renderer.removeClass(this.formField.nativeElement, 'tsum-form-field__active');
            });

        combineLatest([
            this.tsumInput.setInactiveHandle$,
            this.tsumInput.currentError$,
        ])
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
            )
            .subscribe(([isInvalid, error]: [boolean, string | boolean]) => {
                this.isShowError(isInvalid, error)
                    ? this.renderer.addClass(this.formField.nativeElement, 'tsum-form-field__error')
                    : this.renderer.removeClass(this.formField.nativeElement, 'tsum-form-field__error');

            });

        this.tsumInput.inputChange$
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
            )
            .subscribe((text: string | number) => {
                const isActiveElement = this.tsumInput.el.nativeElement === document.activeElement;

                this.tsumInput.inputActive = Boolean((text || text === '0' || text === 0) || isActiveElement);
            });

        this.tsumInput.fieldInited.next();
    }

    private isShowError(isInvalid: boolean, error: string | boolean): boolean {
        return isInvalid
            && !this.tsumInput.inputDisabled
            && error !== false
            && error !== null;
    }
}
