import {
    Directive,
    ElementRef,
    Input,
    OnChanges,
    SimpleChanges,
    ComponentRef,
    ViewContainerRef,
    Renderer2,
} from '@angular/core';
import { TsumGeneralHelper, TsumInputBoolean, TsumDynamicComponentsService } from '@tsum/utils';

import { TsumButtonLoaderComponent } from '../components/loader/tsum-button-loader.component';

/**
 * @description Helper directive to other buttons
 * @description just add "tsumLoaderButton" (and value) to set or remove loader in button
 * @description Able to any of TsumButton
 * @example <button tsumLabelButton [tsumLoaderButton]="true">Label button with loading</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--label}
 */
@Directive({
    selector: 'button[tsumLoaderButton], a[tsumLoaderButton], div[tsumLoaderButton]',
})
export class TsumLoaderButtonDirective implements OnChanges {
    /**
     * @description flag for loading button
     * @example [tsumLoaderButton]="true"
     */
    @TsumInputBoolean()
    @Input()
    public tsumLoaderButton: boolean;

    private loaderRef: ComponentRef<TsumButtonLoaderComponent>;

    constructor(
        private el: ElementRef,
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
        private viewContainer: ViewContainerRef,
        private renderer: Renderer2,
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes && changes.tsumLoaderButton) {
            this.toggleLoader(TsumGeneralHelper.isPropertyActive(changes.tsumLoaderButton.currentValue));
        }
    }

    private toggleLoader(isLoading: boolean): void {
        if (isLoading) {
            this.renderer.addClass(this.el.nativeElement, '_loading');

            this.loaderRef = this.tsumDynamicComponentsService.createChildComponent(TsumButtonLoaderComponent, this.viewContainer);

            this.initDiameterSize();

            this.toggleBackgroundColor(true);
        } else if (this.loaderRef) {
            this.toggleBackgroundColor(false);

            this.tsumDynamicComponentsService.deleteComponent(this.loaderRef);
            this.renderer.removeClass(this.el.nativeElement, '_loading');
        }
    }

    private toggleBackgroundColor(isLoading: boolean): void {
        if (this.el.nativeElement.attributes.tsumLabelbutton) {
            this.loaderRef.instance.setBackgroundColor(isLoading ? '#ffffff' : 'inherit');
        }
    }

    private initDiameterSize(): void {
        if (this.el.nativeElement.attributes.tsumSecondarySidepanelbutton) {
            this.loaderRef.instance.diameter = 14;
        } else if (this.el.nativeElement.attributes.tsumLabelbutton) {
            this.loaderRef.instance.diameter = 12;
        }
    }
}
