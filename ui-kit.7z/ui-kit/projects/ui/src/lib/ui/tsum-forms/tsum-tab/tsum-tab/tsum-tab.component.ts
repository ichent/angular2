import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    Input,
} from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { TsumTab } from '../tsum-tabs.namespace';

@Component({
    selector: 'tsum-tab',
    templateUrl: './tsum-tab.component.html',
    styleUrls: ['./tsum-tab.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumTabComponent<T = string | number | object> implements TsumTab.Tab<T> {

    @Input()
    public label: string;

    @Input()
    public badge: number;

    @Input()
    public width: number;

    @Input()
    public value: T;

    public get active(): boolean {
        return this.activeSubject$.value;
    }

    public set active(value: boolean) {
        this.activeSubject$.next(value);
        this.cd.detectChanges();
    }

    private activeSubject$ = new BehaviorSubject<boolean>(false);

    constructor(
        private cd: ChangeDetectorRef,
    ) {}
}
