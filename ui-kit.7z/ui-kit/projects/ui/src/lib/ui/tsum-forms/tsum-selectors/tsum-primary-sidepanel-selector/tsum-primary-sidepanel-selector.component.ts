import { Component, Input, ChangeDetectionStrategy, forwardRef, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { TsumPrimarySidepanelSelector } from './tsum-primary-sidepanel-selector.namespace';
import { FormControl, NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TsumSelect } from '../tsum-select.namespace';
import Option = TsumPrimarySidepanelSelector.Option;
import Value = TsumPrimarySidepanelSelector.Value;

/**
 * Primary sidepanel button selector
 * Позволяет работать с данной кнопкой как селектором, принимает все те же опции что и обычная кнопка
 * Список инпутов
 * options - Список опций в селекторе
 * countColumns - Количество колонок, по умолчанию 1
 * type - тип селектора, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-primary-sidepanel-selector type="multiple" [options]="options" [formControl]="form"></tsum-primary-sidepanel-selector>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-selector--as-primary-sidepanel-button}
 */
@Component({
    selector: 'tsum-primary-sidepanel-selector',
    templateUrl: './tsum-primary-sidepanel-selector.component.html',
    styleUrls: ['./tsum-primary-sidepanel-selector.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TsumPrimarySidepanelSelectorComponent),
            multi: true,
        },
    ],
})
export class TsumPrimarySidepanelSelectorComponent implements ControlValueAccessor, OnDestroy {

    @Input()
    public options: Option[];

    @Input()
    public countColumns = 1;

    @Input()
    public type: TsumSelect.SelectType = 'radioArray';

    public form = new FormControl();

    private destroyed$ = new Subject<void>();

    constructor(
        private changeDetectorRef: ChangeDetectorRef,
    ) {
        this.form.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((selected: Value) => {
                this.onChange(selected);

                if (!this.changeDetectorRef['destroyed']) {
                    this.changeDetectorRef.detectChanges();
                }

            });
    }

    public writeValue(value: Value): void {
        if (!value) {
            return;
        }

        this.form.setValue(value);
    }

    public registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public isActive(option: Option): boolean {
        const value: Value = this.form.value;

        return Array.isArray(value)
            ? value.includes(option.key)
            : value === option.key;
    }

    public isGrid(): boolean {
        return this.countColumns !== 1;
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onChange = (value: Value) => {};
    private onTouched = () => {};
}
