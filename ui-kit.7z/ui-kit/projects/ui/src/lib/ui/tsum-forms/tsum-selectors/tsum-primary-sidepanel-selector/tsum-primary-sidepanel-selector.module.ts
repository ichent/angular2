import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { TsumPrimarySidepanelSelectorComponent } from './tsum-primary-sidepanel-selector.component';
import { TsumSelectorModule } from '../tsum-selector.module';
import { TsumButtonModule } from '../../tsum-button/tsum-button.module';
import { TsumCssPropertyModule } from '../../../tsum-utils/tsum-css-property/tsum-css-property.module';
import { TsumTextOverflowTooltipModule } from '../../../tsum-utils/tsum-text-overflow-tooltip/tsum-text-overflow-tooltip.module';

const COMPONENTS = [
    TsumPrimarySidepanelSelectorComponent,
];

/**
 * Primary sidepanel button selector
 * Позволяет работать с данной кнопкой как селектором, принимает все те же опции что и обычная кнопка
 * Список инпутов
 * options - Список опций в селекторе
 * countColumns - Количество колонок, по умолчанию 1
 * type - тип селектора, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-primary-sidepanel-selector type="multiple" [options]="options" [formControl]="form"></tsum-primary-sidepanel-selector>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-selector--as-primary-sidepanel-button}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TsumSelectorModule,
        TsumButtonModule,
        TsumCssPropertyModule,
        TsumTextOverflowTooltipModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumPrimarySidepanelSelectorModule { }
