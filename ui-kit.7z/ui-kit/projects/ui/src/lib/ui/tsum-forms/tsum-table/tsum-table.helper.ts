type StickyDirection = 'sticky' | 'rightSticky';

export function tsumTableInitSticky(element: HTMLElement): void {
    setTimeout(() => {
        if (element.classList.contains('_sticky')) {
            tsumTableInitStickyStyles('sticky', element);
        }

        if (element.classList.contains('_right-sticky')) {
            tsumTableInitStickyStyles('rightSticky', element);
        }
    });
}

export function tsumTableInitStickyStyles(direction: StickyDirection, element: HTMLElement): void {
    const classDirection = direction === 'sticky' ? '_sticky' : '_right-sticky';

    if (!element.classList.contains(classDirection)) {
        return;
    }

    const prevElement = element.previousSibling as HTMLElement;
    const nextElement = element.nextSibling as HTMLElement;
    const isNeedSetPosition = direction === 'sticky'
        ? prevElement && prevElement.classList?.contains(classDirection)
        : nextElement && nextElement.classList?.contains(classDirection);

    if (isNeedSetPosition) {
        const position = getPositionByDirection(direction, prevElement, nextElement);

        element.style[direction === 'sticky' ? 'left' : 'right'] = `${position}px`;
    }

    const isNeedShadow = direction === 'sticky'
        ? !nextElement || !nextElement?.classList?.contains(classDirection)
        : !prevElement || !prevElement?.classList?.contains(classDirection);

    if (isNeedShadow) {
        element.classList.add(direction === 'sticky' ? '_with-shadow' : '_with-left-shadow');
    }
}

function getPositionByDirection(direction: StickyDirection, prevElement: HTMLElement, nextElement: HTMLElement): number {
    return direction === 'sticky'
        ? prevElement.offsetWidth + parseInt(window.getComputedStyle(prevElement).left.replace('px', ''), 10)
        : nextElement.offsetWidth + parseInt(window.getComputedStyle(nextElement).right.replace('px', ''), 10);
}
