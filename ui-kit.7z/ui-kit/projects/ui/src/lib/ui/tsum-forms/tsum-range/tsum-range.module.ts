import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumRangeComponent } from './tsum-range.component';
import { TsumInputModule } from '../tsum-input/tsum-input.module';

const COMPONENTS = [
    TsumRangeComponent,
];

/**
 * @description Range/interval component
 * @description Uses for make interval of values and if one of interval is incorrect show error
 * @description Range has default compare function(which compare from/to value in range)
 * @description By default: date/numeric
 * @description Also you can send custom compare function, just send input 'compareFunction'
 * @description This 'compareFunction' returns ValidationErrors, and has arguments 'from/to form control'
 * @example <tsum-range
 * @example   type="date"
 * @example   errorText="Неверная дата">
 * @example   <tsum-form-field rangeFrom>
 * @example     <input
 * @example       tsumInput
 * @example       formControlName="dateFrom"
 * @example       activePlaceholder="Введите дату от"
 * @example       placeholder="_ _ / _ _ / _ _" />
 * @example   </tsum-form-field>
 * @example   <tsum-form-field rangeTo>
 * @example     <input
 * @example       tsumInput
 * @example       formControlName="dateTo"
 * @example       activePlaceholder="Введите дату до"
 * @example       placeholder="_ _ / _ _ / _ _" />
 * @example   </tsum-form-field>
 * @example </tsum-range>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-range-interval--default}
 */
@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
        TsumInputModule,
    ],
})
export class TsumRangeModule { }
