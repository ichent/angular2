export interface CheckboxGroupList {
    title: string;
    value: string | number | object;
    disabled?: boolean;
}
