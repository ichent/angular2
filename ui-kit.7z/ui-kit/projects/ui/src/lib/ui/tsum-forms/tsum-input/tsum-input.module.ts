import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumInputComponent } from './components/tsum-input/tsum-input.component';
import { TsumFormFieldComponent } from './components/tsum-form-field/tsum-form-field.component';
import { TsumInputActivePlaceholderDirective } from './tsum-input-active-placeholder.directive';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumIndicatorModule } from '../../tsum-utils/tsum-indicator/tsum-indicator.module';
import { TsumPlaceholderComponent } from './components/tsum-placeholder/tsum-placeholder.component';

const DIRECTIVES = [
    TsumInputActivePlaceholderDirective,
];

const COMPONENTS = [
    TsumFormFieldComponent,
    TsumInputComponent,
    TsumPlaceholderComponent,
];

/**
 * @description Its wrapper for tsumInput directive
 * @description Just wrap tsumInput directive component into <tsum-form-field>
 * @example <tsum-form-field class="w-320 mt-lg mb-lg d-block test">
 * @example <tsum-icon color="black" name="navigation-search" before></tsum-icon>
 * @example <input
 * @example [formControl]="form"
 * @example tsumInput
 * @example placeholder="Dynamic error message"
 * @example required />
 * @example <tsum-icon name="actions-close" after></tsum-icon>
 * @example </tsum-form-field>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-input--default}
 */
@NgModule({
    declarations: [
        DIRECTIVES,
        COMPONENTS,
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        TsumIconsModule,
        TsumIndicatorModule,
    ],
    exports: [
        DIRECTIVES,
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
    providers: [
        TsumDynamicComponentsService,
    ],
})
export class TsumInputModule {
}
