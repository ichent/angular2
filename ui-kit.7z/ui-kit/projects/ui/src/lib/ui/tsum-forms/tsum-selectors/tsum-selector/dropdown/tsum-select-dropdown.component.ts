import {
    AfterViewInit,
    ChangeDetectionStrategy,
    Component,
    EventEmitter,
    HostBinding,
    Input,
    Output,
    TemplateRef,
} from '@angular/core';
import { TsumSelectDropdown } from './tsum-select-dropdown.namespace';

@Component({
    selector: 'tsum-select-dropdown',
    templateUrl: './tsum-select-dropdown.component.html',
    styleUrls: ['./tsum-select-dropdown.component.styl'],
    host: {
        '[class._top]': 'position === \'top\'',
        '[class._bottom]': 'position === \'bottom\'',
    },
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumSelectDropdownComponent implements AfterViewInit {

    @Input()
    public multiple = false;

    @HostBinding('class._highest')
    @Input()
    public highest: boolean;

    @HostBinding('style.top.px')
    @Input()
    public top = 0;

    @HostBinding('style.left.px')
    @Input()
    public left = 0;

    @HostBinding('style.width.px')
    @Input()
    public width = 0;

    @Input()
    public position: TsumSelectDropdown.Position;

    @Input()
    public contentTemplate: TemplateRef<void>;

    @Output('apply')
    public apply$ = new EventEmitter<void>();

    @Output('cancel')
    public cancel$ = new EventEmitter<void>();

    @Output('render')
    public render$ = new EventEmitter<void>();

    public ngAfterViewInit(): void {
        this.render$.emit();
    }

    public apply(event: Event): void {
        event.stopPropagation();
        this.apply$.emit();
    }

    public cancel(event: Event): void {
        event.stopPropagation();
        this.cancel$.emit();
    }

}
