import { TsumIndicator } from '../../tsum-utils/tsum-indicator/tsum-indicator.namespace';

export namespace TsumButton {
    export interface CircleIndicator {
        type: TsumIndicator.Type;
        description?: string;
    }

    export type State = 'active' | 'inactive';

    export type ActionType = 'select-all' | 'expander' | 'more' | 'in-more' | 'delete' | 'add' | 'edit';

    /** Список действий в кнопке/рубрикаторе */
    export interface Action {
        id: string;
        callback: () => void;
        state?: State;
        type: ActionType;
        title?: string;
        icon?: string;
        size?: number;
    }
}
