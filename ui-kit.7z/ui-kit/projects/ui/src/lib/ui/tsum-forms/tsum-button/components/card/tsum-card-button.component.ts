import {
    Component,
    ChangeDetectionStrategy,
    HostBinding,
    Input,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * @description Card button, usually uses with cards
 * @description have "active" and "disabled" state
 * @description Insert tsum-icon component for showing icon
 * @example <button tsumCardButton><tsum-icon name="actions-close"></tsum-icon></button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--card}
 */
@Component({
    selector: 'button[tsumCardButton], a[tsumCardButton], div[tsumCardButton]',
    templateUrl: './tsum-card-button.component.html',
    styleUrls: ['../tsum-button-base.styl', './tsum-card-button.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumCardButtonComponent {
    /**
     * @description flag for active state button
     * @example [active]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._active')
    @Input()
    public active: boolean;

    /**
     * @description flag for disabled state button
     * @example [disabled]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._disabled')
    @Input()
    public disabled: boolean;
}
