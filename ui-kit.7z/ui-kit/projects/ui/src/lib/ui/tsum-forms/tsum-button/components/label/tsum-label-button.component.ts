import {
    Component,
    ChangeDetectionStrategy,
    HostBinding,
    Input,
    ContentChild,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';
import { TsumButtonLoaderComponent } from '../loader/tsum-button-loader.component';

/**
 * @description Label button, which no have background
 * @description have "warning"/"active"/"small"/"link" state
 * @example <button tsumLabelButton>Label button</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--label}
 */
@Component({
    selector: 'button[tsumLabelButton], a[tsumLabelButton], div[tsumLabelButton]',
    templateUrl: './tsum-label-button.component.html',
    styleUrls: ['../tsum-button-base.styl', './tsum-label-button.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumLabelButtonComponent {
    /**
     * @description Input
     * @description flag for warning state
     * @example
     * [warning]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._warning')
    @Input()
    public warning: boolean;

    /**
     * @description Input
     * @description flag for active state
     * @example
     * [active]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._active')
    @Input()
    public active: boolean;

    /**
     * @description Input
     * @description flag for small state
     * @example
     * [small]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._small')
    @Input()
    public small: boolean;

    @ContentChild(TsumButtonLoaderComponent)
    public tsumButtonLoaderComponent;
}
