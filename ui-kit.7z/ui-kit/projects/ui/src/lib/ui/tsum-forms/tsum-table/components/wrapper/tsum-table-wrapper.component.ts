import {
    Component,
    ChangeDetectionStrategy,
    ElementRef,
    OnDestroy,
    AfterViewInit,
    NgZone,
    Input,
    ViewChildren,
    ContentChildren,
    QueryList,
} from '@angular/core';
import { Observable, Subject, BehaviorSubject, merge, fromEvent } from 'rxjs';
import { takeUntil, tap, map, switchMap, startWith, filter } from 'rxjs/operators';
import { TsumUserAgentService } from '@tsum/utils';
import { TsumTableRowComponent } from './../row/tsum-table-row.component';

/**
 * @description Колонка для таблицы
 * <table tsumTable>
 *   <tr tsumTableRow>
 *     <th tsumTableHead>Name</th>
 *     <th tsumTableHead>Surname</th>
 *   </tr>
 *   <tr tsumTableRow>
 *     <th tsumTableCell>Alex</th>
 *     <th tsumTableCell>Dadigin</th>
 *   </tr>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-table--as-native-table}
 */
@Component({
    selector: 'table[tsumTable]',
    templateUrl: './tsum-table-wrapper.component.html',
    styleUrls: ['./tsum-table-wrapper.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumTableWrapperComponent implements OnDestroy, AfterViewInit {
    @Input()
    public scrollableElement: HTMLElement;

    @ContentChildren(TsumTableRowComponent, { descendants: true })
    public rows: QueryList<TsumTableRowComponent>;

    private destroyed$ = new Subject<void>();

    constructor(
        private elementRef: ElementRef,
        private ngZone: NgZone,
        private tsumUserAgentService: TsumUserAgentService,
    ) {}

    public ngAfterViewInit(): void {
        setTimeout(() => {
            const element: HTMLElement = this.elementRef.nativeElement;

            if (element.offsetWidth > this.getParentElement().offsetWidth) {
                this.ngZone.runOutsideAngular(() => {
                    this.rows.changes
                        .pipe(
                            startWith([null, null]),
                            filter((changes: QueryList<TsumTableRowComponent>) => changes.length > 1),
                            takeUntil(this.destroyed$),
                            switchMap(() =>
                                merge<WheelEvent>(...this.cellElementsToWheelEvents$()),
                            ),
                        )
                        .subscribe((mouseEvent: WheelEvent) => {
                            const scrollWrapper: HTMLElement = this.getParentElement();

                            /**
                             * В windows обычно крутят колесо вниз и контент уходит вниз
                             * В нашем случае контент должен уходить вправо при кручении колеса вниз
                             * Для Мака ситуация инвертируется
                             */
                            if (this.tsumUserAgentService.os.isMacOs()) {
                                requestAnimationFrame(() => {
                                    scrollWrapper.scrollLeft += mouseEvent.deltaY;
                                });
                            } else {
                                requestAnimationFrame(() => {
                                    scrollWrapper.scrollLeft -= Math.sign(mouseEvent.deltaY) * 20;
                                });
                            }

                            mouseEvent.preventDefault();
                        });
                });
            }
        });
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private getParentElement(): HTMLElement {
        const element: HTMLElement = this.elementRef.nativeElement;

        let parent: HTMLElement = element.parentElement;

        /** Обработка для tsum-scroll */
        if (element.parentElement.classList.contains('content-wrapper')) {
            parent = parent.parentElement;
        }

        /** Переопределяем родителя, если передали элемент, который необходимо скролить */
        if (this.scrollableElement) {
            parent = this.scrollableElement;
        }

        return parent;
    }

    private cellElementsToWheelEvents$(): Observable<WheelEvent>[] {
        const rows: HTMLTableRowElement[] = this.elementRef.nativeElement.rows;
        const notStickyCells = [];

        rows.forEach((row: HTMLTableRowElement) => {
            const cells: HTMLTableCellElement[] = row.cells as any;

            cells.forEach((cell: HTMLTableCellElement) => {
                if (cell.getAttribute('sticky') === null && cell.getAttribute('rightSticky') === null) {
                    notStickyCells.push(cell);
                }
            });
        });

        return notStickyCells
            .map((cell: HTMLTableCellElement) =>
                fromEvent<WheelEvent>(cell, 'mousewheel')
                    .pipe(
                        takeUntil(this.destroyed$),
                    ),
            );
    }
}
