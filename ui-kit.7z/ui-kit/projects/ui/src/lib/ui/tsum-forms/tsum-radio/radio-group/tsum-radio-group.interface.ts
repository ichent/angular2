export interface TsumRadioGroupOption<T> {
    title: string;
    value: T;
    disabled?: boolean;
}
