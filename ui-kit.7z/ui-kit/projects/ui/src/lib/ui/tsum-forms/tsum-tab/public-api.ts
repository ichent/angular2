export * from './tsum-tab.module';
export * from './tsum-tabs.component';
export * from './tsum-tabs.namespace';
export * from './tsum-tab/index';
export * from './tsum-tab-badge/index';
