import {
    Component,
    ChangeDetectionStrategy,
    ElementRef,
    Renderer2,
    OnInit,
    Input,
    ComponentRef,
    ViewContainerRef,
    SimpleChanges,
    OnChanges,
    OnDestroy,
    Output,
    EventEmitter,
} from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { distinctUntilChanged, tap, map, takeUntil, filter } from 'rxjs/operators';
import { TsumInputBoolean, TsumGeneralHelper, TsumDynamicComponentsService } from '@tsum/utils';

import { TsumButton } from '../../tsum-button.namespace';
import { TsumIncludeIndicatorComponent } from '../../../../tsum-utils/tsum-include-indicator/tsum-include-indicator.component';
import { TsumButtonColorIndicatorComponent } from '../../modules/tsum-button-color-indicator/tsum-button-color-indicator.component';
import { TsumButtonActionsComponent } from '../../modules/tsum-button-actions/tsum-button-actions.component';

/**
 * @description Primary sidepanel button
 * @example <button tsumPrimarySidepanelButton>Primary sidepanel button</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--primary-sidepanel}
 */
@Component({
    selector: 'button[tsumPrimarySidepanelButton], a[tsumPrimarySidepanelButton]',
    templateUrl: './tsum-primary-sidepanel-button.component.html',
    styleUrls: ['../tsum-button-base.styl', './tsum-primary-sidepanel-button.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class.button-label-white-sp]': 'true',
    },
})
export class TsumPrimarySidepanelButtonComponent implements OnInit, OnChanges, OnDestroy {
    @Input()
    public indicators: TsumButton.CircleIndicator[] = [];

    @Input()
    public includeIndicator: boolean = false;

    @Input()
    public isExpanded: boolean = false;

    @Input()
    public isAdditionalStyles: boolean = true;

    @TsumInputBoolean()
    @Input() public active = false;

    @Input() public actions: TsumButton.Action[] = [];

    @TsumInputBoolean()
    @Input() public dragable = false;

    @Output('inMoreClicked') public inMoreClicked$ = new EventEmitter<string>();

    public includeIndicatorRef: ComponentRef<TsumIncludeIndicatorComponent>;
    public indicatorsRef: ComponentRef<TsumButtonColorIndicatorComponent>;
    public actionsRef: ComponentRef<TsumButtonActionsComponent>;

    private activeSubject$ = new BehaviorSubject<boolean>(false);
    private actionsSubject$ = new BehaviorSubject<TsumButton.Action[]>([]);
    private includeIndicatorSubject$ = new BehaviorSubject<boolean>(false);
    private destroyed$ = new Subject<void>();

    public get active$(): Observable<boolean> {
        return this.activeSubject$.asObservable().pipe(
            distinctUntilChanged(),
            tap((isActive: boolean) => {
                TsumGeneralHelper.isPropertyActive(isActive)
                    ? this.renderer.addClass(this.el.nativeElement, '_active')
                    : this.renderer.removeClass(this.el.nativeElement, '_active');
            })
        );
    }

    public get actions$(): Observable<TsumButton.Action[]> {
        return this.actionsSubject$.asObservable().pipe(
            distinctUntilChanged(),
            filter(Boolean),
            tap((actions: TsumButton.Action[]) => this.initActionsComponent(actions)),
            map((actions: TsumButton.Action[]) => actions.filter((action: TsumButton.Action) => action.type !== 'in-more')),
            tap((actions: TsumButton.Action[]) => {
                if (this.isAdditionalStyles) {
                    this.el.nativeElement.style.paddingRight = `${((actions.length * 48) + 16).toString()}px`;
                }
            })
        );
    }

    public get includeIndicator$(): Observable<boolean> {
        return this.includeIndicatorSubject$.asObservable()
            .pipe(
                distinctUntilChanged(),
                tap((includeIndicator: boolean) => {
                    includeIndicator
                        ? this.initIncludeIndicator()
                        : this.destroyIncludeIndicator();
                }),
            );
    }

    constructor(
        private el: ElementRef,
        private renderer: Renderer2,
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
        private viewContainer: ViewContainerRef,
    ) {
        this.active$.pipe(takeUntil(this.destroyed$)).subscribe();
        this.includeIndicator$.pipe(takeUntil(this.destroyed$)).subscribe();
        this.actions$.pipe(takeUntil(this.destroyed$)).subscribe();
    }

    public ngOnInit(): void {
        if (this.isAdditionalStyles) {
            this.renderer.setStyle(this.el.nativeElement, 'position', 'relative');
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes && changes.includeIndicator) {
            this.includeIndicatorSubject$.next(changes.includeIndicator.currentValue);
        }

        if (changes && changes.indicators) {
            if (!this.indicatorsRef) {
                this.indicatorsRef = this.tsumDynamicComponentsService.createChildComponent(
                    TsumButtonColorIndicatorComponent,
                    this.viewContainer,
                );
            }

            this.indicatorsRef.instance.setIndicators(changes.indicators.currentValue);
        }

        if (changes && changes.active) {
            this.activeSubject$.next(changes.active.currentValue);
        }

        if (changes && changes.actions) {
            this.actionsSubject$.next(changes.actions.currentValue);
        }

        if (changes && changes.isExpanded && this.actionsRef) {
            this.actionsRef.instance.isExpanded = changes.isExpanded.currentValue;

            this.actionsRef.instance.changeDetectorRef.detectChanges();
        }
    }

    public ngOnDestroy(): void {
        if (this.indicatorsRef) {
            this.indicatorsRef.destroy();
        }

        if (this.includeIndicatorRef) {
            this.destroyIncludeIndicator();
        }

        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private initActionsComponent(actions: TsumButton.Action[] = []): void {
        // Create component and update actions
        if (actions.length > 0) {
            if (!this.actionsRef) {
                this.actionsRef = this.tsumDynamicComponentsService.createChildComponent(
                    TsumButtonActionsComponent,
                    this.viewContainer,
                );

                this.actionsRef.instance.dragable = this.dragable;
            }

            this.actionsRef.instance.setActions(actions);

            this.actionsRef.instance.inMoreClicked$
                .pipe(
                    takeUntil(this.destroyed$),
                )
                .subscribe((id: string) => this.inMoreClicked$.next(id));
        } else if (actions.length === 0 && this.actionsRef) { // Destroy component
            this.tsumDynamicComponentsService.deleteComponent(this.actionsRef);

            this.actionsRef = undefined;
        }
    }

    private initIncludeIndicator(): void {
        if (this.includeIndicator) {
            this.includeIndicatorRef = this.tsumDynamicComponentsService.createChildComponent(
                TsumIncludeIndicatorComponent,
                this.viewContainer,
            );
        }
    }

    private destroyIncludeIndicator(): void {
        if (this.includeIndicatorRef) {
            this.tsumDynamicComponentsService.deleteComponent(this.includeIndicatorRef);

            this.includeIndicatorRef = undefined;
        }
    }

    private destroyIndicator(): void {
        if (this.indicatorsRef) {
            this.tsumDynamicComponentsService.deleteComponent(this.indicatorsRef);

            this.indicatorsRef = undefined;
        }
    }
}
