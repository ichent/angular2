import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumTabBadgeComponent } from './tsum-tab-badge/tsum-tab-badge.component';
import { TsumSelectorModule } from '../tsum-selectors/tsum-selector.module';
import { TsumTabsComponent } from './tsum-tabs.component';
import { TsumTabComponent } from './tsum-tab/tsum-tab.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const COMPONENTS = [
    TsumTabComponent,
    TsumTabsComponent,
    TsumTabBadgeComponent,
];

/**
 * @description Dynamic tabs component
 * @example For work with tabs insert component <tsum-tabs></tsum-tabs>
 * @example After add <tsum-tab></tsum-tab> component with content
 * @description You can pass form control to tabs and set activity from form
 * @description and can subscribe to changes
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-tabs--default}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TsumSelectorModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
        TsumSelectorModule,
    ],
})
export class TsumTabModule {}
