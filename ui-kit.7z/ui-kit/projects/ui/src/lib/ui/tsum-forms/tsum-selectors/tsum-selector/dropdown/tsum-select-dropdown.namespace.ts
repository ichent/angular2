export namespace TsumSelectDropdown {
    export enum Position {
        Top = 'top',
        Bottom = 'bottom',
    }
}
