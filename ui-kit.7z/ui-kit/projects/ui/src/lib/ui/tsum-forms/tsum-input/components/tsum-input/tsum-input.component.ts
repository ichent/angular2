import {
    Component,
    HostBinding,
    OnInit,
    ElementRef,
    Input,
    ViewContainerRef,
    ComponentRef,
    OnDestroy,
    OnChanges,
    SimpleChanges,
    Output,
    EventEmitter,
    AfterViewInit,
    ChangeDetectorRef,
    Optional,
    ChangeDetectionStrategy,
} from '@angular/core';
import { NgControl } from '@angular/forms';
import { BehaviorSubject, Observable, Subject, fromEvent } from 'rxjs';
import { map, takeUntil, distinctUntilChanged, tap, switchMap, shareReplay } from 'rxjs/operators';
import { TsumInputBoolean, TsumDynamicComponentsService } from '@tsum/utils';

import { TsumPlaceholderComponent } from '../tsum-placeholder/tsum-placeholder.component';
import { INVALID_STATUS, DISABLED_STATUS } from '../../../../tsum-base/constants/form-status.constant';

/**
 * @description Input directive, uses only on input and textarea tags
 * @description Based on default input, you can use all things of base input, like (keypress)/(blur) etc
 * @description IMPORTANT tsumInput uses only with <tsum-form-field> component
 * @description Has variety of options
 * @description placeholder - default placeholder, when focus on input placeholder blow up top top position
 * @description activePlaceholder - Means change placeholder text to activePlaceholder text when input is on focus or has value
 * @description disabled - disabled state for input, make readonly input and show gray background
 * @description tsumInputDirtyCheck - Flag for check or not check dirty state form, when show error, by default false
 * @description and When false, error show after typing on this input only, when true error show right now
 * @description tsumInputTouchedCheck - Same as tsumInputDirtyCheck, but instead dirty check in form it touched form state
 * @description keepPlaceholderPosition - When has this input, placeholder will not blow up to to
 * @description tsumInputError - Error for input, send text, when you wanna output error. But Error shows only when form is invalid
 * @description Also you can just add input tsumInputError without value and input show error without text.
 * @description It will add red border and red placeholder
 * @description stretch - state for stretching input, width to 100%
 * @example <tsum-form-field class="w-320 mt-lg mb-lg d-block test">
 * @example <tsum-icon color="black" name="navigation-search" before></tsum-icon>
 * @example <input
 * @example [formControl]="form"
 * @example tsumInput
 * @example placeholder="Dynamic error message"
 * @example required />
 * @example <tsum-icon name="actions-close" after></tsum-icon>
 * @example </tsum-form-field>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-input--default}
 */
@Component({
    selector: 'input[tsumInput], textarea[tsumInput]',
    templateUrl: './tsum-input.component.html',
    styleUrls: ['./tsum-input.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumInputComponent implements OnInit, OnDestroy, OnChanges, AfterViewInit {
    /** @description Placeholder text, pass string, this change placeholder component text */
    @Input() public set placeholder(placeholder: string) {
        this.innerPlaceholder = placeholder;

        if (this.isKeepPlaceholderPosition() || !this.placeholderComponentRef) {
            this.el.nativeElement.placeholder = placeholder;

            return;
        }

        this.placeholderComponentRef.instance.text = placeholder;

        if (!this.cd['destroyed']) {
            this.cd.detectChanges();
        }
    }

    public get placeholder(): string {
        return this.innerPlaceholder;
    }

    /** @description disabled state for input, make readonly input and show gray background */
    @TsumInputBoolean()
    @Input()
    public disabled: boolean;

    /** @description required state for input, make indicator */
    @TsumInputBoolean()
    @Input()
    public required: boolean = false;

    /**
     * @description flag for check or not check dirty state form, when show error, by default false
     * @description and When false, error show after typing on this input only, when true error show right now
     */
    @TsumInputBoolean()
    @Input()
    public tsumInputDirtyCheck: boolean = true;

    /** @description flag for readonly state */
    @TsumInputBoolean()
    @Input()
    public readonly: boolean = false;

    /** @description Same as tsumInputDirtyCheck, but instead dirty check in form it touched form state */
    @TsumInputBoolean()
    @Input()
    public tsumInputTouchedCheck: boolean = false;

    /**
     * @description When has this input, placeholder will not blow up to to
     */
    @HostBinding('class._keep-placeholder')
    @TsumInputBoolean()
    @Input()
    public keepPlaceholderPosition: boolean = false;

    /**
     * @description Error for input, send text, when you wanna output error. But Error shows only when form is invalid
     * @description Also you can just add input tsumInputError without value and input show error without text.
     * @description It will add red border and red placeholder
     */
    @Input()
    public tsumInputError: string | boolean = null;

    /**
     * @description state for stretching input, width to 100%
     */
    @TsumInputBoolean()
    @HostBinding('class._stretch')
    @Input()
    public stretch: boolean | string;

    @HostBinding('class._textarea')
    public get textAreaClass(): boolean {
        return this.isKeepPlaceholderPosition();
    }

    /** @event handleEnter emit when type enter in keyboard */
    @Output('handleEnter')
    public handleEnter$: EventEmitter<KeyboardEvent> = new EventEmitter();

    public fieldInited = new EventEmitter<void>();

    private setActiveHandleSubject$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    private setInactiveHandleSubject$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    private currentErrorSubject$: BehaviorSubject<string | boolean> = new BehaviorSubject<string>(null);
    private formInitSubject$: BehaviorSubject<void> = new BehaviorSubject<void>(null);
    private destroyed$: Subject<void> = new Subject<void>();
    private innerPlaceholder: string = '';
    private prevStatus: string;
    private onBlurSubject$: Subject<void> = new Subject<void>();
    private onFocusSubject$: Subject<void> = new Subject<void>();
    private disabledSubject$: Subject<boolean> = new Subject<boolean>();
    private placeholderComponentRef: ComponentRef<TsumPlaceholderComponent> = null;
    private textAreaTag: string = 'TEXTAREA';

    public get tagName(): string {
        return this.el.nativeElement.tagName;
    }

    public get placeholderText(): string {
        return this.isKeepPlaceholderPosition() || !this.placeholderComponentRef
            ? this.el.nativeElement.placeholder
            : this.placeholderComponentRef.instance.text;
    }

    public set placeholderText(text: string) {
        if (this.isKeepPlaceholderPosition() || !this.placeholderComponentRef) {
            this.el.nativeElement.placeholder = text;

            return;
        }

        this.placeholderComponentRef.instance.text = text;
    }

    public get currentError(): string | boolean {
        return this.currentErrorSubject$.getValue();
    }

    public set currentError(errorText: string | boolean) {
        this.currentErrorSubject$.next(errorText);
    }

    public get currentError$(): Observable<string | boolean> {
        return this.currentErrorSubject$.asObservable();
    }

    public get dirtyInput(): boolean {
        return this.el.nativeElement.classList.contains('ng-dirty');
    }

    public get canShowError(): boolean {
        return Boolean((this.dirtyInput || !this.tsumInputDirtyCheck) && !this.tsumInputTouchedCheck)
            || Boolean(this.inputTouched && this.tsumInputTouchedCheck);
    }

    public get formInvalid(): boolean {
        return this.formControl
            ? this.canShowError && (!this.formControl.valid || Boolean(this.formControl.errors))
            : this.el.nativeElement.getAttribute('invalid') !== undefined && this.el.nativeElement.getAttribute('invalid') !== null;
    }

    public set formInvalid(isInvalid: boolean) {
        const invalidStatus = isInvalid && this.canShowError;

        this.setInactiveHandleSubject$.next(invalidStatus);

        invalidStatus
            ? this.el.nativeElement.setAttribute('invalid', '')
            : this.el.nativeElement.removeAttribute('invalid');
    }

    public get formClearInvalid(): boolean {
        return this.formControl
            ? !this.formControl.valid
            : this.el.nativeElement.getAttribute('invalid') !== undefined && this.el.nativeElement.getAttribute('invalid') !== null;
    }

    public set formClearInvalid(isInvalid: boolean) {
        const invalidStatus = isInvalid;

        this.setInactiveHandleSubject$.next(invalidStatus);

        invalidStatus
            ? this.el.nativeElement.setAttribute('invalid', '')
            : this.el.nativeElement.removeAttribute('invalid');
    }

    public get inputValue(): string {
        return this.formControl
            ? this.formControl.value || this.el.nativeElement.value
            : this.el.nativeElement.value;
    }

    public get inputTouched(): boolean {
        return this.el.nativeElement.classList.contains('ng-touched');
    }

    public get inputActive(): boolean {
        return this.el.nativeElement.getAttribute('active') === '';
    }

    public set inputActive(touched: boolean) {
        this.setActiveHandleSubject$.next(touched);

        if (this.placeholderComponentRef) {
            this.placeholderComponentRef.instance.togglePlaceholder(touched);
        }
    }

    public get inputDisabled(): boolean {
        return (this.el.nativeElement.disabled || false)
            || (this.el.nativeElement.getAttribute('disabled') !== undefined
            && this.el.nativeElement.getAttribute('disabled') !== null);
    }

    public set inputDisabled(disabled: boolean) {
        if (this.formControl) {
            if (!disabled) {
                this.formControl.control.enable();

                return;
            }

            disabled || this.formControl.disabled
                ? this.formControl.control.disable()
                : this.formControl.control.enable();
        } else {
            disabled
                ? this.el.nativeElement.setAttribute('disabled', '')
                : this.el.nativeElement.removeAttribute('disabled');
        }
    }

    public get focused(): boolean {
        return this.el.nativeElement.getAttribute('focused') !== undefined
            && this.el.nativeElement.getAttribute('focused') !== null;
    }

    public set focused(isFocused: boolean) {
        isFocused
            ? this.el.nativeElement.setAttribute('focused', '')
            : this.el.nativeElement.removeAttribute('focused');
    }

    public get inputChange$(): Observable<any> {
        return this.formInitSubject$
            .pipe(
                switchMap(() => {
                    return (this.formControl
                        ? this.formControl.valueChanges
                        : fromEvent(this.el.nativeElement, 'keyup')
                            .pipe(
                                takeUntil(this.destroyed$),
                                map(() => this.el.nativeElement.value)
                            ))
                        .pipe(
                            distinctUntilChanged(),
                            tap(() => {
                                this.inputChangeInit();
                            })
                        );
                }),
            );
    }

    public get formValue(): string {
        return this.formControl
            ? this.formControl.control.value
            : this.el.nativeElement.value;
    }

    public set formValue(value: string) {
        this.formControl.control.setValue(value, { emitEvent: false });
        this.el.nativeElement.value = value;
    }

    public get onBlur$(): Observable<void> {
        return this.onBlurSubject$.asObservable()
            .pipe(
                tap(() => this.focused = false),
            );
    }

    public get onFocus$(): Observable<void> {
        return this.onFocusSubject$.asObservable();
    }

    public get disabled$(): Observable<boolean> {
        return this.disabledSubject$.asObservable()
            .pipe(
                shareReplay(1),
            );
    }

    public get setInactiveHandle$(): Observable<boolean> {
        return this.setInactiveHandleSubject$.asObservable();
    }

    public get setActiveHandle$(): Observable<boolean> {
        return this.setActiveHandleSubject$.pipe(distinctUntilChanged());
    }

    constructor(
        public el: ElementRef,
        public cd: ChangeDetectorRef,
        @Optional() public formControl: NgControl,
        private viewContainer: ViewContainerRef,
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
    ) { }

    public ngOnInit(): void {
        if (this.tsumInputDirtyCheck === false) {
            this.formInvalid = true;
        }

        if (this.formControl
            && this.formValue !== null
            && this.formValue !== undefined
            && this.formValue !== ''
            && (!Array.isArray(this.formValue) || Array.isArray(this.formValue) && this.formValue.length > 0)
        ) {
            setTimeout(() => {
                this.inputActive = true;

                if (!this.cd['destroyed']) {
                    this.cd.detectChanges();
                }
            });
        }

        this.onFocus$
            .pipe(
                takeUntil(this.destroyed$),
                tap(() => this.focused = true),
            )
            .subscribe();

        this.el.nativeElement.onfocus = () => {
            if (!this.readonly) {
                this.onFocusSubject$.next();

                this.setActiveHandleSubject$.next(true);
            }
        };

        this.el.nativeElement.onblur = () => {
            this.onBlurSubject$.next();

            this.initTouched();
        };

        this.el.nativeElement.onkeypress = (event: KeyboardEvent) => this.onKeyPress(event);

        if (!this.isKeepPlaceholderPosition()) {
            this.initPlaceholderComponent();
        }

        this.fieldInited
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => {
                if (this.disabled !== undefined) {
                    this.disabledSubject$.next(this.disabled);
                }
            });
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.disabled) {
            this.disabledSubject$.next(changes.disabled.currentValue);
        }

        if (changes.tsumInputError) {
            this.currentError = changes.tsumInputError.currentValue;
            this.setNeededPlaceholder();
        }
    }

    public ngAfterViewInit(): void {
        if (this.formControl && this.formControl.control.disabled) {
            this.initFormState();
        }

        if (this.formControl) {
            this.formControl.statusChanges
                .pipe(
                    takeUntil(this.destroyed$),
                    distinctUntilChanged(),
                )
                .subscribe((status: string) => {
                    this.initFormState(status);
                });
        }

        this.formInitSubject$.next();
        this.setNeededPlaceholder();

        if (!this.cd['destroyed']) {
            this.cd.detectChanges();
        }
    }

    public onKeyPress(event: KeyboardEvent): void {
        if (event.key === 'Enter') {
            this.handleEnter$.emit(event);
        }
    }

    public isTextArea(): boolean {
        return this.tagName === this.textAreaTag;
    }

    public setNeededPlaceholder(): void {
        this.placeholderText = this.isShowErrorPlaceholder() ? this.currentError as string : this.placeholder;
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();

        this.tsumDynamicComponentsService.deleteComponent(this.placeholderComponentRef);
    }

    private isShowErrorPlaceholder(): boolean {
        return Boolean(this.currentError)
            && typeof this.currentError !== 'boolean'
            && typeof this.currentError === 'string'
            && this.formInvalid;
    }

    private initFormState(status: string = this.formControl.control.status): void {
        if (status === DISABLED_STATUS) {
            this.disabledSubject$.next(true);
        } else if (this.inputDisabled && (this.prevStatus === DISABLED_STATUS || this.prevStatus === INVALID_STATUS)) {
            this.disabledSubject$.next(false);
        }

        this.formInvalid = status === INVALID_STATUS;

        this.prevStatus = this.formControl.control.status;
    }

    private initTouched(): void {
        if (typeof this.inputValue === 'string' && this.inputValue.length === 0 && this.tsumInputTouchedCheck) {
            this.initFormState();
        }

        if (!this.cd['destroyed']) {
            this.cd.detectChanges();
        }
    }

    private inputChangeInit(): void {
        if (!this.formControl) {
            return;
        }

        if (this.inputValue.length === 0 && this.tsumInputTouchedCheck) {
            this.initTouched();
        }

        if (this.prevStatus !== this.formControl.control.status) {
            this.setNeededPlaceholder();
        }

        if (this.inputValue.length > 0) {
            this.formInvalid = this.formControl.control.status === INVALID_STATUS;
        }
    }

    private isKeepPlaceholderPosition(): boolean {
        return this.isTextArea() || this.keepPlaceholderPosition;
    }

    private initPlaceholderComponent(): void {
        this.placeholderComponentRef = this.tsumDynamicComponentsService.createComponent(
            TsumPlaceholderComponent,
            { viewContainer: this.viewContainer },
        );

        this.placeholderComponentRef.instance.clicked
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => {
                this.el.nativeElement.focus();
            });
    }
}
