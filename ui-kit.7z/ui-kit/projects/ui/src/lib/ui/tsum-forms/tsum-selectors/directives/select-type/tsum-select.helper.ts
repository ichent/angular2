import { fromEvent, merge, Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { isEqual as _isEqual } from 'lodash';
import { TsumSelect } from '../../tsum-select.namespace';
import { TsumSelectOptionValueDirective } from './tsum-select-option-value.directive';

export namespace TsumSelectHelper {

    import ClickToOptionEvent = TsumSelect.ClickToOptionEvent;
    import SelectType = TsumSelect.SelectType;
    import OptionValueType = TsumSelect.OptionValueType;
    import SelectOptionData = TsumSelect.SelectOptionData;
    import SelectOption = TsumSelect.SelectOption;
    import SelectValuesEvent = TsumSelect.SelectValuesEvent;
    import ValueSelectionResult = TsumSelect.ValueSelectionResult;

    /**
     * Основаная функция выбора значения в селекторе
     *
     * @param selectType - тип селектора
     * @param selectValuesEvent - событие выбора значения
     * @param optionDataList - данные опций селектора
     * @param controlValue - текущее сохраненное значение в контролле
     */
    export function processValueSelection(
        selectType: SelectType,
        selectValuesEvent: SelectValuesEvent,
        optionDataList: SelectOption[],
        controlValue: OptionValueType | OptionValueType[],
    ): ValueSelectionResult {
        const resultValue: OptionValueType | OptionValueType[] = processValueByEvent(
            selectType,
            selectValuesEvent,
            optionDataList,
            controlValue,
        );

        return {
            resultValue,
            isNeedChangeControlValue: isNeedChangeControlValue(selectValuesEvent, resultValue),
        };
    }

    /**
     * Выбор в зависимости от события выбора значения и типа селектора
     *
     * @param selectType - тип селектора
     * @param selectEvent - событие выбора значения
     * @param optionDataList - данные опций селектора
     * @param controlValue - текущее сохраненное значение в контролле
     */
    export function processValueByEvent(
        selectType: SelectType,
        selectEvent: SelectValuesEvent,
        optionDataList: SelectOption[],
        controlValue: OptionValueType | OptionValueType[],
    ): OptionValueType | OptionValueType[] {
        if (selectEvent.eventType === 'set' || selectEvent.eventType === 'writeValue') {
            return TsumSelectHelper.setValueByType(
                selectType,
                optionDataList,
                TsumSelectHelper.optionValueToArray(selectEvent.newValue),
            );
        } else if (selectEvent.eventType === 'select') {
            return TsumSelectHelper.selectValueByType(
                selectType,
                optionDataList,
                TsumSelectHelper.optionValueToArray(controlValue),
                TsumSelectHelper.optionValueToSingle(selectEvent.newValue),
            );
        }
    }

    /**
     * Выбор значения в зависимости от типа селектора
     *
     * @param selectType - тип селектора размеров
     * @param currentOptions - текущее состояние опций селектора
     * @param selectedValues - выбранные значения в селекторе
     * @param newValue - новое выбранное значение
     */
    export function selectValueByType(
        selectType: SelectType,
        currentOptions: SelectOption[],
        selectedValues: OptionValueType[],
        newValue: OptionValueType,
    ): OptionValueType[] | OptionValueType {
        switch (selectType) {
            case 'multiple':
                return selectMultipleValue(selectedValues, newValue);
            case 'single':
                return selectSingleValue(selectedValues, newValue);
            case 'singleArray':
                return selectSingleArrayValue(selectedValues, newValue);
            case 'radio':
                return selectRadioValue(selectedValues, currentOptions, newValue);
            case 'radioArray':
                return selectRadioArrayValue(selectedValues, currentOptions, newValue);
            default:
                return null;
        }
    }

    /**
     * Проверка нужно ли эмитить значение
     *
     * При установке начального значения в formControl извне (writeValue) пропускаем эмит этого изменения наверх
     * т.к. это значение уже сохранено в formControl.
     *
     * Если устанавливается значение в formControl через setValue (writeValue),
     * оно всё равно будет заэмичено в соответствующем контроле (без участия директивы селектора),
     * поэтому этот эмит работает по общему правилу с установкой начального значения и пропускается.
     *
     * Данный подход позволяет избежать двойных эмитов при смене значения через setValue.
     * А также использовать setValue({ emitEvent: false }), для отмены эмита при смене значения.
     *
     * Если, конечно, это значение не было изменено в процессе преобразования нового значения.
     * Например, при автовыборе начального значения в radio селекте или при установке примитива в multiple селект.
     * В таком случае эмит будет.
     *
     * @param selectValuesEvent - событие выбора значения
     * @param resultValue - выбранное значение, после всех преобразований
     */
    export function isNeedChangeControlValue(
        selectValuesEvent: SelectValuesEvent,
        resultValue: OptionValueType | OptionValueType[],
    ): boolean {
        return selectValuesEvent.eventType !== 'writeValue' || !_isEqual(selectValuesEvent.newValue, resultValue);
    }

    export function selectMultipleValue(selectedValues: OptionValueType[], newValue: OptionValueType): OptionValueType[] {
        return toggleSelectedValue(selectedValues, newValue);
    }

    export function selectSingleValue(selectedValues: OptionValueType[], newValue: OptionValueType): OptionValueType {
        const isAlreadySelected: boolean = selectedValues.some((selectedValue: OptionValueType) => _isEqual(selectedValue, newValue));
        const value: OptionValueType = isAlreadySelected ? null : newValue;

        return value === undefined ? null : value;
    }

    export function selectSingleArrayValue(selectedValues: OptionValueType[], newValue: OptionValueType): OptionValueType[] {
        const selectedSingleValue: OptionValueType = selectSingleValue(selectedValues, newValue);
        return selectedSingleValue != null ? [ selectedSingleValue ] : [];
    }

    export function selectRadioValue(
        selectedValues: OptionValueType[],
        currentOptions: SelectOption[],
        newValue: OptionValueType,
    ): OptionValueType {
        const availableOptions: SelectOption[] = toAvailableOptions(currentOptions);
        const selectedValue: OptionValueType = selectedValues?.[0] === undefined ? null : selectedValues[0];

        // Если доступных опций нет - ничего не делаем. Оставляем предыдущее значение и ждём появления опций.
        if (availableOptions?.length === 0) {
            return selectedValue;
        }

        // Если среди доступных опций есть новое выбранное значение, то применяем его
        if (availableOptions.some((option: SelectOption) => _isEqual(option?.value, newValue))) {
            return newValue;
        }

        // Если среди доступных опций есть предыдущее значение, то применяем его
        if (availableOptions.some((option: SelectOption) => _isEqual(option?.value, selectedValue))) {
            return selectedValue;
        }

        // Иначе устанавливаем первое значение как значение по умолчанию
        // т.к. в радио режиме всегда должна быть выбрана одна из доступных опций
        return availableOptions[0].value;
    }

    export function selectRadioArrayValue(
        selectedValues: OptionValueType[],
        currentOptions: SelectOption[],
        newValue: OptionValueType,
    ): OptionValueType[] {
        const selectedRadioValue: OptionValueType = selectRadioValue(selectedValues, currentOptions, newValue);
        return selectedRadioValue != null ? [ selectedRadioValue ] : [];
    }

    /**
     * Установка значения в селекторе размера в зависимости от типа селектора
     *
     * @param selectType - тип селектора размеров
     * @param currentOptions - текущее состояние опций селектора
     * @param newValues - новое значение для селектора
     */
    export function setValueByType(
        selectType: SelectType,
        currentOptions: SelectOption[],
        newValues: OptionValueType[],
    ): OptionValueType[] | OptionValueType {
        switch (selectType) {
            case 'multiple':
                return setMultipleValue(newValues);
            case 'single':
                return setSingleValue(newValues);
            case 'singleArray':
                return setSingleArrayValue(newValues);
            case 'radio':
                return setRadioValue(newValues, currentOptions);
            case 'radioArray':
                return setRadioArrayValue(newValues, currentOptions);
            default:
                return null;
        }
    }

    export function setMultipleValue(values: OptionValueType[]): OptionValueType[] {
        return Array.isArray(values) ? values : [];
    }

    export function setSingleValue(values: OptionValueType[] | OptionValueType): OptionValueType {
        return optionValueToSingle(values);
    }

    export function setSingleArrayValue(values: OptionValueType[]): OptionValueType[] {
        const firstValue: OptionValueType = values?.[0];
        return firstValue != undefined ? [ firstValue ] : [];
    }

    export function setRadioValue(values: OptionValueType[], currentOptions: SelectOption[]): OptionValueType {
        const availableOptions: SelectOption[] = toAvailableOptions(currentOptions);
        let firstAvailableValue: OptionValueType;

        if (Array.isArray(values) && values.length > 0) {
            firstAvailableValue = values
                .find((value: OptionValueType) => availableOptions
                    .some((option: SelectOption) => _isEqual(option.value, value))
                );
        }

        let resultValue: OptionValueType = null;

        if (firstAvailableValue != undefined) {
            resultValue = firstAvailableValue;
        } else if (availableOptions[0]?.value != undefined) {
            resultValue = availableOptions[0].value;
        }

        return selectRadioValue(
            values,
            currentOptions,
            resultValue
        );
    }

    export function setRadioArrayValue(values: OptionValueType[], currentOptions: SelectOption[]): OptionValueType[] {
        const selectedValue: OptionValueType = setRadioValue(values, currentOptions);
        return selectedValue != undefined ? [ selectedValue ] : [];
    }

    function toAvailableOptions(currentOptions: SelectOption[]): SelectOption[] {
        return currentOptions ? currentOptions.filter((option: SelectOption) => !option?.disabled) : [];
    }

    function toggleSelectedValue(
        selectedValue: OptionValueType[],
        newValue: OptionValueType | OptionValueType[],
    ): OptionValueType[] {
        const values: OptionValueType[] = [ ...selectedValue ];
        const valueIndex: number = values.findIndex((value: OptionValueType) => _isEqual(value, newValue));

        if (valueIndex > -1) {
            values.splice(valueIndex, 1);
        } else {
            if (newValue !== null) {
                values.push(newValue);
            }
        }

        return values;
    }

    /**
     * Генерация событие клика по опциям
     * @param optionValueDirectives$ - текущий список опций
     */
    export function switchMapToClickToOptionEvent(
        optionValueDirectives$: Observable<TsumSelectOptionValueDirective[]>,
    ): Observable<ClickToOptionEvent> {
        return optionValueDirectives$
            .pipe(
                switchMap((optionValueDirectives: TsumSelectOptionValueDirective[]) =>
                    merge<ClickToOptionEvent>(...optionValueDirectivesToClickEvents(optionValueDirectives)),
                ),
            );
    }

    function optionValueDirectivesToClickEvents(
        optionValueDirectives: TsumSelectOptionValueDirective[],
    ): Observable<ClickToOptionEvent>[] {
        return optionValueDirectives
            .map((optionValueDirective: TsumSelectOptionValueDirective) =>
                fromEvent(optionValueDirective.el.nativeElement, 'click')
                    .pipe(
                        map((event: MouseEvent) => ({
                            option: toSelectOptionData(optionValueDirective),
                            mouseEvent: event,
                        })),
                    ),
            );
    }

    export function optionValueToArray(optionValue: OptionValueType | OptionValueType[]): OptionValueType[] {
        if (optionValue == undefined) {
            return [];
        }

        return Array.isArray(optionValue) ? optionValue : [ optionValue ];
    }

    export function optionValueToSingle(optionValue: OptionValueType | OptionValueType[]): OptionValueType {
        const value: OptionValueType = Array.isArray(optionValue) ? optionValue[0] : optionValue;

        return value === undefined ? null : value;
    }

    export function toSelectOptionData(optionValueDirective: TsumSelectOptionValueDirective): SelectOptionData {
        return {
            value: optionValueDirective.value,
            disabled: optionValueDirective.disabled,
            selected: optionValueDirective.selected,
        };
    }

    export function toSelectOptionsData(optionValueDirectives: TsumSelectOptionValueDirective[]): SelectOptionData[] {
        return Array.isArray(optionValueDirectives) && optionValueDirectives.length > 0
            ? optionValueDirectives.map(toSelectOptionData)
            : [];
    }

}
