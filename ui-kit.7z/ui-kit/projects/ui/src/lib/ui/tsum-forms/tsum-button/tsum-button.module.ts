import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumSpinnerModule } from '../../tsum-common/tsum-spinner/tsum-spinner.module';
import { TsumLoaderButtonDirective } from './directives/tsum-loader-button.directive';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumStretchButtonDirective } from './directives/tsum-stretch-button.directive';
import { TsumButtonActionsModule } from '../tsum-button/modules/tsum-button-actions/tsum-button-actions.module';
import { TsumElementWrapperModule } from '../../tsum-utils/tsum-element-wrapper/tsum-element-wrapper.module';
import { TsumPrimaryButtonComponent } from './components/primary/tsum-primary-button.component';
import { TsumSecondaryButtonComponent } from './components/secondary/tsum-secondary-button.component';
import { TsumLabelButtonComponent } from './components/label/tsum-label-button.component';
import { TsumSecondarySidepanelButtonComponent } from './components/secondary-sidepanel/tsum-secondary-sidepanel-button.component';
import { TsumSquareButtonComponent } from './components/square/tsum-square-button.component';
import { TsumPrimarySidepanelButtonComponent } from './components/primary-sidepanel/tsum-primary-sidepanel-button.component';
import { TsumButtonLoaderComponent } from './components/loader/tsum-button-loader.component';
import { TsumLinkButtonComponent } from './components/link/tsum-link-button.component';
import { TsumButtonColorIndicatorModule } from './modules/tsum-button-color-indicator/tsum-button-color-indicator.module';
import { TsumIncludeIndicatorModule } from '../../tsum-utils/tsum-include-indicator/tsum-include-indicator.module';
import { TsumCardButtonComponent } from './components/card/tsum-card-button.component';

const DIRECTIVES = [
    TsumLoaderButtonDirective,
    TsumStretchButtonDirective,
];

const COMPONENTS = [
    TsumPrimaryButtonComponent,
    TsumSecondaryButtonComponent,
    TsumLabelButtonComponent,
    TsumSecondarySidepanelButtonComponent,
    TsumSquareButtonComponent,
    TsumPrimarySidepanelButtonComponent,
    TsumButtonLoaderComponent,
    TsumLinkButtonComponent,
    TsumCardButtonComponent,
];

/**
 * @description Buttons component
 * @description Have variety of buttons:
 * @example <button tsumLabelButton>Label button</button>
 * @example <button tsumLabelButton tsumLoaderButton>Label loader button</button>
 * @example <button tsumPrimaryButton>Primary button</button>
 * @example <button tsumSecondaryButton>Secondary button</button>
 * @example <button tsumPrimarySidepanelButton>Primary sidepanel button</button>
 * @example <button tsumSecondarySidepanelButton>Secondary sidepanel button</button>
 * @example <button tsumSquareButton>Label button</button>
 * @example <button tsumLabelButton stretch>Label stretch button</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--label}
 */
@NgModule({
    declarations: [
        DIRECTIVES,
        COMPONENTS,
    ],
    imports: [
        CommonModule,
        TsumSpinnerModule,
        TsumIconsModule,
        TsumButtonActionsModule,
        TsumElementWrapperModule,
        TsumButtonColorIndicatorModule,
        TsumIncludeIndicatorModule,
    ],
    exports: [
        DIRECTIVES,
        COMPONENTS,
    ],
    entryComponents: [
        TsumButtonLoaderComponent,
    ],
    providers: [
        TsumDynamicComponentsService,
    ],
})
export class TsumButtonModule {
}
