import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

import { TsumIcon } from '../../../../tsum-utils/tsum-icons/tsum-icon.namespace';
import { TsumUploader } from '../../tsum-uploader.namespace';


@Component({
    selector: 'tsum-uploader-errors',
    templateUrl: './tsum-uploader-errors.component.html',
    styleUrls: ['./tsum-uploader-errors.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumUploaderErrorsComponent {
    @Input()
    public set errors(value: TsumUploader.ErrorList) {
        this.errorList = Object.keys(value).reduce((errorList: TsumUploader.Error[], currentKey: string) => {
            errorList.push({ error: currentKey, message: value[currentKey] });

            return errorList;
        }, []);
    }

    public iconColors = TsumIcon.Color;

    public errorList: TsumUploader.Error[] = [];

}
