import {
    Directive,
    Input,
    HostBinding,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * @description Helper for stretch button, for all TsumButtons
 * @description just insert "stretch" into button
 * @example <button tsumLabelButton stretch>Label button</button>
 */
@Directive({
    selector: 'button[stretch], a[stretch]',
})
export class TsumStretchButtonDirective {
    /**
     * @description flag for stretch button
     * @example [stretch]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._stretch')
    @Input()
    public stretch: boolean;
}
