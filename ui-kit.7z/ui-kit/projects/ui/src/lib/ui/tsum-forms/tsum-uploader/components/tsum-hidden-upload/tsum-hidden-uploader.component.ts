import {
    Component,
    ChangeDetectionStrategy,
    forwardRef,
    ChangeDetectorRef,
    Host,
    ViewChild,
    ElementRef,
} from '@angular/core';

import {
    NG_VALIDATORS,
} from '@angular/forms';

import { TsumNotificationService } from '../../../../tsum-notifications/tsum-air-message/services/tsum-notification.service';
import { TsumClickOutsideDirective } from '../../../../tsum-utils/tsum-click-outside/tsum-click-outside.directive';
import { TsumUploaderComponent } from '../tsum-uploader/tsum-uploader.component';

@Component({
    selector: 'tsum-hidden-uploader',
    templateUrl: './tsum-hidden-uploader.component.html',
    styleUrls: ['./tsum-hidden-uploader.component.styl'],
    providers: [
        {
            provide: NG_VALIDATORS,
            useExisting: forwardRef(() => TsumHiddenUploaderComponent),
            multi: true,
        },
        TsumClickOutsideDirective,
    ],
    changeDetection: ChangeDetectionStrategy.OnPush,

})
export class TsumHiddenUploaderComponent extends TsumUploaderComponent  {
    @ViewChild('hiddenInput', { static: true })
    public hiddenInputElement: ElementRef;

    constructor(
        tsumNotificationService: TsumNotificationService,
        el: ElementRef,
        @Host() tsumClickOutsideDirective: TsumClickOutsideDirective,
    ) {
        super(tsumNotificationService, el, tsumClickOutsideDirective);
    }

    public fileWrite(file: File): void {
        const reader = new FileReader();

        reader.onerror = (err: ProgressEvent<FileReader>) => {
            this.sendNotification('error', 'Ошибка загрузки документов');
            throw new Error(`Ошибка чтения документа ${err}`);
        };
        reader.onabort = (error: ProgressEvent<FileReader>) => this.sendNotification('warning', 'Отмена загрузки документов');
        reader.onload = () => {
            this.onLoad(file, reader);
            this.submit();
        };
        reader.readAsDataURL(file);
    }
}
