import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumSafeModule } from '@tsum/utils';
import { TsumUploaderComponent } from './components/tsum-uploader/tsum-uploader.component';
import { TsumButtonModule } from '../tsum-button/tsum-button.module';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumUploaderErrorsComponent } from './components/tsum-uploader-errors/tsum-uploader-errors.component';
import { TsumUploaderDirective } from './directives/tsum-uploader.directive';
import { TsumDropPlaceDirective } from './directives/tsum-drop-place.directive';
import { TsumUploaderListComponent } from './components/tsum-uploader-list/tsum-uploader-list.component';
import { TsumUploaderSimpleDirective } from './directives/tsum-uploader-simple.directive';
import { TsumHiddenUploaderComponent } from './components/tsum-hidden-upload/tsum-hidden-uploader.component';

const COMPONENTS = [
    TsumHiddenUploaderComponent,
    TsumUploaderComponent,
    TsumUploaderErrorsComponent,
    TsumUploaderListComponent,
];

const DIRECTIVES = [
    TsumDropPlaceDirective,
    TsumUploaderDirective,
    TsumUploaderSimpleDirective,
];

@NgModule({
    imports: [
        CommonModule,
        TsumButtonModule,
        TsumIconsModule,
        TsumSafeModule,
    ],
    declarations: [
        COMPONENTS,
        DIRECTIVES,
    ],
    exports: [
        COMPONENTS,
        DIRECTIVES,
    ],
    entryComponents: [
        COMPONENTS,
    ],
    providers: [],
})
export class TsumUploaderModule { }
