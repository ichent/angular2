import {
    Component,
    Input,
    ElementRef,
    ViewChild,
    ChangeDetectorRef,
    ChangeDetectionStrategy,
    EventEmitter,
    HostListener,
} from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { TsumDelayDecorator } from '@tsum/utils';

@Component({
    selector: 'tsum-placeholder',
    templateUrl: './tsum-placeholder.component.html',
    styleUrls: ['./tsum-placeholder.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumPlaceholderComponent {
    @Input() public set text(text: string) {
        this.innerText = text;

        if (!this.cd['destroyed']) {
            this.cd.detectChanges();
        }
    }

    public get text(): string {
        return this.innerText;
    }

    @ViewChild('placeholder', { static: false })
    public placeholder: ElementRef;

    public clicked = new EventEmitter<void>();

    private innerText: string = '';

    private wasActiveSubject$ = new BehaviorSubject<boolean>(false);

    constructor(
        public el: ElementRef,
        private cd: ChangeDetectorRef,
    ) {}

    @HostListener('click')
    public onClicked(): void {
        if (!this.wasActiveSubject$.getValue()) {
            this.clicked.emit();
        }
    }

    @TsumDelayDecorator(1)
    public togglePlaceholder(isActive: boolean): void {
        /**
         * В виду того что у нас на клик в placeholder происходит focus инпута, делаем отложенную установку активности
         * и проверяем её по клику. Это необходимо потому что toggle активности происходит моментально
         */
        setTimeout(() => this.wasActiveSubject$.next(isActive), 200);

        isActive
            ? this.placeholder.nativeElement.classList.add('tsum-placeholder_active')
            : this.placeholder.nativeElement.classList.remove('tsum-placeholder_active');
    }
}
