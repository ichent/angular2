import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumSelectorModule } from '../tsum-selector.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxGroupComponent } from './tsum-checkbox-group.component';
import { TsumCheckboxModule } from '../../tsum-checkbox/tsum-checkbox.module';

const COMPONENTS = [
    CheckboxGroupComponent,
];

/**
 * Группа чекбоксов
 * Принимает инпут list, в котором передаем массив key value
 * Далее берем форму и подписываемся на изменения
 * @example <tsum-checkbox-group [list]="list" [form]="form">test checkbox</tsum-checkbox-group>
 * More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-checkbox--checkbox-group}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TsumSelectorModule,
        TsumCheckboxModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumCheckboxGroupModule { }
