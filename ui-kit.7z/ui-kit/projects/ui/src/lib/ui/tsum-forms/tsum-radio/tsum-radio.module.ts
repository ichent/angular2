import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TsumRadioComponent } from './radio/tsum-radio.component';
import { TsumRadioGroupComponent } from './radio-group/tsum-radio-group.component';
import { TsumSelectorModule } from '../tsum-selectors/tsum-selector.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

const COMPONENTS = [
    TsumRadioComponent,
    TsumRadioGroupComponent,
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        TsumSelectorModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumRadioModule {
}
