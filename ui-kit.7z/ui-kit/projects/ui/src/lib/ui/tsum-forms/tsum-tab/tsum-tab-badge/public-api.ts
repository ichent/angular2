export * from './tsum-tab-badge.component';
