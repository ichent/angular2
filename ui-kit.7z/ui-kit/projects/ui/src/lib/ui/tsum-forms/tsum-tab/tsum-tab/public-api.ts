export * from './tsum-tab.component';
