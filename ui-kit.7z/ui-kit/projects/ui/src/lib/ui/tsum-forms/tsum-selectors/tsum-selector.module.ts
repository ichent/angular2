import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { TsumButtonModule } from '../tsum-button/tsum-button.module';
import { TsumCheckboxModule } from '../tsum-checkbox/tsum-checkbox.module';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumClickOutsideModule } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumWordEndingsModule } from '../../tsum-utils/tsum-word-endings/tsum-word-endings.module';
import { TsumIndicatorModule } from '../../tsum-utils/tsum-indicator/tsum-indicator.module';
import { TsumTagModule } from '../../tsum-notifications/tsum-tag/tsum-tag.module';
import { TsumTextOverflowTooltipModule } from '../../tsum-utils/tsum-text-overflow-tooltip/tsum-text-overflow-tooltip.module';
import { TsumScrollModule } from '../../tsum-common/tsum-scroll/tsum-scroll.module';
import { TsumCssPropertyModule } from '../../tsum-utils/tsum-css-property/tsum-css-property.module';
import { TsumSelectTypeDirective } from './directives/select-type/tsum-select-type.directive';
import { TsumSelectOptionValueDirective } from './directives/select-type/tsum-select-option-value.directive';
import { TsumIntersectionModule } from '../../tsum-utils/tsum-intersection/tsum-intersection.module';
import { TsumSelectDropdownComponent } from './tsum-selector/dropdown/tsum-select-dropdown.component';
import { TsumSelectComponent } from './tsum-selector/select/tsum-select.component';
import { TsumSelectOptionComponent } from './tsum-selector/select-option/tsum-select-option.component';

const COMPONENTS = [
    TsumSelectDropdownComponent,
    TsumSelectComponent,
    TsumSelectOptionComponent,
];

const DIRECTIVES = [
    TsumSelectTypeDirective,
    TsumSelectOptionValueDirective,
];

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        TsumIconsModule,
        TsumButtonModule,
        TsumCheckboxModule,
        TsumClickOutsideModule,
        TsumWordEndingsModule,
        TsumIndicatorModule,
        TsumTagModule,
        TsumTextOverflowTooltipModule,
        TsumScrollModule,
        TsumCssPropertyModule,
        TsumIntersectionModule,
    ],
    declarations: [
        COMPONENTS,
        DIRECTIVES,
    ],
    exports: [
        COMPONENTS,
        DIRECTIVES,
    ],
    entryComponents: [
        TsumSelectDropdownComponent,
    ],
})
export class TsumSelectorModule {
}
