import {
    Component,
    ChangeDetectionStrategy,
    Input,
} from '@angular/core';

/**
 * @description This component uses in under tsum-tabs component
 * @description This component render badges in top right corner, send count
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-tabs--default}
 */
@Component({
    selector: 'tsum-tab-badge',
    templateUrl: './tsum-tab-badge.component.html',
    styleUrls: ['./tsum-tab-badge.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumTabBadgeComponent {
    /**
     * @description Input
     * @description Counter for tab badge
     * @example
     * [counter]="6"
     */
    @Input()
    public counter: number;
}
