export namespace TsumSelect {

    export type SelectType = 'single' | 'singleArray' | 'multiple' | 'radio' | 'radioArray';

    export type OptionValueType = string | number | object;

    export interface ClickToOptionEvent {
        option: SelectOptionData;
        mouseEvent: MouseEvent;
    }

    // Расширенный интерфейс опции, после выбора значений
    export interface SelectOptionData extends SelectOption {
        selected: boolean;
    }

    // Базовый интерфейс опции для логики выбора
    export interface SelectOption {
        value: OptionValueType;
        disabled: boolean;
    }

    /**
     * set - замена текущих значений на новые (Public API)
     * select - тоггл значения (Public API)
     * writeValue - событие при сохранении данных через fromControl (начальное значение в контроле и setValue)
     */
    export type SelectValuesEventType = 'set' | 'select' | 'writeValue';

    export interface SelectValuesEvent {
        newValue: OptionValueType[] | OptionValueType;
        eventType: SelectValuesEventType;
    }

    export interface ValueSelectionResult {
        resultValue: OptionValueType | OptionValueType[]; // Итоговое выбранное значение в контроле и директиве
        isNeedChangeControlValue: boolean; // Нужно ли эмитить изменения значения во внешний fromControl
    }

    export const activeClassName = 'active';

    export const disabledClassName = 'disabled';

}
