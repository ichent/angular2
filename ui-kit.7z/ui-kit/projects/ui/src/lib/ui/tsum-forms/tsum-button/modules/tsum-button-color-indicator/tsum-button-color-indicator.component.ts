import { Component, ChangeDetectionStrategy, ElementRef, ChangeDetectorRef } from '@angular/core';
import { TsumButton } from '../../tsum-button.namespace';
import { BehaviorSubject, Observable } from 'rxjs';

@Component({
    selector: 'tsum-button-color-indicator',
    templateUrl: './tsum-button-color-indicator.component.html',
    styleUrls: ['./tsum-button-color-indicator.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumButtonColorIndicatorComponent {
    private indicatorsSubject$ = new BehaviorSubject<TsumButton.CircleIndicator[]>([]);

    public get indicators$(): Observable<TsumButton.CircleIndicator[]> {
        return this.indicatorsSubject$.asObservable();
    }

    constructor(
        public el: ElementRef,
        private changeDetectorRef: ChangeDetectorRef,
    ) { }

    public setIndicators(indicators: TsumButton.CircleIndicator[]): void {
        this.indicatorsSubject$.next(indicators);

        if (!this.changeDetectorRef['destroyed']) {
            this.changeDetectorRef.detectChanges();
        }
    }

    public getTopPosition(index: number): number {
        if (this.indicatorsSubject$.getValue().length === 1) {
            return 16;
        }

        switch (index) {
            case 0:
                return 4;

            case 1:
                return 16;

            case 2:
                return 28;

            default:
                return 4;
        }
    }
}
