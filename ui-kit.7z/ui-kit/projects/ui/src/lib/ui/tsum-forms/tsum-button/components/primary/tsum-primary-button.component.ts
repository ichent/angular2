import { Component, ChangeDetectionStrategy } from '@angular/core';

/**
 * @description Primary button, main button/action means
 * @example <button tsumPrimaryButton>Primary button</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--primary}
 */
@Component({
    selector: 'button[tsumPrimaryButton], a[tsumPrimaryButton]',
    templateUrl: './tsum-primary-button.component.html',
    styleUrls: ['../tsum-button-base.styl', './tsum-primary-button.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class.button-label-white]': 'true',
    }
})
export class TsumPrimaryButtonComponent {
}
