import {
    AfterViewInit,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    ComponentRef,
    ContentChildren,
    ElementRef,
    Inject,
    Input,
    OnDestroy,
    OnInit,
    Optional,
    QueryList,
    Renderer2,
    TemplateRef,
    ViewChild,
} from '@angular/core';
import { BehaviorSubject, combineLatest, fromEvent, merge, Observable, Subject } from 'rxjs';
import {
    distinctUntilChanged,
    filter,
    first,
    map,
    mapTo,
    skip,
    startWith,
    switchMap,
    switchMapTo,
    takeUntil,
    tap,
    throttleTime,
} from 'rxjs/operators';
import { animationFrame } from 'rxjs/internal/scheduler/animationFrame';
import { DOCUMENT } from '@angular/common';
import { isEqual as _isEqual } from 'lodash';
import { TsumInputBoolean, TsumDynamicComponentsService } from '@tsum/utils';

import OptionValueType = TsumSelect.OptionValueType;
import { TsumSelect } from '../../tsum-select.namespace';
import { TsumWordEndingsPipe } from '../../../../tsum-utils/tsum-word-endings/tsum-word-endings.pipe';
import { TsumSelectDropdownComponent } from '../dropdown/tsum-select-dropdown.component';
import { TsumSelectTypeDirective } from '../../directives/select-type/tsum-select-type.directive';
import { TsumIntersectionElementDirective } from '../../../../tsum-utils/tsum-intersection/directives/tsum-intersection-element.directive';
import { TsumSelectDropdown } from '../dropdown/tsum-select-dropdown.namespace';
import { TsumSelectOptionComponent } from '../select-option/tsum-select-option.component';

const DEFAULT_TITLE_VERBS = ['Выбран', 'Выбрано', 'Выбрано'];
const DEFAULT_TITLE_NOUNS = ['элемент', 'элемента', 'элементов'];

const FOCUSED_CLASS = '_focused';
const FILLED_CLASS = '_filled';

interface DisplayedSelectedOption {
    value: OptionValueType;
    content: string;
    centered?: boolean;
}

@Component({
    exportAs: 'tsumSelectComponent',
    selector: 'tsum-select',
    templateUrl: './tsum-select.component.html',
    styleUrls: ['./tsum-select.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        TsumWordEndingsPipe,
    ],
})
export class TsumSelectComponent implements OnInit, AfterViewInit, OnDestroy {
    @Input()
    public titleWords: string[] = DEFAULT_TITLE_NOUNS;

    @TsumInputBoolean()
    @Input()
    public isNeedAlternativeDescription = false;

    @TsumInputBoolean()
    @Input()
    public highestDropdown = false;

    @Input()
    public placeholder: string;

    @TsumInputBoolean()
    @Input()
    public required: boolean;

    /**
     * Использовать для позиционирования выпадающего списка dropUp/dropDown
     * границы контейнера с IntersectionContainerDirective
     */
    @TsumInputBoolean()
    @Input()
    public useIntersectionContainer = true;

    /** Скрыть ли иконку "стрелочки" у селектора */
    @TsumInputBoolean()
    @Input()
    public hideIcon = false;

    /** Центрировать выбранное значение */
    @TsumInputBoolean()
    @Input()
    public centeredValue = false;

    /** Убирать ли плейсхолдер, если значение выбрано */
    @TsumInputBoolean()
    @Input()
    public hidePlaceholderOnSelected = false;

    @ViewChild('content', { static: true })
    public content: TemplateRef<void>;

    @ViewChild('valueContainer', { static: true })
    public valueContainer: ElementRef<HTMLElement>;

    @ViewChild('valueWrapper')
    public valueWrapper: ElementRef<HTMLElement>;

    @ContentChildren(TsumSelectOptionComponent, { descendants: true })
    public optionList: QueryList<TsumSelectOptionComponent>;

    public get isMultiple(): boolean {
        return this.selectorDirective.selectType === 'multiple';
    }

    public get showValues(): boolean {
        return this.selectedTemplateValuesSubject$.value?.length > 0;
    }

    public isAlternative = false;

    public selectedTemplateValues$: Observable<DisplayedSelectedOption[]>;
    public isDropdownOpened$: Observable<boolean>;
    public dropdownRef$: Observable<ComponentRef<TsumSelectDropdownComponent>>;

    // для вывода в шаблон
    private selectedTemplateValuesSubject$ = new BehaviorSubject<DisplayedSelectedOption[]>([]);
    private destroyed$ = new Subject<void>();
    private dropdownRefSubject$ = new BehaviorSubject<ComponentRef<TsumSelectDropdownComponent>>(null);

    private get dropdownRef(): ComponentRef<TsumSelectDropdownComponent> {
        return this.dropdownRefSubject$.value;
    }

    private set dropdownRef(ref: ComponentRef<TsumSelectDropdownComponent>) {
        this.dropdownRefSubject$.next(ref);
    }

    private dropdownDestruction$ = new Subject<void>();

    private isDropupSubject$ = new BehaviorSubject(null);
    private isDropUp$: Observable<boolean> = this.isDropupSubject$.pipe(distinctUntilChanged());

    constructor(
        @Inject(DOCUMENT) private document: any,
        private selectorDirective: TsumSelectTypeDirective,
        private elRef: ElementRef,
        private wordEndingsPipe: TsumWordEndingsPipe,
        private dynamicService: TsumDynamicComponentsService,
        private renderer: Renderer2,
        private cd: ChangeDetectorRef,
        @Optional() private intersectionElementDirective: TsumIntersectionElementDirective,
    ) {
        this.selectedTemplateValues$ =  this.selectedTemplateValuesSubject$.asObservable();
        this.dropdownRef$ = this.dropdownRefSubject$.asObservable();
    }

    public ngOnInit(): void {
        // В multiple режиме выбор опций происходит по submit, а не по клику на опцию
        if (this.isMultiple) {
            this.selectorDirective.isSelectOptionByClick = false;
        } else {
            this.selectorDirective.onClickToOption$
                .pipe(
                    takeUntil(this.destroyed$),
                )
                .subscribe(() => this.closeDropdown());
        }

        this.isDropdownOpened$ = this.dropdownRef$
            .pipe(
                map(Boolean),
                distinctUntilChanged(),
            );
    }

    public ngAfterViewInit(): void {
        if (!this.selectorDirective) {
            console.warn('It has to be used "TsumSelectTypeDirective" with "TsumSelectComponent"');
        }

        this.selectorDirective.selectedValue$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((selectedValues: OptionValueType[] | OptionValueType) => {
                this.setDisplayedSelectedOptions(selectedValues);
            });

        this.subscribeDropdownIntersections(this.intersectionElementDirective);
    }

    public toggleDropdown(): void {
        if (this.dropdownRef) {
            this.closeDropdown();
        } else {
            this.openDropdown();
        }
    }

    public closeDropdown(): void {
        if (!this.dropdownRef) {
            return;
        }

        this.dynamicService.deleteComponent(this.dropdownRef);
        this.dropdownRef = null;
        this.dropdownDestruction$.next();
        this.renderer.removeClass(this.elRef.nativeElement, FOCUSED_CLASS);
    }

    public onApplyMultiple(): void {
        const values: OptionValueType[] = this.getCheckedMultipleOptions();
        this.selectorDirective.setValue(values);
        this.closeDropdown();
    }

    public onDelete(event: Event, value: string): void {
        event.stopPropagation();
        event.preventDefault();
        this.selectorDirective.selectValue(value);
    }

    public getAlternativeDescription(selectedOptions: DisplayedSelectedOption[]): string {
        return `
            ${this.wordEndingsPipe.transform(selectedOptions.length, DEFAULT_TITLE_VERBS, false)}
            ${this.wordEndingsPipe.transform(selectedOptions.length, this.titleWords)}
        `;
    }

    public isNeedPlaceholder(): boolean {
        if (!this.hidePlaceholderOnSelected) {
            return true;
        }

        return !Boolean(this.selectorDirective.selectedValue);
    }

    public ngOnDestroy(): void {
        if (this.dropdownRef) {
            this.closeDropdown();
        }

        this.dropdownDestruction$.next();
        this.dropdownDestruction$.complete();
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private findOption(value: OptionValueType): TsumSelectOptionComponent {
        return this.optionList.find((option: TsumSelectOptionComponent) => _isEqual(option.value, value));
    }

    private openDropdown(): void {
        if (this.dropdownRef) {
            return;
        }

        const isHighest: boolean = this.highestDropdown || this.isFixed(this.elRef.nativeElement);

        this.dropdownRef = this.dynamicService.createComponent(TsumSelectDropdownComponent);

        const fieldRect: DOMRect = this.elRef.nativeElement.getBoundingClientRect();
        const dropdown: TsumSelectDropdownComponent = this.dropdownRef.instance;

        dropdown.width = fieldRect.width;
        dropdown.multiple = this.isMultiple;
        dropdown.contentTemplate = this.content;
        dropdown.highest = isHighest;

        dropdown.apply$
            .pipe(
                takeUntil(this.dropdownDestruction$),
            )
            .subscribe(() => this.onApplyMultiple());

        dropdown.render$
            .pipe(
                first(),
                tap(() => this.renderer.addClass(this.elRef.nativeElement, FOCUSED_CLASS)),
                map(() => this.dropdownRef.location.nativeElement.getBoundingClientRect().height),
                switchMap((dropdownHeight: number) => fromEvent(this.document, 'scroll', { capture: true })
                    .pipe(
                        startWith(dropdownHeight),
                        throttleTime(0, animationFrame),
                        mapTo(dropdownHeight),
                    )
                ),
                takeUntil(this.dropdownDestruction$),
            )
            .subscribe((dropdownHeight: number) => this.setPosition(dropdownHeight));

        const close$: Observable<void> = merge(
            dropdown.cancel$,
            fromEvent(this.document, 'mousedown')
                .pipe(
                    filter((event: Event) => {
                        const isInDropdown: boolean = this.dropdownRef.location.nativeElement.contains(event.target);
                        const isInSelector: boolean = this.elRef.nativeElement.contains(event.target);

                        return !isInDropdown && !isInSelector;
                    }),
                    mapTo(null),
                )
        );

        dropdown.render$
            .pipe(
                first(),
                tap(() => this.resetActualDropdownValue()),
                switchMapTo(close$),
                takeUntil(this.dropdownDestruction$),
            )
            .subscribe(() => this.closeDropdown());
    }

    private isFixed(element: HTMLElement): boolean {
        if (!element) {
            return false;
        }

        return getComputedStyle(element).position === 'fixed' || this.isFixed(element.parentElement);
    }

    private setPosition(dropdownHeight: number): void {
        const dropdown: TsumSelectDropdownComponent = this.dropdownRef.instance;
        const fieldRect: DOMRect = this.elRef.nativeElement.getBoundingClientRect();
        const intersectWithDocument: boolean = !this.useIntersectionContainer
            || !this.intersectionElementDirective
            || !this.intersectionElementDirective.container;

        const intersectionThreshold: number = intersectWithDocument
            ? this.document.documentElement.offsetHeight
            : this.intersectionElementDirective.container.getBoundingClientRect().bottom;

        if (fieldRect.bottom + dropdownHeight >= intersectionThreshold) {
            dropdown.top = fieldRect.top - dropdownHeight;
            dropdown.left = fieldRect.left;
            dropdown.position = TsumSelectDropdown.Position.Top;
            this.isDropupSubject$.next(true);
        } else {
            dropdown.top = fieldRect.bottom;
            dropdown.left = fieldRect.left;
            dropdown.position = TsumSelectDropdown.Position.Bottom;
            this.isDropupSubject$.next(false);
        }

        this.dropdownRef.changeDetectorRef.detectChanges();
    }

    // TODO написать unit test на функцию выбора отображаемых значений
    private setDisplayedSelectedOptions(activeValue: OptionValueType[] | OptionValueType = []): void {
        if (!this.optionList || activeValue == null) {
            return;
        }

        this.isAlternative = false;

        const iteratedValue: OptionValueType[] = Array.isArray(activeValue) ? activeValue : [activeValue];
        let displayedSelectedOptions: DisplayedSelectedOption[] = iteratedValue
            .map((value: OptionValueType) => {
                const option: TsumSelectOptionComponent = this.findOption(value);

                if (!option) {
                    return;
                }

                return {
                    value: option.value,
                    content: option.title ? option.title : option.content.nativeElement.innerText.trim(),
                    centered: this.centeredValue,
                };
            });

        if (!displayedSelectedOptions[0]) {
            displayedSelectedOptions = [];
        }

        displayedSelectedOptions.length > 0
            ? this.renderer.addClass(this.elRef.nativeElement, FILLED_CLASS)
            : this.renderer.removeClass(this.elRef.nativeElement, FILLED_CLASS);

        this.selectedTemplateValuesSubject$.next(displayedSelectedOptions);

        if (!this.cd['destroyed']) {
            this.cd.detectChanges();
        }

        if (this.isMultiple && this.valueWrapper) {
            const containerWidth: number = this.valueContainer.nativeElement.offsetWidth;
            const wrapperWidth: number = this.valueWrapper.nativeElement.offsetWidth;

            this.isAlternative = this.isNeedAlternativeDescription || wrapperWidth > containerWidth;

            if (!this.cd['destroyed']) {
                this.cd.detectChanges();
            }
        }
    }

    /**
     * Получить опции, которые пользователь отметил чекбоксами в multiple режиме
     * Эти значения могут быть еще не применены, т.к. применение происходит по apply
     */
    private getCheckedMultipleOptions(): OptionValueType[] {
        return this.optionList
            .toArray()
            .filter((optionComponent: TsumSelectOptionComponent) => optionComponent.isChecked)
            .map((optionComponent: TsumSelectOptionComponent) => optionComponent.value);
    }

    /**
     * Восстанавливает последнее подтвержденное значение
     */
    private resetActualDropdownValue(): void {
        if (!this.optionList) {
            return;
        }

        setTimeout(() => {
            this.optionList.forEach((option: TsumSelectOptionComponent) => option.resetValue());
        });
    }

    private subscribeDropdownIntersections(intersection: TsumIntersectionElementDirective): void {
        if (!intersection) {
            return;
        }

        combineLatest([
            this.isDropdownOpened$.pipe(skip(1)),
            this.isDropUp$,
        ])
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(([isDropdownOpened, isDropUp]: boolean[]) => {
                if (isDropdownOpened) {
                    intersection.hideOnPartialIntersection = isDropUp;
                    intersection.startObserving();
                } else {
                    intersection.stopObserving();
                }
            });

        this.isDropdownOpened$
            .pipe(
                filter(Boolean),
                switchMap(() => intersection.isIntersecting$),
                filter((isIntersecting: boolean) => !isIntersecting),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.closeDropdown());
    }
}
