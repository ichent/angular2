import { NG_VALUE_ACCESSOR, ControlValueAccessor, FormControl } from '@angular/forms';
import { Component, Input, ChangeDetectionStrategy, forwardRef, OnDestroy, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { TsumTable } from './tsum-table.namespace';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

/**
 * @description Table component component
 * @description has inputs:
 * @description columns - columns of your table
 * @description rows - rows of your table
 * @description title - title of table
 * @description sizeOptions - Uses for paginator, count element per page
 * @description isLoading - loading state, set true if you need show loading
 * @example
 * <tsum-table
 *   title="Test title"
 *   [columns]="columns"
 *   [isLoading]="isLoading"
 *   [rows]="rows"
 *   [formControl]="formControl"
 *   class="d-block h-400"
 * >
 *   <div class="mr-md">
 *       <button tsumPrimaryButton>Button</button>
 *   </div>
 * </tsum-table>
 *
 * <ng-template #content let-data="rowData">
 *   <div>{{ data }}</div>
 * </ng-template>
 *
 * <ng-template #manage let-data="rowData">
 *    Упр
 * </ng-template>
 * @description Has ng content, this content include after paginator
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-table--as-component}
 */
@Component({
  selector: 'tsum-table',
  templateUrl: './tsum-table.component.html',
  styleUrls: ['./tsum-table.component.styl'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => TsumTableComponent),
        multi: true,
    },
  ]
})
export class TsumTableComponent implements ControlValueAccessor, OnDestroy, OnInit, OnChanges {
    @Input()
    public columns: TsumTable.Column<any>[];

    @Input()
    public rows: any[];

    @Input()
    public title: string = '';

    @Input()
    public sizeOptions: number[] = [5, 10, 20];

    @Input()
    public isLoading = false;

    public paginatorControl = new FormControl(null);
    public isInited = false;

    private destroyed$ = new Subject<void>();

    constructor() {
        this.paginatorControl.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((value: number) => this.onChange(value));
    }

    public ngOnInit(): void {
        if (!this.isLoading) {
            this.isInited = true;
        }
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes && changes.isLoading && !changes.isLoading.firstChange) {
            this.isInited = true;
        }
    }

    public registerOnTouched(fn: () => void): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: () => void): void {
        this.onChange = fn;
    }

    public writeValue(value: number): void {
        this.paginatorControl.setValue(value);
    }

    public isHasPagination(): boolean {
        return Boolean(this.paginatorControl.value);
    }

    public isMinHeight(): boolean {
        return this.isLoading && (!this.rows || this.rows.length === 0);
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onChange = (value: number) => {};
    private onTouched = () => {};
}
