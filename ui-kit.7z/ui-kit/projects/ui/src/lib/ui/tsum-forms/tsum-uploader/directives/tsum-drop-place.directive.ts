import {
    Directive,
    ElementRef,
    EventEmitter,
    Input,
    Output,
    HostListener,
    Renderer2,
} from '@angular/core';
import { TsumNotificationService } from '../../../tsum-notifications/tsum-air-message/services/tsum-notification.service';
import { TsumNotification } from '../../../tsum-notifications/tsum-air-message/tsum-air-message.namespace';

const DRAGED_CLASS_NAME = 'tsum-uploader__dropzone_draged';

@Directive({
    selector: '[tsumDrop]',
})
export class TsumDropPlaceDirective {
    @Input()
    public disabled = false;

    @Output('tsumDrop')
    private dropedFail$ = new EventEmitter<FileList>();

    constructor(
        private render: Renderer2,
        private host: ElementRef,
        public tsumNotificationService: TsumNotificationService,
    ){}

    @HostListener('drop', [ '$event' ])
    public droped(event: DragEvent): void {
        this.preventDefault(event);

        if (this.disabled) {
            this.sendAlertNotification();
            return;
        }

        this.dropedFail$.emit(event.dataTransfer.files);
        this.render.removeClass(this.host.nativeElement, DRAGED_CLASS_NAME);
    }

    @HostListener('dragenter', ['$event'])
    public dragentered(event: DragEvent): void {
        this.preventDefault(event);
        this.render.addClass(this.host.nativeElement, DRAGED_CLASS_NAME);
    }

    @HostListener('dragleave', ['$event'])
    public dragleave(event: DragEvent): void {
        this.preventDefault(event);
        this.render.removeClass(this.host.nativeElement, DRAGED_CLASS_NAME);
    }

    @HostListener('dragover', ['$event'])
    public dragover(event: DragEvent): void {
        this.preventDefault(event);
    }

    private preventDefault(event: DragEvent): void {
        event.stopPropagation();
        event.preventDefault();
    }

    private sendAlertNotification(): void {
        this.tsumNotificationService.pushNotifications([
            {
                type: 'error',
                title: 'Ошибка загрузки документов',
                timeoutClose: TsumNotification.Timeout.Medium,
            },
        ]);
    }
}
