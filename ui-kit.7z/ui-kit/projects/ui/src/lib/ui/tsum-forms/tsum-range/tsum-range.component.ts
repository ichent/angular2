import { Component, AfterViewInit, ContentChildren, QueryList, OnDestroy, Input, ChangeDetectionStrategy } from '@angular/core';
import { ValidationErrors, ValidatorFn, AbstractControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil, distinctUntilChanged, delay } from 'rxjs/operators';
import { TsumFormFieldComponent } from '../tsum-input/components/tsum-form-field/tsum-form-field.component';
import { TsumRange } from './tsum-range.namespace';
import { TsumInputComponent } from '../tsum-input/components/tsum-input/tsum-input.component';
import { TsumNumericCompareValidator, TsumDateCompareValidator } from '@tsum/utils';
import { INVALID_STATUS } from '../../tsum-base/constants/form-status.constant';

/**
 * @description Range/interval component
 * @description Uses for make interval of values and if one of interval is incorrect show error
 * @description Range has default compare function(which compare from/to value in range)
 * @description By default: date/numeric
 * @description Also you can send custom compare function, just send input 'compareFunction'
 * @description This 'compareFunction' returns ValidationErrors, and has arguments 'from/to form control'
 * @example <tsum-range
 * @example   type="date"
 * @example   errorText="Неверная дата">
 * @example   <tsum-form-field rangeFrom>
 * @example     <input
 * @example       tsumInput
 * @example       formControlName="dateFrom"
 * @example       activePlaceholder="Введите дату от"
 * @example       placeholder="_ _ / _ _ / _ _" />
 * @example   </tsum-form-field>
 * @example   <tsum-form-field rangeTo>
 * @example     <input
 * @example       tsumInput
 * @example       formControlName="dateTo"
 * @example       activePlaceholder="Введите дату до"
 * @example       placeholder="_ _ / _ _ / _ _" />
 * @example   </tsum-form-field>
 * @example </tsum-range>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-range-interval--default}
 */
@Component({
    selector: 'tsum-range',
    templateUrl: './tsum-range.component.html',
    styleUrls: ['./tsum-range.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumRangeComponent implements AfterViewInit, OnDestroy {
    @ContentChildren(TsumFormFieldComponent, { descendants: true }) formFieldComponents: QueryList<TsumFormFieldComponent>;

    /**
     * @description Type of validation
     * @description send 'date'/'numeric' for compare by this functions
     */
    @Input() public type: TsumRange.Type = 'default';

    /**
     * @description Text of error, shows when any of range element is incorrect
     */
    @Input() public errorText: string = '';

    @Input() public compareFunction: (
        fromControl: AbstractControl,
        toControl: AbstractControl,
    ) => ValidationErrors = null;

    private destroyed$: Subject<void> = new Subject<void>();

    private get rangeFromFormField(): TsumFormFieldComponent {
        return this.formFieldComponents.first;
    }

    private get rangeToFormField(): TsumFormFieldComponent {
        return this.formFieldComponents.last;
    }

    public ngAfterViewInit(): void {
        /** @description
         * Необходимый таймаут, решает проблему когда в нашей форме уже есть валидаторы, без таймаута этих валидаторов нет в форме
         */
        setTimeout(() => this.initValidators());

        this.rangeToFormField.currentForm.statusChanges
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
            )
            .subscribe((status: string) => {
                this.sendOrResetError(status === INVALID_STATUS);
            });

        this.getCurrentInput('from').tsumInputDirtyCheck = false;
        this.getCurrentInput('to').tsumInputDirtyCheck = false;

        this.getCurrentInput('from').inputChange$
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
                delay(0), // Do not delete this, it throw error expression was changed
            )
            .subscribe((text: string) => {
                if (text) {
                    this.rangeToFormField.currentForm.control.updateValueAndValidity();
                }
            });

        this.getCurrentInput('to').inputChange$
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
                delay(0),
            )
            .subscribe((text: string) => {
                if (text) {
                    this.rangeToFormField.currentForm.control.updateValueAndValidity();
                }
            });
    }

    public getCurrentInput(rangeType: TsumRange.RangeType): TsumInputComponent {
        return rangeType === 'from'
            ? this.rangeFromFormField.tsumInput
            : this.rangeToFormField.tsumInput;
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private initValidators(): void {
        const oldValidator = this.rangeToFormField.currentForm.control.validator;

        // Если есть compareFunction, то работает с ней, в остальных случаях пробуем с дефолтными типами
        if (this.compareFunction) {
            if (oldValidator) {
                this.rangeToFormField.currentForm.control.setValidators([
                    this.customCompare(),
                    oldValidator,
                ]);
            } else {
                this.rangeToFormField.currentForm.control.setValidators([
                    this.customCompare(),
                ]);
            }

            return;
        }

        switch (this.type) {
            case 'numeric': {
                if (oldValidator) {
                    this.rangeToFormField.currentForm.control.setValidators([
                        this.numericCompare(),
                        oldValidator,
                    ]);
                } else {
                    this.rangeToFormField.currentForm.control.setValidators([
                        this.numericCompare(),
                    ]);
                }

                break;
            }

            case 'date': {
                if (oldValidator) {
                    this.rangeToFormField.currentForm.control.setValidators([
                        this.dateCompare(),
                        oldValidator,
                    ]);
                } else {
                    this.rangeToFormField.currentForm.control.setValidators([
                        this.dateCompare(),
                    ]);
                }

                break;
            }

            default:
                break;
        }
    }

    private customCompare(): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            const errors: ValidationErrors = this.compareFunction(
                this.rangeFromFormField.currentForm.control,
                this.rangeToFormField.currentForm.control,
            );

            if (Object.keys(errors).length !== 0) {
                this.setError();
            }

            return errors;
        };
    }

    private numericCompare(): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            const errors: ValidationErrors = TsumNumericCompareValidator.tsumNumericCompareValidator(
                this.rangeFromFormField.currentForm.control,
                this.rangeToFormField.currentForm.control,
            );

            if (Object.keys(errors).length !== 0) {
                this.setError();
            }

            return errors;
        };
    }

    private dateCompare(): ValidatorFn {
        return (control: AbstractControl): ValidationErrors | null => {
            const errors: ValidationErrors = TsumDateCompareValidator.tsumDateCompareValidator(
                this.rangeFromFormField.currentForm.control,
                this.rangeToFormField.currentForm.control,
            );

            if (Object.keys(errors).length !== 0) {
                this.setError();
            }

            return errors;
        };
    }

    private sendOrResetError(isInvalidFrom: boolean): void {
        isInvalidFrom === true
            ? this.setError(true)
            : this.resetError('to');
    }

    private setError(isStatusChanges?: boolean): void {
        this.getCurrentInput('to').currentError = this.errorText;

        if (isStatusChanges) {
            this.getCurrentInput('to').setNeededPlaceholder();
        }
    }

    private resetError(rangeType: TsumRange.RangeType): void {
        const currentInput: TsumInputComponent = this.getCurrentInput(rangeType);

        if (!currentInput.inputValue) {
            return;
        }

        this.getCurrentInput('to').setNeededPlaceholder();

        currentInput.currentError = this.getCurrentInput(rangeType).tsumInputError ? this.getCurrentInput(rangeType).tsumInputError : null;
    }
}
