import {
    Component,
    ChangeDetectionStrategy,
    Input,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';
import { CheckboxDirective } from '../../tsum-checkbox/directives/checkbox.directive';

/**
 * @description Компонент radio, имеет состояние disabled
 * disabled - Не активное состояние для toggler
 * @example <tsum-radio></tsum-radio>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-radio--radio}
 */
@Component({
    selector: 'tsum-radio',
    templateUrl: './tsum-radio.component.html',
    styleUrls: ['./tsum-radio.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        CheckboxDirective,
    ],
})
export class TsumRadioComponent {
    @TsumInputBoolean()
    @Input()
    public disabled = false;

    /**
     * @description uses for prevent click
     */
    public onClickNativeRadio(event: Event): void {
        event.preventDefault();
        event.stopPropagation();
    }
}
