import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumTableComponent } from './tsum-table.component';
import { TsumPaginatorModule } from '../tsum-paginator/tsum-paginator.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TsumSpinnerModule } from '../../tsum-common/tsum-spinner/tsum-spinner.module';
import { TsumTableWrapperComponent } from './components/wrapper/tsum-table-wrapper.component';
import { TsumTableRowComponent } from './components/row/tsum-table-row.component';
import { TsumTableCellComponent } from './components/cell/tsum-table-cell.component';
import { TsumTableCellHeadComponent } from './components/cell-head/tsum-table-cell-head.component';
import { TsumScrollModule } from '../../tsum-common/tsum-scroll/tsum-scroll.module';
import { TsumPaneModule } from '../../tsum-layout/tsum-pane/tsum-pane.module';

const COMPONENTS = [
    TsumTableComponent,
    TsumTableWrapperComponent,
    TsumTableRowComponent,
    TsumTableCellComponent,
    TsumTableCellHeadComponent,
];

/**
 * @description Компонент таблица, готовое решение "из коробки" нужно прокидывать данные
 * @description Список инпутов:
 * @description columns - Ячейки таблицы
 * @description rows - Колонки
 * @description title - Заголовок таблицы
 * @description sizeOptions - Для пагинатора, количество элементов на странице(выбор из этих значений)
 * @description isLoading - Состояние загрузки
 * @example
 * <tsum-table
 *   title="Test title"
 *   [columns]="columns"
 *   [isLoading]="isLoading"
 *   [rows]="rows"
 *   [formControl]="formControl"
 *   class="d-block h-400"
 * >
 *   <div class="mr-md">
 *       <button tsumPrimaryButton>Button</button>
 *   </div>
 * </tsum-table>
 *
 * <ng-template #content let-data="rowData">
 *   <div>{{ data }}</div>
 * </ng-template>
 *
 * <ng-template #manage let-data="rowData">
 *    Упр
 * </ng-template>
 * @description Has ng content, this content include after paginator
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-table--as-component}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TsumPaginatorModule,
        TsumSpinnerModule,
        TsumScrollModule,
        TsumPaneModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumTableModule { }
