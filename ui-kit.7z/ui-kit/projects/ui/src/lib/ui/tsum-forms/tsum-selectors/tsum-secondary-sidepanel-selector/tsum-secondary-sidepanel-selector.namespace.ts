/**
 * @description Namespace for TsumSecondarySidepanelSelector
 * @description Contains interfaces and constants
 */
export namespace TsumSecondarySidepanelSelector {

    /**
     * @description Option key type
     */
    export type Key = string | number | object;

    /**
     * @description Selector value type
     */
    export type Value = Key | Key[];

    /**
     * @description Current element in selector, usually uses in arrays for input
     */
    export interface Option<T extends Key = Key> {
        key: T;
        title: string;
        disabled?: boolean;
    }

    /**
     * @description Output in form for options
     */
    export interface Result {
        [key: string]: boolean;
    }
}
