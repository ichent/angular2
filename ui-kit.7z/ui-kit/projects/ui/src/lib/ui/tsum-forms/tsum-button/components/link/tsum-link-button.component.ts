import {
    Component,
    ChangeDetectionStrategy,
    HostBinding,
    Input,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * @description Label button, which no have background
 * @description have "warning"/"active"/"small"/"link" state
 * @example <button tsumLabelButton>Label button</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--link}
 */
@Component({
    selector: 'button[tsumLinkButton], a[tsumLinkButton], div[tsumLinkButton]',
    templateUrl: './tsum-link-button.component.html',
    styleUrls: ['../tsum-button-base.styl', './tsum-link-button.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumLinkButtonComponent {
    /**
     * @description Input
     * @description flag for hover state
     * @example
     * [hover]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._clickable')
    @Input()
    public clickable: boolean;

    /**
     * @description Input
     * @description flag for opened state
     * @example
     * [opened]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._opened')
    @Input()
    public opened: boolean;

    /**
     * @description Input
     * @description flag for active state
     * @example
     * [active]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._active')
    @Input()
    public active: boolean;

    /**
     * @description Input
     * @description flag for small state
     * @example
     * [small]="true"
     */
    @TsumInputBoolean()
    @HostBinding('class._small')
    @Input()
    public small: boolean;
}
