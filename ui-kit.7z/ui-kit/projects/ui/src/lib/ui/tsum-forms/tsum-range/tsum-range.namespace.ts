export namespace TsumRange {
    export type Type = 'numeric' | 'date' | 'default';

    export type RangeType = 'from' | 'to';
}
