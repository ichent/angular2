import {
    AfterViewInit,
    ChangeDetectionStrategy,
    Component,
    ContentChildren,
    EventEmitter,
    forwardRef,
    OnDestroy,
    Output,
    QueryList,
    ViewChild,
    ChangeDetectorRef,
} from '@angular/core';
import { Subject } from 'rxjs';
import { distinctUntilChanged, map, startWith, takeUntil, tap } from 'rxjs/operators';
import { ControlValueAccessor, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { TsumTab } from './tsum-tabs.namespace';
import { TsumTabComponent } from '../tsum-tab/tsum-tab/tsum-tab.component';
import { TsumSelectTypeDirective } from '../tsum-selectors/directives/select-type/tsum-select-type.directive';

@Component({
    selector: 'tsum-tabs',
    templateUrl: './tsum-tabs.component.html',
    styleUrls: ['./tsum-tabs.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TsumTabsComponent),
            multi: true,
        },
    ],
})
export class TsumTabsComponent implements ControlValueAccessor, OnDestroy, AfterViewInit {

    @Output('userClickedTab')
    public onUserClickedTab$ = new EventEmitter<TsumTab.Tab>();

    @ContentChildren(forwardRef(() => TsumTabComponent))
    public optionList: QueryList<TsumTabComponent>;

    @ViewChild(TsumSelectTypeDirective)
    public tsumSelectTypeDirective: TsumSelectTypeDirective;

    public get tabs(): TsumTab.Tab[] {
        return this.optionList ? this.optionList.map(this.optionListToTab) : [];
    }

    public get isOnlyOneTab(): boolean {
        return this.tabs.length === 1;
    }

    public tabsControl = new FormControl(null);

    private destroyed$ = new Subject<void>();

    constructor(
        private changeDetectorRef: ChangeDetectorRef,
    ) {}

    public ngAfterViewInit(): void {
        this.tabsControl.valueChanges
            .pipe(
                startWith(this.tabsControl.value),
                distinctUntilChanged(),
                map((value: string) => this.tabs.find((tab: TsumTab.Tab) => tab.value === value)),
                takeUntil(this.destroyed$),
            )
            .subscribe((tab: TsumTab.Tab) => {
                this.setActiveTab(tab?.value);

                this.onUserClickedTab$.emit(tab);
            });

        this.tsumSelectTypeDirective.onChangeFormControlValue$
            .pipe(
                tap((value: string) => {
                    this.onChange(value);
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe();

        this.optionList.changes
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => {
                if (!this.changeDetectorRef['destroyed']) {
                    this.changeDetectorRef.detectChanges();
                }
            });
    }

    public trackByValue(index: number, tab: TsumTab.Tab): string | number | object {
        return tab.value;
    }

    public writeValue(value: string): void {
        this.tabsControl.setValue(value);
    }

    public registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onChange = (value: string) => {};
    private onTouched = () => {};

    private setActiveTab(tabValue: string | number | object): void {
        this.optionList.forEach((tab: TsumTabComponent) => {
            tab.active = tab.value === tabValue;
        });
    }

    private optionListToTab(tab: TsumTabComponent): TsumTab.Tab {
        return {
            label: tab.label,
            active: tab.active,
            value: tab.value,
            badge: tab.badge,
            width: tab.width,
        };
    }
}
