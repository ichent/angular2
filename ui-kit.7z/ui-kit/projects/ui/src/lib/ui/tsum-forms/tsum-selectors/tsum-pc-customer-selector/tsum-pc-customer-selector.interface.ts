import { TemplateRef } from '@angular/core';

import { TsumIndicator } from '../../../tsum-utils/tsum-indicator/tsum-indicator.namespace';
import {
    TsumPreviewCardCustomer,
} from '../../../tsum-common/tsum-preview-card/tsum-preview-card-customer/tsum-preview-card-customer.namespace';

export interface TsumPreviewCardCustomerOption {
    title: string;
    value: string | number | object;
    indicatorType: TsumIndicator.Type;
    info: TsumPreviewCardCustomer.Info[];
    content?: TemplateRef<void>;
}
