import { Component, ChangeDetectionStrategy, ElementRef, Renderer2 } from '@angular/core';

/**
 * @description Primary button, main button/action means
 * @example <button tsumPrimaryButton>Primary button</button>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-buttons--primary}
 */
@Component({
    selector: 'tsum-button-loader',
    templateUrl: './tsum-button-loader.component.html',
    styleUrls: ['./tsum-button-loader.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumButtonLoaderComponent {
    public diameter = 14;

    constructor(
        public el: ElementRef,
        private renderer: Renderer2,
    ) {}

    public setBackgroundColor(color: string): void {
        this.renderer.setStyle(this.el.nativeElement, 'background-color', color);
    }
}
