import { TemplateRef } from '@angular/core';
import { TsumButton } from '../../tsum-button/tsum-button.namespace';

/**
 * @description Namespace for TsumPrimarySidepanelSelector
 * @description Contains interfaces and constants
 */
export namespace TsumPrimarySidepanelSelector {

    /**
     * @description Option key type
     */
    export type Key = string | number | object;

    /**
     * @description Selector value type
     */
    export type Value = Key | Key[];

    /**
     * @description Current element in selector, usually uses in arrays for input
     */
    export interface Option<T extends Key = Key> {
        key: T;
        title: string;
        includeIndicator?: boolean;
        actions?: TsumButton.Action[];
        indicators?: TsumButton.CircleIndicator[];
        dragable?: boolean;
        beforeTemplate?: TemplateRef<void>;
        afterTemplate?: TemplateRef<void>;
        customContent?: TemplateRef<void>;
    }

    /**
     * @description Output in form for options
     */
    export interface Result {
        [key: string]: boolean;
    }
}
