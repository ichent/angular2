import {
    Component,
    ChangeDetectionStrategy,
    HostBinding,
    Input,
    AfterViewInit,
    ElementRef,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';
import { tsumTableInitSticky } from '../../tsum-table.helper';

/**
 * @description Ячейка для таблицы
 * @example
 * <table tsumTable>
 *   <tr tsumTableRow>
 *     <th tsumTableCellHead>Name</th>
 *     <th tsumTableCellHead>Surname</th>
 *   </tr>
 *   <tr tsumTableRow>
 *     <th tsumTableCell>Alex</th>
 *     <th tsumTableCell>Dadigin</th>
 *   </tr>
 *  <table>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-table--as-native-table}
 */
@Component({
    selector: 'td[tsumTableCell]',
    templateUrl: './tsum-table-cell.component.html',
    styleUrls: ['./tsum-table-cell.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class.sheets-body-left]': 'true',
    },
})
export class TsumTableCellComponent implements AfterViewInit {
    @TsumInputBoolean()
    @HostBinding('class._sticky')
    @Input()
    public sticky = false;

    @TsumInputBoolean()
    @HostBinding('class._right-sticky')
    @Input()
    public rightSticky = false;

    constructor(
        private elementRef: ElementRef,
    ) {}

    public ngAfterViewInit(): void {
        tsumTableInitSticky(this.elementRef.nativeElement);
    }
}
