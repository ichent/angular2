import {
    Component,
    ChangeDetectionStrategy,
    Input,
    forwardRef,
    OnDestroy,
    ChangeDetectorRef,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, FormControl } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

import { TsumPreviewCardCustomerOption } from './tsum-pc-customer-selector.interface';
import { TsumSelect } from '../tsum-select.namespace';

/**
 * Группа preview card customer
 * Принимает инпут list, в котором передаем массив TsumPreviewCardCustomerOption
 * Далее берем форму и подписываемся на изменения
 * Принимает input type - тип возвращаемых данных и поведение, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-preview-card-customer-selector [list]="list" [formControl]="form"></tsum-preview-card-customer-selector>
 * More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-selector--preview-card-customer}
 */
@Component({
    selector: 'tsum-preview-card-customer-selector',
    templateUrl: './tsum-pc-customer-selector.component.html',
    styleUrls: ['./tsum-pc-customer-selector.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TsumPreviewCardCustomerSelectorComponent),
            multi: true,
        },
    ],
})
export class TsumPreviewCardCustomerSelectorComponent implements ControlValueAccessor, OnDestroy {
    @Input()
    public type: TsumSelect.SelectType = 'multiple';

    @Input()
    public list: TsumPreviewCardCustomerOption[] = [];

    public form = new FormControl();

    private destroyed$ = new Subject<void>();

    constructor(
        private changeDetectorRef: ChangeDetectorRef,
    ) {
        this.form.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((selected: string[]) => {
                this.onChange(selected);

                if (!this.changeDetectorRef['destroyed']) {
                    this.changeDetectorRef.detectChanges();
                }
            });
    }

    public writeValue(result: string[]): void {
        if (!result) {
            return;
        }

        this.form.setValue(result);
    }

    public registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    public isActive(element: TsumPreviewCardCustomerOption): boolean {
        if (!this.form?.value) {
            return false;
        }

        if (Array.isArray(this.form.value)) {
            return this.form.value.includes(element.value);
        } else {
            return element.value === this.form.value;
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onChange = (value: string[]) => {};
    private onTouched = () => {};
}
