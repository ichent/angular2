import {
    Directive,
    HostListener,
    Output,
    EventEmitter,
    ComponentRef,
    OnDestroy,
    Input,
} from '@angular/core';
import { Subject } from 'rxjs';
import { tap, takeUntil } from 'rxjs/operators';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumUploader } from '../tsum-uploader.namespace';
import { TsumHiddenUploaderComponent } from '../components/tsum-hidden-upload/tsum-hidden-uploader.component';

@Directive({
    selector: '[tsumUploaderSimple]',
})
export class TsumUploaderSimpleDirective implements OnDestroy {
    @Input()
    public acceptFilesTypes: string[] = [];
    @Input()
    public sizeLimit: number = TsumUploader.DEFAULT_SIZE_LIMIT;

    @Output('uploaded')
    public uploaded$ = new EventEmitter<TsumUploader.FileLoaded[]>();
    public destroyed$ = new Subject<void>();

    private hiddenInput: ComponentRef<TsumHiddenUploaderComponent>;

    constructor(
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
    ) {}

    @HostListener('click', ['$event'])
    public onClick($event: MouseEvent): void {
        this.hiddenInput = this.tsumDynamicComponentsService.createComponent(
            TsumHiddenUploaderComponent,
        );

        const componentInstance = this.hiddenInput.instance;

        componentInstance.acceptFilesTypes = this.acceptFilesTypes;
        componentInstance.sizeLimit = this.sizeLimit;

        componentInstance.hiddenInputElement.nativeElement.click();
        componentInstance.uploaded$
            .pipe(
                tap((loadedFile: TsumUploader.FileLoaded[]) => this.uploaded$.emit(loadedFile)),
                tap(() => this.tsumDynamicComponentsService.deleteComponent(this.hiddenInput)),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
