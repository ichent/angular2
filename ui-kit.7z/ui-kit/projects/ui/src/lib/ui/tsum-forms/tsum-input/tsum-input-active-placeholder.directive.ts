import {
    Directive,
    Input,
    AfterViewInit,
} from '@angular/core';
import { TsumInputComponent } from './components/tsum-input/tsum-input.component';
import { Subject, BehaviorSubject, combineLatest, Observable } from 'rxjs';
import { takeUntil, distinctUntilChanged } from 'rxjs/operators';

@Directive({
    selector: 'input[activePlaceholder], textarea[activePlaceholder]',
})
export class TsumInputActivePlaceholderDirective implements AfterViewInit {
    @Input() public set activePlaceholder(text: string) {
        this.innerActivePlaceholderSubject$.next(text);
    }

    private destroyed$: Subject<void> = new Subject<void>();
    private defaultPlaceholderSubject$ = new BehaviorSubject<string>(null);
    private innerActivePlaceholderSubject$ = new BehaviorSubject<string>('');
    private innerActivePlaceholder$: Observable<string> = this.innerActivePlaceholderSubject$.asObservable()
        .pipe(
            distinctUntilChanged(),
        );

    constructor(
        private tsumInputComponent: TsumInputComponent,
    ) { }

    public ngAfterViewInit(): void {
        this.defaultPlaceholderSubject$.next(this.tsumInputComponent.placeholder);

        combineLatest([
            this.tsumInputComponent.inputChange$,
            this.tsumInputComponent.currentError$,
            this.innerActivePlaceholder$,
        ])
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
            )
            .subscribe(([text, currentError, activePlaceholder]: [string, string, string]) => {
                const activeText = activePlaceholder
                    ? activePlaceholder : this.tsumInputComponent.placeholder;

                if (text) {
                    this.tsumInputComponent.placeholder = currentError && this.tsumInputComponent.formInvalid
                        ? currentError as string
                        : activeText;
                } else if (!this.tsumInputComponent.inputActive) {
                    this.tsumInputComponent.placeholder = currentError && this.tsumInputComponent.formInvalid
                        ? currentError as string
                        : this.defaultPlaceholderSubject$.getValue();
                } else if (this.tsumInputComponent.inputActive && !this.tsumInputComponent.formInvalid) {
                    this.tsumInputComponent.placeholder = activeText;
                }
            });

        combineLatest([
            this.tsumInputComponent.onFocus$,
            this.innerActivePlaceholder$,
        ])
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(([onFocus, activePlaceholder]: [void, string]) => {
                const activeText = activePlaceholder
                    ? activePlaceholder : this.tsumInputComponent.placeholder;

                if (!this.tsumInputComponent.currentError || !this.tsumInputComponent.formInvalid) {
                    this.tsumInputComponent.placeholder = activeText;
                }
            });

        this.tsumInputComponent.onBlur$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => {
                if (!this.tsumInputComponent.inputValue) {
                    this.tsumInputComponent.placeholder = this.defaultPlaceholderSubject$.getValue();
                }
            });
    }
}
