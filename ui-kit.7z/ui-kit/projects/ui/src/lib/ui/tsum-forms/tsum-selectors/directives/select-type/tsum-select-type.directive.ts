import {
    AfterViewInit,
    ContentChildren,
    Directive,
    ElementRef,
    EventEmitter,
    forwardRef,
    Input,
    OnDestroy,
    Output,
    QueryList,
    Renderer2,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { BehaviorSubject, combineLatest, Observable, Subject } from 'rxjs';
import { distinctUntilChanged, filter, map, startWith, takeUntil } from 'rxjs/operators';
import { isEqual as _isEqual } from 'lodash';
import { TsumSelect } from '../../tsum-select.namespace';
import OptionValueType = TsumSelect.OptionValueType;
import SelectType = TsumSelect.SelectType;
import SelectValuesEvent = TsumSelect.SelectValuesEvent;
import SelectOption = TsumSelect.SelectOption;
import { TsumSelectOptionValueDirective } from './tsum-select-option-value.directive';
import { TsumSelectHelper } from './tsum-select.helper';
import { TsumGeneralHelper } from '@tsum/utils';

@Directive({
    exportAs: 'tsumSelectDirective',
    selector: '[tsumSelectType]',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TsumSelectTypeDirective),
            multi: true,
        },
    ],
})
export class TsumSelectTypeDirective implements ControlValueAccessor, AfterViewInit, OnDestroy {
    /**
     * Тип директивы. Обязательное поле.
     *
     * single
     * Опциональный выбор одного значения.
     * Возможность снять выбранное значение.
     * В ответ одно значение или null.
     *
     * singleArray
     * Опциональный выбор одного значения.
     * Возможность снять выбранное значение.
     * В ответ массив из одного значения или пустой массив.
     *
     * multiple
     * Опциональный выбор нескольких значений.
     * Возможность снять выбранное значение.
     * В ответ массив из нескольких значений или пустой массив.
     *
     * radio
     * Обязательный выбор одного значения.
     * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
     * Нельзя снять выбранное значение.
     * В ответ одно значение.
     * Если опций нет, то null.
     *
     * radioArray
     * Обязательный выбор одного значения.
     * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
     * Нельзя снять выбранное значение.
     * В ответ массив из одного значения.
     * Если опций нет, то пустой массив.
     */
    @Input('tsumSelectType')
    public set selectType(selectType: SelectType) {
        this.selectTypeSubject$.next(selectType);
    }

    public get selectType(): SelectType {
        return this.selectTypeSubject$.value;
    }

    /**
     * Автоматически выбирает кликнутую опцию.
     * Для реализации кастомного выбора необходимо отключить.
     */
    @Input()
    public isSelectOptionByClick: boolean = true;

    @Input()
    public activeClassName: string = TsumSelect.activeClassName;

    @Input()
    public disabledClassName: string = TsumSelect.disabledClassName;

    @Input()
    public set disabled(value: boolean) {
        this.setDisabledState(value);
    }

    /**
     * Событие изменения значения.
     */
    @Output('valueChanged')
    public onChangeFormControlValue$ = new EventEmitter<OptionValueType[] | OptionValueType>();

    /**
     * Клик по опции, срабатывает не зависимо от логики выбора значения, а также флага disabled.
     */
    @Output('clickToOption')
    public onClickToOption$ = new EventEmitter<TsumSelect.ClickToOptionEvent>();

    @ContentChildren(TsumSelectOptionValueDirective, { descendants: true })
    public optionValueDirectivesList: QueryList<TsumSelectOptionValueDirective>;

    public selectType$: Observable<SelectType>;

    /**
     * Получить observable на выбранное значение.
     */
    public selectedValue$: Observable<OptionValueType[] | OptionValueType>;

    /**
     * Получить выбранное значение.
     */
    public get selectedValue(): OptionValueType[] | OptionValueType {
        return this.selectedValueSubject$.value;
    }

    private selectedValueSubject$ = new BehaviorSubject<OptionValueType[] | OptionValueType>(null);

    /**
     * Событие выбора значения, которое происходит до обработки выбранных значений.
     * Итоговое выбранное значение может быть другим (поэтому не является публичным свойством).
     * BehaviorSubject нужен т.к хук ngAfterViewInit, в котором доступны опции,
     * выполняется после хука writeValue, в котором устанавливаются значения в контроле.
     */
    private onSelectValuesSubject$ = new BehaviorSubject<SelectValuesEvent>(null);
    private onSelectValues$: Observable<SelectValuesEvent> = this.onSelectValuesSubject$
        .pipe(distinctUntilChanged(_isEqual));

    private isDisabled = false;
    private selectTypeSubject$ = new BehaviorSubject(null);

    private destroyed$ = new Subject<void>();

    constructor(
        private renderer: Renderer2,
        private el: ElementRef,
    ) {
        this.selectType$ = this.selectTypeSubject$.pipe(distinctUntilChanged());
        this.selectedValue$ = this.selectedValueSubject$.asObservable();
    }

    public ngAfterViewInit(): void {
        if (!this.selectType) {
            console.error('The input "tsumSelectType" in "TsumSelectTypeDirective" has to be set');
            console.error('All possible values you can find in the type "SelectType" in the namespace "TsumSelect"');
        }

        const optionValueDirectives$: Observable<TsumSelectOptionValueDirective[]> = this.optionValueDirectivesList.changes
            .pipe(
                startWith(this.optionValueDirectivesList),
                map((queryList: QueryList<TsumSelectOptionValueDirective>) => queryList.toArray()),
            );

        // TODO В задаче CMI-3436 Сделать чтобы optionValueDirectives$ эмитилось не только при изменении списка опций,
        //  а еще при изменеии disable инпута в каждой опции,
        //  тогда будет работать динамический выбор новой радио опции, если выбрана опция стала disabled.

        const selectOptions$: Observable<SelectOption[]> = optionValueDirectives$.pipe(map(TsumSelectHelper.toSelectOptionsData));

        /**
         * Основная логика выбора значений
         */
        this.onSelectValuesSubject$
            .pipe(
                filter(Boolean),
                takeUntil(this.destroyed$),
            )
            .subscribe((selectEvent: SelectValuesEvent) => {
                const { resultValue, isNeedChangeControlValue } = TsumSelectHelper.processValueSelection(
                    this.selectType,
                    selectEvent,
                    TsumSelectHelper.toSelectOptionsData(this.optionValueDirectivesList.toArray()),
                    this.selectedValue,
                );

                if (isNeedChangeControlValue) {
                    setTimeout(() => this.onChange(resultValue));
                }

                this.selectedValueSubject$.next(resultValue);
                this.onChangeFormControlValue$.emit(resultValue);
            });

        // /**
        //  * Если опции или тип селектора поменялись, то проверяем необходимость выбора нового значения
        //  * и меняем только если значение изменилось, чтобы избежать лишних эмитов
        //  */
        combineLatest([this.selectType$, selectOptions$])
            .pipe(takeUntil(this.destroyed$))
            .subscribe(([selectType, selectOption]: [SelectType, SelectOption[]]) => {
                if (!selectType) {
                    return;
                }

                const newSelectedValue: OptionValueType[] | OptionValueType = TsumSelectHelper.setValueByType(
                    selectType,
                    selectOption,
                    TsumSelectHelper.optionValueToArray(this.selectedValue),
                );

                if (!_isEqual(newSelectedValue, this.selectedValue)) {
                    this.setValue(newSelectedValue);
                }
            });

        // /**
        //  * Установка активности опций
        //  */
        combineLatest([this.selectedValue$, optionValueDirectives$])
            .pipe(takeUntil(this.destroyed$))
            .subscribe(([selectedValue, optionValueDirectives]: [
                OptionValueType[] | OptionValueType,
                TsumSelectOptionValueDirective[]
            ]) => this.markSelectedOptions(optionValueDirectives, selectedValue));

        // /**
        //  * Обработка клика по опции
        //  */
        optionValueDirectives$
            .pipe(
                TsumSelectHelper.switchMapToClickToOptionEvent,
                takeUntil(this.destroyed$),
            )
            .subscribe((clickToOptionEvent: TsumSelect.ClickToOptionEvent) => this.onClickToOption(clickToOptionEvent));
    }

    /**
     * Основная функция выбора значения.
     */
    public selectValue(newValue: OptionValueType | OptionValueType[]): void {
        this.onSelectValuesSubject$.next({
            newValue,
            eventType: 'select',
        });
    }

    /**
     * Основная функция замены выбранных значений.
     */
    public setValue(newValue: OptionValueType | OptionValueType[]): void {
        this.onSelectValuesSubject$.next({
            newValue,
            eventType: 'set',
        });
    }

    public registerOnTouched(fn: () => {}): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: () => {}): void {
        this.onChange = fn;
    }

    /**
     * Не использовать как внешнее API. Вместо этого применять функцию setValue
     */
    public writeValue(newValue: OptionValueType | OptionValueType[]): void {
        this.onSelectValuesSubject$.next({ newValue, eventType: 'writeValue' });
    }

    /**
     * Не использовать как внешнее API. Вместо этого изменять динамически через formControl или устанавливать атрибут в html
     */
    public setDisabledState(isDisabled: boolean): void {
        this.isDisabled = TsumGeneralHelper.isPropertyActive(isDisabled);

        isDisabled
            ? this.renderer.addClass(this.el.nativeElement, this.disabledClassName)
            : this.renderer.removeClass(this.el.nativeElement, this.disabledClassName);
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private onClickToOption(event: TsumSelect.ClickToOptionEvent): void {
        this.onClickToOption$.emit(event);

        if (!this.isSelectOptionByClick) {
            return;
        }

        if (this.isDisabled || event.option.disabled) {
            return;
        }

        this.selectValue(event.option.value);
    }

    private markSelectedOptions(
        valueDirectives: TsumSelectOptionValueDirective[],
        selectedValue: OptionValueType[] | OptionValueType,
    ): void {
        if (!valueDirectives) {
            return;
        }

        valueDirectives.forEach((valueDirective: TsumSelectOptionValueDirective) => {
            if (
                Array.isArray(selectedValue)
                && selectedValue.some((value: OptionValueType) => _isEqual(value, valueDirective.value))
                || _isEqual(selectedValue, valueDirective.value)
            ) {
                this.renderer.addClass(valueDirective.el.nativeElement, this.activeClassName);
                valueDirective.selected = true;
            } else {
                this.renderer.removeClass(valueDirective.el.nativeElement, this.activeClassName);
                valueDirective.selected = false;
            }
        });
    }

    private onChange = (value: OptionValueType | OptionValueType[]) => {};

    private onTouched = () => {};
}
