import {
    Directive,
    Input,
    ElementRef,
    Renderer2,
    Inject,
} from '@angular/core';
import {
    TsumPositioningService,
    TsumPlatformEventListenerService,
    TsumPositioning,
    TsumDynamicComponentsService,
} from '@tsum/utils';

import {
    TsumUploaderComponent,
} from '../components/tsum-uploader/tsum-uploader.component';
import {
    TsumDynamicPositioningPopupDirective,
} from '../../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.directive';
import {
    TsumPositioningPopup,
} from '../../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.namespace';
import { TsumUploader } from '../tsum-uploader.namespace';
import {
    TSUM_POSITIONING_CONFIG,
} from '../../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.constant';

@Directive({
    selector: '[tsumUploader]',
})
export class TsumUploaderDirective extends TsumDynamicPositioningPopupDirective<TsumUploader.FileLoaded[], TsumUploaderComponent> {
    @Input('tsumUploader')
    public set setup(value: Omit<TsumPositioningPopup.Config<TsumUploaderComponent>, 'component'>)  {
        this.config = {
            ...this.injectionConfig,
            ...{
                preferablePositions: [
                    TsumPositioning.Direction.Bottom,
                    TsumPositioning.Direction.BottomRight,
                    TsumPositioning.Direction.Right,
                ],
                offset: 16,
            },
            ...value,
            component: TsumUploaderComponent
        };
    }

    constructor(
        el: ElementRef,
        tsumDynamicComponentsService: TsumDynamicComponentsService,
        tsumUtilsPositioningService: TsumPositioningService,
        tsumEventEmitterService: TsumPlatformEventListenerService,
        render: Renderer2,
        @Inject(TSUM_POSITIONING_CONFIG)
        private injectionConfig: TsumPositioningPopup.Config<TsumUploaderComponent>,
    ) {
        super(
            el,
            tsumDynamicComponentsService,
            tsumUtilsPositioningService,
            tsumEventEmitterService,
            render,
        );
    }
}
