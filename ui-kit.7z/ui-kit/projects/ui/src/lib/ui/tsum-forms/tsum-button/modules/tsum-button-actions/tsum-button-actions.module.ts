import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumButtonActionsComponent } from './tsum-button-actions.component';
import { TsumIconsModule } from '../../../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumPopoverModule } from '../../../../tsum-common/tsum-popover/tsum-popover.module';

const COMPONENTS = [
    TsumButtonActionsComponent,
];

@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
        TsumPopoverModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumButtonActionsModule { }
