export namespace TsumSelector {
    export interface SelectorOptionForm {
        active: boolean;
        value: string;
    }

    export interface Option<T> {
        title: string;
        value: T;
    }
}
