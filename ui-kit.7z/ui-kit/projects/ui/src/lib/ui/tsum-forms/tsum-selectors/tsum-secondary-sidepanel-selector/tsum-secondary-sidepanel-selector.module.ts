import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumSelectorModule } from '../tsum-selector.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TsumButtonModule } from '../../tsum-button/tsum-button.module';
import { TsumSecondarySidepanelSelectorComponent } from './tsum-secondary-sidepanel-selector.component';

const COMPONENTS = [
    TsumSecondarySidepanelSelectorComponent,
];

/**
 * Secondary sidepanel button selector
 * Позволяет работать с данной кнопкой как селектором, принимает все те же опции что и обычная кнопка
 * Список инпутов
 * options - Список опций в селекторе
 * countColumns - Количество колонок, по умолчанию 1
 * type - тип селектора, могут быть
 * single
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ одно значение или null.
 *
 * singleArray
 * Опциональный выбор одного значения.
 * Возможность снять выбранное значение.
 * В ответ массив из одного значения или пустой массив.
 *
 * multiple
 * Опциональный выбор нескольких значений.
 * Возможность снять выбранное значение.
 * В ответ массив из нескольких значений или пустой массив.
 *
 * radio
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ одно значение.
 * Если опций нет, то null.
 *
 * radioArray
 * Обязательный выбор одного значения.
 * Если значение в formControl не выбрано, будет выбрано значение первой доступной опции
 * Нельзя снять выбранное значение.
 * В ответ массив из одного значения.
 * Если опций нет, то пустой массив.
 *
 * @example <tsum-secondary-sidepanel-selector type="multiple" [options]="options" [formControl]="form"></tsum-secondary-sidepanel-selector>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/forms-selector--as-secondary-sidepanel-button}
 */
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TsumSelectorModule,
        TsumButtonModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumSecondarySidepanelSelectorModule { }
