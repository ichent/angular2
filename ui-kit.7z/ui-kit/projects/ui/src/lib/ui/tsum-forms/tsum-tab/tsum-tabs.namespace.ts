import { TemplateRef } from '@angular/core';

export namespace TsumTab {
    export interface Tab<T = string | number | object> {
        label?: TemplateRef<any> | string;
        content?: TemplateRef<any>;
        active: boolean;
        value: T;
        badge?: number;
        width?: number;
    }
}
