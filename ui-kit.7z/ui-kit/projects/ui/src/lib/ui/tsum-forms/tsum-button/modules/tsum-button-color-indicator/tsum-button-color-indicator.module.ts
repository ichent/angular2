import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumButtonColorIndicatorComponent } from './tsum-button-color-indicator.component';
import { TsumIconsModule } from '../../../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumIndicatorModule } from '../../../../tsum-utils/tsum-indicator/tsum-indicator.module';

const COMPONENTS = [
    TsumButtonColorIndicatorComponent,
];

@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
        TsumIndicatorModule
    ],
    declarations: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ]
})
export class TsumButtonColorIndicatorModule { }
