import { Component, ElementRef, AfterViewInit, EventEmitter, Host, OnDestroy, HostListener } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { delay, tap, takeUntil, skip } from 'rxjs/operators';
import { TsumClickOutsideDirective } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.directive';

@Component({
    selector: 'tsum-dynamic-base',
    templateUrl: './tsum-dynamic-base.component.html',
})
export class TsumDynamicBaseComponent<T> implements AfterViewInit, OnDestroy {
    // tslint:disable-next-line:member-ordering
    public closeComponentSubject$ = new Subject<void | T>();
    public closeComponent$: Observable<void | T> = this.closeComponentSubject$.asObservable()
        .pipe(
            delay(100)
        );

    public render$ = new EventEmitter<void>();
    public clickOutside$ = new EventEmitter<void>();
    public destroyed$ = new Subject<void>();
    public hovered$ = new EventEmitter<boolean>();
    public hoveredMainElement$ = new BehaviorSubject<boolean>(false);
    public hoveredInnerElement$ = new BehaviorSubject<boolean>(false);

    constructor(
        public el: ElementRef,
        public tsumClickOutsideDirective: TsumClickOutsideDirective,
    ) {
        this.tsumClickOutsideDirective?.clickOutside$
            .pipe(
                takeUntil(
                    this.destroyed$,
                )
            )
            .subscribe(() => this.clickOutside$.emit());

        this.hoveredMainElement$.asObservable()
            .pipe(
                takeUntil(this.destroyed$),
                skip(1),
                delay(100),
            )
            .subscribe((isHovered: boolean) => {
                if (!isHovered && !this.hoveredInnerElement$.getValue()) {
                    this.hovered$.emit(false);
                }
            });
    }

    public ngAfterViewInit(): void {
        this.render$.next();
    }

    @HostListener('mouseenter')
    public onMouseEnter(): void {
        this.hoveredInnerElement$.next(true);

        this.hovered$.emit(true);
    }

    @HostListener('mouseleave')
    public onMouseLeave(): void {
        this.hoveredInnerElement$.next(false);

        if (!this.hoveredMainElement$.getValue()) {
            this.hovered$.emit(false);
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
