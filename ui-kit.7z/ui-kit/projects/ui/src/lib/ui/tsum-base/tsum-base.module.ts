import { NgModule, ComponentRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumDatepickerModule } from '../tsum-forms/tsum-datepicker/complex/tsum-datepicker.module';
import { TsumClickOutsideModule } from '../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumConfirmModule } from '../tsum-notifications/tsum-confirm/tsum-confirm.module';
import { TsumIconsModule } from '../tsum-utils/tsum-icons/tsum-icons.module';
import {
    TsumIncludeIndicatorModule,
} from '../tsum-utils/tsum-include-indicator/tsum-include-indicator.module';
import {
    TsumButtonColorIndicatorModule,
} from '../tsum-forms/tsum-button/modules/tsum-button-color-indicator/tsum-button-color-indicator.module';
import { TsumButtonActionsModule } from '../tsum-forms/tsum-button/modules/tsum-button-actions/tsum-button-actions.module';
import { TsumPopoverModule } from '../tsum-common/tsum-popover/tsum-popover.module';
import { TsumButtonModule } from '../tsum-forms/tsum-button/tsum-button.module';
import { TsumAirMessageWrapperComponent } from '../tsum-notifications/tsum-air-message/components/wrapper/tsum-air-message-wrapper.component';
import { TsumNotificationService } from '../tsum-notifications/tsum-air-message/services/tsum-notification.service';
import { TsumNotification } from '../tsum-notifications/tsum-air-message/tsum-air-message.namespace';
import { TsumSidenavModule } from '../tsum-layout/tsum-sidenav/tsum-sidenav.module';
import { TsumAirMessagesModule } from '../tsum-notifications/tsum-air-message/tsum-air-message.module';
import { TsumDynamicBaseComponent } from './tsum-dynamic-base/tsum-dynamic-base.component';

/**
 * @description Base module, import this module in your AppModule.
 * @description Without this import, dynamic components not working
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
        TsumDatepickerModule,
        TsumClickOutsideModule,
        TsumConfirmModule,
        TsumIncludeIndicatorModule,
        TsumButtonColorIndicatorModule,
        TsumButtonActionsModule,
        TsumPopoverModule,
        TsumButtonModule,
        TsumSidenavModule,
        TsumAirMessagesModule,
    ],
    exports: [
        TsumDatepickerModule,
        TsumConfirmModule,
        TsumDynamicBaseComponent,
    ],
    declarations: [ TsumDynamicBaseComponent ],
})
export class TsumBaseModule {
    constructor(
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
        private tsumNotificationService: TsumNotificationService,
    ) {
        /** Чистим старые */
        document.querySelectorAll('tsum-air-messages').forEach((x: HTMLElement) => x.remove());

        const ref: ComponentRef<TsumAirMessageWrapperComponent> = this.tsumDynamicComponentsService
            .createComponent(TsumAirMessageWrapperComponent);

        this.tsumNotificationService.notifications$
            .subscribe((notifications: TsumNotification.Notification[]) => {
                ref.instance.notifications = notifications;

                if (!ref.instance.changeDetectorRef['destroyed']) {
                    ref.instance.changeDetectorRef.detectChanges();
                }
            });
    }
}
