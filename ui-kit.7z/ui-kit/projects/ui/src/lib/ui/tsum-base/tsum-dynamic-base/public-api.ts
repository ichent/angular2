export * from './tsum-dynamic-base.component';
