export const STRING = 'string';
