import { Component, Input, ChangeDetectionStrategy, HostBinding } from '@angular/core';

/**
 * @description Footer for layout
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-footer--default}
 */
@Component({
    selector: 'tsum-footer',
    templateUrl: './tsum-footer.component.html',
    styleUrls: ['./tsum-footer.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumFooterComponent {
    @Input() public title = '© 1933 – 2020 ООО «Торговый дом ЦУМ». Все права защищены';

    @HostBinding('class.main-big-dark-gray')
    public fontClass = true;
}
