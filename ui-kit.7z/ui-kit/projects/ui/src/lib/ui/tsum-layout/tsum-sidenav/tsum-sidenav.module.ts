import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumSidenavHeaderDirective } from './directives/tsum-sidenav-header.directive';
import { TsumSidenavFooterDirective } from './directives/tsum-sidenav-footer.directive';
import { TsumSidenavTabsDirective } from './directives/tsum-sidenav-full-width.directive';
import { TsumClickOutsideModule } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumSidenavDividerComponent } from './tsum-sidenav-divider/tsum-sidenav-divider.component';
import { TsumSidenavComponent } from './tsum-sidenav.component';
import { TsumScrollModule } from '../../tsum-common/tsum-scroll/tsum-scroll.module';

const DIRECTIVES = [
    TsumSidenavHeaderDirective,
    TsumSidenavFooterDirective,
    TsumSidenavTabsDirective,
];

const COMPONENTS = [
    TsumSidenavDividerComponent,
    TsumSidenavComponent,
];

/**
 * @description Sidenav service
 * @description Uses for dynamically create sidenav via tsumSidenavService
 * @example tsumSidenavService.openSidenav(SidenavComponent).then(...);
 * @description Before it you should create component for sidenav
 * @example <div *tsumSidenavHeader>Header</div>
 * @example <div>Content</div>
 * @example <div *tsumSidenavFooter>Footer</div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-sidenav--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumClickOutsideModule,
        TsumIconsModule,
        TsumScrollModule,
    ],
    declarations: [
        ...DIRECTIVES,
        ...COMPONENTS,
    ],
    providers: [
        TsumDynamicComponentsService,
    ],
    entryComponents: [
        TsumSidenavComponent,
    ],
    exports: [
        ...DIRECTIVES,
        ...COMPONENTS,
    ],
})
export class TsumSidenavModule {}
