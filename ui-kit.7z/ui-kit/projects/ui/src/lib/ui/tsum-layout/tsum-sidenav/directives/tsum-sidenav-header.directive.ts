import { AfterViewInit, Directive, Input, Optional, TemplateRef } from '@angular/core';
import { TsumSidenavComponent } from '../tsum-sidenav.component';

export type SidenavHeaderType = 'title' | 'subtitle';

/**
 * @description Header of sidenav
 * @description Header can have title of subtitle style, just send input 'tsumSidenavHeader'
 * @description You can change close icon via sending 'tsumSidenavHeaderCloseIcon'
 * @example <div tsumSidenavHeader>Header</div>
 */
@Directive({
    selector: '[tsumSidenavHeader]',
})
export class TsumSidenavHeaderDirective implements AfterViewInit {

    @Input('tsumSidenavHeader')
    public type: SidenavHeaderType = 'title';

    @Input('tsumSidenavHeaderCloseIcon')
    public icon: boolean = true;

    constructor(
        private templateRef: TemplateRef<void>,
        @Optional() private sidenavComponent: TsumSidenavComponent,
    ) {}

    public ngAfterViewInit(): void {
        if (this.sidenavComponent) {
            this.sidenavComponent.registerHeader(this.templateRef, this.type === 'subtitle', !this.icon);
        }
    }

}
