/**
 * @description Namespace for TsumLayoutHeader
 */
export namespace TsumLayoutHeader {
    export interface Route {
        title: string;
        route: string;
        countNotification?: number;
        isPopover?: boolean;
        isSubheader?: boolean;
        disabled?: boolean;
        childs?: Route[];
    }
}
