import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumBreadcrumbComponent } from './element/tsum-breadcrumb.component';
import { TsumBreadcrumbListComponent } from './list/tsum-breadcrumb-list.component';

const COMPONENTS = [
    TsumBreadcrumbComponent,
    TsumBreadcrumbListComponent,
];

/**
 * Модуль с хлебными крошками
 * Есть два метода работы с данным модулем:
 * 1 - Делаем хлебные крошки сами из отдельных компонентов
 * 2 - Используем список, передаем массив "крошек" и работает с этим
 * @example
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-breadcrumb--element}
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-breadcrumb--list}
 */
@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumBreadcrumbModule { }
