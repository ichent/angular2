import {
    Component,
    Input,
    Renderer2,
    ElementRef,
    HostBinding,
    OnDestroy,
    ChangeDetectionStrategy,
    Host,
} from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

import { TsumClickOutsideDirective } from './../../tsum-utils/tsum-click-outside/tsum-click-outside.directive';
import { SlideToShowAnimation200 } from '../../tsum-core/animations/slide-to-show.animation';
import { TsumAnimation } from '../../tsum-core/animations/animation.namespace';
import { TsumDynamicBaseComponent } from '../../tsum-base/tsum-dynamic-base/tsum-dynamic-base.component';

export type TsumProfileEmitType = 'manage' | 'logout';

@Component({
    selector: 'tsum-profile',
    templateUrl: './tsum-profile.component.html',
    styleUrls: ['./tsum-profile.component.styl'],
    animations: [
        SlideToShowAnimation200,
    ],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        TsumClickOutsideDirective,
    ],
})
export class TsumProfileComponent
    extends TsumDynamicBaseComponent<TsumProfileEmitType>
    implements OnDestroy {
    @Input()
    public photoUrl = '';

    @Input()
    public name = 'NO NAME';

    @Input()
    @TsumInputBoolean()
    public hideManage = false;

    @HostBinding('@slideToShowAnimation')
    public isInit: TsumAnimation.State = TsumAnimation.State.In;

    constructor(
        public el: ElementRef,
        private renderer: Renderer2,
        @Host() public tsumClickOutsideDirective: TsumClickOutsideDirective,
    ) {
        super(el, tsumClickOutsideDirective);
    }

    public setStyle(property: string, value: string): void {
        this.renderer.setStyle(this.el.nativeElement, property, value);
    }

    public manage(): void {
        this.closeComponentSubject$.next('manage');
    }

    public logout(): void {
        this.closeComponentSubject$.next('logout');
    }
}
