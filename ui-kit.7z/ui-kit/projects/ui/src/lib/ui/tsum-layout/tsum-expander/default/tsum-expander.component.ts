import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { trigger, state, transition, animate, style } from '@angular/animations';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { TsumIcon } from '../../../tsum-utils/tsum-icons/tsum-icon.namespace';

/**
 * Раскрывающийся контент(спойлер)
 * Прокидываем input - title с заголовком
 * И внутрь кидаем контент
 * @example <tsum-expander title="hello">Winter is coming</tsum-expander>
 * {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-expander--default}
 */
@Component({
    selector: 'tsum-expander',
    templateUrl: './tsum-expander.component.html',
    styleUrls: ['./tsum-expander.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    animations: [
        trigger('expandCollapse', [
            state('open', style({
                height: '*',
                paddingTop: '16px',
            })),
            state('close', style({
                height: '0px',
            })),
            transition('open <=> close', animate(200)),
        ]),
        trigger('rotateZ', [
            state('open', style({
                transform: 'rotateZ(180deg)',
            })),
            state('close', style({
                transform: 'rotateZ(0deg)',
            })),
            transition('open <=> close', animate(200)),
        ]),
    ]
})
export class TsumExpanderComponent {
    @Input() public title = '';

    @Input() public subtitle: string;

    public iconName = TsumIcon.Arrows.ListDown;

    public expanded$: Observable<boolean>;
    public animationState$: Observable<string>;

    private expandedSubject$ = new BehaviorSubject<boolean>(false);

    constructor() {
        this.expanded$ = this.expandedSubject$.asObservable();
        this.animationState$ = this.expanded$.pipe(
            map((isExpanded: boolean) => isExpanded ? 'open' : 'close'),
        );
    }

    public toggleExpand(): void {
        this.expandedSubject$.next(this.expandedSubject$.getValue() === false);
    }
}
