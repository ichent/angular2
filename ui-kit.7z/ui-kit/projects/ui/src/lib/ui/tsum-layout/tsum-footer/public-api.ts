export * from './tsum-footer.component';
export * from './tsum-footer.module';
