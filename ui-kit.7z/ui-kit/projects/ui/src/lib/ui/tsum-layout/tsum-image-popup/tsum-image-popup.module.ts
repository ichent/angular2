import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumImagePopupComponent } from './tsum-image-popup.component';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumClickOutsideModule } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumImagePopupDirective } from './tsum-image-popup.directive';

const COMPONENTS = [
    TsumImagePopupComponent,
];

const DIRECTIVES = [
    TsumImagePopupDirective,
];

@NgModule({
    imports: [
        CommonModule,
        TsumClickOutsideModule,
        TsumIconsModule,
    ],
    declarations: [
        COMPONENTS,
        DIRECTIVES,
    ],
    exports: [
        COMPONENTS,
        DIRECTIVES,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumImagePopupModule { }
