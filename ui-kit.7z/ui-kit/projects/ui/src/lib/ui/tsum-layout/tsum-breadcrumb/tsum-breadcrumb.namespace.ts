export namespace TsumBreadcrumb {
    export type State = 'active' | 'inactive';

    export interface Element {
        title: string;
        callback?: () => void;
    }
}
