import { Component } from '@angular/core';

@Component({
    selector: 'tsum-content-header',
    templateUrl: './tsum-content-header.component.html',
    styleUrls: ['./tsum-content-header.component.styl']
})
export class TsumContentHeaderComponent {
}
