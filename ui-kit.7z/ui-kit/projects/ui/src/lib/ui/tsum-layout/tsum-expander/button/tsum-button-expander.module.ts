import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumButtonExpanderComponent } from './tsum-button-expander.component';
import { TsumIconsModule } from '../../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumButtonModule } from '../../../tsum-forms/tsum-button/tsum-button.module';
import { TsumScrollModule } from '../../../tsum-common/tsum-scroll/tsum-scroll.module';

const COMPONENTS = [
    TsumButtonExpanderComponent,
];

/**
 * Раскрывающийся контент(спойлер)
 * Прокидываем input - title с заголовком
 * И внутрь кидаем контент
 * @example <tsum-button-expander title="hello">Winter is coming</tsum-button-expander>
 * {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-expander--as-button}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
        TsumButtonModule,
        TsumScrollModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumButtonExpanderModule { }
