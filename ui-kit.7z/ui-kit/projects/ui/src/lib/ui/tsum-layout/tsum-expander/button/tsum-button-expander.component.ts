import {
    Component,
    Input,
    ChangeDetectionStrategy,
    OnInit,
    ChangeDetectorRef,
    ElementRef,
    OnDestroy,
    HostBinding,
    Renderer2,
} from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map, tap, takeUntil, distinctUntilChanged } from 'rxjs/operators';

import { TsumIcon } from '../../../tsum-utils/tsum-icons/tsum-icon.namespace';

/**
 * Раскрывающийся контент(спойлер)
 * Прокидываем input - title с заголовком
 * И внутрь кидаем контент
 * @example <tsum-button-expander title="hello">Winter is coming</tsum-button-expander>
 * {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-expander--as-button}
 */
@Component({
    selector: 'tsum-button-expander',
    templateUrl: './tsum-button-expander.component.html',
    styleUrls: ['./tsum-button-expander.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumButtonExpanderComponent implements OnInit, OnDestroy {
    @Input()
    public title = '';

    public expanded$: Observable<boolean>;

    public iconName$: Observable<string>;

    private expandedSubject$ = new BehaviorSubject<boolean>(false);
    private destroyed$ = new Subject<void>();

    @HostBinding('class._expanded')
    public get expanded(): boolean {
        return this.expandedSubject$.getValue();
    }

    constructor(
        private changeDetectorRef: ChangeDetectorRef,
        private elementRef: ElementRef,
        private renderer: Renderer2,
    ) {
        this.expanded$ = this.expandedSubject$.asObservable()
            .pipe(
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
                tap((isExpanded: boolean) => {
                    const element: HTMLElement = this.elementRef.nativeElement;

                    if (!element) {
                        return;
                    }

                    const contentElement: HTMLElement = element.querySelector('.tsum-button-expander__content');
                    const buttonElement: HTMLElement = element.querySelector('.tsum-button-expander__button');
                    const dummyElement: HTMLElement = element.querySelector('.tsum-button-expander__dummy');

                    if (!contentElement || !buttonElement || !dummyElement) {
                        return;
                    }

                    /**
                     * Устанавливаем для родителя стиль position: relative
                     * Далее устанавливаем высоту контента за вычетом высоты кнопки
                     * А так же устанавливаем высоту заглушки, что бы при раскрытии у нас кнопка не убирала высоту
                     */
                    if (isExpanded) {
                        this.renderer.setStyle(element.parentNode, 'position', 'relative');
                        this.renderer.setStyle(
                            contentElement, 'paddingTop', `${buttonElement.offsetHeight}px`,
                        );
                        this.renderer.setStyle(
                            contentElement, 'height', `calc(100% - ${buttonElement.offsetHeight}px)`,
                        );
                        this.renderer.setStyle(
                            dummyElement, 'height', `${buttonElement.offsetHeight}px`,
                        );

                        /** Дожидаемся анимации */
                        setTimeout(() => {
                            const newButtonElement: HTMLElement = element.querySelector('.tsum-button-expander__button');
                            const scrollHeight = contentElement.offsetHeight - newButtonElement.offsetHeight;

                            this.renderer.setStyle(
                                element.querySelector('tsum-scroll'), 'height', `${scrollHeight}px`,
                            );
                        });
                    } else {
                        this.renderer.setStyle(contentElement, 'paddingTop', '0px');
                        this.renderer.setStyle(contentElement, 'height', '0px');
                        this.renderer.setStyle(dummyElement, 'height', '0px');
                    }
                }),
            );
    }

    public ngOnInit(): void {
        this.iconName$ = this.expandedSubject$.pipe(
            map((isExpanded: boolean) => isExpanded ? TsumIcon.Arrows.ListDown : TsumIcon.Arrows.ListUp),
            tap(() => this.changeDetectorRef.detectChanges()),
        );
    }

    public toggleExpand(): void {
        this.expandedSubject$.next(this.expandedSubject$.getValue() === false);
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
