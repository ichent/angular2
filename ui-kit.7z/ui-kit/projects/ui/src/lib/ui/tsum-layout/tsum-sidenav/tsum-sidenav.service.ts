import { ComponentRef, Injectable, Optional, SkipSelf, Type, ViewContainerRef } from '@angular/core';
import { TsumSidenavComponent } from './tsum-sidenav.component';
import { asapScheduler, EMPTY, scheduled } from 'rxjs';
import { TsumDynamicComponentsService } from '@tsum/utils';

/**
 * @description Sidenav service
 * @description Uses for dynamically create sidenav via tsumSidenavService
 * @example tsumSidenavService.openSidenav(SidenavComponent).then(...);
 */
@Injectable({
    providedIn: 'root',
})
export class TsumSidenavService {

    private refs = new Map<Type<any>, ComponentRef<TsumSidenavComponent>>([]);

    constructor(
        private dynamicService: TsumDynamicComponentsService,
        @Optional() @SkipSelf() private parentSidenavService: TsumSidenavService, // если нужен доступ к глобальным сайднавам
    ) {}

    /**
     * @description Opens sidenav
     * @description first argument is component
     * @description Second argument is data, is state of current component
     * @description Thirds argument is immortal, it means what sidenav don't remove sidenav in dom
     */
    public openSidenav<C>(component: Type<C>, data?: Partial<C>, immortal?: boolean): Promise<void> {
        if (this.refs.has(component)) {
            return this.refs.get(component).instance.open();
        }

        const sidenavRef: ComponentRef<TsumSidenavComponent> = this.dynamicService.createComponent(TsumSidenavComponent);
        this.refs.set(component, sidenavRef);

        const viewContainer: ViewContainerRef = sidenavRef.instance.containerRef;
        const componentRef: ComponentRef<C> = this.dynamicService.createComponent(component, { viewContainer });

        if (data) {
            Object.keys(data).forEach((key: string) => componentRef.instance[key] = data[key]);
        }

        if (!immortal) {
            scheduled(sidenavRef.instance.closed$, asapScheduler)
                .subscribe(() => {
                    this.destroySidenav(sidenavRef);
                    this.refs.delete(component);
                });
        }

        sidenavRef.changeDetectorRef.detectChanges();

        return sidenavRef.instance.open();
    }

    /**
     * @description Close sidenav, but not delete from DOM
     */
    public closeSidenav<C>(component: Type<C>): Promise<void> {
        if (!this.refs.has(component)) {
            return EMPTY.toPromise();
        }

        return this.refs.get(component).instance.close();
    }

    private destroySidenav<C>(sidenavRef: ComponentRef<TsumSidenavComponent>): void {
        this.dynamicService.deleteComponent(sidenavRef, null);
    }

}
