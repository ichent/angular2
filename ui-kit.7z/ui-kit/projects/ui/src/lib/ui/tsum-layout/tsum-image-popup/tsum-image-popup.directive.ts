import {
    Directive,
    OnDestroy,
    Input,
    ElementRef,
    Renderer2,
    Inject,
} from '@angular/core';
import {
    TsumPositioningService,
    TsumPlatformEventListenerService,
    TsumPositioning,
    TsumDynamicComponentsService,
} from '@tsum/utils';

import {
    TsumDynamicPositioningPopupDirective,
} from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.directive';
import {
    TsumPositioningPopup,
} from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.namespace';
import {
    TSUM_POSITIONING_CONFIG,
} from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.constant';
import { TsumImagePopupComponent } from './tsum-image-popup.component';

@Directive({
    selector: '[tsumImagePopup]'
})
export class TsumImagePopupDirective
    extends TsumDynamicPositioningPopupDirective<void, TsumImagePopupComponent>
    implements OnDestroy {

    @Input('tsumImagePopup')
    public set setup(value: TsumPositioningPopup.Config<TsumImagePopupComponent>) {
        this.config = {
            ...this.injectionConfig,
            ...{
                alignType: 'fixed',
                isHoverable: true,
                preferablePositions: [TsumPositioning.Direction.Bottom, TsumPositioning.Direction.Top],
                className: 'tsum-image-popup',
                props: {
                    photoUrl: '',
                },
            },
            ...value,
            component: TsumImagePopupComponent,
        };
    }

    constructor(
        el: ElementRef,
        tsumDynamicComponentsService: TsumDynamicComponentsService,
        tsumUtilsPositioningService: TsumPositioningService,
        tsumEventEmitterService: TsumPlatformEventListenerService,
        render: Renderer2,
        @Inject(TSUM_POSITIONING_CONFIG)
        private injectionConfig: TsumPositioningPopup.Config<TsumImagePopupComponent>,
    ) {
        super(
            el,
            tsumDynamicComponentsService,
            tsumUtilsPositioningService,
            tsumEventEmitterService,
            render,
        );
    }
}
