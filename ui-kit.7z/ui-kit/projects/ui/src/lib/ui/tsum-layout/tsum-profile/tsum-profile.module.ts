import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumProfileComponent } from './tsum-profile.component';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumClickOutsideModule } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumProfileDirective } from './tsum-profile.directive';

const COMPONENTS = [
    TsumProfileComponent,
];

const DIRECTIVES = [
    TsumProfileDirective,
];

@NgModule({
    imports: [
        CommonModule,
        TsumClickOutsideModule,
        TsumIconsModule,
    ],
    declarations: [
        COMPONENTS,
        DIRECTIVES,
    ],
    exports: [
        COMPONENTS,
        DIRECTIVES,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumProfileModule { }
