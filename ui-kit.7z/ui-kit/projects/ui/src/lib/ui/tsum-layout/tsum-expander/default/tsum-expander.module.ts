import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumExpanderComponent } from './tsum-expander.component';
import { TsumIconsModule } from '../../../tsum-utils/tsum-icons/tsum-icons.module';

const COMPONENTS = [
    TsumExpanderComponent,
];

/**
 * Раскрывающийся контент(спойлер)
 * Прокидываем input - title с заголовком
 * И внутрь кидаем контент
 * @example <tsum-expander title="hello">Winter is coming</tsum-expander>
 * {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-expander--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumExpanderModule { }
