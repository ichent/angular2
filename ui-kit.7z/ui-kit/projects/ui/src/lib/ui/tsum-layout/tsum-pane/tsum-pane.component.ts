import { Component, HostBinding, Input } from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

@Component({
    selector: 'tsum-pane',
    templateUrl: './tsum-pane.component.html',
    styleUrls: ['./tsum-pane.component.styl']
})
export class TsumPaneComponent {
    @TsumInputBoolean()
    @Input()
    @HostBinding('class._selected')
    public selected: boolean;

    @TsumInputBoolean()
    @Input()
    @HostBinding('class._warning')
    public warning = false;

    @TsumInputBoolean()
    @Input()
    @HostBinding('class._more-shadow')
    public moreShadow = false;
}
