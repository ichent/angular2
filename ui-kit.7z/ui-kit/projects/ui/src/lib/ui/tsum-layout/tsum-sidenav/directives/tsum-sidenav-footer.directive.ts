import { AfterViewInit, Directive, Input, Optional, TemplateRef } from '@angular/core';
import { TsumSidenavComponent } from '../tsum-sidenav.component';

export type SidenavFooterType = 'right' | 'left';

/**
 * @description Footer for sidenav
 * @description Just create component for sidenav and add footer directive
 * @description You can pass your content to right/left of footer sidenav
 * @example <div tsumSidenavFooter="right">Button</div>
 */
@Directive({
    selector: '[tsumSidenavFooter]',
})
export class TsumSidenavFooterDirective implements AfterViewInit {
    /**
     * @description Position of content
     */
    @Input('tsumSidenavFooter')
    public side: SidenavFooterType  = 'right';

    constructor(
        private templateRef: TemplateRef<void>,
        @Optional() private sidenavComponent: TsumSidenavComponent,
    ) {}

    public ngAfterViewInit(): void {
        if (this.sidenavComponent) {
            this.sidenavComponent.registerFooter(this.templateRef, this.side === 'left');
        }
    }

}
