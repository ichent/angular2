import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    EventEmitter,
    Output,
    TemplateRef,
    ViewChild,
    ViewContainerRef,
    ElementRef,
} from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { EMPTY } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TsumIcon } from '../../tsum-utils/tsum-icons/tsum-icon.namespace';

const animationTime = 200;

/**
 * @description Sidenav component
 * @description Uses for dynamically create sidenav via tsumSidenavService
 * @example tsumSidenavService.openSidenav(SidenavComponent).then(...);
 * @description Before it you should create component for sidenav
 * @example <div *tsumSidenavHeader>Header</div>
 * @example <div>Content</div>
 * @example <div *tsumSidenavFooter>Footer</div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-sidenav--default}
 */
@Component({
    selector: 'tsum-sidenav',
    templateUrl: './tsum-sidenav.component.html',
    styleUrls: ['./tsum-sidenav.component.styl'],
    animations: [
        trigger('sidenav', [
            state('true', style({
                opacity: 1,
                transform: 'translateX(0)',
            })),
            state('false', style({
                opacity: 0,
                transform: 'translateX(100%)',
            })),
            transition('true <=> false', [
                animate(animationTime),
            ]),
        ]),
    ],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumSidenavComponent {
    /**
     * @description Emits when close ends
     */
    @Output('closed')
    public closed$ = new EventEmitter<void>();

    @ViewChild('container', { read: ViewContainerRef, static: true })
    public containerRef: ViewContainerRef;

    @ViewChild('headerTitle', { read: ViewContainerRef, static: true })
    public headerTitleRef: ViewContainerRef;

    @ViewChild('headerSubtitle', { read: ViewContainerRef, static: false })
    public headerSubtitleRef: ViewContainerRef;

    @ViewChild('tabs', { read: ViewContainerRef, static: true })
    public tabsRef: ViewContainerRef;

    @ViewChild('footerLeft', { read: ViewContainerRef, static: true })
    public footerLeftRef: ViewContainerRef;

    @ViewChild('footerRight', { read: ViewContainerRef, static: true })
    public footerRightRef: ViewContainerRef;

    public closeIcon = TsumIcon.Actions.Close;
    public opened = false;
    public hasSubtitle = false;

    constructor(
        public el: ElementRef,
        private cd: ChangeDetectorRef,
    ) {}

    public registerHeader(templateRef: TemplateRef<void>, isSubtitle: boolean, noIcon: boolean): void {
        if (isSubtitle) {
            this.hasSubtitle = true;
            this.cd.detectChanges();
        }

        if (noIcon) {
            this.closeIcon = null;
        }

        const container: ViewContainerRef = isSubtitle ? this.headerSubtitleRef : this.headerTitleRef;
        container.createEmbeddedView(templateRef);
        this.cd.detectChanges();
    }

    public registerTabs(templateRef: TemplateRef<void>): void {
        this.tabsRef.createEmbeddedView(templateRef);
        this.cd.detectChanges();
    }

    public registerFooter(templateRef: TemplateRef<void>, isLeft: boolean): void {
        const container: ViewContainerRef = isLeft ? this.footerLeftRef : this.footerRightRef;
        container.createEmbeddedView(templateRef);
        this.cd.detectChanges();
    }

    public open(): Promise<void> {
        this.opened = true;
        this.cd.detectChanges();
        return EMPTY.pipe(delay(animationTime)).toPromise();
    }

    public close(): Promise<void> {
        this.opened = false;
        this.cd.detectChanges();
        return EMPTY.pipe(delay(animationTime)).toPromise().then(() => {
            this.closed$.emit();
        });
    }

}
