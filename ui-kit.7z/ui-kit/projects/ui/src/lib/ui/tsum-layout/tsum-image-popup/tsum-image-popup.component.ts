import {
    Component,
    Input,
    ElementRef,
    ChangeDetectionStrategy,
} from '@angular/core';

import { TsumDynamicBaseComponent } from '../../tsum-base/tsum-dynamic-base/tsum-dynamic-base.component';

@Component({
    selector: 'tsum-image-popup',
    templateUrl: './tsum-image-popup.component.html',
    styleUrls: ['./tsum-image-popup.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumImagePopupComponent extends TsumDynamicBaseComponent<string> {
    @Input()
    public photoUrl = '';

    constructor(
        public el: ElementRef,
    ) {
        super(el, null);
    }
}
