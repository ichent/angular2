import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumLayoutComponent } from './tsum-layout.component';

const COMPONENTS = [
    TsumLayoutComponent,
];

/**
 * @classdesc Component for layout
 * @example use <tsum-layout>Content</tsum-layout>
 * @example And you have multi slot - layout-header/layout-footer
 * @description by default content inserts in <ng-content></ng-content>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-layout--default}
 */
@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumLayoutModule { }
