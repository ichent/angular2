import { AfterViewInit, Directive, Optional, TemplateRef } from '@angular/core';
import { TsumSidenavComponent } from '../tsum-sidenav.component';

/**
 * @description Tabs for sidenav, by default you don't need tsumSidenavTabs
 * @description But if you need multiply of content in sidenav just implement this directive
 * @example <div *uiSidenavTabs *ngFor="let item of items">
 * @example   <div>{{ item.title }}</div>
 * @example </div>
 */
@Directive({
    selector: '[tsumSidenavTabs]',
})
export class TsumSidenavTabsDirective implements AfterViewInit {

    constructor(
        private templateRef: TemplateRef<void>,
        @Optional() private sidenavComponent: TsumSidenavComponent,
    ) {}

    public ngAfterViewInit(): void {
        this.sidenavComponent.registerTabs(this.templateRef);
    }

}
