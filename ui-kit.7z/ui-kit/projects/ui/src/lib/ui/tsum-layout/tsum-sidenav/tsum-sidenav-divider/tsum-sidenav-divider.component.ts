import { Component, Input } from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

@Component({
    selector: 'tsum-sidenav-divider',
    templateUrl: './tsum-sidenav-divider.component.html',
    styleUrls: ['./tsum-sidenav-divider.component.styl']
})
export class TsumSidenavDividerComponent {
    @TsumInputBoolean()
    @Input()
    public removeTopMargin: boolean = false;
}
