import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumContentHeaderComponent } from './tsum-content-header.component';
import { TsumTextOverflowTooltipModule } from '../../tsum-utils/tsum-text-overflow-tooltip/tsum-text-overflow-tooltip.module';

const COMPONENTS = [
    TsumContentHeaderComponent,
];

@NgModule({
    imports: [
        CommonModule,
        TsumTextOverflowTooltipModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumContentHeaderModule { }
