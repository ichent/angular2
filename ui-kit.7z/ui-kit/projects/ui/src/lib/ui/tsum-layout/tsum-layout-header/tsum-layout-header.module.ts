import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumLayoutHeaderComponent } from './tsum-layout-header.component';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumPopoverModule } from '../../tsum-common/tsum-popover/tsum-popover.module';
import { TsumNotificationAlertModule } from '../../tsum-notifications/tsum-notification-alert/tsum-notification-alert.module';

const COMPONENTS = [
    TsumLayoutHeaderComponent,
];

/**
 * @description Layout header component. Uses with tsum-layout
 * @description Make auto generate routes via input "routes"
 * @example you can use
 * <tsum-layout-header [routes]="routes" [activeRouteName]="activeRouteName$ | async" name="UI-KIT"></tsum-layout-header>
 * @example for routes you interface TsumLayoutHeader.Route[]
 * @example isSubheader uses for recursive, do not use this
 * @example [routes]="[{
 * @example   title: 'Test route name',
 * @example   route: '/test/route',
 * @example   childs?: [{
 * @example     title: 'Test child route name',
 * @example     route: '/test/route/child',
 * @example   }],
 * @example }]"
 * @example <tsum-layout-header [routes]="routes" [activeRouteName]="activeRouteName$ | async" name="UI-KIT"></tsum-layout-header>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-header--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
        TsumPopoverModule,
        TsumNotificationAlertModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
    providers: [
        TsumDynamicComponentsService,
    ]
})
export class TsumLayoutHeaderModule { }
