import { Component, Input, ChangeDetectionStrategy, HostBinding } from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * Модуль с хлебными крошками
 * Есть два метода работы с данным модулем:
 * 1 - Делаем хлебные крошки сами из отдельных компонентов
 * 2 - Используем список, передаем массив "крошек" и работает с этим
 * @example
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-breadcrumb--element}
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/layout-breadcrumb--list}
 */
@Component({
    selector: 'tsum-breadcrumb',
    templateUrl: './tsum-breadcrumb.component.html',
    styleUrls: ['./tsum-breadcrumb.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class.main-medium-black]': '!last',
        '[class.main-medium-dark-gray]': 'last',
    }
})
export class TsumBreadcrumbComponent {
    @TsumInputBoolean()
    @HostBinding('class._last')
    @Input()
    public last = false;
}
