import { Component, Input } from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * @classdesc Component for layout
 * @example use <tsum-layout>Content</tsum-layout>
 * @example And you have multi slot - layout-header/layout-footer
 * @description by default content inserts in <ng-content></ng-content>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-layout--default}
 */
@Component({
    selector: 'tsum-layout',
    templateUrl: './tsum-layout.component.html',
    styleUrls: ['./tsum-layout.component.styl']
})
export class TsumLayoutComponent {
    /**
     * @description Flag for set sticky header
     */
    @TsumInputBoolean()
    @Input()
    public stickyHeader = true;
}
