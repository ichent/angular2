import {
    Directive,
    OnDestroy,
    Input,
    ElementRef,
    Renderer2,
    Inject,
} from '@angular/core';
import {
    TsumPositioningService,
    TsumPlatformEventListenerService,
    TsumPositioning,
    TsumDynamicComponentsService,
} from '@tsum/utils';

import { TsumProfileComponent } from './tsum-profile.component';
import {
    TsumDynamicPositioningPopupDirective,
} from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.directive';
import {
    TsumPositioningPopup,
} from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.namespace';
import {
    TSUM_POSITIONING_CONFIG,
} from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.constant';

@Directive({
    selector: '[tsumProfile]'
})
export class TsumProfileDirective
    extends TsumDynamicPositioningPopupDirective<void, TsumProfileComponent>
    implements OnDestroy {
    @Input('tsumProfile')
    public set setup(value: TsumPositioningPopup.Config<TsumProfileComponent>) {
        this.config = {
            ...this.injectionConfig,
            ...{
                alignType: 'fixed',
                className: 'tsum-datepicker-wrapper',
                preferablePositions: [TsumPositioning.Direction.RightCorner],
                props: {
                    photoUrl: '',
                    name: '',
                    hideManage: false,
                },
            },
            ...value,
            component: TsumProfileComponent,
        };
    }

    constructor(
        el: ElementRef,
        tsumDynamicComponentsService: TsumDynamicComponentsService,
        tsumUtilsPositioningService: TsumPositioningService,
        tsumEventEmitterService: TsumPlatformEventListenerService,
        render: Renderer2,
        @Inject(TSUM_POSITIONING_CONFIG)
        private injectionConfig: TsumPositioningPopup.Config<TsumProfileComponent>,
    ) {
        super(
            el,
            tsumDynamicComponentsService,
            tsumUtilsPositioningService,
            tsumEventEmitterService,
            render,
        );
    }
}
