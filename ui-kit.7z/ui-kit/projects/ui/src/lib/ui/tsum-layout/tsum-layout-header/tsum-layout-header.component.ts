import { Component, Input, Output, EventEmitter } from '@angular/core';
import { TsumLayoutHeader } from './tsum-layout-header.namespace';
import { TsumPopover } from '../../tsum-common/tsum-popover/tsum-popover.namespace';
import { TsumPositioningPopup } from '../../tsum-common/tsum-dynamic-positioning-popup/tsum-dynamic-positioning-popup.namespace';
import { TsumPopoverComponent } from '../../tsum-common/tsum-popover/tsum-popover.component';

/**
 * @description Layout header component. Uses with tsum-layout
 * @description Make auto generate routes via input "routes"
 * @example you can use
 * <tsum-layout-header [routes]="routes" [activeRouteName]="activeRouteName$ | async" name="UI-KIT"></tsum-layout-header>
 * for routes you interface TsumLayoutHeader.Route[]
 * isSubheader uses for recursive, do not use this
 * [routes]="[{
 *   title: 'Test route name',
 *   route: '/test/route',
 *   childs?: [{
 *     title: 'Test child route name',
 *     route: '/test/route/child',
 *   }],
 * }]"
 * @example <tsum-layout-header [routes]="routes" [activeRouteName]="activeRouteName$ | async" name="UI-KIT"></tsum-layout-header>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-header--default}
 */
@Component({
    selector: 'tsum-layout-header',
    templateUrl: './tsum-layout-header.component.html',
    styleUrls: ['./tsum-layout-header.component.styl']
})
export class TsumLayoutHeaderComponent {
    /**
     * @description Input
     * @description Array of routes
     * @example
     * [routes]="[{
     *   title: 'Test route name',
     *   route: '/test/route',
     *   childs?: [{
     *     title: 'Test child route name',
     *     route: '/test/route/child',
     *   }],
     * }]"
     */
    @Input()
    public routes: TsumLayoutHeader.Route[] = [];

    @Input()
    public name = '';

    @Input()
    public normalizedRoutes: Record<string, TsumLayoutHeader.Route>;

    /**
     * @description Input
     * @description current active route name, not id
     * @example
     * [activeRouteName]="'/test/route'"
     */
    @Input()
    public activeRouteName: string = '';

    /**
     * @description Input
     * @description Flag, for showing is current header is subheader. Used in recursive component
     * @example
     * [isSubheader]="true"
     */
    @Input()
    public isSubheader: boolean = false;

    /**
     * @event TsumLayoutHeaderComponent#handleRoute
     * @description Emit route value when clicked at open route
     */
    @Output('handleRoute')
    public handleRoute$: EventEmitter<string> = new EventEmitter<string>();

    @Output('appClicked')
    public appClicked$ = new EventEmitter<void>();

    public isOpenedPopover: Record<string, boolean> = {};

    public get activeRoute(): TsumLayoutHeader.Route {
        const foundActiveRoute = this.routes
            .find((route: TsumLayoutHeader.Route) => (this.activeRouteName || '').indexOf(route.route) > -1);

        if (!foundActiveRoute) {
            return null;
        }

        return foundActiveRoute;
    }

    public get realActiveRoute(): TsumLayoutHeader.Route {
        return this.getRealActiveRoute(this.activeRouteName);
    }

    public get activeRouteChild(): TsumLayoutHeader.Route[] {
        if (!this.activeRoute) {
            return null;
        }

        return this.activeRoute.childs || [];
    }

    public get activeTitle(): string {
        return this.activeRoute.title;
    }

    public getPopoverConfig(route: TsumLayoutHeader.Route): TsumPositioningPopup.Config<TsumPopoverComponent<string>> {
        if (route.childs.length < 1) {
            return null;
        }

        const popovers: TsumPopover.Popover<string>[] = route.childs.map((
            child: TsumLayoutHeader.Route,
            index: number,
        ): TsumPopover.Popover<string> => {
            return {
                name: child.title,
                type: child.route,
                id: index,
            };
        });

        const config: TsumPositioningPopup.Config<TsumPopoverComponent<string>> = {};

        config.props = {};
        config.props.popovers = popovers;

        return config;
    }

    public onSelectPopover(popover: TsumPopover.Popover<string>): void {
        this.openRoute(popover.type);

        this.toggleOpenPopover(popover.type);
    }

    public isActiveRoute(route: string): boolean {
        return (this.activeRouteName || '').indexOf(route) > -1;
    }

    public openRoute(route: string): void {
        if (this.getNormalizedRoutes()[route].childs && this.getNormalizedRoutes()[route].childs.length > 0) {
            this.handleRoute$.next(this.getNormalizedRoutes()[route].childs[0].route);
        } else {
            this.handleRoute$.next(route);
        }
    }

    public hasChilds(): boolean {
        if (!this.activeRoute) {
            return false;
        }

        return Boolean(this.activeRoute.childs);
    }

    public toggleOpenPopover(routeTitle: string): void {
        this.isOpenedPopover[routeTitle] = !this.isOpenedPopover[routeTitle] ? true : false;
    }

    public getNormalizedRoutes(): Record<string, TsumLayoutHeader.Route> {
        if (this.normalizedRoutes) {
            return this.normalizedRoutes;
        }

        return this.getInnerNormalizedRoutes(this.routes);
    }

    public appClick(): void {
        this.appClicked$.next();
    }

    private getInnerNormalizedRoutes(
        routes: TsumLayoutHeader.Route[],
        innerNormalized: Record<string, TsumLayoutHeader.Route> = {},
    ): Record<string, TsumLayoutHeader.Route> {
        routes.forEach((route: TsumLayoutHeader.Route) => {
            innerNormalized[route.route] = route;

            if (route.childs && route.childs.length > 0) {
                this.getInnerNormalizedRoutes(route.childs, innerNormalized);
            }
        });

        return innerNormalized;
    }

    private getRealActiveRoute(routeName: string): TsumLayoutHeader.Route {
        const foundActiveRoute = this.routes
            .find((route: TsumLayoutHeader.Route) => (routeName || '').indexOf(route.route) > -1);

        if (!foundActiveRoute) {
            return null;
        }

        if (foundActiveRoute.route === this.activeRouteName || !foundActiveRoute.childs) {
            return foundActiveRoute;
        } else {
            const foundChildActiveRoute = foundActiveRoute.childs
                .find((route: TsumLayoutHeader.Route) => (routeName || '').indexOf(route.route) > -1);

            if (!foundChildActiveRoute) {
                return null;
            }

            return foundChildActiveRoute;
        }
    }
}
