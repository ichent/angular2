export * from './tsum-pane.component';
export * from './tsum-pane.module';
