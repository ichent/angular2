import { Pipe, PipeTransform } from '@angular/core';
import { TsumNotification } from '../tsum-air-message.namespace';
import { TsumIcon } from '../../../tsum-utils/tsum-icons/tsum-icon.namespace';

/**
 * @description Return notification fill color of icon, depends of notification type
 */
@Pipe({
    name: 'airMessageFillIcon',
})
export class TsumAirMessageFillIconPipe implements PipeTransform {
    transform(notificationType: TsumNotification.Type): string {
        switch (notificationType) {
            case 'error':
                return TsumIcon.Color.Danger;

            case 'warning':
                return TsumIcon.Color.Primary;

            case 'info':
                return TsumIcon.Color.Info;

            case 'success':
                return TsumIcon.Color.Success;

            default:
                return TsumIcon.Color.Info;
        }
    }

}
