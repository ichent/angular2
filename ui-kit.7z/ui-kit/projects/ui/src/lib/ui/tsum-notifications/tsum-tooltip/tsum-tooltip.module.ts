import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumTooltipDirective } from './tsum-tooltip.directive';
import { TsumTooltipComponent } from './tsum-tooltip.component';

@NgModule({
    declarations: [
        TsumTooltipComponent,
        TsumTooltipDirective,
    ],
    imports: [
        CommonModule,
    ],
    entryComponents: [
        TsumTooltipComponent,
    ],
    exports: [
        TsumTooltipDirective,
    ],
})
export class TsumTooltipModule {}
