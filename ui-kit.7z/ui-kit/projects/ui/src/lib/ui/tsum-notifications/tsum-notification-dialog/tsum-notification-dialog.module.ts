import { TsumNotificationDialogComponent } from './tsum-notification-dialog.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumClickOutsideModule } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumButtonModule } from '../../tsum-forms/tsum-button/tsum-button.module';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import {
    TsumSecondaryButtonComponent
} from '../../tsum-forms/tsum-button/components/secondary/tsum-secondary-button.component';
import {
    TsumPrimaryButtonComponent
} from '../../tsum-forms/tsum-button/components/primary/tsum-primary-button.component';
import { TsumSafeModule } from '@tsum/utils';

/**
 * @description Resolve window. Uses for inform user about something
 * @description Send icon key (see @TsumIcon
 * @description And send data of this window(title/description etc)
 * @description For use this component, inject tsumResolveService via constructor
 * @description And use method "open" in this service
 * @description Also you can detect close event(when click on success or cancel button)
 * @description Method "open" - it's promise, just use ".then" and catch event
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-Resolve--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumClickOutsideModule,
        TsumButtonModule,
        TsumIconsModule,
        TsumSafeModule,
    ],
    declarations: [
        TsumNotificationDialogComponent,
    ],
    exports: [
        TsumNotificationDialogComponent,
    ],
    entryComponents: [
        TsumNotificationDialogComponent,
        TsumPrimaryButtonComponent,
        TsumSecondaryButtonComponent,
    ],
})
export class TsumNotificationDialogModule {
}
