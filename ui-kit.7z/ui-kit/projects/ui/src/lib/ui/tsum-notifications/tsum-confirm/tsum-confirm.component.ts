import { Component, Input, EventEmitter, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy, ElementRef } from '@angular/core';
import { TsumIcon } from '../../tsum-utils/tsum-icons/tsum-icon.namespace';
import { TsumConfirm } from './tsum-confirm.namespace';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';

/**
 * @description Confirm window. Uses for inform user about something
 * @description Send type(error/warning/success/info)
 * @description And send data of this window(title/description etc)
 * @description For use this component, inject tsumConfirmService via constructor
 * @description And use method "open" in this service
 * @description Also you can detect close event(when click on success or cancel button)
 * @description Method "open" - it's promise, just use ".then" and catch event
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-confirm--default}
 */
@Component({
    selector: 'tsum-confirm',
    templateUrl: './tsum-confirm.component.html',
    styleUrls: ['./tsum-confirm.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumConfirmComponent implements OnDestroy {
    @Input() public title = 'NO TITLE';
    @Input() public type: TsumConfirm.Type = 'info';
    @Input() public description = '';
    @Input() public additionalDescription = '';
    @Input() public buttonText = null;
    @Input() public secondButtonText = '';
    @Input() public successMethod: Observable<any> | Function;
    @Input() public rejectMethod: Observable<any> | Function;

    public closeEmitter$ = new EventEmitter<TsumConfirm.Emit>();

    private destroyed$ = new Subject<void>();

    private isLoadingSubject$ = new BehaviorSubject<boolean>(false);

    public get icon(): string {
        switch (this.type) {
            case 'error':
                return TsumIcon.Notifications.TriangleError;

            case 'info':
                return TsumIcon.Notifications.HollowInfo;

            case 'success':
                return TsumIcon.Notifications.Success;

            case 'warning':
                return TsumIcon.Notifications.TriangleWarning;

            default:
                return TsumIcon.Notifications.Error;
        }
    }

    public get color(): string {
        switch (this.type) {
            case 'error':
                return TsumIcon.Color.Danger;

            case 'info':
                return TsumIcon.Color.Info;

            case 'success':
                return TsumIcon.Color.Success;

            case 'warning':
                return TsumIcon.Color.Warning;

            default:
                return TsumIcon.Color.Warning;
        }
    }

    public get isLoading$(): Observable<boolean> {
        return this.isLoadingSubject$.asObservable();
    }

    constructor(
        public el: ElementRef,
        public cd: ChangeDetectorRef,
    ) { }

    public onClose(): void {
        if (this.rejectMethod) {
            if (!(this.rejectMethod instanceof Observable)) {
                this.rejectMethod();
            } else {
                (this.rejectMethod as Observable<any>)
                    .pipe(
                        takeUntil(this.destroyed$),
                    )
                    .subscribe();
            }
        }

        this.closeEmitter$.next('close');
    }

    public onSuccess(): void {
        if (!this.successMethod) {
            this.closeEmitter$.next('success');

            return;
        }

        if (!(this.successMethod instanceof Observable)) {
            this.successMethod();

            this.closeEmitter$.next('success');

            return;
        }

        this.isLoadingSubject$.next(true);

        (this.successMethod as Observable<any>)
            .pipe(
                takeUntil(this.destroyed$),
                catchError((e: string) => {
                    this.closeEmitter$.next('error');

                    throw Error(e);
                }),
            )
            .subscribe(() => {
                this.isLoadingSubject$.next(false);

                this.closeEmitter$.next('success');
            });
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
