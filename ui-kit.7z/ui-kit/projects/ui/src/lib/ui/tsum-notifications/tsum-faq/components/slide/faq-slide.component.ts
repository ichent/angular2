import { Component, ChangeDetectionStrategy, Input, ViewChild, ElementRef } from '@angular/core';

/**
 * @description Faq slide component
 * Uses only with tsum-faq component
 * has input:
 * title
 * @example <tsum-faq-slide title="title" description="description"></tsum-faq-slide>
 * @see More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-faq--default}
 */
@Component({
    selector: 'tsum-faq-slide',
    templateUrl: './faq-slide.component.html',
    styleUrls: ['./faq-slide.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumFaqSlideComponent {
    @Input()
    public title = '';

    @ViewChild('contentTemplate', { static: true })
    public contentTemplate: ElementRef<void>;
}
