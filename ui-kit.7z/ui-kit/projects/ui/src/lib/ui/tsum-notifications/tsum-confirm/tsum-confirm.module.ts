import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumConfirmComponent } from './tsum-confirm.component';
import { TsumClickOutsideModule } from '../../tsum-utils/tsum-click-outside/tsum-click-outside.module';
import { TsumButtonModule } from '../../tsum-forms/tsum-button/tsum-button.module';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumSafeModule } from '@tsum/utils';

const COMPONENTS = [
    TsumConfirmComponent,
];

/**
 * @description Confirm window. Uses for inform user about something
 * @description Send type(error/warning/success/info)
 * @description And send data of this window(title/description etc)
 * @description For use this component, inject tsumConfirmService via constructor
 * @description And use method "open" in this service
 * @description Also you can detect close event(when click on success or cancel button)
 * @description Method "open" - it's promise, just use ".then" and catch event
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-confirm--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumClickOutsideModule,
        TsumButtonModule,
        TsumIconsModule,
        TsumSafeModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumConfirmModule { }
