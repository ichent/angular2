import { Pipe, PipeTransform } from '@angular/core';
import { TsumNotification } from '../tsum-air-message.namespace';

/**
 * @description Return notification default title, depends of notification type
 */
@Pipe({
    name: 'tsumAirMessageTitle',
})
export class TsumAirMessageTitlePipe implements PipeTransform {
    transform(notificationType: TsumNotification.Type): string {
        switch (notificationType) {
            case 'error':
                return 'ОШИБКА';

            case 'warning':
                    return 'ОБРАТИТЕ ВНИМАНИЕ';

            case 'info':
                    return 'Обновление системы';

            case 'success':
                    return 'Успешно сохранено';

            default:
                return 'Обновление системы';
        }
    }

}
