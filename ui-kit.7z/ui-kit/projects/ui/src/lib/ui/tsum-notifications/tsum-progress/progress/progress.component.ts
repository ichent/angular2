import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { TsumIndicator } from '../../../tsum-utils/tsum-indicator/tsum-indicator.namespace';
import { BehaviorSubject, Observable } from 'rxjs';
import { TsumGeneralHelper, TsumInputBoolean } from '@tsum/utils';

/**
 * @description Progress component
 * @example <tsum-progress active indicatorType="primary">Progress with info indicator</tsum-progress>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-progress--default}
 */
@Component({
    selector: 'tsum-progress',
    templateUrl: './progress.component.html',
    styleUrls: ['./progress.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumProgressComponent {
    @TsumInputBoolean()
    @Input()
    public set active(isActive: boolean | string) {
        this.activeSubject$.next(TsumGeneralHelper.isPropertyActive(isActive));
    }

    @Input()
    public set indicatorType(type: TsumIndicator.Type) {
        this.indicatorTypeSubject$.next(type || null);
    }

    private activeSubject$ = new BehaviorSubject<boolean>(false);
    private indicatorTypeSubject$ = new BehaviorSubject<TsumIndicator.Type>(null);

    public get indicatorType$(): Observable<TsumIndicator.Type> {
        return this.indicatorTypeSubject$.asObservable();
    }

    public get active$(): Observable<boolean> {
        return this.activeSubject$.asObservable();
    }
}
