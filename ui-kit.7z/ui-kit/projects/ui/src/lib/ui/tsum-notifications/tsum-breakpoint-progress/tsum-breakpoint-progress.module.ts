import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumBreakpointProgressComponent } from './progress/tsum-breakpoint-progress.component';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';

const COMPONENTS = [
    TsumBreakpointProgressComponent,
];

/**
 * @description Breakpoint Progress component
 * Данный компонент предназначен для отображения прогрессии, но с разделительными точками
 * В данные точки можно добавить свой функционал, например - кнопки
 * @example <tsum-breakpoint-progress [breakpoints]="breakpoints" type="vertical" size="default"></tsum-breakpoint-progress>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-progress--breakpoint-progress}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumBreakpointProgressModule {}
