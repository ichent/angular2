import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { scan, startWith, shareReplay, tap } from 'rxjs/operators';
import { TsumNotification } from '../tsum-air-message.namespace';
import { TsumMathHelper } from '@tsum/utils';

/**
 * @description Сервис для управления нотификациями
 * @example
 * this.tsumNotificationService.pushNotifications([{
 *   title: 'Delete init',
 *   type: 'warning',
 * }]
 */
@Injectable({
    providedIn: 'root'
})
export class TsumNotificationService {
    /** @description значение top position по умолчанию */
    public readonly defaultTopPosition = 48;

    /** @description значение right position по умолчанию */
    public readonly defaultRightPosition = 24;

    public notifications: TsumNotification.Notification[] = [];

    private defaultTimeout = TsumNotification.Timeout.Medium;

    private notificationsSubject$ = new BehaviorSubject<TsumNotification.Notification[]>([]);

    private topPositionSubject$ = new BehaviorSubject<number>(this.defaultTopPosition);
    private rightPositionSubject$ = new BehaviorSubject<number>(this.defaultRightPosition);

    /** @description Установка top position */
    public set top(position: number) {
        this.topPositionSubject$.next(position);
    }

    /** @description получение top position */
    public get top(): number {
        return this.topPositionSubject$.getValue();
    }

    /** @description Observable top position */
    public get top$(): Observable<number> {
        return this.topPositionSubject$.asObservable();
    }

    /** @description Установка right position */
    public set right(position: number) {
        this.rightPositionSubject$.next(position);
    }

    /** @description Получение right position */
    public get right(): number {
        return this.rightPositionSubject$.getValue();
    }

    /** @description Observable right position */
    public get right$(): Observable<number> {
        return this.rightPositionSubject$.asObservable();
    }

    /**
     * @description Возвращает observable TsumNotification.Notification[] возвращает уникальные нотификации
     * Нотификации закрываются автоматический по таймауту, вы можете указать у конкретной нотификации время закрытия
     */
    public get notifications$(): Observable<TsumNotification.Notification[]> {
        return this.notificationsSubject$
            .pipe(
                map((notifications: TsumNotification.Notification[]): TsumNotification.Notification[] => {
                    return notifications
                        .filter(Boolean)
                        .map((notification: TsumNotification.Notification): TsumNotification.Notification => {
                            if (!(notification.id && notification.timeoutClose)) {
                                notification.timeoutClose = notification.timeoutClose ? notification.timeoutClose : this.defaultTimeout;
                                notification.id = TsumMathHelper.getUniqueId();
                            }

                            return notification;
                        });
                }),
                tap((notifications: TsumNotification.Notification[]) => {
                    notifications.forEach((notification: TsumNotification.Notification) => {
                        if (!notification.deleted && notification.timeoutClose !== Infinity) {
                            setTimeout(() => this.closeNotification(notification.id, notifications), notification.timeoutClose);
                        }
                    });
                }),
                scan((currentNotification: TsumNotification.Notification[], newNotification: TsumNotification.Notification[]) => {
                    const filteredCurrentNotifications = currentNotification
                        .filter((filteredCurrentNotification: TsumNotification.Notification) => {
                            return newNotification
                                .some((filteredNewNotification: TsumNotification.Notification) =>
                                    filteredCurrentNotification.id !== filteredNewNotification.id
                                );
                        });

                    return [...filteredCurrentNotifications, ...newNotification]
                        .filter((notification: TsumNotification.Notification) => !notification.deleted);
                }),
                startWith([]),
                shareReplay(1)
            );
    }

    constructor(
    ) {
        this.notifications$.subscribe((notifications: TsumNotification.Notification[]) => {
            this.notifications = notifications;
        });
    }

    /**
     * @description Установка новых нотификаций, принимает массив нотификаций
     */
    public pushNotifications(notifications: TsumNotification.Notification[]): void {
        this.notificationsSubject$.next(notifications);
    }

    /**
     * @description Удаление конкретной нотификации
     */
    public closeNotification(id: string, notifications: TsumNotification.Notification[] = this.notifications): void {
        const resultNotifications: TsumNotification.Notification[] = notifications.map((notification: TsumNotification.Notification) => {
            if (notification.id === id) {
                notification.deleted = true;
            }

            return notification;
        });

        this.notificationsSubject$.next(resultNotifications);
    }

    /** @description Установка позиций по умолчанию */
    public setDefaultPositions(): void {
        this.topPositionSubject$.next(this.defaultTopPosition);
        this.rightPositionSubject$.next(this.defaultRightPosition);
    }
}
