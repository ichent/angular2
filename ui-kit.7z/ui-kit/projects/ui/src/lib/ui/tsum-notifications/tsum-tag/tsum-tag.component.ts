import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';
import { TsumIcon } from '../../tsum-utils/tsum-icons/tsum-icon.namespace';
import { TsumInputBoolean } from '@tsum/utils';
import { BehaviorSubject, Observable } from 'rxjs';
import { TsumGeneralHelper } from '@tsum/utils';

@Component({
    selector: 'tsum-tag',
    templateUrl: './tsum-tag.component.html',
    styleUrls: ['./tsum-tag.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumTagComponent {
    @Input()
    public set readonly(isReadonly: boolean | string) {
        this.readonlySubject$.next(TsumGeneralHelper.isPropertyActive(isReadonly));
    }

    @TsumInputBoolean()
    @Input()
    public big = false;

    @TsumInputBoolean()
    @Input()
    public small = false;

    @Output('onCleared')
    public onCleared$ = new EventEmitter<Event>();

    public closeIcon = TsumIcon.Actions.Close;
    public iconColor = TsumIcon.Color;

    private readonlySubject$ = new BehaviorSubject<boolean>(false);

    public get readonly$(): Observable<boolean> {
        return this.readonlySubject$.asObservable();
    }

    public onClear(event: Event): void {
        this.onCleared$.next(event);
    }
}
