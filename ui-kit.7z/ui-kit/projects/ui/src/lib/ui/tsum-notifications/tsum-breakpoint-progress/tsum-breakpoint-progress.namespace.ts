import { TemplateRef } from '@angular/core';

export namespace TsumBreakpointProgress {
    export interface Breakpoint {
        title: string;
        isActive: boolean;
        template?: TemplateRef<void>;
    }
}
