export * from './faq-wrapper.component';
