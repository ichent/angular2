import { Injectable, ComponentRef } from '@angular/core';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumConfirm } from './tsum-confirm.namespace';
import { TsumConfirmComponent } from './tsum-confirm.component';

/**
 * @description Confirm window. Uses for inform user about something
 * @description Send type(error/warning/success/info)
 * @description And send data of this window(title/description etc)
 * @description For use this component, inject tsumConfirmService via constructor
 * @description And use method "open" in this service
 * @description Also you can detect close event(when click on success or cancel button)
 * @description Method "open" - it's promise, just use ".then" and catch event
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-confirm--default}
 */
@Injectable({
    providedIn: 'root',
})
export class TsumConfirmService {
    private tsumConfirmRef: ComponentRef<TsumConfirmComponent>;

    constructor(
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
    ) {}

    public open(data: TsumConfirm.Window): Promise<TsumConfirm.Emit> {
        return new Promise((resolve: Function, reject: Function) => {
            this.tsumConfirmRef = this.tsumDynamicComponentsService.createComponent(TsumConfirmComponent);

            Object.keys(data).forEach((key: string) => {
                this.tsumConfirmRef.instance[key] = data[key];
            });

            this.tsumConfirmRef.instance.cd.detectChanges();

            document.getElementsByTagName('body')[0].style.overflow = 'hidden';

            this.tsumConfirmRef.instance.closeEmitter$.subscribe((emit: TsumConfirm.Emit) => {
                this.destroy();

                if (emit === 'error') {
                    reject();
                } else if (emit === 'success') {
                    resolve(emit);
                }
            });
        });
    }

    public destroy(): void {
        if (this.tsumConfirmRef) {
            document.getElementsByTagName('body')[0].style.overflow = 'inherit';

            this.tsumDynamicComponentsService.deleteComponent(this.tsumConfirmRef);
            this.tsumConfirmRef = undefined;
        }
    }
}
