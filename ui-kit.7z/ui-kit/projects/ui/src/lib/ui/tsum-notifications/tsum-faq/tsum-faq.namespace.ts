export namespace TsumFaq {
    export type Change = 'next' | 'prev' | 'start' | 'end';
}
