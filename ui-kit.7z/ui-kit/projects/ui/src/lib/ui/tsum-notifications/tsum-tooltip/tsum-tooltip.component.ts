import { ChangeDetectionStrategy, Component, HostBinding } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { TsumTooltip } from './tsum-tooltip.namespace';

@Component({
    templateUrl: './tsum-tooltip.component.html',
    styleUrls: ['./tsum-tooltip.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    animations: [
        trigger('tooltip', [
            state('void', style({
                opacity: 0,
            })),
            transition(':enter', [
                animate('.1s'),
            ]),
        ]),
    ],
})
export class TsumTooltipComponent {
    // параметры задаются из одноименной директиве
    public text = '';
    public hasImage: boolean;
    public position: TsumTooltip.Position;
    public offsetX: number;
    public offsetY: number;

    @HostBinding('@tooltip')
    public tooltipAnimation = true;

    @HostBinding('class')
    public styleClass: string;

    @HostBinding('style.top.px')
    public get top(): number {
        return this.position !== TsumTooltip.Position.Top && this.offsetY;
    }

    @HostBinding('style.right.px')
    public get right(): number {
        return this.position === TsumTooltip.Position.Left && this.offsetX;
    }

    @HostBinding('style.bottom.px')
    public get bottom(): number {
        return this.position === TsumTooltip.Position.Top && this.offsetY;
    }

    @HostBinding('style.left.px')
    public get left(): number {
        return this.position !== TsumTooltip.Position.Left && this.offsetX;
    }

}
