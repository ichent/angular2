import {
    Directive,
    ViewContainerRef,
    ComponentRef,
    OnDestroy,
    Input,
    OnChanges,
    SimpleChanges,
    ElementRef,
    Renderer2,
} from '@angular/core';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumNotificationAlertComponent } from './tsum-notification-alert.component';

/**
 * @description Count of alerts notification
 * @example <div [tsumNotificationAlert]="14"></div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-alert--default}
 */
@Directive({
    selector: '[tsumNotificationAlert]'
})
export class TsumNotificationAlertDirective implements OnDestroy, OnChanges {
    @Input()
    public tsumNotificationAlert = 0;

    public notificationAlertRef: ComponentRef<TsumNotificationAlertComponent>;

    constructor(
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
        private elementRef: ElementRef,
        private renderer: Renderer2,
        private viewContainerRef: ViewContainerRef,
    ) {}

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.tsumNotificationAlert && changes.tsumNotificationAlert.currentValue) {
            this.createComponent(changes.tsumNotificationAlert.currentValue);
        } else {
            this.destroy();
        }
    }

    public ngOnDestroy(): void {
        this.destroy();
    }

    private destroy(): void {
        if (this.notificationAlertRef) {
            this.renderer.removeStyle(this.elementRef.nativeElement, 'position');

            this.notificationAlertRef.destroy();
            this.notificationAlertRef = undefined;
        }
    }

    private createComponent(countNotification: number = this.tsumNotificationAlert): void {
        if (!this.notificationAlertRef && this.tsumNotificationAlert) {
            this.notificationAlertRef = this.tsumDynamicComponentsService.createChildComponent(
                TsumNotificationAlertComponent,
                this.viewContainerRef,
            );

            this.renderer.setStyle(this.elementRef.nativeElement, 'position', 'relative');

            const component: TsumNotificationAlertComponent = this.notificationAlertRef.instance;

            component.count = countNotification;

            component.changeDetectorRef.detectChanges();
        } else if (this.notificationAlertRef) {
            const component: TsumNotificationAlertComponent = this.notificationAlertRef.instance;

            component.count = countNotification;

            component.changeDetectorRef.detectChanges();
        }
    }
}
