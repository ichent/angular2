import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ChangeDetectorRef,
    HostBinding,
    OnDestroy,
} from '@angular/core';
import { TsumNotification } from '../../tsum-air-message.namespace';
import { HideInDomAnimation } from '../../../../tsum-core/animations/hide-in-dom.animation';
import { TsumNotificationService } from '../../services/tsum-notification.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

/**
 * @description Notifications component
 * @description Uses with combination of TsumNotificationService
 * @description You can update/remove and get notification from service
 * @example <tsum-air-messages [notifications]="tsumNotificationService.notifications$"></tsum-air-messages>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-air-message--default}
 */
@Component({
    selector: 'tsum-air-messages',
    templateUrl: './tsum-air-message-wrapper.component.html',
    styleUrls: ['./tsum-air-message-wrapper.component.styl'],
    animations: [
        HideInDomAnimation,
    ],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumAirMessageWrapperComponent implements OnDestroy {
    /**
     * @description Input
     * @description Array of notifications. Usually use via tsumNotificationService.notifications$
     * @example [notifications]="tsumNotificationService.notifications$ | async"
     */
    @Input() public notifications: TsumNotification.Notification[] = [];

    @HostBinding('style.top.px')
    public top;

    @HostBinding('style.right.px')
    public right;

    private destroyed$ = new Subject<void>();

    constructor(
        public changeDetectorRef: ChangeDetectorRef,
        private tsumNotificationService: TsumNotificationService,
    ) {
        this.tsumNotificationService.top$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((position: number) => {
                this.top = position;
            });

        this.tsumNotificationService.right$
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((position: number) => {
                this.right = position;
            });
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
