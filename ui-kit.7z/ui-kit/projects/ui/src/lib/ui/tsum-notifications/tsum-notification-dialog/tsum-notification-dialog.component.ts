import { Component, Input, EventEmitter, OnDestroy, ChangeDetectorRef, ChangeDetectionStrategy, ElementRef } from '@angular/core';
import { TsumIcon } from '../../tsum-utils/tsum-icons/tsum-icon.namespace';
import { TsumNotificationDialog } from './tsum-notification-dialog.namespace';
import { Observable, BehaviorSubject, Subject, throwError } from 'rxjs';
import { takeUntil, catchError } from 'rxjs/operators';
import { TsumIconHelper } from '@tsum/utils';

/**
 * @description Resolve window. Uses for offer user two actions
 * @description Send type from icons enums
 * @description And send data of this window(title/description etc)
 * @description For use this component, inject tsumResolveService via constructor
 * @description And use method "open" in this service
 * @description Also you can detect close event(when click on success or cancel button)
 * @description Method "open" - it's promise, just use ".then" and catch event
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-notification-dialog--default}
 */
@Component({
    selector: 'tsum-notification-dialog',
    templateUrl: './tsum-notification-dialog.component.html',
    styleUrls: ['./tsum-notification-dialog.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumNotificationDialogComponent implements OnDestroy {
    @Input()
    public title = 'NO TITLE';

    /** string taken from TsumIconHelper.icons */
    @Input()
    public iconName: string = 'notification-info';

    @Input()
    public description = '';

    @Input()
    public additionalDescription = '';

    @Input()
    public buttonText = '';

    @Input()
    public secondButtonText = '';

    @Input()
    public successMethod: Observable<any> | Function;

    @Input()
    public catchMethod: Observable<any> | Function;

    public closeEmitter$ = new EventEmitter<TsumNotificationDialog.Emit>();

    private destroyed$ = new Subject<void>();

    private isSuccessLoadingSubject$ = new BehaviorSubject<boolean>(false);
    private isCatchLoadingSubject$ = new BehaviorSubject<boolean>(false);

    public get icon(): string {
        if (TsumIconHelper.getIcons(TsumIcon).has(this.iconName)) {
            return this.iconName;
        } else {
            throw new Error(`Icon with type ${this.iconName} is not exists in the ui-kit`);
        }
    }

    public get isCatchLoading$(): Observable<boolean> {
        return this.isCatchLoadingSubject$.asObservable();
    }

    public get isSuccessLoading$(): Observable<boolean> {
        return this.isSuccessLoadingSubject$.asObservable();
    }

    public get color(): string {
        return TsumIcon.Color.Primary;
    }

    constructor(
        public el: ElementRef,
        public cd: ChangeDetectorRef,
    ) {}

    public onClose(): void {
        this.closeEmitter$.next('close');
    }

    public onCatch(): void {
        if (!(this.catchMethod instanceof Observable)) {
            this.catchMethod();

            this.closeEmitter$.next('catch');
        } else {
            this.resolveClick(this.catchMethod as Observable<any>, 'catch', this.isCatchLoadingSubject$);
        }
    }

    public onSuccess(): void {
        if (!(this.successMethod instanceof Observable)) {
            this.successMethod();

            this.closeEmitter$.next('success');
        } else {
            this.resolveClick(this.successMethod as Observable<any>, 'success', this.isSuccessLoadingSubject$);
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private resolveClick(
        method: Observable<any>,
        event: TsumNotificationDialog.Emit,
        loadingSubject: BehaviorSubject<boolean>,
    ): void {
        if (!method) {
            this.closeEmitter$.next(event);
        }

        loadingSubject.next(true);

        method
            .pipe(
                takeUntil(this.destroyed$),
                catchError((error: string) => {
                    this.closeEmitter$.next('error');
                    return throwError(error);
                }),
            )
            .subscribe(() => {
                loadingSubject.next(false);
                this.closeEmitter$.next(event);
            });
    }
}
