import { Injectable, ComponentRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { TsumDynamicComponentsService } from '@tsum/utils';

import { TsumNotificationDialog } from './tsum-notification-dialog.namespace';
import { TsumNotificationDialogComponent } from './tsum-notification-dialog.component';

/**
 * @description Resolve window. Uses for offer user two actions
 * @description Send type from icons enums
 * @description And send data of this window(title/description etc)
 * @description For use this component, inject tsumNotificationDialogService via constructor
 * @description And use method "open" in this service
 * @description Also you can detect close event(when click on success or cancel button)
 * @description Method "open" - it's promise, just use ".then" and catch event
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-notification-dialog--default}
 */
@Injectable({
    providedIn: 'root',
})
export class TsumNotificationDialogService {
    private tsumNotificationDialogRef: ComponentRef<TsumNotificationDialogComponent>;
    private subscription: Subscription;

    constructor(
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
    ) {
    }

    public open(data: TsumNotificationDialog.Window): Promise<TsumNotificationDialog.Emit> {
        return new Promise((resolve: Function, reject: Function) => {
            this.tsumNotificationDialogRef = this.tsumDynamicComponentsService.createComponent(TsumNotificationDialogComponent);

            Object.keys(data).forEach((key: string) => {
                this.tsumNotificationDialogRef.instance[key] = data[key];
            });

            this.tsumNotificationDialogRef.instance.cd.detectChanges();

            document.getElementsByTagName('body')[0].style.overflow = 'hidden';

            this.subscription = this.tsumNotificationDialogRef.instance.closeEmitter$
                .subscribe((emit: TsumNotificationDialog.Emit) => {
                    const isResolve: boolean = (emit === 'success') || (emit === 'catch');
                    const isReject: boolean = (emit === 'error');

                    this.destroy();
                    this.subscription.unsubscribe();

                    if (isResolve) {
                        resolve(emit);
                    } else if (isReject) {
                        reject();
                    }
                });
        });
    }

    public destroy(): void {
        if (this.tsumNotificationDialogRef) {
            document.getElementsByTagName('body')[0].style.overflow = 'inherit';

            this.tsumDynamicComponentsService.deleteComponent(this.tsumNotificationDialogRef);
            this.tsumNotificationDialogRef = undefined;
        }
    }
}
