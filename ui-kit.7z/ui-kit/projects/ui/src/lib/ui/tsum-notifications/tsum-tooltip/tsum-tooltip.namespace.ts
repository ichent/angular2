export namespace TsumTooltip {
    export enum Position {
        Top = 'top',
        Right = 'right',
        Bottom = 'bottom',
        Left = 'left',
    }

    export enum StyleClass {
        BreakWord = 'break-word',
        ImageSmall = 'image-small',
    }
}
