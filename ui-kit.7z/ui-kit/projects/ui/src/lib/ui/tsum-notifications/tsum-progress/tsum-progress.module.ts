import { NgModule } from '@angular/core';
import { TsumProgressComponent } from './progress/progress.component';
import { CommonModule } from '@angular/common';
import { TsumIndicatorModule } from '../../tsum-utils/tsum-indicator/tsum-indicator.module';
import { TsumTextOverflowTooltipModule } from '../../tsum-utils/tsum-text-overflow-tooltip/tsum-text-overflow-tooltip.module';

const COMPONENTS = [
    TsumProgressComponent,
];

/**
 * @description Progress component
 * @example <tsum-progress active indicatorType="primary">Progress with info indicator</tsum-progress>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-progress--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIndicatorModule,
        TsumTextOverflowTooltipModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumProgressModule {}
