import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumTagComponent } from './tsum-tag.component';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';

const COMPONENTS = [
    TsumTagComponent,
];

@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumTagModule { }
