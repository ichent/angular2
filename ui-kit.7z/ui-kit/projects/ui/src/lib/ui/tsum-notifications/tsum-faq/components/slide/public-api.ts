export * from './faq-slide.component';
