import { Observable } from 'rxjs';

export namespace TsumConfirm {
    export type Type = 'error' | 'warning' | 'success' | 'info' | 'black';

    export interface Window {
        title: string;
        type: Type;
        description: string;
        additionalDescription?: string;
        buttonText: string;
        secondButtonText?: string;
        successMethod?: Observable<any> | Function;
        rejectMethod?: Observable<any> | Function;
    }

    export type Emit = 'success' | 'close' | 'error';
}
