import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TsumAirMessageComponent } from './components/air-message/tsum-air-message.component';
import { TsumAirMessageTitlePipe } from './pipes/tsum-air-message-title.pipe';
import { TsumAirMessageIconPipe } from './pipes/tsum-air-message-icon.pipe';
import { TsumIconsModule } from '../../tsum-utils/tsum-icons/tsum-icons.module';
import { TsumAirMessageFillIconPipe } from './pipes/tsum-air-message-fill-icon.pipe';
import { TsumAirMessageWrapperComponent } from './components/wrapper/tsum-air-message-wrapper.component';

const COMPONENTS = [
    TsumAirMessageComponent,
    TsumAirMessageWrapperComponent,
];

const PIPES = [
    TsumAirMessageTitlePipe,
    TsumAirMessageIconPipe,
    TsumAirMessageFillIconPipe,
];

/**
 * @description Notifications component
 * @description Uses with combination of TsumNotificationService
 * @description You can update/remove and get notification from service
 * @description In this component you should pass notifications input
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-air-message--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
    ],
    declarations: [
        ...COMPONENTS,
        ...PIPES,
    ],
    exports: COMPONENTS,
    entryComponents: [
        TsumAirMessageWrapperComponent,
    ],
})
export class TsumAirMessagesModule {

}
