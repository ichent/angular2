import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ElementRef,
    Renderer2,
    ChangeDetectorRef,
} from '@angular/core';

/**
 * @description Count of alerts
 * @example <tsum-notification-alert>14</tsum-notification-alert>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-alert--default}
 */
@Component({
    selector: 'tsum-notification-alert',
    templateUrl: './tsum-notification-alert.component.html',
    styleUrls: ['./tsum-notification-alert.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumNotificationAlertComponent {
    @Input()
    public count = 0;

    constructor(
        public el: ElementRef,
        public changeDetectorRef: ChangeDetectorRef,
        private renderer: Renderer2,
    ) {}
}
