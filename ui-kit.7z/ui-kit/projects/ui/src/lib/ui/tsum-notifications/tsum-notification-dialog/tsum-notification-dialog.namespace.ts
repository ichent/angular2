import { Observable } from 'rxjs';

export namespace TsumNotificationDialog {
    export interface Window {
        title: string;
        iconName: string;
        description: string;
        additionalDescription?: string;
        buttonText: string;
        secondButtonText?: string;
        successMethod?: Observable<any> | Function;
        catchMethod?: Observable<any> | Function;
    }

    export type Emit = 'success' | 'catch' | 'close' | 'error';
}
