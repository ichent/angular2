import { Component, ChangeDetectionStrategy, Input, HostBinding } from '@angular/core';
import { TsumInputBoolean } from '@tsum/utils';

/**
 * @description Status text with many colors, by default is default color
 * @description Possible variety of types, you need attach as attribute(input) this type
 * @description default - default color
 * @description primary - primary color
 * @description danger - danger color
 * @description info - info color
 * @description success - success color
 * @example <tsum-notification-status primary>Text</tsum-notification-status>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-status--default}
 */
@Component({
    selector: 'tsum-notification-status',
    templateUrl: './tsum-notification-status.component.html',
    styleUrls: ['./tsum-notification-status.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumNotificationStatusComponent {
    @HostBinding('class._default')
    @TsumInputBoolean()
    @Input()
    public default = true;

    @HostBinding('class._primary')
    @TsumInputBoolean()
    @Input()
    public primary = false;

    @HostBinding('class._danger')
    @TsumInputBoolean()
    @Input()
    public danger = false;

    @HostBinding('class._info')
    @TsumInputBoolean()
    @Input()
    public info = false;

    @HostBinding('class._success')
    @TsumInputBoolean()
    @Input()
    public success = false;
}
