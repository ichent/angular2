import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumFaqSlideComponent } from './components/slide/faq-slide.component';
import { TsumFaqWrapperComponent } from './components/wrapper/faq-wrapper.component';
import { TsumButtonModule } from '../../tsum-forms/tsum-button/tsum-button.module';

const COMPONENTS = [
    TsumFaqSlideComponent,
    TsumFaqWrapperComponent,
];

/**
 * @description Faq component
 * @example
 * <tsum-faq-progress (onChanged)="handleChange($event)">
 *     <tsum-faq-slide title="title" description="description"></tsum-faq-slide>
 *     <tsum-faq-slide title="title2" description="description2"></tsum-faq-slide>
 *     <tsum-faq-slide title="title3" description="description3"></tsum-faq-slide>
 * </tsum-faq-progress>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-faq--default}
 */
@NgModule({
    imports: [
        CommonModule,
        TsumButtonModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
    entryComponents: [
        COMPONENTS,
    ],
})
export class TsumFaqModule {}
