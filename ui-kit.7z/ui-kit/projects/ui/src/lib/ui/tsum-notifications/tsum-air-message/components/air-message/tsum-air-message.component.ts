import { trigger, transition, style, animate } from '@angular/animations';
import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { TsumIcon } from '../../../../tsum-utils/tsum-icons/tsum-icon.namespace';
import { TsumNotificationService } from '../../services/tsum-notification.service';
import { TsumNotification } from '../../tsum-air-message.namespace';

/**
 * @description Component for notification view, use with tsumNotificationService
 * @description Not use this component by alone, you should use <tsum-air-messages></tsum-air-messages> for it
 * @description used in <tsum-air-messages></tsum-air-messages>
 * @example [notification]="{
 * @example   type: 'info',
 * @example   title: 'Title',
 * @example   description: 'Description',
 * @example }"
 * @example <tsum-air-message [notification]="notification"></tsum-air-message>
 */
@Component({
    selector: 'tsum-air-message',
    templateUrl: './tsum-air-message.component.html',
    styleUrls: ['./tsum-air-message.component.styl'],
    animations: [
        trigger('slideToShowAnimation', [
            transition(':enter', [
                style({ opacity: '0', transform: 'translateX(16px)' }),
                animate('.5s ease-out', style({ opacity: '1', transform: 'translateX(0)' })),
            ]),
            transition(':leave', [
                style({ opacity: '1', transform: 'translateX(0)' }),
                animate('.5s ease-out', style({ opacity: '0', transform: 'translateX(52px)' })),
            ]),
        ]),
    ],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumAirMessageComponent {
    /**
     * @description Input
     * @description Notification
     * @example [notification]="{
     * @example   type: 'info',
     * @example   title: 'Title',
     * @example   description: 'Description',
     * @example }"
     */
    @Input() public notification: TsumNotification.Notification;

    public closeIcon = TsumIcon.Actions.Close;

    constructor(
        private tsumNotificationService: TsumNotificationService
    ) { }

    public get classes(): string[] {
        const mainClass: string = 'tsum-air-message';
        const result: string[] = [
            mainClass,
            `${mainClass}_${this.notification.type}`,
        ];

        if (this.notification.description) {
            result.push(`${mainClass}_with-description`);
        }

        return result;
    }

    public getNotificationIcon(): string {
        switch (this.notification.type) {
            case 'error':
                return TsumIcon.Notifications.Error;

            case 'warning':
                    return TsumIcon.Notifications.Warning;

            case 'info':
                    return TsumIcon.Notifications.HollowInfo;

            case 'success':
                    return TsumIcon.Notifications.Success;

            default:
                return TsumIcon.Notifications.Info;
        }
    }

    public closeNotification(id: string): void {
        this.tsumNotificationService.closeNotification(id, [this.notification]);
    }
}
