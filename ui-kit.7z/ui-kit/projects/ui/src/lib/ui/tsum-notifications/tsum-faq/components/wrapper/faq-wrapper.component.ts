import {
    Component,
    ChangeDetectionStrategy,
    AfterViewInit,
    Output,
    EventEmitter,
    Sanitizer,
    QueryList,
    ContentChildren,
    ChangeDetectorRef,
    ElementRef,
    Renderer2,
} from '@angular/core';
import { TsumFaqSlideComponent } from '../slide/faq-slide.component';
import { TsumFaq } from '../../tsum-faq.namespace';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, filter } from 'rxjs/operators';

const PROGRESS_BAR_WIDTH = 200;

/**
 * @description Компонент подсказка, используется обычно в паре с tsum-pulsar
 * @example
 * <tsum-faq-progress (onChanged)="handleChange($event)">
 *     <tsum-faq-slide title="title">description</tsum-faq-slide>
 *     <tsum-faq-slide title="title2">Описание 2</tsum-faq-slide>
 *     <tsum-faq-slide title="title3">description3</tsum-faq-slide>
 * </tsum-faq-progress>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-faq--default}
 */
@Component({
    selector: 'tsum-faq',
    templateUrl: './faq-wrapper.component.html',
    styleUrls: ['./faq-wrapper.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumFaqWrapperComponent implements AfterViewInit {
    @Output('onChanged')
    public changeEmitter = new EventEmitter<TsumFaq.Change>();

    @ContentChildren(TsumFaqSlideComponent, { descendants: true })
    public slideList: QueryList<TsumFaqSlideComponent>;

    private activeSlideSubject$ = new BehaviorSubject<number>(0);
    private initedSubject$ = new BehaviorSubject<boolean>(false);

    public get activeSlide$(): Observable<number> {
        return this.activeSlideSubject$.asObservable();
    }

    public get inited$(): Observable<boolean> {
        return this.initedSubject$.asObservable();
    }

    public get activeSlide(): number {
        return this.activeSlideSubject$.getValue();
    }

    public get isLastSlide$(): Observable<boolean> {
        return this.activeSlide$
            .pipe(
                filter(() => Boolean(this.slideList)),
                map((currentSlideNumber: number) => currentSlideNumber === this.slideList.length - 1)
            );
    }

    public get isFirstSlide$(): Observable<boolean> {
        return this.activeSlide$
            .pipe(
                map((currentSlideNumber: number) => currentSlideNumber === 0)
            );
    }

    public get currentSlide(): ElementRef<any> {
        return this.slideList
            .find((slide: TsumFaqSlideComponent, index: number) => index === this.activeSlide).contentTemplate;
    }

    constructor(
        public elementRef: ElementRef,
        private renderer: Renderer2,
        private sanitizer: Sanitizer,
        private changeDetectorRef: ChangeDetectorRef,
    ) {}

    public ngAfterViewInit(): void {
        this.initedSubject$.next(true);

        if (!this.changeDetectorRef['destroyed']) {
            this.changeDetectorRef.detectChanges();
        }
    }

    public setStyle(style: string, value: string): void {
        this.renderer.setStyle(this.elementRef.nativeElement, style, value);
    }

    public getProgressCssVariable(): string {
        const activeSlide = this.activeSlide + 1;
        const perSlideWidth = PROGRESS_BAR_WIDTH / this.slideList.length;
        const progressWidth = perSlideWidth * activeSlide;

        return (this.sanitizer as any).bypassSecurityTrustStyle(`--tsum-faq-progress: ${progressWidth}px`);
    }

    public getPositionCssVariable(): string {
        const perSlideWidth = PROGRESS_BAR_WIDTH / this.slideList.length;

        return (this.sanitizer as any).bypassSecurityTrustStyle(`--tsum-faq-position: ${perSlideWidth}px`);
    }

    public openNextPage(): void {
        this.activeSlideSubject$.next(this.activeSlideSubject$.getValue() + 1);

        this.changeEmitter.next('next');
    }

    public openPrevPage(): void {
        this.activeSlideSubject$.next(this.activeSlideSubject$.getValue() - 1);

        this.changeEmitter.next('prev');
    }

    public end(): void {
        this.changeEmitter.next('end');
    }

    public openStart(): void {
        this.activeSlideSubject$.next(0);

        this.changeEmitter.next('start');
    }

    public resetToDefault(): void {
        this.activeSlideSubject$.next(0);
    }
}
