import { Pipe, PipeTransform } from '@angular/core';
import { TsumNotification } from '../tsum-air-message.namespace';
import { TsumIcon } from '../../../tsum-utils/tsum-icons/tsum-icon.namespace';

/**
 * @description Return notification icon, depends of notification type
 */
@Pipe({
    name: 'airMessageIcon',
})
export class TsumAirMessageIconPipe implements PipeTransform {
    transform(notificationType: TsumNotification.Type): string {
        switch (notificationType) {
            case 'error':
                return TsumIcon.Notifications.HollowError;

            case 'warning':
                return TsumIcon.Notifications.HollowWarning;

            case 'info':
                return TsumIcon.Notifications.HollowInfo;

            case 'success':
                return TsumIcon.Notifications.HollowSuccess;

            default:
                return TsumIcon.Notifications.HollowInfo;
        }
    }

}
