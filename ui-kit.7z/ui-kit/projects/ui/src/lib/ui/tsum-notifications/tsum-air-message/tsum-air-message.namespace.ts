/**
 * @description Namespace for TsumNotifications. Keep enums, interfaces, types and other
 */
export namespace TsumNotification {
    export interface Notification {
        type: Type;
        title?: string;
        description?: string;
        timeoutClose?: number;
        id?: string;
        deleted?: boolean;
    }

    export type Type = 'error' | 'warning' | 'info' | 'success';

    export enum Timeout {
        UltraFast = 100,
        Fast = 2000,
        Medium = 5000,
        Slow = 10000,
        Endless = Infinity,
    }
}
