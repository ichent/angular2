import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumNotificationAlertComponent } from './tsum-notification-alert.component';
import { TsumNotificationAlertDirective } from './tsum-notification-alert.directive';

const COMPONENTS = [
    TsumNotificationAlertComponent,
];

const DIRECTIVES = [
    TsumNotificationAlertDirective,
];

/**
 * @description Count of alerts notification
 * @example <tsum-notification-alert>14</tsum-notification-alert>
 * @example <div [tsumNotificationAlert]="14"></div>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-alert--default}
 */
@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        COMPONENTS,
        DIRECTIVES,
    ],
    exports: [
        COMPONENTS,
        DIRECTIVES,
    ],
    entryComponents: [
        TsumNotificationAlertComponent,
    ],
})
export class TsumNotificationAlertModule {
}
