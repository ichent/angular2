import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumNotificationStatusComponent } from './tsum-notification-status.component';

const COMPONENTS = [
    TsumNotificationStatusComponent,
];

/**
 * @description Status text with many colors, by default is default color
 * @description Possible variety of types, you need attach as attribute(input) this type
 * @description default - default color
 * @description primary - primary color
 * @description danger - danger color
 * @description info - info color
 * @description success - success color
 * @example <tsum-notification-status primary>Text</tsum-notification-status>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/notifications-status--default}
 */
@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class TsumNotificationStatusModule {
}
