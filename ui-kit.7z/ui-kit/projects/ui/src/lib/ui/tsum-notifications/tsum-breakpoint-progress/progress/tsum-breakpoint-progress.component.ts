import { Component, Input, ChangeDetectionStrategy, HostBinding } from '@angular/core';

import { TsumBreakpointProgress } from '../tsum-breakpoint-progress.namespace';

/**
 * @description Breakpoint Progress component
 * Данный компонент предназначен для отображения прогрессии, но с разделительными точками
 * В данные точки можно добавить свой функционал, например - кнопки
 * @example <tsum-breakpoint-progress [breakpoints]="breakpoints" type="vertical" size="default"></tsum-breakpoint-progress>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-progress--breakpoint-progress}
 */
@Component({
    selector: 'tsum-breakpoint-progress',
    templateUrl: './tsum-breakpoint-progress.component.html',
    styleUrls: ['./tsum-breakpoint-progress.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumBreakpointProgressComponent {
    @Input()
    public breakpoints: TsumBreakpointProgress.Breakpoint[];

    @Input()
    public type: 'vertical' | 'horizontal' = 'vertical';

    @HostBinding('class')
    @Input()
    public size: 'default' | 'small' = 'default';
}
