import {
    ComponentFactory,
    ComponentFactoryResolver,
    ComponentRef,
    Directive,
    Input,
    OnDestroy,
    ViewContainerRef,
} from '@angular/core';
import { TsumTooltipComponent } from './tsum-tooltip.component';
import { fromEvent, Subject } from 'rxjs';
import { debounceTime, startWith, switchMap, takeUntil, tap } from 'rxjs/operators';
import { TsumTooltip } from './tsum-tooltip.namespace';
import { TsumInputBoolean } from '@tsum/utils';

@Directive({
    selector: '[tsumTooltip], [tsumTextOverflowTooltip]',
})
export class TsumTooltipDirective implements OnDestroy {
    @Input() set tsumTooltip(text: string) {
        this.text = text;
        this.text ? this.listenPointer() : this.destroyed$.next();
    }

    @Input('tsumTooltipDelay')
    public delay = 1000;

    @TsumInputBoolean()
    @Input('tsumTooltipTextWrap')
    public textWrap = false;

    @Input('tsumTooltipPosition')
    public position: TsumTooltip.Position = TsumTooltip.Position.Right;

    @Input('tsumTooltipMinOffset')
    public minOffset: number = 200;

    @TsumInputBoolean()
    @Input('tsumTooltipImage')
    public isImage = false;

    @TsumInputBoolean()
    @Input('tsumTooltipBind')
    public isBindToContainer = false;

    public text = '';

    private componentRef: ComponentRef<TsumTooltipComponent>;
    private factory: ComponentFactory<TsumTooltipComponent>;
    private destroyed$ = new Subject<void>();

    constructor(
        private resolver: ComponentFactoryResolver,
        private viewContainerRef: ViewContainerRef,
    ) {}

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private listenPointer(): void {
        const containerElement: Element = this.viewContainerRef.element.nativeElement;

        fromEvent(containerElement, 'mouseleave')
            .pipe(
                tap(() => this.removeTooltip()),
                startWith(null as Event),
                switchMap(() => fromEvent(containerElement, 'mouseenter')
                    .pipe(
                        debounceTime(this.delay),
                    ),
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe((event: MouseEvent) => this.createTooltip(event));
    }

    private removeTooltip(): void {
        if (this.viewContainerRef) {
            this.viewContainerRef.clear();
        }
        if (this.componentRef) {
            this.componentRef.destroy();
        }
    }

    private createTooltip(event: MouseEvent): void {
        if (!this.factory) {
            this.factory = this.resolver.resolveComponentFactory(TsumTooltipComponent);
        }

        this.removeTooltip();
        this.componentRef = this.viewContainerRef.createComponent(this.factory);

        const containerElement: Element = this.viewContainerRef.element.nativeElement;

        let correctedPosition: TsumTooltip.Position = this.position;
        const styleClass: string[] = [];

        let offsetX: number = event.clientX;
        let offsetY: number = event.clientY;

        if (this.isBindToContainer) {
            const containerPositions: ClientRect = containerElement.getBoundingClientRect();
            offsetX = containerPositions.left;
            offsetY = containerPositions.top;
        }

        const topOffset: number = document.body.clientHeight - offsetY;
        const rightOffset: number = document.body.clientWidth - offsetX;

        if ((this.position === TsumTooltip.Position.Bottom) && (topOffset < this.minOffset)) {
            correctedPosition = TsumTooltip.Position.Top;
        }

        if ((this.position === TsumTooltip.Position.Right) && (rightOffset < this.minOffset)) {
            correctedPosition = TsumTooltip.Position.Left;
        }

        if (this.position === TsumTooltip.Position.Top && offsetY < this.minOffset) {
            correctedPosition = TsumTooltip.Position.Bottom;
        }

        if (this.position === TsumTooltip.Position.Left && offsetX < this.minOffset) {
            correctedPosition = TsumTooltip.Position.Right;
        }

        if (this.isBindToContainer) {
            if (correctedPosition === TsumTooltip.Position.Bottom) {
                offsetY += containerElement.clientHeight;
            }

            if (correctedPosition === TsumTooltip.Position.Right) {
                offsetX += containerElement.clientWidth;
            }
        }

        if (correctedPosition === TsumTooltip.Position.Top) {
            offsetY = topOffset;
        }

        if (correctedPosition === TsumTooltip.Position.Left) {
            offsetX = rightOffset;
        }

        if (this.textWrap) {
            styleClass.push(TsumTooltip.StyleClass.BreakWord);
        }

        if (this.isImage) {
            styleClass.push(TsumTooltip.StyleClass.ImageSmall);
        }

        styleClass.push(correctedPosition);

        const instance: TsumTooltipComponent = this.componentRef.instance;
        instance.text = this.text;
        instance.hasImage = this.isImage;
        instance.position = correctedPosition;
        instance.styleClass = styleClass.join(' ');
        instance.offsetX = offsetX;
        instance.offsetY = offsetY;
        this.componentRef.changeDetectorRef.detectChanges();
    }
}
