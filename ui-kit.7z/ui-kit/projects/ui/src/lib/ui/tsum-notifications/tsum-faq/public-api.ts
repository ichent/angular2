export * from './tsum-faq.module';
export * from './components/index';
export * from './tsum-faq.namespace';
