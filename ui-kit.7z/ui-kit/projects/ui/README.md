# Использование
1. Устанавливаем ui-kit `npm i git+ssh://git@gitlab.int.tsum.com:tsum-platform/ui.git --save`
2. Импортируем нужный модуль, например import { TsumButtonModule } from '@tsum/ui'
3. Можно использовать в проекте, например `<tsum-button>test</tsum-button>`
4. Импорт стилей делать через @import '~@tsum/ui/style/index.styl';
