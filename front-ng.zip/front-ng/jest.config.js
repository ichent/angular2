module.exports = {
    globals: {
        'ts-jest': {
            tsConfig: '<rootDir>/tsconfig.spec.json',
            stringifyContentPathRegex: '\\.html$',
            astTransformers: [
                '<rootDir>/node_modules/jest-preset-angular/InlineHtmlStripStylesTransformer',
            ],
            diagnostics: false,
        },
    },
    transform: {
        '^.+\\.(ts|js|html)$': 'ts-jest',
    },
    testEnvironment: 'jest-environment-jsdom-thirteen',
    moduleFileExtensions: ['ts', 'html', 'js', 'json'],
    moduleNameMapper: {
        '^src/(.*)$': '<rootDir>/src/$1',
        '^app/(.*)$': '<rootDir>/src/app/$1',
        '^assets/(.*)$': '<rootDir>/src/assets/$1',
        '^environments/(.*)$': '<rootDir>/src/environments/$1',
    },
    modulePathIgnorePatterns: [
        "<rootDir>/cypress/"
    ],
    transformIgnorePatterns: [
        'node_modules/(?!@ngrx)',
    ],
    snapshotSerializers: [
        './node_modules/jest-preset-angular/AngularSnapshotSerializer.js',
        './node_modules/jest-preset-angular/HTMLCommentSerializer.js',
    ],
};
