/**
 *
 * Работа с браузерным хранилищем
 *
 */

/**
 * Очистка sessionStorage
 */
Cypress.Commands.add('clearSessionStorage', () => {
    cy.log('Clearing session storage');
    cy.window().then(window => window.sessionStorage.clear());
});
