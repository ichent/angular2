import { snakeCaseToCamel, transformPosition } from "../helpers";

/**
 *
 * ПОЛУЧЕНИЕ ДАННЫХ
 *
 */

/**
 * Стора страницы создания/редактирования лука
 */
Cypress.Commands.add('getLookListProductsStore', () => {
    return cy.window().then(window => window['look-list-products'])
});

/**
 * Первый товар из сторы создания/редактирования лука
 */
Cypress.Commands.add('getLookListProductsStoreFirstItem', () => {
    return cy.getLookListProductsStore()
        .then(store => {
            const firstKey = Object.keys(store.entities)[0];
            return store.entities[firstKey].listItem;
        });
});

/**
 * Стора списков товаров / списков луков
 */
Cypress.Commands.add('getProductListStore', () => {
    return cy.window().then(window => window['product-list'])
});

/**
 * Id текущего списка товаров
 */
Cypress.Commands.add('getCurrentProductListId', () => {
    return cy.getProductListStore().then(store => store.active);
});

/**
 * Текущий список товаров
 */
Cypress.Commands.add('getCurrentProductList', () => {
    return cy.getProductListStore()
        .then((listsStore) => {
            return cy.getCurrentProductListId()
                .then((currentListId) => {
                    return listsStore.entities[currentListId];
                });
        });
});

/**
 * Конкретный список товаров/луков из общей сторы списка товаров/луков
 */
Cypress.Commands.add('getProductListStoreEntity', (id) => {
    return cy.getProductListStore().then(store => {
        return store.entities[id];
    });
});


/**
 *
 * ПРОВЕРКА ДАННЫХ
 *
 */

/**
 * Проверить что текущий список товаров обнулился
 */
Cypress.Commands.add('checkCurrentProductListIsNull', () => {
    cy.log('Current product list is null');
    cy.getCurrentProductListId().then((currentProductListId) => expect(currentProductListId).to.be.null);
});

/**
 * Проверить что текущий список существует
 */
Cypress.Commands.add('checkCurrentProductListIsExist', () => {
    cy.log('Current product list is exist');
    cy.getCurrentProductListId().then((currentProductListId) => expect(currentProductListId).to.exist);
});

/**
 * Проверка `productList` на соотвествие локальному стейту списка/лука в сторе по его id
 */
Cypress.Commands.add('isEqualToListInStore', (productList) => {
    cy.getProductListStoreEntity(productList.id)
        .then(productListInStore => cy.isProductListsEquals(productListInStore, productList));
});

/**
 * Проверка товаров `externalList` на соотвествие товарам в сторе текущего списка
 */
Cypress.Commands.add('isItemsEqualsToCurrentProductList', (externalList) => {
    cy.getCurrentProductList().then((currentProductList) => cy.isProductListsItemsEquals(currentProductList, externalList));
});

/**
 * Проверка списков/луков на соотвествие друг другу
 * listInStore может быть как из общей сторы списков (product-list) так и из сторы текущего лука (look-list-products)
 */
Cypress.Commands.add('isProductListsEquals', (listInStore, listFromApi) => {
    expect(listInStore.id).to.equal(listFromApi.id);
    expect(listInStore.listInfo.title).to.equal(listFromApi.title);
    expect(listInStore.status).to.equal(listFromApi.status);
    cy.isProductListsItemsEquals(listInStore, listFromApi);
});

/**
 * Проверка на сооствествите items/entities в `listInStore` с `listFromApi`
 * listInStore может быть как из общей сторы списков (product-list) так и из сторы текущего лука (look-list-products)
 */
Cypress.Commands.add('isProductListsItemsEquals', (listInStore, listFromApi) => {
    Object.keys(listInStore.entities || listInStore.items).forEach(productHash => {
        const localListItem = listInStore.entities
            ? listInStore.entities[productHash].listItem
            : listInStore.items[productHash];

        const externalListItem = listFromApi.items[productHash];
        let cameledExternalListItem = Object.fromEntries(
            Object.entries(externalListItem).map(([ key, value ]) => [ snakeCaseToCamel(key), value ])
        );

        if (listInStore.isLook) {
            const imageRatio = externalListItem.width / externalListItem.height;
            const defaultRatio = 0.65; // width/height рамки
            cameledExternalListItem = transformPosition(defaultRatio, imageRatio, cameledExternalListItem, false);
        }

        Object.keys(localListItem).forEach(key => {
            const message = `Local listItem key(${key}) is equal to external one (value is: ${localListItem[key]})`;

            expect(localListItem[key]).to.be.equal(cameledExternalListItem[key], message);
        });
    });
});
