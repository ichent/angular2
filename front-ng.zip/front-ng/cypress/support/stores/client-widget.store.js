/**
 * Стора виджета клиента со списком кастомеров
 */
Cypress.Commands.add('getClientWidgetCustomersStore', () => {
    return cy.window().then(window => window['client-widget-customers-sidenav'])
});
