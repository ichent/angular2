/**
 * Мок ответа метода получения заказа
 *
 * @param order - данные заказа, которые необходимо изменить в дефолтном варианте (order-res.json)
 */
Cypress.Commands.add('openMocOrderPage', (order = { status: 1 }) => {
    cy.oauth(`/order/${order.status}`);

    cy.server();

    cy.fixture('order/order-res').then((res) => {
        if (order && (order.status === 0 || order.status)) {
            res.data.status = order.status;
            res.data.uuid = order.status;
        }

        cy.route('GET', '/api/order/*', res).as('order');
    });

    cy.wait('@order');
});

/**
 * Сохранение лука как личный или публичный
 *
 * @param status - id статуса
 * @param title - название статуса в интерфейсе
 * @param groupTitle - название группы статуса в интерфейсе
 * @param actions - название действий доступных в этом статусе (некоторые действия объединены общим названием)
 */
Cypress.Commands.add('checkOrderStatus', ({ status, title, groupTitle, actions }) => {
    cy.get('[data-cy="order-status-group"].active')
        .within(() => {
            cy.scrollTo(0, 0);
            cy.get('[data-cy="order-status-title"]').should('contain', title);
            cy.get('[data-cy="order-status-group-title"]').should('contain', groupTitle);

            cy.get('[data-cy="order-status-actions-button"]').click({ force: true });

            cy.get('[data-cy="order-status-action"]').should('have.length', actions.length);
            actions.forEach((actionUiTitle) => {
                cy.get('[data-cy="order-status-actions"]').should('contain', actionUiTitle);
            });
        });

    // cy.screenshot(`order_status_${status}`, {  capture: 'viewport' });
});
