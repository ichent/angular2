/**
 * Проверить есть ли список или лук на странице списков товаров/луков
 */
Cypress.Commands.add('checkListIsOnThePage', (listId) => {
    cy.log('Checking the page contains the list');
    cy.get('[data-cy="list-id"]').contains(listId);
});
