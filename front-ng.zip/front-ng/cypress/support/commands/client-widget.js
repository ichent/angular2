Cypress.Commands.add('cwInit', (fx = 'one-client') => {
    cy.server();
    cy.route('POST', '/crm/v1/api/search/by-communication', `fx:client-widget/${fx}`).as('by-communication');
    cy.oauth('/catalog?incoming=79000000001&type=phone&user=asd');
    cy.wait('@by-communication');
});
