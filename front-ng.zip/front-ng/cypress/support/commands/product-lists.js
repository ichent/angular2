/**
 * Добавление товаров в список со страницы каталога
 */
Cypress.Commands.add('addProductsToList', (productsIndexes = [0, 1]) => {
    cy.server();
    cy.route('POST', '/api/product-lists/add-item-to-list/bulk').as('addProductToList');
    cy.get('[data-cy="add-to-product-list-button"]').as('addButtons');

    productsIndexes.forEach((productIndex) => {
        cy.get('@addButtons').eq(productIndex).click({ force: true });
        cy.wait('@addProductToList');
    });
});

/**
 * Открыть сайднав списка товаров со страницы каталога
 */
Cypress.Commands.add('openProductListSidenav', () => {
    cy.log('Opening the save product list sidenav');
    cy.get('[data-cy="open-product-list-sidenav"]').click({ force: true });
});

/**
 * Открыть ещё действия в сайднаве списка товаров
 */
Cypress.Commands.add('openActionsInListSidenav', () => {
    cy.log('Opening actions in product list sidenav');
    cy.get('[data-cy="product-list-sidenav-more-actions"]').click({ force: true });
});

/**
 * Открыть форму сохранения списка товаров в сайднаве сохранения списка товаров.
 */
Cypress.Commands.add('chooseSaveProductListSidenavAction', () => {
    cy.log('Opening the save product list form');
    cy.get('[data-cy="product-list-sidenav-open-save-form"]').click({ force: true });
});
