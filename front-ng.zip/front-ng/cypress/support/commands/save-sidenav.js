/**
 * Заполнить форму сохранения списка/лука
 * @param saveAsOption: 'private', 'public'
 */
Cypress.Commands.add('fillSaveListSidenavForm', (saveAsOption) => {
    cy.log('Filling the form');
    cy.get('[data-cy="save-sidenav-description-input"]').type('test via cypress');

    if (saveAsOption === 'private') {
        cy.contains('Личный').click();
    } else if (saveAsOption === 'public') {
        cy.contains('Публичный').click();
    }

});

/**
 * Отправить форму сохранения списка/лука
 */
Cypress.Commands.add('submitSaveListSidenavForm', () => {
    cy.log('Saving a list or a look');
    cy.get('[data-cy="save-look-sidenav-save-button"]')
        .should('not.be.disabled')
        .click({ force: true });
});

/**
 * Открыть сайднав отправки ссылки на список/лук внутри сайндава сохранения списка/лука
 */
Cypress.Commands.add('openInnerSendListSidenav', () => {
    cy.log('Opening an inner create link sidenav');
    cy.get('[data-cy="open-create-list-link-sidenav-button"]').click({ force: true });
});

/**
 * Заполнить форму отправки списка/лука
 */
Cypress.Commands.add('fillSendListForm', () => {
    cy.log('Filling at least one field (client phone number) for sending look to user');
    cy.get('input[data-cy="client-phone-input"]').type(1111111111, { force: true });
});

/**
 * Отправить форму отправки списка/лука
 */
Cypress.Commands.add('submitSendListForm', () => {
    cy.log('Generating a sent look by clicking the button');
    cy.get('[data-cy="generate-list-link-button"]').click({ force: true });
});

/**
 * Нажать кнопку "готово", тем самыйм закрыв сайднав
 */
Cypress.Commands.add('pressDoneButtonInSaveSidenav', () => {
    cy.log('Pressing the done button');
    cy.get('[data-cy="done-with-sending-list-button"]').click({ force: true });
});
