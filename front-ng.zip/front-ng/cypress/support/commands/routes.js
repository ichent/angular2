/**
 * Проверить url на частичное соотвествите
 */
Cypress.Commands.add('checkUrl', (url) => {
    cy.log(`The url includes ${url}`);
    cy.url().should('include', url);
});
