Cypress.Commands.add('mocCatalogForLooks', () => {
    cy.server();
    cy.route('GET', '/v2/catalog/search**', `fx:catalog/for-looks/products`).as('products');
    cy.route('POST', '/api/catalog/sizes**', `fx:catalog/for-looks/sizes`).as('sizes');
    cy.wait('@products');
    cy.wait('@sizes');
});
