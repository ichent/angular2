/**
 * Создание лука через сайндав на странице каталога
 */
Cypress.Commands.add('toLookCreatingPageViaProductListSidenav', () => {
    cy.openProductListSidenav();
    cy.openActionsInListSidenav();
    cy.get('[data-cy="product-list-sidenav-create-look"]').click({ force: true });
    cy.url().should('include', 'look/edit');
});

/**
 * Перемещение первого товара на холст, создавая тем самым лук.
 * position: topLeft, top, topRight, left, center, right, bottomLeft, bottom, bottomRight
 */
Cypress.Commands.add('moveFirstProductToCanvas', (position = 'topLeft', productIndex = 0) => {
    cy.server();
    cy.route('POST', /product-lists\/\d+\/copy-as-look/).as('lookWasCreated');
    cy.route('POST', /product-lists\/\d+\/replace-items/).as('replaceLookItems');
    moveProductToCanvas(position, productIndex);

    // Дождаться создания лука из текущего списка и обновления items в созданном луке
    cy.wait(['@lookWasCreated', '@replaceLookItems']);
});

/**
 * Перемещение второго и последующих товаров на холст, когда лук уже создан
 * position: topLeft, top, topRight, left, center, right, bottomLeft, bottom, bottomRight
 */
Cypress.Commands.add('moveSubsequentProductToCanvas', (position = 'center', productIndex = 0) => {
    cy.server();
    cy.route('POST', /product-lists\/\d+\/replace-items/).as('replaceLookItems');
    moveProductToCanvas(position, productIndex);
    cy.wait('@replaceLookItems', { timeout: 10000 });
});

/**
 * Перемещение товара на холст без ожидания запросов. Не использовать напрямую!
 * position: topLeft, top, topRight, left, center, right, bottomLeft, bottom, bottomRight
 */
function moveProductToCanvas(position = 'topLeft',  productIndex = 0) {
    cy.get('[data-cy="look-product"]')
        .eq(productIndex)
        .trigger('mouseover')
        .trigger('mousedown', 'topLeft', { which: 1, force: true, button: 0 })
        // для сдвига фотографии за порог dnd с сохранением события mousedown
        .trigger('mousemove', { clientX: -100, clientY: -100 });

    cy.get('[data-cy="look-canvas-target"]')
        .trigger('mousemove', position, { force: true })
        .trigger('mouseup', { force: true });
}

/**
 * Точное перемещение товаров по канве на странице редактирования/создания лука
 * newPosition: topLeft, top, topRight, left, center, right, bottomLeft, bottom, bottomRight
 */
Cypress.Commands.add('moveProductOnCanvas', (left = 0, top = 0, productIndex = 0) => {
    cy.get('[data-cy="look-canvas-target"]')
        .eq(0)
        .scrollIntoView()
        .then(canvasTarget => {
            const rect = canvasTarget.get(0).getBoundingClientRect();

            cy.get('[data-cy="look-canvas-product"]')
                .eq(productIndex)
                .trigger('mouseover')
                .trigger('mousedown', 'topLeft', { which: 1, force: true, button: 0 })
                // для сдвига фотографии за порог dnd с сохранением события mousedown
                .trigger('mousemove', { clientX: -100, clientY: -100 });

            cy.get('[data-cy="look-canvas-target"]')
                .trigger('mousemove', { clientX: rect.left + left, clientY: rect.top + top })
                .trigger('mouseup', { force: true });
        });

    cy.wait(50);
});

/**
 * Выбор размер у товара на холсте, если есть размер товара
 */
Cypress.Commands.add('selectProductSizeInCanvas', (productIndex = 0, sizeIndex = 0) => {
     // Нажать на иконку "i" для открытия оверлея с информацией и селектором размера
     cy.get('[data-cy="look-canvas-product-show-info"]')
         .eq(productIndex)
         // force нужен клик корректно срабатывал, если кнопка скрыта за другими элементами (например, fixed меню)
         .click({ force: true });

    cy.get('[data-cy="look-canvas-product"]').eq(productIndex)
        .then(el => {
            // Если есть селектор размера (исключаем вариант с NS)
            if (/look-canvas-product-size-selector/.test(el.html())) {
                // Открываем селектор размеров
                cy.get('[data-cy="look-canvas-product-size-selector"]').eq(productIndex).click();
                // Выбираем размер по индексу
                cy.get('[data-cy="look-canvas-product-size-option"]').eq(sizeIndex).click();
            }
        });
});

/**
 * Увеличение масштаба товара на холсте
 */
Cypress.Commands.add('scaleLookProductUp', (productIndex = 0) => {
    cy.scaleLookProduct(productIndex, 30, -30);
});

/**
 * Уменьшение масштаба товара на холсте
 */
Cypress.Commands.add('scaleLookProductDown', (productIndex = 0) => {
    cy.scaleLookProduct(productIndex, -30, 30);
});

/**
 * Изменение масштаба товара на холсте путем перемещения мыши от заданного resizeHandlerIndex на расстояние distanceX и distanceY.
 */
Cypress.Commands.add('scaleLookProduct', (productIndex = 0, distanceX = 30, distanceY = -30, resizeHandlerIndex = 1) => {
    cy.get('[data-cy="look-canvas-product"]')
        .eq(productIndex)
        .click();

    cy.get('[data-cy="resize-handler"]')
        .eq(resizeHandlerIndex)
        .trigger('mousedown', { which: 1, force: true })
        .trigger('mousemove',  distanceX, distanceY)
        .wait(200);

    cy.get('[data-cy="look-canvas-target"]')
        .trigger('mouseup', { force: true });
});

/**
 * Совершить действие на странице списков товаров/луков
 * со списком, который был отредактирован/создан последним
 *
 * @param action: copyAsPrivate | edit
 */
Cypress.Commands.add('makeActionWithListOnListsPage', (action) => {
    cy.log('Taking the active list row in the lists table');

    cy.get('[data-cy="table-row"][data-cy-active]')
        .eq(0)
        .within(() => {
            cy.log('Clicking the list\'s actions button');
            cy.get('[data-cy="list-action-selector"]').click({ force: true })
        });

    cy.log(`Clicking on the ${action} button`);

    let actionSelectorText = null;

    if (action === 'copyAsPrivate') {
        actionSelectorText = 'Создать копию';
    } else if (action === 'edit') {
        actionSelectorText = 'Изменить';
    }

    cy.get('tsum-popover-component').contains(actionSelectorText).click({ force: true });
});

/**
 * Проверка `externalLook` на соотвествие локальному стейту текущего лука
 */
Cypress.Commands.add('isEqualToLookInCurrentLookStore', (externalLook) => {
    cy.getLookListProductsStore()
        .then(lookInStore => cy.isProductListsEquals(lookInStore, externalLook));
});
