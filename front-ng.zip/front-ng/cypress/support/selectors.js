export const getSelector = (name) => {
    return `[data-cy="${name}"]`;
};

export const CLIENT_WIDGET_INCOMING_ICON = 'client-widget-incoming-icon';
export const CLIENT_WIDGET_INCOMING_VALUE = 'client-widget-incoming-value';
export const CLIENT_WIDGET_CUSTOMER_NAME = 'client-widget-customer-name';
export const CLIENT_WIDGET_ACTIONS = 'client-widget-actions';
export const CLIENT_WIDGET_ACTION = 'client-widget-action';
export const CLIENT_WIDGET_BAR_EXPANDER = 'client-widget-bar-expander';
export const CLIENT_WIDGET_BOX_EXPANDER = 'client-widget-box-expander';
export const CLIENT_WIDGET_MORE_CUSTOMERS = 'client-widget-more-customers';
export const CLIENT_WIDGET_BOX = 'client-widget-box';
export const CLIENT_WIDGET_BAR = 'client-widget-bar';
export const CLIENT_WIDGET_CUSTOMERS = 'client-widget-customers';
export const CLIENT_WIDGET_CUSTOMER = 'client-widget-customer';
export const CLIENT_WIDGET_SELECT_CUSTOMER_BUTTON = 'client-widget-select-customer-button';
