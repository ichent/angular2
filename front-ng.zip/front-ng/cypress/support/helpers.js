export const camelCaseToSnake = (string) => string && string.replace(/[A-Z]/g, g => '_' + g.toLowerCase());

export const snakeCaseToCamel = (string) => string && string.replace(/_([a-z])?/g, (_, l = '') => l.toUpperCase());

export const accessTokenFilePath = 'cypress/fixtures/token.json';

function roundNumber(value, digitsAfterComma = 2) {
    return value ? Number(value.toFixed(digitsAfterComma)) : 0;
}

/**
 * @description Используется для преобразования координат товара на холсте, тк на стороне Back-End
 * позиционирование идет относительно фотографии
 */
export function transformPosition(outerRatio, innerRatio, initialParams, inside = true) {
    let width;
    let height;
    let dx = 0;
    let dy = 0;

    if (innerRatio > outerRatio) {
        width = initialParams.width;
        height = width / (inside ? innerRatio : outerRatio);
        dy = (initialParams.height - height) * initialParams.scaleY / 2;
    } else {
        height = initialParams.height;
        width = height * (inside ? innerRatio : outerRatio);
        dx = (initialParams.width - width) * initialParams.scaleX / 2;
    }

    return {
        ...initialParams,
        width: roundNumber(width),
        height: roundNumber(height),
        top: roundNumber(initialParams.top + dy),
        left: roundNumber(initialParams.left + dx),
    };
}

export function saveAuthTokenInCurrentSession(token) {
    window.localStorage.setItem("userAccessToken", token);
}

export function isAccessTokenExpired(tokenCreatedTime, countHoursIfIsExpired = 1) {
    return Date.now() / 1000 - Date.parse(tokenCreatedTime) / 1000 > 60 * 60 * countHoursIfIsExpired;
}
