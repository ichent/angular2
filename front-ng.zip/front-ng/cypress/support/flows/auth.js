/**
 *
 * АВТОРИЗАЦИЯ ПОЛЬЗОВАТЕЛЕЙ
 *
 */

import { saveAuthTokenInCurrentSession, isAccessTokenExpired, accessTokenFilePath } from "../helpers";

/**
 * Основной метод авторизация пользователя в системе
 */
Cypress.Commands.add('oauth', (route = '/catalog', login = 'cc_apa', password = '123456') => {
    sessionStorage.clear();

    cy.log('Authorizing');

    cy.task('readFileIfExists', accessTokenFilePath).then((content) => {
        if (!content) {
            authViaApi(route, login, password);
        } else {
            const tokenData = JSON.parse(content);

            if (isAccessTokenExpired(tokenData.time)) {
                authViaApi(route, login, password);
            } else {
                saveAuthTokenInCurrentSession(tokenData.token);
            }
        }

        cy.visit(route);
        cy.checkUrl(route);
    });
});

/**
 * Авторизация через редирект на стороннюю страницу авторизации oauth (как делают пользователи)
 */
function authViaForm(route, login, password) {
    cy.visit(route);
    cy.get("input[name='username']").type(login);
    cy.get("input[name='password']").type(password);
    cy.get("form[name='login-form']").submit();
    cy.get(".message-instead-of-form a").click();
}

/**
 * Авторизация через API
 *
 * ВАЖНО!
 * Используется магический код авторизации полученный от тестировщиков.
 * Работает быстрее чем авторизации через форму, но метод менее надёжный.
 * В случае отказа, использовать надежный метод авторизации через форму (authViaForm).
 */
function authViaApi(route, login, password) {
    cy.request({
        method: 'POST',
        url: 'https://oauth-alpha.int.tsum.com/api/oauth/code',
        form: true,
        body: {
            clientId: '90899b8aa04d7d3a40aa86655d5dbd17',
            username: login,
            password: password,
            redirectUrl: 'https://cc-cmi-beta.int.tsum.com/oauth'
        }
    })
        .then((response) =>
            cy.request({
                method: 'POST',
                url: 'https://api-cc-cmi-beta.int.tsum.com/api/oauth/code',
                form: true,
                body: {
                    code: response.body.data['code'],
                    redirect_url: 'https://cc-cmi-beta.int.tsum.com/oauth'
                }
            })
        )
        .then((response) => {
            saveAuthTokenInCurrentSession(response.body.data['access_token']);

            cy.writeFile(accessTokenFilePath, {
                token: response.body.data['access_token'],
                time: new Date().toISOString()
            });
        });
}
