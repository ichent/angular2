/**
 * Данный файл предназначен для создания законченных сущностей луков(образов).
 * Используются комбинация более низкоуровневых команд из commands.js
 *
 * Например, создать черновик/личный/публичны/отправленный лук(образ).
 */

/**
 * Создание черновика лука
 *
 * Начальная страница: каталог, список пуст
 * Конечная страница: страница редактирования лука, список пуст, 2 товара в луке (draft)
 */
Cypress.Commands.add('createDraftLook', () => {
    cy.log('Creating a draft look');
    cy.clearSessionStorage();
    cy.createDraftList();
    cy.toLookCreatingPageViaProductListSidenav();
    cy.moveFirstProductToCanvas();
    cy.moveSubsequentProductToCanvas();
    cy.get('[data-cy="look-product"]').should('have.length', 0);
    cy.get('[data-cy="look-canvas-product"]').should('have.length', 2);
});

/**
 * Создание отправленного лука из текущего лука.
 *
 * Начальная страница: страница редактирования лука.
 * Конечная страница: страница списков отправленных луков.
 */
Cypress.Commands.add('createSentLook', (checkStateFunction) => {
    cy.log('Creating a sent look');

    cy.log('Opening a save look sidenav');
    cy.get('[data-cy="open-save-look-sidenav-button"]').click({ force: true });

    cy.openInnerSendListSidenav();
    cy.fillSendListForm();

    cy.submitSendListForm();

    cy.server();
    cy.route('POST', /product-lists\/\d+\/mark-as-sent/).as('sentList');
    cy.route('GET', '**/looks/sent**').as('sentPage');

    cy.log('Waiting for the sent look creation');

    return cy.wait('@sentList', { timeout: 10000 })
        .then(({ responseBody: { data: savedLookData} }) => {
            cy.log('Checking a copy link button existence');
            cy.get('[data-cy="copy-list-link-button"]');

            if (checkStateFunction) {
                checkStateFunction(savedLookData);
            }

            cy.pressDoneButtonInSaveSidenav();
            cy.checkUrl('/lists/looks/sent');
            cy.log('Waiting for the sent tab get loaded');
            cy.wait('@sentPage', { timeout: 10000 })
                .then(() => cy.checkListIsOnThePage(savedLookData.id));
        });
});

/**
 * Создание личного лука
 *
 * Начальная страница: каталог, список пуст
 * Конечная страница: страница списков личных луков, список пуст, 2 товара в луке (private),
 */
Cypress.Commands.add('createPrivateLook', (callback) => {
    cy.createDraftLook();
    cy.saveLookAs('private', callback);
    cy.checkCurrentProductListIsNull();
});

/**
 * Создание публичного лука
 *
 * Начальная страница: каталог, список пуст
 * Конечная страница: страница списков личных луков, список пуст, 2 товара в луке (public),
 */
Cypress.Commands.add('createPublicLook', (callback) => {
    cy.createDraftLook();
    cy.saveLookAs('public', callback);
    cy.checkCurrentProductListIsNull();
});

/**
 * Сохранение лука как личный или публичный
 *
 * Начальная страница: страница редактирования лука, лук создан
 * Конечная страница: страница списков личных или публичных луков
 *
 * @param listType: 'private', 'public'
 */
Cypress.Commands.add('saveLookAs', (lookType, callback) => {
    cy.log(`Creating a ${lookType} look`);

    cy.log('Opening save sidenav');
    cy.get('[data-cy="open-save-look-sidenav-button"]').click({ force: true });

    cy.fillSaveListSidenavForm(lookType);
    cy.submitSaveListSidenavForm();

    cy.server();
    cy.route('POST', /product-lists\/\\d+\/replace-items/).as('replaceLookItems');

    cy.wait('@replaceLookItems', { timeout: 10000 })
        .then(({ responseBody: { data: savedLookData} }) => {
            if (callback) {
                callback(savedLookData);
            }
            cy.checkUrl(`/lists/looks/${lookType}`);
            cy.checkListIsOnThePage(savedLookData.id);
        });
});
