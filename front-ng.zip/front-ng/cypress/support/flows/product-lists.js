/**
 * Данный файл предназначен для создания законченных сущностей списков товаров.
 * Используются комбинация более низкоуровневых команд из commands.js
 *
 * Например, создать черновик/личный/публичны/отправленный список товаров.
 */

/**
 * Создание черновика списка товаров
 *
 * Начальная страница: каталог, список пуст.
 * Конечная страница: каталог, 2 товара в списке (draft)
 */
Cypress.Commands.add('createDraftList', () => {
    cy.log('Creating a draft product list');
    cy.addProductsToList([0, 1]);
});

/**
 * Создание личного списка товаров
 *
 * Начальная страница: каталог, список пуст
 * Конечная страница: страница списков личных луков, список пуст, 2 товара в луке (private),
 */
Cypress.Commands.add('createPrivateList', (onCreated) => {
    cy.createDraftList();
    cy.saveProductListAs('private', onCreated);
    cy.checkCurrentProductListIsNull();
});

/**
 * Создание публичного списка товаров
 *
 * Начальная страница: каталог, список пуст
 * Конечная страница: страница списков личных луков, список пуст, 2 товара в луке (private),
 */
Cypress.Commands.add('createPublicList', (onCreated) => {
    cy.createDraftList();
    cy.saveProductListAs('public', onCreated);
    cy.checkCurrentProductListIsNull();
});

/**
 * Сохранение списка товаров как личный, публичный или отправленный
 *
 * Начальная страница: каталог, список товаров создан (черновик)
 * Конечная страница: страница списков личных или публичных товаров
 *
 * @param listType: 'private', 'public', 'sent'
 */
Cypress.Commands.add('saveProductListAs', (listType, checkStateFunction) => {
    const isSaveAsSent = listType === 'sent';
    cy.log(`Creating a ${listType} product list`);
    cy.openProductListSidenav();
    cy.openActionsInListSidenav();
    cy.chooseSaveProductListSidenavAction();
    cy.fillSaveListSidenavForm(listType);

    cy.server();
    cy.route('POST', new RegExp(`product-lists\/\\d+\/\\w+-as-${listType}`)).as('savingList');

    if (isSaveAsSent) {
        cy.openInnerSendListSidenav();
        cy.fillSendListForm();
        cy.submitSendListForm();
    } else {
        cy.submitSaveListSidenavForm();
    }

    cy.wait('@savingList').then(({ responseBody: { data: list} }) => {
        if (isSaveAsSent) {
            cy.log('Checking a copy link button existence');
            cy.get('[data-cy="copy-list-link-button"]');
            cy.pressDoneButtonInSaveSidenav();
        }

        if (checkStateFunction) {
            checkStateFunction(list);
        }

        expect(list.status).to.equal(listType);
        cy.checkUrl(`/lists/products/${listType}`);
        cy.checkListIsOnThePage(list.id);
    });
});
