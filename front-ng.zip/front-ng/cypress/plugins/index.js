// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

const fs = require('fs');

module.exports = (on, config) => {
    // `on` is used to hook into various events Cypress emits
    // `config` is the resolved Cypress config

    /**
     * Fix Chrome crash in docker container.
     *
     * By default, Docker runs a container with a /dev/shm shared memory space 64MB.
     * This is typically too small for Chrome and will cause Chrome to crash when rendering large pages.
     * To fix, run the container with docker run --shm-size=1gb to increase the size of /dev/shm. Since Chrome 65,
     * this is no longer necessary. Instead, launch the browser with the --disable-dev-shm-usage flag.
     *
     * You can read more here:
     * Cypress issue: https://github.com/cypress-io/cypress/issues/350
     * Chrome documentation: https://developers.google.com/web/tools/puppeteer/troubleshooting#tips
     */
    on('before:browser:launch', (browser = {}, args) => {
        if (browser.name === 'chrome') {
            args.push('--disable-dev-shm-usage');
            return args;
        }

        return args;
    });

    /**
     * Вызов: cy.log()
     * Нужно использовать чтобы было видно сообщения в gitlab ci во время запуска job'ы в целях дебагинга.
     * Особенно актуально при длинных сценариях.
     */
    on("task", {
        log(message) {
            // Tasks have access to node`s console so print log messages directly to it.
            console.info('>>>>> ', message);
            return null;
        }
    });

    /**
     * Чтение файла и проверка, существует ли он
     */
    on('task', {
        readFileIfExists(filename) {
            if (fs.existsSync(filename)) {
                return fs.readFileSync(filename, 'utf8');
            }

            return null;
        }
    });
};
