import {
    getSelector,
    CLIENT_WIDGET_INCOMING_ICON,
    CLIENT_WIDGET_CUSTOMER_NAME,
    CLIENT_WIDGET_INCOMING_VALUE,
    CLIENT_WIDGET_ACTIONS,
    CLIENT_WIDGET_BAR_EXPANDER,
    CLIENT_WIDGET_MORE_CUSTOMERS
} from "../../support/selectors";

describe('Client widget. Bar panel markup', () => {

    it(('should have valid markup, when there is one client'), () => {
        cy.cwInit();

        cy.get(getSelector(CLIENT_WIDGET_INCOMING_ICON));
        cy.get(getSelector(CLIENT_WIDGET_CUSTOMER_NAME));
        cy.get(getSelector(CLIENT_WIDGET_INCOMING_VALUE));
        cy.get(getSelector(CLIENT_WIDGET_ACTIONS));
        cy.get(getSelector(CLIENT_WIDGET_BAR_EXPANDER));
    });

    it(('should have valid markup, when there are zero clients'), () => {
        cy.cwInit('zero-clients');

        cy.get(getSelector(CLIENT_WIDGET_INCOMING_ICON));
        cy.get(getSelector(CLIENT_WIDGET_CUSTOMER_NAME));
        cy.get(getSelector(CLIENT_WIDGET_INCOMING_VALUE));
        cy.get(getSelector(CLIENT_WIDGET_ACTIONS));
        cy.get(getSelector(CLIENT_WIDGET_BAR_EXPANDER));
    });


    it(('should have valid markup, when there are many clients'), () => {
        cy.cwInit('many-clients');

        cy.get(getSelector(CLIENT_WIDGET_INCOMING_ICON));
        cy.get(getSelector(CLIENT_WIDGET_CUSTOMER_NAME));
        cy.get(getSelector(CLIENT_WIDGET_INCOMING_VALUE));
        cy.get(getSelector(CLIENT_WIDGET_MORE_CUSTOMERS));
        cy.get(getSelector(CLIENT_WIDGET_ACTIONS));
        cy.get(getSelector(CLIENT_WIDGET_BAR_EXPANDER));
    });
});
