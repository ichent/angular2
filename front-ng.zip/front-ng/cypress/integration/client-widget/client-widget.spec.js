import {
    CLIENT_WIDGET_ACTION,
    CLIENT_WIDGET_ACTIONS,
    CLIENT_WIDGET_BAR,
    CLIENT_WIDGET_BAR_EXPANDER,
    CLIENT_WIDGET_BOX,
    CLIENT_WIDGET_BOX_EXPANDER,
    CLIENT_WIDGET_CUSTOMER,
    CLIENT_WIDGET_CUSTOMER_NAME,
    CLIENT_WIDGET_CUSTOMERS,
    CLIENT_WIDGET_MORE_CUSTOMERS,
    CLIENT_WIDGET_SELECT_CUSTOMER_BUTTON,
    getSelector
} from "../../support/selectors";

describe('Client widget', () => {

    it(('should open client widget by phone, client exists, switch widget to box view'), () => {
        cy.cwInit();

        cy.get(getSelector(CLIENT_WIDGET_BAR_EXPANDER)).click();
        cy.get(getSelector(CLIENT_WIDGET_BOX));
    });

    it(('should open client widget by phone, client exists, switch widget to bar view'), () => {
        cy.cwInit();

        cy.get(getSelector(CLIENT_WIDGET_BAR_EXPANDER)).click();
        cy.get(getSelector(CLIENT_WIDGET_BOX_EXPANDER)).click();
        cy.get(getSelector(CLIENT_WIDGET_BAR));
    });

    it(('should have an equal list of clients in a widget and in a sidenav'), () => {
        cy.cwInit('many-clients');

        cy.get(getSelector(CLIENT_WIDGET_MORE_CUSTOMERS)).click();

        cy.getClientWidgetCustomersStore().then(store => {
            cy.get(`${getSelector(CLIENT_WIDGET_CUSTOMERS)} ${getSelector(CLIENT_WIDGET_CUSTOMER)}`).should('have.length', store.total);
        })
    });

    it(('should have a correct list of actions for a known client'), () => {
        cy.cwInit();

        cy.get(getSelector(CLIENT_WIDGET_ACTIONS)).click();
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).should('have.length', 3);
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(0).should('contain', 'Задачи по заказам');
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(1).should('contain', 'Создать заказ');
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(2).should('contain', 'Отложить звонок');
    });

    it(('should have a correct list of actions for an unknown client'), () => {
        cy.cwInit('zero-clients');

        cy.get(getSelector(CLIENT_WIDGET_ACTIONS)).click();
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).should('have.length', 4);
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(0).should('contain', 'Задачи по заказам');
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(1).should('contain', 'Создать заказ');
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(2).should('contain', 'Отложить звонок');
        cy.get(getSelector(CLIENT_WIDGET_ACTION)).eq(3).should('contain', 'Найти клиента');
    });


    it(('should change a main client correctly'), () => {
        cy.cwInit('many-clients');

        cy.get(getSelector(CLIENT_WIDGET_MORE_CUSTOMERS)).click();
        cy.get(getSelector(CLIENT_WIDGET_CUSTOMER)).eq(1).click();

        cy.get(getSelector(CLIENT_WIDGET_SELECT_CUSTOMER_BUTTON)).click();

        cy.cwInit('many-clients-second-main');

        cy.get(getSelector(CLIENT_WIDGET_CUSTOMER_NAME)).should('contain', 'Петров Петр Петрович');
    });
});
