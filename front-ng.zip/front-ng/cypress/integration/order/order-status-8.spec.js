describe('Check order in 8 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 8 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 8,
            title: 'Отправлен',
            groupTitle: 'Передан на доставку',
            actions: [
                'дублировать заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
            ],
        });
    });

});
