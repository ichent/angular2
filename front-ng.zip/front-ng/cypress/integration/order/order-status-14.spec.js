describe('Check order in 14 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 14 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 14,
            title: 'Частичный возврат',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
                'привязать КЛ'
            ],
        });
    });

});
