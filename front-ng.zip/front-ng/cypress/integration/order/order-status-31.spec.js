describe('Check order in 31 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 31 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 31,
            title: 'К возврату из филиала',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
            ],
        });
    });

});
