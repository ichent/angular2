describe('Check order in 25 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 25 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 25,
            title: 'К упаковке',
            groupTitle: 'Упаковка',
            actions: [
                'объединить заказы',
                'дублировать заказ',
                'отменить заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
                'списать бонусы КЛ или средства с ПК',
            ],
        });
    });

});
