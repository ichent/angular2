describe('Check order in 21 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 21 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 21,
            title: 'Самовывоз',
            groupTitle: 'ПВЗ',
            actions: [
                'дублировать заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
            ],
        });
    });

});
