describe('Check order in 16 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 16 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 16,
            title: 'Ошибка доставки',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
