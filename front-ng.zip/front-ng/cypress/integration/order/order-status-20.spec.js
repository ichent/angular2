describe('Check order in 20 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 20 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 20,
            title: 'Не удалось доставить',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
