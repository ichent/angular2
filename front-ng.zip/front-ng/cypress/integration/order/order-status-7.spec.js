describe('Check order in 7 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 7 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 7,
            title: 'Готов к отправке',
            groupTitle: 'Отгружен',
            actions: [
                'объединить заказы',
                'дублировать заказ',
                'отменить заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
                'списать бонусы КЛ или средства с ПК',
            ],
        });
    });

});
