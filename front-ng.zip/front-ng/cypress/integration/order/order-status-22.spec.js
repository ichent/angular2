describe('Check order in 22 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 22 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 22,
            title: 'Примерочная VIP Woman',
            groupTitle: 'ПВЗ',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
            ],
        });
    });

});
