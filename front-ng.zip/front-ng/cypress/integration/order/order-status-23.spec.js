describe('Check order in 23 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 23 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 23,
            title: 'Примерочная VIP Man',
            groupTitle: 'ПВЗ',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
            ],
        });
    });

});
