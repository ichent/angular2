describe('Check order in 15 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 15 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 15,
            title: 'Возврат',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
