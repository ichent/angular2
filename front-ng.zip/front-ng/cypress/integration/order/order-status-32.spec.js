describe('Check order in 32 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 32 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 32,
            title: 'Возвращается из филиала',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
            ],
        });
    });

});
