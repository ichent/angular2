describe('Check order in 30 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 30 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 30,
            title: 'Потерян',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
