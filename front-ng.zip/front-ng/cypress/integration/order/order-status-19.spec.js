describe('Check order in 19 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 19 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 19,
            title: 'Отказ клиента',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
