describe('Check order in 11 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 11 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 11,
            title: 'Частично доставлен',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
                'списать бонусы КЛ или средства с ПК',
            ],
        });
    });

});
