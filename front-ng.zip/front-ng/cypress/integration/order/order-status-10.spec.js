describe('Check order in 10 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 10 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 10,
            title: 'Доставлен',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
                'списать бонусы КЛ или средства с ПК',
            ],
        });
    });

});
