describe('Check order in 13 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 13 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 13,
            title: 'Отмена',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
