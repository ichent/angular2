describe('Check order in 27 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 27 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 27,
            title: 'Отправлен в филиал',
            groupTitle: 'Отгружен',
            actions: [
                'дублировать заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
            ],
        });
    });

});
