describe('Check order in 29 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 29 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 29,
            title: 'Прибыл в филиал',
            groupTitle: 'Отгружен',
            actions: [
                'дублировать заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
            ],
        });
    });

});
