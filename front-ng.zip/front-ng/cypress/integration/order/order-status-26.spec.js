describe('Check order in 26 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 26 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 26,
            title: 'Упаковка',
            groupTitle: 'Упаковка',
            actions: [
                'объединить заказы',
                'дублировать заказ',
                'отменить заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
                'списать бонусы КЛ или средства с ПК',
            ],
        });
    });

});
