describe('Check order in 33 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 33 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 33,
            title: 'Готов к выдаче',
            groupTitle: 'ПВЗ',
            actions: [
                'дублировать заказ',
                'корректировать данные оформителя и получателя',
                'корректировать агента, адрес и дату доставки',
                'привязать КЛ',
            ],
        });
    });

});
