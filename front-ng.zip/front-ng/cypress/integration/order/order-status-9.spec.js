describe('Check order in 9 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 9 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 9,
            title: 'В пути',
            groupTitle: 'Передан на доставку',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
            ],
        });
    });

});
