describe('Check order in 12 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 12 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 12,
            title: 'Отказ/Не удалось доставить',
            groupTitle: 'Завершён',
            actions: [
                'дублировать заказ',
            ],
        });
    });

});
