describe('Check order in 28 status', () => {

    before(() => {
        cy.openMocOrderPage({ status: 28 });
    });

    it('Check status title, group title and actions titles', () => {
        cy.checkOrderStatus({
            status: 28,
            title: 'На маршруте в филиал',
            groupTitle: 'Отгружен',
            actions: [
                'дублировать заказ',
                'привязать КЛ',
            ],
        });
    });

});
