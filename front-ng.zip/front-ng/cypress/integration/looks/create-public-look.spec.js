describe('Create a public look', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a public look', () => {
        cy.createPublicLook();
    });

});
