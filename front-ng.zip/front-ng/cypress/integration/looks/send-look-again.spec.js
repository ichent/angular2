/**
 * Повторная отправка отправленного лука.
 *
 * Проверяется, что новый отправленный лук будет содержать измененный список товаров,
 * а оригинальный отправленный лук не изменится.
 *
 * Повторная отправка реализуется через промежуточное копирование отправленного лука в личные луки.
 */
describe('Send a sent look again', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a sent look, copied it, changed the look\'s items, and send the look again', () => {
        let initialSentLook = null;

        // Создание черновика лука и отправка его
        cy.createDraftLook();
        cy.createSentLook((sentLookData) => {
            initialSentLook = sentLookData;
        });

        // Копирование отправленного лука
        cy.server();
        cy.route('POST', /product-lists\/\d+\/copy-as-private/).as('lookWasCopied');
        cy.makeActionWithListOnListsPage('copyAsPrivate');
        cy.wait('@lookWasCopied')
            .then(({responseBody: {data: copiedLookData}}) => {
                const pattern = new RegExp(`/product-lists/${copiedLookData.id}/replace-items`);
                cy.route('POST', pattern).as('copiedLook');
            });
        cy.checkUrl('/lists/looks/sent');

        cy.get('[data-cy-tab-label="private"]').click({ force: true })
        // Редактирование отправленного лука
        cy.makeActionWithListOnListsPage('edit');
        cy.checkUrl('/look/edit');
        cy.moveProductOnCanvas(0, 336);
        cy.moveProductOnCanvas(435, 0);

        // Отправка отредактированного лука
        cy.createSentLook((newSentLook) => {
            cy.log('Checking that the initial sent look is the same');
            cy.isEqualToListInStore(initialSentLook);

            cy.wait('@copiedLook')
                .then(({responseBody: {data: copiedLook}}) => cy.getProductListStoreEntity(copiedLook.id))
                .then(copiedListInStore => {
                    cy.log('Checking that items in copied look and sent look are the same');
                    cy.isProductListsItemsEquals(copiedListInStore, newSentLook);
                });
        });
    });

});
