describe('Edit a look', () => {

    it(('should create a new draft look'), () => {
        cy.oauth();
        cy.mocCatalogForLooks();
        cy.addProductsToList([0]);
        cy.toLookCreatingPageViaProductListSidenav();
        cy.moveFirstProductToCanvas();
    });

    it(('should move product on canvas'), () => {
        const left = 100;
        const top = 150;
        cy.moveProductOnCanvas(left, top);

        cy.window()
            .then(window => window['look-list-products'])
            .then(store => {
                const firstKey = Object.keys(store.entities)[0];
                const storeLookListItem = store.entities[firstKey].listItem;

                expect(storeLookListItem.left).to.equal(left);
                expect(storeLookListItem.top).to.equal(top);
            });
    });

    it('should resize product on canvas up', () => {
        scaleLookProduct(cy.scaleLookProductUp)
            .then(({ prevScaleX, currentScaleX, prevScaleY, currentScaleY }) => {
                expect(currentScaleX > prevScaleX).to.equal(true);
                expect(currentScaleY > prevScaleY).to.equal(true);
            });
    });

    it('should resize product on canvas down', () => {
        scaleLookProduct(cy.scaleLookProductDown)
            .then(({ prevScaleX, currentScaleX, prevScaleY, currentScaleY }) => {
                expect(currentScaleX < prevScaleX).to.equal(true);
                expect(currentScaleY < prevScaleY).to.equal(true);
            });
    });

});

function scaleLookProduct(scaleFunction) {
    return cy.getLookListProductsStoreFirstItem()
        .then(storeLookListItem => {
            const prevScaleX = storeLookListItem.scaleX;
            const prevScaleY = storeLookListItem.scaleY;

            scaleFunction();

            cy.getLookListProductsStoreFirstItem()
                .then(storeLookListItem => {
                    const currentScaleX = storeLookListItem.scaleX;
                    const currentScaleY = storeLookListItem.scaleY;

                    return {
                        prevScaleX,
                        prevScaleY,
                        currentScaleX,
                        currentScaleY,
                    };
                });
        });
}
