describe('Create a sent look', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should sent look and redirect to a sent looks page', () => {
        cy.createDraftLook();
        cy.createSentLook((savedLookData) => {
            cy.log('Checking that local look`s products are in a sent list response');
            cy.isEqualToLookInCurrentLookStore(savedLookData);
        });
    });

});
