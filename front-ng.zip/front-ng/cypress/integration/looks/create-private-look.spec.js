describe('Create a private look', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a private look', () => {
        cy.createPrivateLook();
    });

});
