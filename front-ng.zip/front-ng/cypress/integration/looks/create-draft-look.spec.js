describe('Create a draft look', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a draft look', () => {
        cy.createDraftLook();
    });

    it('should select products sizes', () => {
        cy.selectProductSizeInCanvas(0);
        cy.selectProductSizeInCanvas(1);
    });

    it('should save state', () => {
        cy.server();
        cy.route('POST', '/api/product-lists/*/replace-items').as('saveLookProducts');
        cy.wait('@saveLookProducts')
            .then(({ responseBody: { data: savedLookData} }) => {
                cy.isEqualToLookInCurrentLookStore(savedLookData);
            });
    });

});
