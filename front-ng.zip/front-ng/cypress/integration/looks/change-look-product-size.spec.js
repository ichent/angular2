describe('Change look product size', () => {

    it(('should create a new draft look'), () => {
        cy.oauth();
        cy.mocCatalogForLooks();
        cy.addProductsToList([0]);
        cy.toLookCreatingPageViaProductListSidenav();
        cy.moveFirstProductToCanvas();
    });

    it(('should change product size on canvas'), () => {
        cy.get('[data-cy="look-canvas-product"]')
            .eq(0)
            .within(() => cy.get('[data-cy="look-canvas-product-show-info"]'))
            .eq(0)
            .click();

        let selectedSizeSkuId = null;

        cy.get('[data-cy="look-canvas-product-size-selector"]').eq(0).click();
        cy.get('[data-cy="look-canvas-product-size-option"]').eq(0)
            .then(el => {
                selectedSizeSkuId = parseInt(el.attr('data-cy-sku-id'));
                return el;
            })
            .click();

        cy.window()
            .then(window => window['look-list-products'])
            .then(store => {
                const firstKey = Object.keys(store.entities)[0];
                const storeLookListItem = store.entities[firstKey].listItem;

                // Выбранный размер из селектора размеров совпадает с сохранённым размером в сторе текущего лука
                expect(storeLookListItem.skuId).to.equal(selectedSizeSkuId);
            });
    });

});
