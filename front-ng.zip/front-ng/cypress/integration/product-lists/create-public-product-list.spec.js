describe('Create a public product list', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a public product list', () => {
        cy.createPublicList((list) => cy.isItemsEqualsToCurrentProductList(list));
    });

});
