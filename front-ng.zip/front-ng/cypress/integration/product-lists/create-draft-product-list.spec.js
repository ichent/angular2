describe('Create a draft product list', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a draft product list', () => {
        cy.createDraftList();
        cy.get('[data-cy="product-list-items-counter"]').should('contain', '2');
        cy.checkCurrentProductListIsExist();
    });

});
