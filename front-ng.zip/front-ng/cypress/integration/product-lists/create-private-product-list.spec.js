describe('Create a private product list', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a private product list', () => {
        cy.createPrivateList((list) => cy.isItemsEqualsToCurrentProductList(list));
    });

});
