describe('Create a sent product list', () => {

    before(() => {
        cy.oauth();
        cy.mocCatalogForLooks();
    });

    it('should create a sent product list', () => {
        cy.createDraftList();
        cy.saveProductListAs('sent', (list) => cy.isItemsEqualsToCurrentProductList(list));
        cy.checkCurrentProductListIsNull();
    });

});
