var ENDPOINTS = {
    NP_API_URL: 'https://api.rho.int.tsum.com/',
    NP_BACKEND_API_URL: 'https://admin.rho.int.tsum.com/api/',
    NP_URL: 'https://rho.int.tsum.com/',
    GEO_API_URL:  'https://api.gamma-geo.int.tsum.com/',
    BASE_API_URL:  'https://api-cc-cmi-alpha.int.tsum.com/api/',
    BASE_GATEWAY_API_URL: 'https://ax-gw-alpha.int.tsum.com/',
    WEBSOCKET_URL: 'wss://fanout-dev.int.tsum.com:8000/connection/websocket/',
    CENTRIFUGE_TOKEN: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIn0.JZHLINDjY09EvP3f7oc-TtNE3rlDs1C2BC0f9OiwwXQ',
};
