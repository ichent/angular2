import { ErrorHandler, Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NewReleaseNotificationDialogComponent } from './features/new-release-notification/new-release-notification-dialog/new-release-notification-dialog.component';

@Injectable()
export class AppErrorHandler implements ErrorHandler {

    constructor(
        private dialog: MatDialog,
    ) {}

    public handleError(error: Error): void {
        // При развертывании новой версии на сервере и изменении незагруженных lazy-load модулей,
        // при попытке их загрузить возникает ошибка (т.к. на сервере уже нет модулей для текущей версии приложения).
        // Поэтому действуем так же, как и при плановом обновлении.
        // Показываем попап с требованием перезагрузки страницы.
        if (/Loading chunk [\d]+ failed/.test(error.message)) {
            this.dialog.open(NewReleaseNotificationDialogComponent, { disableClose: true, autoFocus: true });
        } else {
            console.error(error);
        }
    }
}
