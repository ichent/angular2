import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { timeout } from 'rxjs/operators';

const MAX_REQUEST_TIME = 30000;

@Injectable()
export class TimeoutInterceptor implements HttpInterceptor {

    // Завершает ошибкой все HTTP запросы, которые длятся больше MAX_REQUEST_TIME
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(timeout(MAX_REQUEST_TIME));
    }

}
