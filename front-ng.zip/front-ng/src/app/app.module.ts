import { APP_INITIALIZER, LOCALE_ID, NgModule, ErrorHandler } from '@angular/core';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { AppRoutingModule } from './app.routing';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ENDPOINTS_TOKEN, getEndpointsConfig } from './config/endpoints';
import { AuthService } from './services/auth.service';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { UserService } from './services/user.service';
import { delay, finalize, retryWhen, switchMap, take } from 'rxjs/operators';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { UiModule } from './ui/ui.module';
import { TimeoutInterceptor } from './interceptors/timeout.interceptor';
import { ProductListSidenavModule } from './sidenavs/product-list-sidenav/product-list-sidenav.module';
import { CreateLinkSidenavModule } from './sidenavs/create-link-sidenav/create-link-sidenav.module';
import { SizeTableSidenavModule } from './sidenavs/size-table-sidenav/size-table-sidenav.module';
import { ProductPhotoSidenavModule } from './sidenavs/product-photo-sidenav/product-photo-sidenav.module';
import { ProductLooksSidenavModule } from './sidenavs/product-looks-sidenav/product-looks-sidenav.module';
import { ClientWidgetFeatureModule } from './features/client-widget/client-widget-feature.module';
import {
    ClientWidgetCustomersSidenavModule,
} from './sidenavs/client-widget-customers-sidenav/client-widget-customers-sidenav.module';
import {
    ClientWidgetFindCustomersSidenavModule,
} from './sidenavs/client-widget-find-customers-sidenav/client-widget-find-customers-sidenav.module';
import { ProductDetailsSidenavModule } from './sidenavs/product-details-sidenav/product-details-sidenav.module';
import {
    ClientWidgetCreateEditSidenavModule,
} from './sidenavs/client-widget-create-edit-sidenav/client-widget-create-edit-sidenav.module';
import { ClientWidgetCommunicationAddressesSidenavModule } from './sidenavs/client-widget-communication-addresses-sidenav/client-widget-communication-addresses-sidenav.module';
import { ClientWidgetPreferredCommunicationAddressesSidenavModule } from './sidenavs/client-widget-preferred-communication-addresses-sidenav/client-widget-preferred-communication-addresses-sidenav.module';
import { SaveSidenavModule } from './sidenavs/save-sidenav/save-sidenav.module';
import { LooksCatalogSidenavModule } from './sidenavs/looks-catalog-sidenav/looks-catalog-sidenav.module';
import { ProductCategoryFilterSidenavModule } from './sidenavs/product-category-filter-sidenav/product-category-filter-sidenav.module';
import { ProductFilterSidenavModule } from './sidenavs/product-filter-sidenav/product-filter-sidenav.module';
import { TsumBaseModule, TsumFooterModule, TsumIconsModule, TsumLayoutHeaderModule, TsumLayoutModule } from '@tsum/ui';
import { DEFAULT_DATEPICKER_FORMATS } from './constants/common.constant';
import { registerLocaleData } from '@angular/common';
import localeRu from '@angular/common/locales/ru';
import { CartSidenavModule } from './sidenavs/cart-sidenav/cart-sidenav.module';
import { OrderCreationSidenavModule } from './sidenavs/orders/order-create-edit-sidenav/order-creation-sidenav/order-creation-sidenav.module';
import { MarkupFeatureModule } from './features/markup/markup-feature.module';
import { NewReleaseNotificationFeatureModule } from './features/new-release-notification/new-release-notification-feature.module';
import { Observable, throwError } from 'rxjs';
import { AppErrorHandler } from './app-error-handler';
import { BuyGiftCardSidenavModule } from './sidenavs/buy-gift-card-sidenav/buy-gift-card-sidenav.module';
import { LayoutFeatureModule } from './features/layout/layout-feature.module';
import { MockModule } from './mock/mock.module';

registerLocaleData(localeRu, 'ru');

@NgModule({
    imports: [
        RouterModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        CoreModule,
        HttpClientModule,
        UiModule,
        ProductListSidenavModule,
        CartSidenavModule,
        LooksCatalogSidenavModule,
        CreateLinkSidenavModule,
        SaveSidenavModule,
        SizeTableSidenavModule,
        ProductPhotoSidenavModule,
        ProductLooksSidenavModule,
        ProductDetailsSidenavModule,
        ClientWidgetCustomersSidenavModule,
        ClientWidgetFindCustomersSidenavModule,
        ClientWidgetPreferredCommunicationAddressesSidenavModule,
        ClientWidgetCommunicationAddressesSidenavModule,
        ProductFilterSidenavModule,
        ProductCategoryFilterSidenavModule,
        OrderCreationSidenavModule,
        ClientWidgetFeatureModule,
        ClientWidgetCreateEditSidenavModule,
        TsumBaseModule,
        TsumIconsModule,
        MarkupFeatureModule,
        NewReleaseNotificationFeatureModule,
        TsumFooterModule,
        BuyGiftCardSidenavModule,
        TsumLayoutModule,
        TsumLayoutHeaderModule,
        LayoutFeatureModule,
        MockModule,
    ],
    declarations: [
        AppComponent,
    ],
    providers: [
        {
            provide: ENDPOINTS_TOKEN,
            useFactory: getEndpointsConfig,
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TimeoutInterceptor,
            multi: true,
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true,
        },
        {
            provide: APP_INITIALIZER,
            useFactory: getUserInfo,
            deps: [AuthService, UserService],
            multi: true,
        },
        {
            provide: MAT_DATE_LOCALE,
            useValue: 'ru',
        },
        {
            provide: LOCALE_ID,
            useValue: 'ru',
        },
        {
            provide: DateAdapter,
            useClass: MomentDateAdapter,
            deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
        },
        {
            provide: MAT_DATE_FORMATS,
            useValue: DEFAULT_DATEPICKER_FORMATS,
        },
        {
            provide: ErrorHandler,
            useClass: AppErrorHandler,
        }
    ],
    bootstrap: [
        AppComponent,
    ],
})
export class AppModule {
}

export function getUserInfo(authService: AuthService, userService: UserService): () => Promise<any> | void {
    return () => {
        if (location.pathname === '/oauth') {
            const code: string = new URLSearchParams(location.search).get('code');
            const backUrl: string = location.search
                .replace('?path=', '')
                .replace(/&code=(\d|\w)+/, '');

            return authService
                .authenticate(code, authService.getRedirectUrl({ path: backUrl }))
                .pipe(
                    retryWhen((errorRes: Observable<any>) => {
                        // В случае ошибки авторизации пробуем еще раз
                        return errorRes
                            .pipe(
                                delay(500),
                                take(1),
                            );
                    }),
                    // Отменяем дальнейшую загрузку приложения и редиректим
                    switchMap(() => throwError('Waiting for redirect...')),
                    finalize(() => location.href = backUrl),
                )
                .toPromise();
        }

        return authService.isLogged$
            .pipe(
                take(1),
                switchMap((isLogged: boolean) => isLogged
                    ? userService.getInfo()
                    : authService.redirectToLoginPage()
                ),
            )
            .toPromise();
    };
}
