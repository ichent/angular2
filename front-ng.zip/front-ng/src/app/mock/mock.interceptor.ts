import { Inject, Injectable } from '@angular/core';
import {
    HttpHandler,
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { MockRequestName } from './mock-request-name.enum';
import { ENDPOINTS_TOKEN, EndpointsConfigInterface } from '../config/endpoints';
import { OrderLine } from '../state/orders/interfaces/order-line.interface';
import { BaseApiResponse } from '../services/api/base-api.service';
import { Order } from '../state/orders/interfaces/order.interface';
import { MockHelper } from './mock.helper';
import { CombineOrdersRequest } from '../sidenavs/orders/combine-orders-sidenav/interfaces/combine-delivery.interface';
import { OrderDelivery } from '../state/orders/interfaces/order-delivery.interface';
import { OrderStatus } from '../constants/order/order-status.enum';
import { Product } from '../state/products/product.interface';
import { SkuItem } from '../interfaces/sku.interface';
import { TransformHelper } from '../helpers/transform.helper';
import { PRODUCT_TO_ORDER_LINE } from '../state/orders/constants/product-to-order-line.schema';
import { MathHelper } from '../helpers/math.helper';
import { ListPage } from '../interfaces/list-page.interface';
import { ListOrder } from '../state/pages/orders-page/interfaces/list-order.interface';
import { OrderDeliveryInterval } from '../sidenavs/orders/combine-orders-sidenav/interfaces/order-delivery-interval.interface';
import * as moment from 'moment';
import { ProductsQuery } from '../state/products/products.query';
import { OrdersQuery } from '../state/orders/orders.query';
import { AddOrderLineData } from './interfaces/add-order-line-data.interface';
import { OrderListType, OrderType } from '../state/pages/orders-page/interfaces/orders-filters.interface';
import { cloneDeep as _cloneDeep } from 'lodash';

const ORDER_MOCK_URL = './assets/mocks/order/order.mock.json';
const ORDERS_BY_CUSTOMER_MOCK_URL = './assets/mocks/order/combine-orders/by-customer.mock.json';
const ORDERS_ADDRESSES_MOCK_URL = './assets/mocks/order/combine-orders/addresses.mock.json';
const ORDERS_ADDRESS_INTERVALS_MOCK_URL = './assets/mocks/order/combine-orders/delivery.mock.json';
const ORDER_CANCEL_REASON_MOCK_URL = './assets/mocks/order/order-actual-cancel-reasons.json';
const ACTUAL_ORDER_LINE_REJECTION_REASONS = './assets/mocks/order/order-line-rejection-reasons.mock.json';
const ORDERS_LIST_MOCK_URL = './assets/mocks/orders/orders-list.mock.json';

/**
 * Перехватчик HTTP запросов для подмены на mock ответы
 * https://kb.int.tsum.com/display/CMI/Mock+interceptor
 *
 * Включение: localStorage.setItem('activateMockService', 'order, orders')
 * Отключение: localStorage.removeItem('activateMockService');
 */
@Injectable()
export class MockInterceptor implements HttpInterceptor {

    private readonly apiUrl = this.endpointsConfig.BASE_API_URL;

    private readonly activationLocalStorageKey = 'activateMockService';

    private activateMocFor: MockRequestName[] = [];

    constructor(
        @Inject(ENDPOINTS_TOKEN) protected endpointsConfig: EndpointsConfigInterface,
        private productsQuery: ProductsQuery,
        private ordersQuery: OrdersQuery,
    ) {
        this.activateMocFor = (localStorage.getItem(this.activationLocalStorageKey) || '')
            .split(',')
            .map((el: string) => el.trim())
            .filter(Boolean) as MockRequestName[];
    }

    public intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
        if (this.activateMocFor.length === 0) {
            return next.handle(req);
        }

        /**
         * При добавлении нового метода дополнять документацию:
         * https://kb.int.tsum.com/pages/viewpage.action?pageId=847490157
         */
        if (this.activateMocFor.includes(MockRequestName.Order)) {
            const order: Order = this.ordersQuery.getActive();

            // Новый контракт получения информации о заказе для КЦ
            // https://jira.int.tsum.com/browse/GAPI-77
            if (this.isGetOrder(req)) {
                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleGetOrder, order);
            }

            // [API] Редактирование заказа. Метод удаления товара из заказа
            // https://jira.int.tsum.com/browse/CMI-1565
            if (this.isOrderLineDeletion(req)) {
                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleRemoveOrderLine, order);
            }

            // [API] Объединение. Получение подходящих заказов для объединения доставок
            // https://jira.int.tsum.com/browse/CMI-1552
            if (this.isCombineOrdersByCustomer(req)) {
                return MockHelper.handleRequest(req, next, ORDERS_BY_CUSTOMER_MOCK_URL);
            }

            // [API] Получение адресов доставки по заказам
            // https://jira.int.tsum.com/browse/CMI-1555
            if (this.isOrdersAddresses(req)) {
                return MockHelper.handleRequest(req, next, ORDERS_ADDRESSES_MOCK_URL);
            }

            // [API] Получение доступных инервалов доставки по методу
            //  https://jira.int.tsum.com/browse/CMI-1557
            if (this.isOrderAddressIntervals(req)) {
                return MockHelper.handleRequest(req, next, ORDERS_ADDRESS_INTERVALS_MOCK_URL);
            }

            // [API] Объединение. Выбор службы доставки
            // https://jira.int.tsum.com/browse/CMI-1558
            if (this.isOrderMergeDelivery(req)) {
                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleMergeOrdersDelivery);
            }

            // [API] Метод отмены заказа
            // https://jira.int.tsum.com/browse/CMI-1731 + https://jira.int.tsum.com/browse/CMI-3547
            if (this.isCancelOrder(req)) {
                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleCancelOrder, order);
            }

            // [API] Добавление товара в заказ. Непосредственное добавление
            // https://jira.int.tsum.com/browse/CMI-1564
            if (this.isOrderLineAdd(req)) {
                const data: AddOrderLineData = {
                    products: this.productsQuery.getAll(),
                    order: this.ordersQuery.getActive()
                };

                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleAddOrderLine, data)
            }

            // [API] Метод получения актуального списка поричин отмен заказа
            // https://jira.int.tsum.com/browse/CMI-3634
            if (this.isActualOrderCancellationReasons(req)) {
                return MockHelper.handleRequest(req, next, ORDER_CANCEL_REASON_MOCK_URL);
            }

            // [API] Метод получения актуального списка отмен товарных строк заказа
            // https://jira.int.tsum.com/browse/CMI-3633
            if (this.isOrderLineRejectionReasons(req)) {
                return MockHelper.handleRequest(req, next, ACTUAL_ORDER_LINE_REJECTION_REASONS);
            }

            // [API] Получение ПДД для заказа и выбранных размеров товара
            //  https://jira.int.tsum.com/browse/CMI-3534
            if (this.isOrderDeliveryIntervals(req)) {
                return MockHelper.handleRequest(req, next, ORDERS_ADDRESS_INTERVALS_MOCK_URL, this.handleOrderDeliveryIntervals);
            }

            // [API] Добавление/удаление подарочной упаковки в/из заказа. Указание товаров в ПУ
            //  https://jira.int.tsum.com/browse/CMI-1566
            if (this.isOrderAddPackage(req)) {
                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleOrderAddPackage, req.body.items);
            }
            if (this.isOrderRemovePackage(req)) {
                return MockHelper.handleRequest(req, next, ORDER_MOCK_URL, this.handleOrderRemovePackage);
            }
        }

        /**
         * При добавлении нового метода дополнять документацию:
         * https://kb.int.tsum.com/pages/viewpage.action?pageId=847492595
         */
        if (this.activateMocFor.includes(MockRequestName.Orders)) {
            // [API] Необходимо добавить метод для поиска заказов в CMI
            // https://jira.int.tsum.com/browse/CMI-1446
            if (this.isSearchOrders(req)) {
                return MockHelper.handleRequest(req, next, ORDERS_LIST_MOCK_URL, this.handleOrdersSearch);
            }
        }

        return next.handle(req);
    }

    /**
     * Запрос получения конкретного заказа (не очередь заказов и не поиск заказов)
     * GET /order/:order-uuid
     */
    private isGetOrder(req: HttpRequest<any>): boolean {
        return req.method === 'GET'
            && new RegExp(`${this.apiUrl}\/order\/(?!queue|search)[\\w-]+\/?$`).test(req.url);
    }

    private handleGetOrder(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>,
        order: Order,
    ): HttpResponse<BaseApiResponse<Order>> {
        const uuid: string = req.url.match(/([\w|-]+)\/?$/)[0];

        // Обработка случая возврата на страницу редактируемого заказа
        if (order && order.uuid === uuid) {
            resCopy.body.data = order;
        } else {
            resCopy.body.data.uuid = req.url.match(/([\w|-]+)\/?$/)[0];
        }

        return resCopy;
    }

    /**
     * Запрос удаления товарной строки из заказа
     * POST /order/:order-uuid/order-line/:line-uuid/reject
     */
    private isOrderLineDeletion(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`${this.apiUrl}\/order\/(?!queue|search)[\\w-]+\/order-line\/[\\w\d]+\/reject\/?$`)
                .test(req.url);
    }

    private handleRemoveOrderLine(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>,
        order: Order,
    ): HttpResponse<BaseApiResponse<Order>> {
        const regExpMatchArray: RegExpMatchArray = req.url
            .match(/order\/([\w|-]+)(\/order-line\/)([\d|\w]+)\/reject\/?/);
        const orderUuid: string = regExpMatchArray[1];
        const lineUuid: string = regExpMatchArray[3];

        if (order && order.uuid === orderUuid) {
            resCopy.body.data = _cloneDeep(order);
        } else {
            resCopy.body.data.uuid = orderUuid;
        }

        const line: OrderLine = resCopy.body.data.lines
            .find((line: OrderLine) => `${line.uuid}` === lineUuid);

        if (line) {
            line.isDeleted = true;
            line.reject.reason = req.body.reject;
        }

        return resCopy;
    }

    /**
     * Запрос получения заказов клиента для объединения
     * GET /orders/by-customer/:dr
     */
    private isCombineOrdersByCustomer(req: HttpRequest<any>): boolean {
        return req.method === 'GET'
            && /\/orders\/by-customer\/[%\w\dа-я]+\/?$/i.test(req.url);
    }

    /**
     * Запрос получения адресов у заказов
     * POST order/addresses
     */
    private isOrdersAddresses(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/addresses\/?$`).test(req.url);
    }

    /**
     * Запрос получения интервалов доставки для адреса
     * POST order/:uuid/delivery
     */
    private isOrderAddressIntervals(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/(?!queue|search)[\\w-]+/delivery\/?$`).test(req.url);
    }

    /**
     * Запрос объединения доставки заказов
     * POST /order/merge-delivery
     */
    private isOrderMergeDelivery(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/merge-delivery\/?$`).test(req.url);
    }

    private handleMergeOrdersDelivery(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>
    ): HttpResponse<BaseApiResponse<Order>> {
        const body: CombineOrdersRequest = req.body;
        const reqOrder: Order = resCopy.body.data;
        const orderDelivery: OrderDelivery = reqOrder.delivery;

        reqOrder.uuid = body.uuid[0];
        orderDelivery.address.address = body.delivery.address;
        orderDelivery.agent.id = body.delivery.agent.id;
        orderDelivery.agent.title = body.delivery.agent.title;
        orderDelivery.date = body.delivery.date;
        orderDelivery.interval = body.delivery.interval;

        return resCopy;
    }

    /**
     * Запрос отмены заказа
     * POST /api/order/:uuid/cancel
     */
    private isCancelOrder(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/(?!queue|search)[\\w-]+\/cancel\/?$`).test(req.url);
    }

    private handleCancelOrder(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>,
        order: Order,
    ): HttpResponse<BaseApiResponse<Order>> {
        const orderUuid: string = req.url.match(/([\w|-]+)\/cancel\/?$/)[1];

        if (order && order.uuid === orderUuid) {
            resCopy.body.data = _cloneDeep(order);
        } else {
            resCopy.body.data.uuid = orderUuid;
        }

        resCopy.body.data.status = OrderStatus.Canceled;

        return resCopy;
    }

    /**
     * Добавление товарной строки в заказ
     * POST /order/:order-uuid/order-line
     */
    private isOrderLineAdd(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`${this.apiUrl}\/order\/(?!queue|search)[\\w-]+\/order-line\/?$`).test(req.url);
    }

    private handleAddOrderLine(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>,
        { products, order }: AddOrderLineData,
    ): HttpResponse<BaseApiResponse<Order>> {
        const regExpMatchArray: RegExpMatchArray = req.url
            .match(/order\/([\w|-]+)(\/order-line\/?)/);
        const newOrderLines: OrderLine[] = req.body.items
            .map((item: { id: string }) => {
                const product: Product = products
                    .find((product: Product) =>
                        product.skuList.some((skuItem: SkuItem) => `${skuItem.extId}` === item.id),
                    );
                const orderLine: OrderLine = TransformHelper.to(
                    {
                        ...product, skuList: product.skuList.filter((sku: SkuItem) =>
                            item.id === `${sku.extId}` || item.id === sku.extGuid)
                    },
                    PRODUCT_TO_ORDER_LINE
                );

                orderLine.uuid = MathHelper.getUniqueId();

                return orderLine;
            }
        );

        resCopy.body.data = { ...order };
        resCopy.body.data.uuid = regExpMatchArray[1];
        resCopy.body.data.lines = [ ...resCopy.body.data.lines, ...newOrderLines ];

        return resCopy;
    }

    /**
     * Актуальный список причин отмены заказа
     * GET /order/reject-list/actual
     */
    private isActualOrderCancellationReasons(req: HttpRequest<any>): boolean {
        return req.method === 'GET'
            && new RegExp(`${this.apiUrl}\/order\/reject-list\/actual\/?$`).test(req.url);
    }

    /**
     * Проверка на запрос списка актуальных причин удаления строк
     * GET /order-line/reject-list/actual
     */
    private isOrderLineRejectionReasons(req: HttpRequest<any>): boolean {
        return req.method === 'GET'
            && new RegExp(`${this.apiUrl}\/order-line\/reject-list\/actual`).test(req.url);
    }

    /**
     * Проверка на запрос получения ПДД для заказа по списку sku
     * GET /order/:order-uuid/sku-delivery
     */
    private isOrderDeliveryIntervals(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/(?!queue|search)[\\w-]+/sku-delivery\/?$`).test(req.url);
    }

    private handleOrderDeliveryIntervals(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<OrderDeliveryInterval[]>>
    ): HttpResponse<BaseApiResponse<OrderDeliveryInterval[]>> {
        resCopy.body.data
            .forEach((interval: OrderDeliveryInterval, index) => interval.planedAt = moment().add(index, 'days').valueOf());

        return resCopy;
    }

    /**
     * Запрос получения результата поиска заказов
     * POST /order/search
     */
    private isSearchOrders(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`${this.apiUrl}\/order\/search`).test(req.url);
    }

    private handleOrdersSearch(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<ListPage<ListOrder>>>
    ): HttpResponse<BaseApiResponse<ListPage<ListOrder>>> {
        const perPage: number = +req.params.get('per-page');
        const ordersPage: ListPage<ListOrder> = resCopy.body.data;

        const newItems: ListOrder[] = [];
        let mockItems: ListOrder[];

        switch (req.body['list_type']) {
            case(OrderListType.OnlyVip):
                mockItems = ordersPage.items.filter((order: ListOrder) => order.client.isVip);
                break;
            case(OrderListType.ExcludeVip):
                mockItems = ordersPage.items.filter((order: ListOrder) => !order.client.isVip);
                break;
            default:
                mockItems = [ ...ordersPage.items ];
        }

        if (req.body['type'].includes(OrderType.Unconfirmed)) {
            mockItems = ordersPage.items.filter((order: ListOrder) => order.callCenterConfirmed === false);
        }

        for (let i = 0; i < perPage; i++) {
            const nextOrder: ListOrder = mockItems[i % mockItems.length];

            nextOrder.created = new Date().toISOString();
            newItems.push(nextOrder);
        }

        ordersPage['items'] = newItems;
        ordersPage['per-page'] = perPage;
        ordersPage['page'] = +req.params.get('page');

        return resCopy;
    }

    /**
     * Проверка на запрос удаления подарочной упаковки
     * POST /order/:order-uuid/pack/:pack-uuid/reject
     */
    private isOrderRemovePackage(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/(?!queue|search)[\\w-]+\/pack\/[\\w-]+/reject?$`).test(req.url);
    }

    private handleOrderRemovePackage(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>,
    ): HttpResponse<BaseApiResponse<Order>> {
        resCopy.body.data.uuid = req.url.match(/([\w|-]+)\/pack/)[1];
        resCopy.body.data.packs = [];

        return resCopy;
    }

    /**
     * Проверка на запрос добавления подарочной упаковки
     * POST /order/:order-uuid/pack
     */
    private isOrderAddPackage(req: HttpRequest<any>): boolean {
        return req.method === 'POST'
            && new RegExp(`^${this.apiUrl}\/order\/(?!queue|search)[\\w-]+\/pack\/?$`).test(req.url);
    }

    private handleOrderAddPackage(
        req: HttpRequest<any>,
        resCopy: HttpResponse<BaseApiResponse<Order>>,
        pack: string[],
    ): HttpResponse<BaseApiResponse<Order>> {
        resCopy.body.data.uuid = req.url.match(/([\w|-]+)\/pack/)[1];
        resCopy.body.data.packs[0].items = pack;

        return resCopy;
    }


}
