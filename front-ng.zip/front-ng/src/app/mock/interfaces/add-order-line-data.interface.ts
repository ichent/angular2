import { Product } from '../../state/products/product.interface';
import { Order } from '../../state/orders/interfaces/order.interface';

export interface AddOrderLineData {
    products: Product[];
    order: Order;
}
