export enum MockRequestName {
    Order = 'order',
    Orders = 'orders',
}
