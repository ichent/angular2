import { HttpEvent, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export namespace MockHelper {

    /**
     * Generic функция для обработки перехваченных запросов
     *
     * @param request оригинальный запрос
     * @param next обработчик запросов из HttpClient
     * @param mockUrl url файла с моками
     * @param responseHandler кастомная функция для изменения полученного ответа
     * @param customData кастомные данные для добавления в ответ
     */
    export function handleRequest(
        request: HttpRequest<any>,
        next: HttpHandler,
        mockUrl: string,
        responseHandler: (req: HttpRequest<any>, resCopy: HttpResponse<any>, customData: any) => HttpResponse<any> = (req, res) => res,
        customData?: any,
    ): Observable<HttpEvent<any>> {
        const modifiedRequest: HttpRequest<any> = request.clone({
            url: mockUrl,
            method: 'GET',
        });

        return handleResponse(modifiedRequest, next, (res: HttpResponse<any>) =>
            responseHandler(request, res.clone(), customData)
        );
    }

    /**
     * Generic функция для обработки перехваченных ответов
     *
     * @param modifiedRequest перехваченный оригинальный запрос с изменённым url на мок данные
     * @param next обработчик запросов из HttpClient
     * @param responseHandler кастомная функция для изменения полученного ответа
     */
    function handleResponse(
        modifiedRequest: HttpRequest<any>,
        next: HttpHandler,
        responseHandler: (res: HttpResponse<any>) => HttpResponse<any>,
    ): Observable<HttpEvent<any>> {
        return next.handle(modifiedRequest)
            .pipe(
                map((event: HttpEvent<any>) => {
                    if (event instanceof HttpResponse) {
                        return responseHandler(event);
                    }

                    return event;
                }),
            );
    }

}
