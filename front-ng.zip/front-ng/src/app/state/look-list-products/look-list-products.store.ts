import { Injectable } from '@angular/core';
import { EntityState, EntityStore, EntityUIStore, StoreConfig } from '@datorama/akita';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { ListType } from '../../pages/lists/list-type.enum';
import { ListAuthor } from '../product-list/product-list.interface';
import { LookListGlobalUi, LookListProductsUi } from './look-list-products-ui.interface';

/**
 *  Эта стора отвечает за отрисовку товаров на странице лука
 *  Кодовое имя: Текущий лук.
 */
export interface LookListProductsState extends EntityState<ListProduct> {
    createdBy: {
        user: ListAuthor,
        date: string,
    };
    sentBy: {
        user: ListAuthor,
        date: string,
    };
    updatedBy: {
        user: ListAuthor,
        date: string,
    };
    listInfo: {
        title: string,
        id: number,
    };
    background: string;
    clientDr: string;
    clientEmail: string;
    clientPhone: string;
    clientTitle: string;
    copyCount: number;
    createdFromList: number;
    description: string;
    id: number;
    imageHeight: number;
    imageUrl: string;
    imageWidth: number;
    isDraft: boolean;
    isLook: boolean;
    isPublic: boolean;
    isSynchronized: boolean;
    isVisibleToClient: boolean;
    status: ListType;
    url?: string;
    ui?: LookListGlobalUi;
}

const initialAuthor = (): ListAuthor => ({
    id: null,
    lastName: null,
    firstName: null,
});

const initialState = (): LookListProductsState => ({
    createdBy: {
        user: initialAuthor(),
        date: null,
    },
    sentBy: {
        user: initialAuthor(),
        date: null,
    },
    updatedBy: {
        user: initialAuthor(),
        date: null,
    },
    listInfo: {
        title: null,
        id: null,
    },
    background: null,
    clientDr: null,
    clientEmail: null,
    clientPhone: null,
    clientTitle: null,
    copyCount: null,
    createdFromList: null,
    description: null,
    id: null,
    imageHeight: null,
    imageUrl: null,
    imageWidth: null,
    isDraft: null,
    isLook: null,
    isPublic: null,
    isSynchronized: null,
    isVisibleToClient: null,
    status: null,
    url: null,
});

export interface LookListProductsUIState extends EntityState<LookListProductsUi> {}

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'look-list-products',
    idKey: 'productListHash',
})
export class LookListProductsStore extends EntityStore<LookListProductsState> {
    public ui: EntityUIStore<LookListProductsUIState>;

    constructor() {
        super(initialState());
        this.createUIStore().setInitialEntityState({
            imageRatio: null,
            isOverlayVisible: false,
        });
    }

    public resetState(): void {
        this.update(initialState());
    }

    public resetEntities(): void {
        this.set([]);
    }

    public updateForceSaveNotification(forceSaveNotification: boolean): void {
        this.update({ ui: { forceSaveNotification } })
    }

}
