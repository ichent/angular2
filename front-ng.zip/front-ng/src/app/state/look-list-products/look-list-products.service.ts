import { Injectable } from '@angular/core';
import { LookListProductsStore } from './look-list-products.store';
import { LookListProductsQuery } from './look-list-products.query';
import { finalize, first, map, mapTo, switchMap, tap } from 'rxjs/operators';
import { ListItem, ProductList, ReplaceListItem } from '../product-list/product-list.interface';
import { ProductListQuery } from '../product-list/product-list.query';
import { ProductListApiService } from '../product-list/product-list-api.service';
import { combineLatest, Observable, of, throwError } from 'rxjs';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { NotificationService } from '../../services/notification.service';
import { ProductListStore } from '../product-list/product-list.store';
import { ListProductHelper } from '../../helpers/list-product.helper';
import { ProductListRepository } from '../product-list/product-list.repository';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { ProductsRepository } from '../products/products.repository';
import { Product } from '../products/product.interface';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';

@Injectable({
    providedIn: 'root',
})
export class LookListProductsService {

    constructor(
        private lookListProductsStore: LookListProductsStore,
        private lookListProductsQuery: LookListProductsQuery,
        private productListQuery: ProductListQuery,
        private productListStore: ProductListStore,
        private productListApiService: ProductListApiService,
        private notificationService: NotificationService,
        private productListRepository: ProductListRepository,
        private productsRepository: ProductsRepository,
    ) {}

    /**
     * Добавляет товары в текущий лук, если его нет - создаёт текущий лук из текущего списка, а затем добавляет в копию
     */
    public addProductsToCurrentLook(items: Partial<ListItem>[]): Observable<ProductList> {
        return this.getNewProductsForCurrentLook(items)
            .pipe(
                first(),
                tap(([productList, products]: [ProductList, Product[]]) => {
                    const isDraft: boolean = productList.isDraft;
                    const listProducts: ListProduct[] = isDraft
                        ? ListProductHelper.toProductInList(productList, products)
                        : ListProductHelper.toLocalListProduct(productList.id, products);
                    this.lookListProductsStore.add(listProducts);
                }),
                map(([productList]: [ProductList, Product[]]) => productList),
            );
    }

    /**
     * Удаляет товар из текущего лука, если его нет - копирует текущий лук из текущего списка, а затем удаляет из копии
     */
    public removeProductFromCurrentLook(hash: string): Observable<number> {
        return this.selectCurrentLookId()
            .pipe(
                switchMap((lookId: number) => {
                    const isDraft: boolean = this.productListQuery.getIsDraft(lookId);

                    return isDraft // для черновиков сохранение на сервер происходит сразу, для остальных при переходе с холста
                        ? this.productListApiService.removeProductFromList(lookId, hash)
                            .pipe(
                                map((productList: ProductList) => productList.id)
                            )
                        : of(lookId);
                }),
                tap(
                    () => {
                        this.notificationService.pushNotifications([{
                            type: UiNotificationType.Info,
                            title: 'Товар удален с холста',
                        }]);

                        this.lookListProductsStore.remove(hash);
                    },
                    () => {
                        this.notificationService.pushNotifications([{
                            type: UiNotificationType.Error,
                            title: 'Не удалось удалить товар с холста',
                        }]);
                    }),
            );
    }

    /**
     * Заменяет товары из текущего лука, если его нет - копирует текущий лук из текущего списка, а затем заменяет в копии
     */
    public replaceProductsInCurrentLook(replaceItems: ReplaceListItem[], withoutStoreUpdate = false): Observable<ProductList> {
        return this.selectCurrentLookId()
            .pipe(
                switchMap((lookId: number) =>
                    this.productListApiService.replaceProductsInList(lookId, replaceItems, withoutStoreUpdate)
                ),
            );
    }

    /**
     * Возвращает id текущего лука, если его нет - копирует текущий лук из текущего списка, а затем возвращает
     */
    private selectCurrentLookId(): Observable<number> {
        const activeLookId: number = this.lookListProductsQuery.getId();

        if (activeLookId) {
            return of(activeLookId);
        } else if (this.productListQuery.getActiveId()) {
            return this.productListApiService.copyAsLook(this.productListQuery.getActiveId())
                .pipe(
                    map((look: ProductList) => look.id)
                );
        } else {
            return throwError('Текущий лук и список не существуют');
        }
    }

    /**
     * Сохраняет данные о товарах текущего лука в стору списка луков
     */
    public saveCurrentLookItems(): void {
        const currentLookId: number = this.lookListProductsQuery.getId();

        if (!currentLookId) {
            return;
        }

        this.productListStore.upsert(currentLookId, {
            ...this.productListQuery.getEntity(currentLookId),
            items: ListProductHelper.toListItems(this.lookListProductsQuery.getAll()),
        });
    }

    public saveCurrentLookChanges(silent: boolean = false): Observable<ProductList> {
        const listId: number = this.lookListProductsQuery.getId();
        return this.saveLookChanges(listId, silent);
    }

    public saveLookChanges(listId: number, silent: boolean = false): Observable<ProductList> {
        this.lookListProductsStore.setLoading(!silent);
        return this.lookListProductsQuery.selectAll()
            .pipe(
                first(),
                switchMap((listProducts: ListProduct[]) => this.saveLookList(listId, listProducts)),
                tap(() => {
                    if (!silent) {
                        this.notificationService.pushNotifications([
                            {
                                type: UiNotificationType.Success,
                                title: 'Успешно сохранено',
                                timeoutClose: TimeoutNotificationConstant.fast,
                            }
                        ]);
                    }
                }),
                finalize(() => {
                    this.setForceSave(false);
                    this.lookListProductsStore.setLoading(false);
                }),
            );
    }

    public setForceSave(forceSave: boolean): void {
        this.lookListProductsStore.updateForceSaveNotification(forceSave);
    }

    private addListProductsToStore(productList: ProductList): Observable<ProductList> {
        return this.productListRepository.selectListProducts(productList.id)
            .pipe(
                first(),
                tap((listProducts: ListProduct[]) => this.lookListProductsStore.set(listProducts)),
                mapTo(productList),
            );
    }

    private getNewProductsForCurrentLook(items: Partial<ListItem>[]): Observable<[ProductList, Product[]]> {
        const newProductsIds: number[] = (items || []).map((listItem: ListItem) => listItem.itemId);
        const productList$: Observable<ProductList> = this.selectCurrentLookId()
            .pipe(
                switchMap((lookId: number) => {
                    const isDraft: boolean = this.productListQuery.getIsDraft(lookId);

                    return isDraft // для черновиков сохранение на сервер происходит сразу, для остальных при переходе с холста
                        ? this.productListApiService.addProductToList(lookId, items)
                        : this.productListRepository.selectProductList(lookId);
                }),
            );
        const newProducts$: Observable<Product[]> = this.productsRepository.selectProducts(newProductsIds).pipe(first());

        return combineLatest([productList$, newProducts$]);
    }

    private saveLookList(listId: number, listProducts: ListProduct[]): Observable<ProductList> {
        const savedListProductHashes: string[] = this.productListQuery.getListItemsHashes(listId);

        const listProductsToReplace: ListProduct[] = this.getListProductsToReplace(savedListProductHashes, listProducts);
        const listItemsToAdd: ListItem[] = this.getListItemsToAdd(savedListProductHashes, listProducts);
        const listProductHashesToRemove: string[] = this.getListProductHashesToRemove(savedListProductHashes, listProductsToReplace);

        return this.productListApiService.replaceProductsInList(
            listId,
            ListProductHelper.toReplaceListItems(listProductsToReplace),
        )
            .pipe(
                switchMap(() => this.removeProductsFromList(listId, listProductHashesToRemove)),
                switchMap(() => this.addProductsToList(listId, listItemsToAdd)),
                switchMap((productList: ProductList) => this.addListProductsToStore(productList)),
            );
    }

    private getListProductsToReplace(savedListProductHashes: string[], listProducts: ListProduct[]): ListProduct[] {
        return listProducts
            .filter((listProduct: ListProduct) => savedListProductHashes.includes(listProduct.productListHash));
    }

    private getListItemsToAdd(savedListProductHashes: string[], listProducts: ListProduct[]): ListItem[] {
        return listProducts
            .filter((listProduct: ListProduct) => !savedListProductHashes.includes(listProduct.productListHash))
            .map((listProduct: ListProduct) => listProduct.listItem);
    }

    private getListProductHashesToRemove(savedListProductHashes: string[], listProductsToReplace: ListProduct[]): string[] {
        return savedListProductHashes
            .filter((hash: string) => !listProductsToReplace
                .map((listProduct: ListProduct) => listProduct.productListHash)
                .includes(hash)
            );
    }

    private removeProductsFromList(listId: number, hashes: string[]): Observable<ProductList> {
        if (!hashes || !hashes.length) {
            return this.productListRepository.selectProductList(listId).pipe(first());
        }
        return this.productListApiService.batchRemove(listId, hashes);
    }

    private addProductsToList(listId: number, items: ListItem[]): Observable<ProductList> {
        if (!items || !items.length) {
            return this.productListRepository.selectProductList(listId).pipe(first());
        }
        return this.productListApiService.addProductToList(listId, items, true);
    }

}
