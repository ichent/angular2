import { Injectable } from '@angular/core';
import { EntityUIQuery, QueryConfig, QueryEntity } from '@datorama/akita';
import { LookListProductsState, LookListProductsStore, LookListProductsUIState } from './look-list-products.store';
import { Observable } from 'rxjs';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { map } from 'rxjs/operators';
import { LookListProductsUi } from './look-list-products-ui.interface';
import { ReplaceListItem } from '../product-list/product-list.interface';
import { ListProductHelper } from '../../helpers/list-product.helper';
import { queryCypressBinding } from '../e2e-store';

// сортируем по uuid товара в списке, чтобы сохранялось положение товара на холсте и не происходило лишней перерисовки
@QueryConfig({
    sortBy: 'productListHash',
})
@Injectable({
    providedIn: 'root',
})
export class LookListProductsQuery extends QueryEntity<LookListProductsState> {
    public ui: EntityUIQuery<LookListProductsUIState, LookListProductsUi>;

    constructor(
        protected store: LookListProductsStore,
    ) {
        super(store);
        queryCypressBinding(this);
        this.createUIQuery();
    }

    public selectListProductsInCanvas(): Observable<ListProduct[]> {
        return this.selectAll()
            .pipe(
                map((listProducts: ListProduct[]) =>
                    listProducts.filter((listProduct: ListProduct) => listProduct.listItem.visibility)
                ),
            );
    }

    public selectListProductsNotInCanvas(): Observable<ListProduct[]> {
        return this.selectAll()
            .pipe(
                map((listProducts: ListProduct[]) =>
                    listProducts.filter((listProduct: ListProduct) => !listProduct.listItem.visibility)
                ),
            );
    }

    public getHighestLayer(): number {
        return this.getAll()
            .reduce((highestLevel: number, lookListProduct: ListProduct) =>
                Math.max(highestLevel, lookListProduct.listItem.layer),
                1
            );
    }

    public getId(): number {
        return this.getValue().id;
    }

    public selectListProductOverlayVisibility(listProductHash: string): Observable<boolean> {
        return this.ui.selectEntity(listProductHash)
            .pipe(
                map(({ isOverlayVisible }) => isOverlayVisible),
            );
    }

    public getListProductImageRatio(listProductHash: string): number {
        return this.ui.getEntity(listProductHash).imageRatio;
    }

    public getReplaceListItems(): ReplaceListItem[] {
        return ListProductHelper.toReplaceListItems(this.getAll());
    }

    public forceSaveNotification(): boolean {
        return this.getValue().ui ? this.getValue().ui.forceSaveNotification : false;
    }

}
