export interface LookListProductsUi {
    imageRatio: number;
    isOverlayVisible: boolean;
}

export interface LookListGlobalUi {
    forceSaveNotification: boolean;
}
