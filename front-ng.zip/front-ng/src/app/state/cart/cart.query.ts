import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { CartState, CartStore } from './cart.store';
import { combineLatest, Observable } from 'rxjs';
import { countBy as _countBy } from 'lodash';
import { CartProduct } from './interfaces/cart-product.interface';
import { filter, map } from 'rxjs/operators';
import { SkuQuantity } from '../../interfaces/list-product/list-sku-quantity.interface';
import { SkuStocksQuery } from '../sku-stocks/sku-stocks.query';

@Injectable({
    providedIn: 'root',
})
export class CartQuery extends QueryEntity<CartState> {

    constructor(
        protected store: CartStore,
        private skuStocksQuery: SkuStocksQuery,
    ) {
        super(store);
    }

    public selectCartProductByUuid(uuid: string): Observable<CartProduct> {
        return this.selectEntity(uuid);
    }

    public selectCartProductSkuId(uuid: string): Observable<number> {
        return this.selectCartProductByUuid(uuid)
            .pipe(
                filter(Boolean),
                map((cartProduct: CartProduct) => cartProduct.skuId),
            );
    }

    public selectCartProductAvailableSkuQuantity(productId: number): Observable<SkuQuantity> {
        return combineLatest([
            this.skuStocksQuery.selectProductSkuQuantity(productId),
            this.mapCartProductSkuQuantity(productId),
        ])
            .pipe(
                map(([stocks, selected]: SkuQuantity[]) => {
                    const result: SkuQuantity = new Map(stocks);

                    selected.forEach((quantity: number, skuId: number) => {
                        result.set(skuId, stocks.get(skuId) - quantity || 0);
                    });

                    return result;
                }),
            );
    }

    /**
     * Количество выбранных sku для товара в корзине
     * @param productId - id товара в каталоге NP (ТОЦ)
     */
    public selectCartProductSkuQuantity(productId: number): Observable<SkuQuantity> {
        return this.mapCartProductSkuQuantity(productId);
    }

    private selectCartSkuIdsByProductId(productId: number): Observable<number[]> {
        return this.selectAll()
            .pipe(
                map((cartProducts: CartProduct[]) =>
                    cartProducts
                        .filter((cartProduct: CartProduct) => cartProduct.product.id === productId && !!cartProduct.skuId)
                        .map((cartProduct: CartProduct) => cartProduct.skuId)
                ),
            );
    }

    private mapCartProductSkuQuantity(productId: number): Observable<SkuQuantity> {
        return this.selectCartSkuIdsByProductId(productId)
            .pipe(
                map((skuIds: number[]) => _countBy(skuIds)),
                map((skuIdsCount: { [skuId: string]: number }) => {
                    const skuQuantityMap: SkuQuantity = new Map<number, number>();

                    Object.keys(skuIdsCount).forEach((skuId: string) => {
                        skuQuantityMap.set(parseInt(skuId, 10), skuIdsCount[skuId]);
                    });

                    return skuQuantityMap;
                }),
            );
    }

}
