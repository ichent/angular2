import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { CartProduct } from './interfaces/cart-product.interface';

export interface CartState extends EntityState<CartProduct, string> {
}

@Injectable({
    providedIn: 'root',
})

@StoreConfig({
    name: 'cart',
    idKey: 'uuid',
})

export class CartStore  extends EntityStore<CartState> {

    constructor() {
        super({ loading: false });
    }

}
