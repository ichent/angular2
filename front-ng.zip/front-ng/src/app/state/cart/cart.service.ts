import { Injectable, OnDestroy } from '@angular/core';
import { CartStore } from './cart.store';
import { Observable, Subject } from 'rxjs';
import { ProductListRepository } from '../product-list/product-list.repository';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { filter, map, switchMap, take, takeUntil } from 'rxjs/operators';
import { CartProduct } from './interfaces/cart-product.interface';
import { SizeSkuListItem, SkuSizeItem } from '../../features/size/interfaces/sku-size.interface';
import { SkuSizesQuery } from '../sku-sizes/sku-sizes.query';
import { EntityState } from '@datorama/akita';
import { ProductListQuery } from '../product-list/product-list.query';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { NotificationService } from '../../services/notification.service';
import { OrderLine } from '../orders/interfaces/order-line.interface';
import { Order } from '../orders/interfaces/order.interface';
import { ProductsRepository } from '../products/products.repository';
import { OrdersQuery } from '../orders/orders.query';
import { TransformHelper } from '../../helpers/transform.helper';
import { ORDER_LINE_TO_ORDER_PRODUCT } from '../../pages/order/constants/order-line-to-order-product.schema';

@Injectable({
    providedIn: 'root',
})
export class CartService implements OnDestroy {

    private destroyed$ = new Subject<void>();

    constructor(
        private cartStore: CartStore,
        private productListRepository: ProductListRepository,
        private productListQuery: ProductListQuery,
        private productsRepository: ProductsRepository,
        private skuSizesQuery: SkuSizesQuery,
        private ordersQuery: OrdersQuery,
        private notificationService: NotificationService,
    ) {}

    public setLoading(value: boolean): void {
        this.cartStore.setLoading(value);
    }

    public convertCurrentListToCart(): void {
        const listId: number = this.productListQuery.getActiveId();

        if (!listId) {
            this.cartStore.set([]);
        }

        this.convertListToCart(listId);
    }

    public convertListToCart(listId: number): void {
        this.mapProductListToCartProducts(listId)
            .pipe(
                take(1),
                map((cartProducts: CartProduct[]) => this.cartStore.set(cartProducts)),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    public changeCartProductSize(uuid: string, skuId: number): void {
        this.cartStore.update(uuid, (entity: EntityState) => {
            return {
                ...entity,
                skuId
            };
        });
    }

    public addProductsToCart(cartProducts: CartProduct[]): void {
        this.cartStore.add(cartProducts);

        this.notificationService.pushNotifications([{
            title: 'Успешно добавлено в корзину',
            type: UiNotificationType.Success,
        }]);
    }

    public addOrderProductsToCart(): void {
        this.ordersQuery.selectActive()
            .pipe(
                filter(Boolean),
                map((order: Order) => this.mapOrderToCartProducts(order)),
                takeUntil(this.destroyed$),
            )
            .subscribe((cartProducts: CartProduct[]) => {
                this.cartStore.set(cartProducts);
            });
    }

    public removeProductFromCart(uuid: string): void {
        this.cartStore.remove(uuid);

        this.notificationService.pushNotifications([{
            title: 'Успешно удалено из корзины',
            type: UiNotificationType.Success,
        }]);
    }

    private mapProductListToCartProducts(listId: number): Observable<CartProduct[]> {
        return this.productListRepository.selectListProducts(listId)
            .pipe(
                take(1),
                switchMap((listProducts: ListProduct[]) =>
                    this.skuSizesQuery.selectMany(listProducts.map((listProduct: ListProduct) => listProduct.product.id))
                        .pipe(
                            map((skuSizeItems: SkuSizeItem[]) => this.mapListProductsToCartProducts(listProducts, skuSizeItems)),
                        )
                ),
            );
    }

    private mapListProductsToCartProducts(listProducts: ListProduct[], skuSizeItems: SkuSizeItem[]): CartProduct[] {
        return listProducts.map((listProduct: ListProduct) => {
            const skuSizeItem: SkuSizeItem = skuSizeItems
                .find((skuSizeItem: SkuSizeItem) => skuSizeItem.productId === listProduct.product.id);
            const sizeSkuListItem: SizeSkuListItem = skuSizeItem
                ? skuSizeItem.skuList.find((skuListItem: SizeSkuListItem) => skuListItem.id === listProduct.listItem.skuId)
                : null;

            return {
                uuid: listProduct.productListHash,
                product: listProduct.product,
                skuId: listProduct.listItem.skuId,
                sizeAttributes: sizeSkuListItem ? sizeSkuListItem.sizeAttributes : null,
                price: listProduct.product?.skuList?.[0]
            };
        });
    }

    public mapOrderToCartProducts(order: Order): CartProduct[] {
        if (!order.lines || !order.lines.length) {
            return null;
        }

        return order.lines.map((line: OrderLine) => TransformHelper.to(line, ORDER_LINE_TO_ORDER_PRODUCT));
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
