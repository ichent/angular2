import { Injectable } from '@angular/core';
import { GiftCardStore } from './gift-card.store';
import { GiftCard } from './interfaces/gift-card.interface';

@Injectable({
    providedIn: 'root',
})
export class GiftCardService {

    constructor(
        private bonusCardStore: GiftCardStore,
    ) {}

    public setGiftCardsLoading(isLoading: boolean): void {
        this.bonusCardStore.setLoading(isLoading);
    }

    public setGiftCardId(id: string): void {
        this.bonusCardStore.update({ id });
    }

    public addGiftCardInfo(giftCard: GiftCard): void {
        this.bonusCardStore.update(giftCard);
    }

    public resetGiftCardInfo(): void {
        this.bonusCardStore.update({ cardBalance: null, type: null });
    }

}
