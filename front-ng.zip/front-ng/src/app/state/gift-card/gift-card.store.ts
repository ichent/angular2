import { Injectable } from '@angular/core';
import { Store, StoreConfig } from "@datorama/akita";
import { GiftCard } from "./interfaces/gift-card.interface";

export interface GiftCardState extends GiftCard{
    id: string,
}

const initialState: GiftCardState = {
    id: null,
    cardBalance: null,
    type: null,
};

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'gift-card',
})
export class GiftCardStore extends Store<GiftCardState> {

    constructor() {
        super(initialState);
    }

}
