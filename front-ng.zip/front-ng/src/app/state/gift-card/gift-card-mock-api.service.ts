import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { GiftCard } from "./interfaces/gift-card.interface";
import { GiftCardProduct } from '../../interfaces/gift-card-product.interface';

@Injectable({
    providedIn: 'root',
})
export class GiftCardMockApiService {

    public mockGiftCard(): Observable<GiftCard> {
        return of({
            cardBalance: 2500,
            type: null,
        }).pipe(delay(1500));
    }

    public mockGiftCardProduct(): Observable<GiftCardProduct[]> {
        return of([
            {
                id: 1,
                title: 'Made to Measure',
                subtitle: '4349е05е44',
                isOnlyVirtual: false,
                isOnlyOnlinePay: false,
                itemExtId: null,
                itemSkuExtId: null,
                photos: {
                    x1: 'https://st2.tsum.com/sig/7b48ab2e7b889829a3109850655dc8e1/width/375/photos/2/1/2101ec3a05856a67f9167f938e88b705bb1cf080.png',
                    x2: null,
                    x3: null,
                }
            },
            {
                id: 2,
                title: 'Классическая ЦУМ',
                subtitle: '4349е05е44',
                isOnlyVirtual: false,
                isOnlyOnlinePay: false,
                itemExtId: null,
                itemSkuExtId: null,
                photos: {
                    x1: 'https://st1.tsum.com/sig/0e6eb8ab4a39ef9849c3997399954b7d/width/1125/photos/a/8/a8e3a454728dfd24987db8491d22b5a4872fe414.png',
                    x2: null,
                    x3: null,
                }
            },
            {
                id: 3,
                title: 'Классическая',
                subtitle: '4349е05е44',
                isOnlyVirtual: false,
                isOnlyOnlinePay: false,
                itemExtId: null,
                itemSkuExtId: null,
                photos: {
                    x1: 'https://st1.tsum.com/sig/47f631014707b85f3ac46ca775f42688/width/1125/photos/2/6/26402a29800ad7103cfcbf7cca0fb242c52a5d23.png',
                    x2: null,
                    x3: null,
                }
            },
            {
                id: 4,
                title: 'Новогодняя',
                subtitle: '4349е05е44',
                isOnlyVirtual: false,
                isOnlyOnlinePay: false,
                itemExtId: null,
                itemSkuExtId: null,
                photos: {
                    x1: 'https://st2.tsum.com/sig/8b370a59bd6b779874e0656e7c4e4747/width/1125/photos/9/8/987229ced233c48e44afc5f72b6bf53c1b1a7525.jpg',
                    x2: null,
                    x3: null,
                }
            },
        ]).pipe(delay(1500));
    }

}
