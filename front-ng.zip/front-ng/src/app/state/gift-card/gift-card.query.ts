import { Injectable } from '@angular/core';
import { Query } from "@datorama/akita";
import { GiftCardState, GiftCardStore } from "./gift-card.store";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root',
})
export class GiftCardQuery extends Query<GiftCardState> {

    constructor(
        protected store: GiftCardStore,
    ) {
        super(store);
    }

    public getGiftCardBalance(): number {
        return this.getValue().cardBalance;
    }

    public getGiftCardId(): string {
        return this.getValue().id;
    }

    public selectGiftCardId(): Observable<string> {
        return this.select('id');
    }

    public selectGiftCardBalance(): Observable<number> {
        return this.select('cardBalance');
    }

}
