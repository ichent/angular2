import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { filter, finalize, tap } from 'rxjs/operators';
import { ApiService } from '../../services/api/api.service';
import { GiftCardService } from "./gift-card.service";
import { GiftCardMockApiService } from "./gift-card-mock-api.service";
import { GiftCard } from "./interfaces/gift-card.interface";

@Injectable({
    providedIn: 'root',
})
export class GiftCardApiService {

    constructor(
        private apiService: ApiService,
        private giftCardService: GiftCardService,
        private giftCardMockApiService: GiftCardMockApiService,

    ) {}

    /**
     * Получить данные подарочной карты
     */
    public getGiftCard(giftCardId: string, pinCode: string): Observable<GiftCard> {
        this.giftCardService.setGiftCardsLoading(true);

        return this.giftCardMockApiService.mockGiftCard()
            .pipe(
                filter(Boolean),
                tap((bonusCard: GiftCard) => this.giftCardService.addGiftCardInfo(bonusCard)),
                finalize(() => this.giftCardService.setGiftCardsLoading(false)),
            )
    }

}
