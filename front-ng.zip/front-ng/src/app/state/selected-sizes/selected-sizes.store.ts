import { Injectable } from '@angular/core';
import { Store, StoreConfig } from '@datorama/akita';
import { SizeSelectionContext } from '../../features/size/constants/size-selection-context.enum';
import { ProductSkuSizes } from '../../features/size/interfaces/product-sku-sizes.interface';

/**
 * Выбранные размеры этих контекстов хранятся в данной сторе,
 * тогда как выбранные размеры других контекстов хранятся в других сторах
 */
export const SELECTED_SIZES_STATE_CONTEXTS: SizeSelectionContext[] = [
    SizeSelectionContext.OrderEdit,
    SizeSelectionContext.ProductList,
    SizeSelectionContext.Cart,
];

export type SelectedSizesState = Partial<{ [key in SizeSelectionContext]: ProductSkuSizes }>

const getInitialState = (): SelectedSizesState => {
    return SELECTED_SIZES_STATE_CONTEXTS.reduce((state: SelectedSizesState, context: SizeSelectionContext) => {
        state[context] = {};
        return state;
    }, {});
};

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'selected-sizes',
})
export class SelectedSizesStore extends Store<SelectedSizesState> {

    constructor() {
        super(getInitialState());
    }

}
