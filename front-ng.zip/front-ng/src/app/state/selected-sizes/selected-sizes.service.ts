import { Injectable } from '@angular/core';
import { SizeSelectionContext } from '../../features/size/constants/size-selection-context.enum';
import { SELECTED_SIZES_STATE_CONTEXTS, SelectedSizesStore } from './selected-sizes.store';
import { SelectedSizesQuery } from './selected-sizes.query';
import { ContextQuery } from '../context/context.query';

@Injectable({
    providedIn: 'root'
})
export class SelectedSizesService {

    constructor(
        private selectedSizesStore: SelectedSizesStore,
        private selectedSizesQuery: SelectedSizesQuery,
        private contextQuery: ContextQuery,
    ) {}

    public setSelectedSizes(productId: number, skuSizeIds: number[], context?: SizeSelectionContext): void {
        context = context || this.contextQuery.getSizeSelectionContext();

        // Возможно сохранять размеры в эту стору только в некоторых контекстах,
        // размеры для остальных контекстов хранятся в других сторах
        if (SELECTED_SIZES_STATE_CONTEXTS.includes(context)) {
            this.selectedSizesStore.update({
                [context]: {
                    ...this.selectedSizesQuery.getAllByContext(),
                    [productId]: skuSizeIds,
                },
            });
        }
    }
}
