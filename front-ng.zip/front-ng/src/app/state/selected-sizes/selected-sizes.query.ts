import { Injectable } from '@angular/core';
import { Query } from '@datorama/akita';
import { ContextQuery } from '../context/context.query';
import { SelectedSizesState, SelectedSizesStore } from './selected-sizes.store';
import { ProductsQuery } from '../products/products.query';
import { ProductListQuery } from '../product-list/product-list.query';
import { Observable, of } from 'rxjs';
import { ProductSkuSizes } from '../../features/size/interfaces/product-sku-sizes.interface';
import { map, switchMap, tap } from 'rxjs/operators';
import { SizeSelectionContext } from '../../features/size/constants/size-selection-context.enum';
import { ProductList } from '../product-list/product-list.interface';
import { CartQuery } from '../cart/cart.query';
import { CartProduct } from '../cart/interfaces/cart-product.interface';
import { Look } from '../../interfaces/catalog.interface';

@Injectable({
    providedIn: 'root',
})
export class SelectedSizesQuery extends Query<SelectedSizesState> {

    constructor(
        protected store: SelectedSizesStore,
        private contextQuery: ContextQuery,
        private productsQuery: ProductsQuery,
        private productListQuery: ProductListQuery,
        private cartQuery: CartQuery,
    ) {
        super(store);
    }

    /**
     * Выбранные размеры для конкретного товара в текущем контексте
     *
     * @param productId -
     *   id продукта для контекста списка товаров
     *   hash товара в списке для контекста страницы списка товаров
     *
     * @param sizeContext - контекст выбора размера (не путать с глобальным контекстом)
     */
    public selectBy(productId: number | string, sizeContext?: SizeSelectionContext): Observable<number[]> {
        return this.selectManyBy([ productId ], sizeContext)
            .pipe(
                map((sizes: ProductSkuSizes) => sizes && sizes[productId] || []),
            );
    }

    public getBy(productId: number | string, sizeContext?: SizeSelectionContext): number[] {
        const productSkuSizes: ProductSkuSizes = this.getManyBy([ productId ], sizeContext);
        return productSkuSizes && productSkuSizes[productId] || [];
    }

    /**
     * Выбранные размеры для нескольких товара в текущем контексте
     *
     * @param productIds -
     *   id продукта для контекста списка товаров
     *   hash товара в списке для контекста страницы списка товаров
     *
     * @param sizeContext - контекст выбора размера (не путать с глобальным контекстом)
     */
    public getManyBy(productIds: (number | string)[], sizeContext?: SizeSelectionContext): ProductSkuSizes {
        sizeContext = sizeContext || this.contextQuery.getSizeSelectionContext();
        const sizes: ProductSkuSizes = this.getAllByContext(sizeContext);

        return this.filterByProductIds(sizes, productIds);
    }

    public selectManyBy(productIds: (number | string)[], sizeContext?: SizeSelectionContext): Observable<ProductSkuSizes> {
        return (sizeContext ? of(sizeContext) : this.contextQuery.selectSizeSelectionContext())
            .pipe(
                switchMap((sizeContext: SizeSelectionContext) => this.selectAllByContext(sizeContext)),
                map((sizes: ProductSkuSizes) => this.filterByProductIds(sizes, productIds)),
            );
    }

    /**
     * Проверка выбраны ли размеры у запрашиваемых товаров в данном контексте
     *
     * @param productIds -
     *   id продукта для контекста списка товаров
     *   hash товара в списке для контекста страницы списка товаров
     *
     * @param sizeContext - контекст выбора размера (не путать с глобальным контекстом)
     */
    public selectIsAllSelected(productIds: (number | string)[], sizeContext?: SizeSelectionContext): Observable<boolean> {
        return this.selectManyBy(productIds)
            .pipe(
                map((productSkuSizes: ProductSkuSizes) =>
                    Object.keys(productSkuSizes)
                        .map((productId: number | string) => productSkuSizes[productId]?.length > 0)
                        .every(Boolean)
                ),
            );
    }

    /**
     * Выбранные размеры для всех товаров в запрашиваемом контексте
     */
    public selectAllByContext(sizeContext?: SizeSelectionContext): Observable<ProductSkuSizes> {
        sizeContext = sizeContext || this.contextQuery.getSizeSelectionContext();

        switch (sizeContext) {
            case SizeSelectionContext.Cart:
                return this.selectAllForCart();
            case SizeSelectionContext.CartPage:
                return this.selectAllForCartPage();
            case SizeSelectionContext.OrderEdit:
                return this.selectAllForEditOrder();
            case SizeSelectionContext.ProductList:
                return this.selectAllForProductList();
            case SizeSelectionContext.ProductListPage:
                return this.selectAllForProductListPage();
            default:
                return of(null);
        }
    }

    public getAllByContext(sizeContext?: SizeSelectionContext): ProductSkuSizes {
        sizeContext = sizeContext || this.contextQuery.getSizeSelectionContext();

        switch (sizeContext) {
            case SizeSelectionContext.Cart:
                return this.getAllForCart();
            case SizeSelectionContext.CartPage:
                return this.getAllForCartPage();
            case SizeSelectionContext.OrderEdit:
                return this.getAllForEditOrder();
            case SizeSelectionContext.ProductList:
                return this.getAllForProductList();
            case SizeSelectionContext.ProductListPage:
                return this.getAllForProductListPage();
        }
    }

    /**
     * Выбранные размеры для всех товаров в контексте корзины
     */
    private selectAllForCart(): Observable<ProductSkuSizes> {
        return this.select((state: SelectedSizesState) => state[SizeSelectionContext.Cart]);
    }

    private getAllForCart(): ProductSkuSizes {
        return this.getValue()[SizeSelectionContext.Cart];
    }

    /**
     * Выбранные размеры для всех товаров в контексте страницы корзины
     */
    private selectAllForCartPage(): Observable<ProductSkuSizes> {
        return this.cartQuery.selectAll().pipe(map(this.cartProductsToSelectedProductSkuSizes));
    }

    private getAllForCartPage(): ProductSkuSizes {
        return this.cartProductsToSelectedProductSkuSizes(this.cartQuery.getAll());
    }

    /**
     * Выбранные размеры для всех товаров в контексте редактирования заказа
     */
    private selectAllForEditOrder(): Observable<ProductSkuSizes> {
        return this.select((state: SelectedSizesState) => state[SizeSelectionContext.OrderEdit]);
    }

    private getAllForEditOrder(): ProductSkuSizes {
        return this.getValue()[SizeSelectionContext.OrderEdit];
    }

    /**
     * Выбранные размеры для всех товаров в контексте списка товаров
     */
    private selectAllForProductList(): Observable<ProductSkuSizes> {
        return this.select((state: SelectedSizesState) => state[SizeSelectionContext.ProductList]);
    }

    private getAllForProductList(): ProductSkuSizes {
        return this.getValue()[SizeSelectionContext.ProductList];
    }

    /**
     * Выбранные размеры для всех товаров в контексте страницы списка товаров (редактирование списка)
     */
    private selectAllForProductListPage(): Observable<ProductSkuSizes> {
        return this.productListQuery.selectActive()
            .pipe(
                map(this.productListToSelectedSizes),
            );
    }

    private getAllForProductListPage(): ProductSkuSizes {
        return this.productListToSelectedSizes(this.productListQuery.getActive());
    }

    private filterByProductIds(sizes: ProductSkuSizes, productIds: (number | string)[]): ProductSkuSizes {
        if (!productIds.length) {
            return [];
        }

        return productIds.reduce((acc: ProductSkuSizes, productId: number | string) => {
            acc[productId] = sizes && sizes[productId] || [];
            return acc;
        }, {});
    }

    private productListToSelectedSizes(list: ProductList): ProductSkuSizes {
        const selectedProductSkuSizes: ProductSkuSizes = {};

        if (!list) {
            return selectedProductSkuSizes;
        }

        for (let productHash in list.items) {
            selectedProductSkuSizes[productHash] = selectedProductSkuSizes[productHash]
                ? [ ...selectedProductSkuSizes[productHash], list.items[productHash].skuId ].filter(Boolean)
                : [ list.items[productHash].skuId ].filter(Boolean)
        }

        return selectedProductSkuSizes;
    }

    private cartProductsToSelectedProductSkuSizes(cartProducts: CartProduct[]): ProductSkuSizes {
        return (cartProducts || [])
            .reduce((acc: ProductSkuSizes, cartProduct: CartProduct) => {
                acc[cartProduct.uuid] = [ cartProduct.skuId ].filter(Boolean);
                return acc;
            }, {});
    }

}
