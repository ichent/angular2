import { Injectable } from '@angular/core';
import { ActiveState, EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Order } from './interfaces/order.interface';
import { RelativeOrder } from './interfaces/relative-order.interface';

export interface OrdersState extends EntityState<Order>, ActiveState {
    relativeOrders: RelativeOrder[];
}

const createInitialState = (): OrdersState => ({
    active: null,
    relativeOrders: null,
});

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'orders',
    idKey: 'uuid',
})
export class OrdersStore extends EntityStore<OrdersState> {

    constructor() {
        super(createInitialState());
    }

}
