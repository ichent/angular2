import { Injectable } from '@angular/core';
import { EMPTY, Observable } from 'rxjs';
import { catchError, finalize, map, tap } from 'rxjs/operators';
import { OrderService } from './order.service';
import { Order } from './interfaces/order.interface';
import { CombineOrder } from '../../sidenavs/orders/combine-orders-sidenav/interfaces/combine-order.interface';
import {
    OrderDeliveryAddressRes,
} from '../../sidenavs/orders/combine-orders-sidenav/interfaces/order-delivery-address.interface';
import {
    OrderDeliveryInterval,
} from '../../sidenavs/orders/combine-orders-sidenav/interfaces/order-delivery-interval.interface';
import { CcApiHelper } from '../../helpers/cc-api.helper';
import { ApiService } from '../../services/api/api.service';
import {
    CombineDeliveryRequest,
    CombineOrdersRequest,
} from '../../sidenavs/orders/combine-orders-sidenav/interfaces/combine-delivery.interface';
import { CartService } from '../cart/cart.service';
import { BaseApiResponse } from '../../services/api/base-api.service';
import { HttpParams } from '@angular/common/http';
import { OrderCommentTab } from '../../sidenavs/orders/order-comments-sidenav/order-comments-sidenav.constant';
import { CommentInfo } from '../../interfaces/comment-info.interface';
import { OrderComments } from './interfaces/order-comments.interface';
import { Aura } from '../../helpers/aura.helper';
import { GiftCardService } from '../gift-card/gift-card.service';
import { OrderCancelReq } from './interfaces/order-cancel.interface';
import { OrderLineRejection } from '../../pages/order/constants/order-line-rejection.namespace';
import { ORDER_CANCEL_REASON_TITLES, OrderCancelReason } from '../../constants/order/order-cancel-reason.constant';
import { OrderCancelSuggest } from '../../interfaces/order/order-cancel-suggest.interface';
import { ProductsRepository } from '../products/products.repository';
import { Product } from '../products/product.interface';
import { SkuItem } from '../../interfaces/sku.interface';
import { ProductsQuery } from '../products/products.query';
import { ID } from '@datorama/akita';
import { OrdersStore } from './orders.store';
import { ContextQuery } from '../context/context.query';
import { ProductSkuSizes } from '../../features/size/interfaces/product-sku-sizes.interface';
import { NotificationService } from '../../services/notification.service';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { OrderValidation } from '../../features/order/interfaces/order-validation.interface';
import { OrdersQuery } from './orders.query';
import { OrderValidationService } from '../../features/order/services/order-validation.service';
import { OrderValidationOptions } from '../../features/order/interfaces/order-validation-options.interface';

@Injectable({
    providedIn: 'root',
})
export class OrderApiService {

    constructor(
        private apiService: ApiService,
        private orderService: OrderService,
        private contextQuery: ContextQuery,
        private ordersStore: OrdersStore,
        private giftCardService: GiftCardService,
        private cartService: CartService,
        private productsRepository: ProductsRepository,
        private productsQuery: ProductsQuery,
        private notificationService: NotificationService,
        private ordersQuery: OrdersQuery,
        private orderValidationService: OrderValidationService,
    ) {}

    public addCommentToClient(id: string, comment: string): Observable<CommentInfo[]> {
        return this.apiService.post<BaseApiResponse<CommentInfo[]>>(`client/${id}/add-comment`, { comment })
            .pipe(map(CcApiHelper.toResponseData));
    }

    /**
     * Удаление товарной строки из заказа
     *
     * @param orderId уникальный идентификтор заказа
     * @param lineId уникальный идентификтор строки заказа
     * @param deleteReason причина удаления: https://kb.int.tsum.com/display/GW/Enum+-+Order-line
     */
    public deleteOrderProduct(orderId: string, lineId: string, deleteReason: OrderLineRejection.Reason): Observable<Order> {
        return this.apiService.post<BaseApiResponse<Order>>(
            `order/${orderId}/order-line/${lineId}/reject`,
            {
                reject: deleteReason
            },
        )
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => this.orderService.upsertOrderToStore(order)),
            );
    }

    public createOrder(): Observable<Order> {
        return this.getOrderById('create-order-mock')
            .pipe(
                tap((order: Order) => this.orderService.setActiveOrder(order.uuid)),
            );
    }

    public getOrderById(uuid: string): Observable<Order> {
        this.cartService.setLoading(true);

        return this.apiService.get<BaseApiResponse<Order>>(`order/${uuid}`)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => {
                    this.orderService.upsertOrderToStore(order);

                    if (order && order.loyalty) {
                        this.giftCardService.setGiftCardId(order.loyalty.giftCard);
                    }
                }),
                finalize(() => this.cartService.setLoading(false)),
            );
    }

    public getOrderCommentsById(uuid: string, type?: OrderCommentTab): Observable<Partial<OrderComments>> {
        const params = type ? new HttpParams({ fromObject: { 'list-type': Aura.camelCaseToKebab(type) } }) : null;

        return this.apiService.get<BaseApiResponse<OrderComments>>(`order/${uuid}/comments`, { params })
            .pipe(map(CcApiHelper.toResponseData));
    }

    public modifyClientComment(uuid: string, comment: string): Observable<CommentInfo[]> {
        return this.apiService.post<BaseApiResponse<CommentInfo[]>>(`order/${uuid}/add-client-comment`, { comment })
            .pipe(map(CcApiHelper.toResponseData));
    }

    public addComment(uuid: string, comment: string): Observable<CommentInfo[]> {
        return this.apiService.post<BaseApiResponse<CommentInfo[]>>(`order/${uuid}/add-operator-comment`, { comment })
            .pipe(map(CcApiHelper.toResponseData));
    }

    /**
     * Добавление товаров в заказ по индентификатору товара конкрентного размера в Аксапте
     *
     * @param orderId - идентефикатор заказа
     * @param extIds - массив extGuid или extId уровня sku
     */
    public addProductsBySkuExtIds(orderId: ID, extIds: string[]): Observable<Order> {
        const { isValid }: OrderValidation = this.orderValidationService.validateAddProduct(
            this.ordersQuery.getEntity(orderId),
            extIds,
            { showValidationNotification: true },
        );

        if (!isValid) {
            return EMPTY;
        }

        const items: { id: string }[] = extIds.map((id: string) => ({ id }));

        return this.apiService.post<BaseApiResponse<Order>>(`order/${orderId}/order-line`, { items })
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => this.updateStore(order)),
                catchError(() => {
                    this.notificationService.pushNotifications([{
                        title: 'Ошибка добавления товара',
                        type: UiNotificationType.Error,
                    }]);

                    // При возврате EMPTY, subscribe у отправителя запроса не выполнится.
                    // И, следовательно, happy path не будет исполнен.
                    // В тоже время, не будет и необработанных ошибок.
                    return EMPTY;
                }),
            );
    }

    /**
     * Добавление товаров в заказ по индентификатору товара конкрентного размера сайте NP
     *
     * @param orderId - идентефикатор заказа
     * @param productSkuSizes - { productId: skuIds[] }, где
     *   productId - id товара на сайте NP (ТОЦ),
     *   skuIds - массив id уровня sku
     */
    public addProductsBySkuSizes(orderId: ID, productSkuSizes: ProductSkuSizes): Observable<Order> {
        let extIds: string[] = [];

        Object.entries(productSkuSizes).forEach(([productId, skuIds]: [string, number[]]) => {
            const product: Product = this.productsQuery.getEntity(productId);
            extIds = [ ...extIds, ...this.skuIdsToExtIds(skuIds, product) ];
        });

        return this.addProductsBySkuExtIds(orderId, extIds);
    }

    /**
     *  Объединение заказов. Получение заказов, которые можно объединить у клиента
     */
    public getOrdersToCombine(dr: string): Observable<CombineOrder[]> {
        return this.apiService.get<BaseApiResponse<CombineOrder[]>>(`orders/by-customer/${dr}`)
            .pipe(map(CcApiHelper.toResponseData));
    }

    /**
     *  Получение информации о доставке из заказов
     *
     *  @param orders - id заказов
     */
    public getOrdersDelivery(orders: string[]): Observable<OrderDeliveryAddressRes[]> {
        return this.apiService.post<BaseApiResponse<OrderDeliveryAddressRes[]>>('order/addresses', { orders })
            .pipe(map(CcApiHelper.toResponseData));
    }

    /**
     * Получение доставки для адреса
     *
     * @param orderId - id заказа
     * @param address - адрес доставки одной строкой
     * @param deliveryMethod - метод доставки для GEO (может отличаться от того, который в заказе)
     */
    public getAddressDeliveryIntervals(
        orderId: string,
        address: string,
        deliveryMethod: string = 'unspecified'
    ): Observable<OrderDeliveryInterval[]> {
        return this.apiService.post<BaseApiResponse<OrderDeliveryInterval[]>>(
            `order/${orderId}/delivery`,
            { address, deliveryMethod }
        ).pipe(map(CcApiHelper.toResponseData));
    }

    /**
     * Объединение доставки заказов
     */
    public combineOrdersDelivery(delivery: CombineDeliveryRequest, orderIds: string[]): Observable<Order> {
        const combineOrderRequestBody: CombineOrdersRequest = {
            delivery,
            uuid: orderIds,
        };

        return this.apiService.post<BaseApiResponse<Order>>('order/merge-delivery', combineOrderRequestBody)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => this.updateStore(order)),
            );
    }

    /**
     * Получение доставки для списка sku
     *
     * @param orderId - id заказа
     * @param address - адрес доставки одной строкой
     * @param skuIds - список sku id
     */
    public getAddressDeliveryIntervalsBySku(
        orderId: string,
        address: string,
        skuIds: string[],
    ): Observable<OrderDeliveryInterval[]> {
        return this.apiService.post<BaseApiResponse<OrderDeliveryInterval[]>>(
            `order/${orderId}/sku-delivery`,
            { address, skuIds }
        ).pipe(map(CcApiHelper.toResponseData));
    }

    /**
     * Отмена заказа
     */
    public cancelOrder(orderId: string, reason: number, comment?: string): Observable<Order> {
        const cancelReq: OrderCancelReq = {
            reason,
            operatorComment: comment
        };

        return this.apiService.post<BaseApiResponse<Order>>(`order/${orderId}/cancel`, cancelReq)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => this.updateStore(order)),
            );
    }

    /**
     * Список причин отмены заказа
     */
    public getOrderCancelActualReasons(): Observable<OrderCancelSuggest[]> {
        return this.apiService.get<BaseApiResponse<OrderCancelReason[]>>('order/reject-list/actual')
            .pipe(
                map(CcApiHelper.toResponseData),
                map((reasons: OrderCancelReason[]) => (reasons || [])
                    .map((reason: OrderCancelReason) => ({
                        reason,
                        title: ORDER_CANCEL_REASON_TITLES[reason],
                    })),
                ),
            );
    }

    /**
     * Получение списка актуальных причин для удаления строки заказа
     */
    public getOrderLineRejectionReasons(): Observable<OrderLineRejection.Reason[]> {
        return this.apiService.get<BaseApiResponse<OrderLineRejection.Reason[]>>('order-line/reject-list/actual')
            .pipe(map(CcApiHelper.toResponseData));
    }

    private skuIdsToExtIds(skuIds: number[], product: Product): string[] {
        return (skuIds || [])
            .map((skuId: number) =>
                (product?.skuList || []).find((skuItem: SkuItem) => skuItem.id === skuId)?.extId
            )
            .filter(Boolean)
            .map((extId: number | string) => `${extId}`);
    }

    private updateStore(order: Order): void {
        if (!order) {
            return;
        }

        this.ordersStore.upsert(order.uuid, order);
        this.ordersStore.setLoading(false);
    }

    /**
     * Добавление подарочной упаковки в заказ
     * @param uuid - id заказа
     * @param items - массив uuid строк заказа, которые необходимо упаковать в подарочную упаковку
     */
    public addGiftPackage(uuid: string, items: string[]): Observable<Order> {
        this.orderService.setLoading(true);
        return this.apiService.post<BaseApiResponse<Order>>(`order/${uuid}/pack`, { items })
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => this.updateStore(order)),
            );
    }

    /**
     * Удаление подарочной упаковки из заказа
     * @param uuid - id заказа
     * @param packUuid - uuid упаковки, которую необходимо удалить
     */
    public removeGiftPackage(uuid: string, packUuid: string): Observable<Order> {
        this.orderService.setLoading(true);
        return this.apiService.post<BaseApiResponse<Order>>(`order/${uuid}/pack/${packUuid}/reject`, {})
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((order: Order) => this.updateStore(order)),
            );
    }

}
