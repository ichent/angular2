import { Injectable } from '@angular/core';
import { OrdersStore } from './orders.store';
import { Order } from './interfaces/order.interface';
import { RelativeOrder } from './interfaces/relative-order.interface';
import { OrdersQuery } from './orders.query';
import { DeliveryPlanService } from '../delivery-plan/delivery-plan.service';

@Injectable({
    providedIn: 'root',
})
export class OrderService {

    constructor(
        private ordersStore: OrdersStore,
        private ordersQuery: OrdersQuery,
        private deliveryPlanService: DeliveryPlanService,
    ) {}

    public setActiveOrder(orderId: string): void {
        this.ordersStore.setActive(orderId);
        this.deliveryPlanService.setDeliveryCity(this.ordersQuery.getActive()?.delivery?.address?.address);
    }

    public upsertOrderToStore(order: Order): void {
        this.ordersStore.upsert(order.uuid, order);
    }

    public updateRelativeOrders(relativeOrders: RelativeOrder[]): void {
        this.ordersStore.update({relativeOrders});
    }

    public setLoading(loading: boolean): void {
        this.ordersStore.setLoading(loading);
    }

}
