import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { OrdersState, OrdersStore } from './orders.store';
import { Observable } from 'rxjs';
import { RelativeOrder } from './interfaces/relative-order.interface';
import { OrderStatusHelper } from '../../helpers/order-status.helper';
import { OrderActionId } from '../../constants/order/order-action-id.enum';
import { OrderAction } from '../../interfaces/order/order-action.interface';
import { OrderStatus } from '../../constants/order/order-status.enum';
import { map } from 'rxjs/operators';
import { Order } from './interfaces/order.interface';
import { ContextQuery } from '../context/context.query';
import { SkuQuantity } from '../../interfaces/list-product/list-sku-quantity.interface';
import { SkuQuantityHelper } from '../../helpers/sku-quantity.helper';

@Injectable({
    providedIn: 'root',
})
export class OrdersQuery extends QueryEntity<OrdersState> {

    constructor(
        protected store: OrdersStore,
        private contextQuery: ContextQuery,
    ) {
        super(store);
    }

    /**
     * Другие заказы клиента
     */
    public selectRelativeOrders(): Observable<RelativeOrder[]> {
        return this.select('relativeOrders');
    }

    /**
     * Получить Id клиента заказа
     */
    public getOrderClientDr(orderId: string): string {
        return this.getEntity(orderId)?.client?.id || null;
    }

    /**
     * Доступно ли действие в этом статусе
     */
    public getIsActionAvailable(orderId: string, actionId: OrderActionId): boolean {
        return OrderStatusHelper.isActionAvailable(this.getOrderStatus(orderId), actionId, this.contextQuery.getOrderPageContext());
    }

    public selectIsActionAvailable(orderId: string, actionId: OrderActionId): Observable<boolean> {
        return this.selectOrderStatus(orderId)
            .pipe(
                map((status: OrderStatus) =>
                    OrderStatusHelper.isActionAvailable(status, actionId, this.contextQuery.getOrderPageContext())
                ),
            );
    }

    /**
     * Доступны ли какие-либо действия из списка в этом статусе
     */
    public getIsSomeActionsAvailable(orderId: string, actionIds: OrderActionId[]): boolean {
        return (actionIds || []).some((actionId: OrderActionId) =>
            OrderStatusHelper.isActionAvailable(this.getOrderStatus(orderId), actionId, this.contextQuery.getOrderPageContext())
        );
    }

    /**
     * Потенциально доступные действия для заказа
     *
     * Если по техническим ограничениям действите на данный момент не поддерживается,
     * флаг isSupported в действии будет проставлен в false
     */
    public getAllActions(orderId: string): OrderAction[] {
        return OrderStatusHelper.getStatusActions(this.getOrderStatus(orderId));
    }

    /**
     * Доступные, на данный момент, действия для заказа
     */
    public getAllAvailableActions(orderId: string): OrderAction[] {
        return this.getAllActions(orderId).filter((action: OrderAction) => action.isSupported);
    }

    /**
     * Статус заказа
     */
    public getOrderStatus(orderId: string): OrderStatus {
        return this.getEntity(orderId)?.status || null;
    }

    public selectOrderStatus(orderId: string): Observable<OrderStatus> {
        return this.selectEntity(orderId).pipe(map((order: Order) => this.getOrderStatus(order?.uuid)));
    }

    /**
     * Количество товаров в активном заказе
     */
    public selectActiveOrderLinesCount(): Observable<number> {
        return this.selectActive()
            .pipe(
                map((state: Order) => state.lines?.length || 0)
            );
    }

    /**
     * Количество выбранных sku для товара в текущем списке
     * @param productId - id товара в каталоге NP (ТОЦ)
     */
    public selectActiveOrderSkuQuantity(productId: number): Observable<SkuQuantity> {
        return this.selectActive()
            .pipe(
                map(SkuQuantityHelper.fromOrder),
            );
    }

}
