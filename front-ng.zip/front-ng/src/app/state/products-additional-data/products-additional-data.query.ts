import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { ProductsAdditionalDataStore, ProductsAdditionalDataState } from './products-additional-data.store';

@Injectable({
    providedIn: 'root'
})
export class ProductsAdditionalDataQuery extends QueryEntity<ProductsAdditionalDataState> {

    constructor(
        protected store: ProductsAdditionalDataStore,
    ) {
        super(store);
    }

}
