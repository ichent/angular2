import { Injectable } from '@angular/core';
import { NpApiService } from '../../services/api/np-api.service';
import { Observable } from 'rxjs';
import { ProductAdditionalData } from './product-additional-data.interface';
import { map, tap } from 'rxjs/operators';
import { ProductsAdditionalDataStore } from './products-additional-data.store';
import { FullProductApi } from './interfaces/full-product-api.interface';
import { TransformHelper } from '../../helpers/transform.helper';
import {
    FULL_PRODUCT_TO_PRODUCT,
    FULL_PRODUCT_TO_PRODUCT_ADDITIONAL_DATA,
} from './transform-schemes/full-product-transform-schemas.constant';
import { Product } from '../products/product.interface';
import { ProductsStore } from '../products/products.store';
import { HttpParams } from '@angular/common/http';

@Injectable({
    providedIn: 'root',
})
export class ProductAdditionalDataApiService {

    constructor(
        private npApiService: NpApiService,
        private productsAdditionalDataStore: ProductsAdditionalDataStore,
        private productsStore: ProductsStore,
    ) {}

    public getProductAdditionalData(id: number): Observable<ProductAdditionalData> {
        const httpParams = new HttpParams({ fromObject: { checkAccess: '1' }});

        return this.npApiService.get<FullProductApi>(`catalog/item/${id}`, { params: httpParams })
            .pipe(
                tap((fullProduct: FullProductApi) => {
                    const product: Product = TransformHelper.to(fullProduct, FULL_PRODUCT_TO_PRODUCT);

                    if (product && product.id) {
                        this.productsStore.upsert(product.id, product);
                    }
                }),
                map(this.toAdditionalData),
                tap((productAdditionalData: ProductAdditionalData) => {
                    this.productsAdditionalDataStore.upsert(productAdditionalData.id, productAdditionalData)
                }),
            );
    }

    private toAdditionalData(fullProduct: FullProductApi): ProductAdditionalData {
        return TransformHelper.to(fullProduct, FULL_PRODUCT_TO_PRODUCT_ADDITIONAL_DATA);
    }

}
