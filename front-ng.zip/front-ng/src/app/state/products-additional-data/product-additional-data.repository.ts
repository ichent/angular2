import { Injectable } from '@angular/core';
import { ProductsAdditionalDataQuery } from './products-additional-data.query';
import { ProductAdditionalDataApiService } from './product-additional-data-api.service';
import { BehaviorSubject, EMPTY, Observable } from 'rxjs';
import { ProductAdditionalData } from './product-additional-data.interface';
import { finalize, map, switchMap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root',
})
export class ProductAdditionalDataRepository {

    private loadingIdsSubject$ = new BehaviorSubject<number[]>([]);

    constructor(
        private productsAdditionalDataQuery: ProductsAdditionalDataQuery,
        private productAdditionalDataApiService: ProductAdditionalDataApiService,
    ) {}

    public selectProductAdditionalData(id: number, force = false): Observable<ProductAdditionalData> {
        if (!id) {
            return EMPTY;
        }

        if (!force && this.productsAdditionalDataQuery.hasEntity(id)) {
            return this.productsAdditionalDataQuery.selectEntity(id);
        }

        if (this.getIsLoading(id)) {
            return this.productsAdditionalDataQuery.selectEntity(id);
        }

        this.addToLoading(id);

        return this.productAdditionalDataApiService.getProductAdditionalData(id)
            .pipe(
                finalize(() => this.removeFromLoading(id)),
                switchMap(() => this.productsAdditionalDataQuery.selectEntity(id)),
            );
    }

    public selectIsLoading(id: number): Observable<boolean> {
        return this.loadingIdsSubject$
            .pipe(
                map((ids: number[]) => ids.includes(id)),
            );
    }

    public getIsLoading(id: number): boolean {
        return this.loadingIdsSubject$.value.includes(id);
    }

    private addToLoading(id: number): void {
        this.loadingIdsSubject$.next(Array.from(new Set([ ...this.loadingIdsSubject$.value, id ])));
    }

    private removeFromLoading(id: number): void {
        const newLoadingIds: number[] = [ ...this.loadingIdsSubject$.value ]
            .filter((loadingId: number) => loadingId !== id);
        this.loadingIdsSubject$.next(newLoadingIds);
    }
}
