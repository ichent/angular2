import { ItemByThisModel, Look } from '../../interfaces/catalog.interface';

export interface ProductAdditionalData {
    id: number;

    // Товары разных цветов
    allItemsByThisModel: ItemByThisModel[];

    // Описание
    builtCountry: string;
    codeVnd: string;
    composition: string;
    designCountry: string;
    descriptionTech: string;
    descriptionLit: string;
    extId: string;

    // Дизайнерские луки с товаром
    looks: Look[];
}
