import { Injectable } from '@angular/core';
import { ProductAdditionalData } from './product-additional-data.interface';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';

export interface ProductsAdditionalDataState extends EntityState<ProductAdditionalData> {}

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'products-additional-data',
})
export class ProductsAdditionalDataStore extends EntityStore<ProductsAdditionalDataState> {

    constructor() {
        super();
    }

}

