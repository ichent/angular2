import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { BonusCard } from "./interfaces/bonus-card.interface";

@Injectable({
    providedIn: 'root',
})
export class BonusCardMockApiService {

    public mockBonusCard(orderId: string): Observable<BonusCard[]> {
        return of([
                {
                    loyaltyCard: '1234456778900123',
                    balance: '2503',
                    cardType: 'orange',
                    cardHolderName: 'Иванов Андрей Дмитриевич',
                    cardHolderPhone: '79998887733',
                },
                {
                    loyaltyCard: '1234456778900121',
                    balance: '2501',
                    cardType: 'black',
                    cardHolderName: 'Иванов Андрей Дмитриевич',
                    cardHolderPhone: '79998887733',
                },
                {
                    loyaltyCard: '1234456778900122',
                    balance: '2500',
                    cardType: 'white',
                    cardHolderName: 'Иванов Андрей Дмитриевич',
                    cardHolderPhone: '79998887733',
                },
            ])
                .pipe(delay(1500));
    }

}
