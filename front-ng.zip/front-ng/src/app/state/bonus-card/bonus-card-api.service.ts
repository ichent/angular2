import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';
import { ApiService } from '../../services/api/api.service';
import { BonusCard } from "./interfaces/bonus-card.interface";
import { BonusCardService } from "./bonus-card.service";
import { BonusCardMockApiService } from "./bonus-card-mock-api.service";
import { OrderClient } from "../orders/interfaces/order-client.interface";

@Injectable({
    providedIn: 'root',
})
export class BonusCardApiService {

    constructor(
        private apiService: ApiService,
        private bonusCardService: BonusCardService,
        private bonusCardMockApiService: BonusCardMockApiService,

    ) {}

    /**
     * Получить бонусные карты клиента по заказу
     */
    public getBonusCards(orderId: string, client: OrderClient): Observable<BonusCard[]> {
        this.bonusCardService.setBonusCardsLoading(true);

        return this.searchBonusCards(orderId, client)
            .pipe(
                tap((bonusCards: BonusCard[]) => {
                    this.bonusCardService.setBonusCardsToStore(bonusCards);
                    bonusCards && bonusCards.length
                        ? this.bonusCardService.setActiveBonusCard(bonusCards[0].loyaltyCard)
                        : this.bonusCardService.removeActiveBonusCard();
                }),
                finalize(() => this.bonusCardService.setBonusCardsLoading(false)),
            )
    }

    /**
     * Поиск бонусных карт
     */
    public searchBonusCards(orderId: string, client: Partial<OrderClient>): Observable<BonusCard[]> {
        return this.bonusCardMockApiService.mockBonusCard(orderId);
    }

}
