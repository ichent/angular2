import { Injectable } from '@angular/core';
import { ActiveState, EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { BonusCard } from "./interfaces/bonus-card.interface";

export interface BonusCardState extends EntityState<BonusCard, string>, ActiveState {
}

const initialState: BonusCardState = {
    active: null,
};

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'bonus-card',
    idKey: 'loyaltyCard'
})
export class BonusCardStore extends EntityStore<BonusCardState> {

    constructor() {
        super(initialState);
    }

}
