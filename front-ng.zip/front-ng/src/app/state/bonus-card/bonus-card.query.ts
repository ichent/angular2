import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { BonusCardStore } from './bonus-card.store';
import { Observable } from 'rxjs';
import { BonusCardState } from "./bonus-card.store";
import { BonusCard } from "./interfaces/bonus-card.interface";
import { filter, map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root',
})
export class BonusCardQuery extends QueryEntity<BonusCardState> {

    constructor(
        protected store: BonusCardStore,
    ) {
        super(store);
    }

    public getBonusCardIds(): string[] {
        return this.getAll()
            .map((bonusCard: BonusCard) => bonusCard.loyaltyCard);
    }

    public selectActiveBonusCard(): Observable<BonusCard> {
        return this.selectActive();
    }

    public selectActiveBonusCardBalance(): Observable<string> {
        return this.selectActive()
            .pipe(
                filter(Boolean),
                map((bonusCard: BonusCard) => bonusCard.balance),
            );
    }

}
