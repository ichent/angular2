import { Injectable } from '@angular/core';
import { BonusCardStore } from './bonus-card.store';
import { BonusCard } from "./interfaces/bonus-card.interface";

@Injectable({
    providedIn: 'root',
})
export class BonusCardService {

    constructor(
        private bonusCardStore: BonusCardStore,
    ) {}

    public setBonusCardsLoading(isLoading: boolean): void {
        this.bonusCardStore.setLoading(isLoading);
    }

    public setActiveBonusCard(id: string): void {
        this.bonusCardStore.setActive(id);
    }

    public removeActiveBonusCard(): void {
        this.bonusCardStore.setActive(null);
    }

    public setBonusCardsToStore(bonusCards: BonusCard[]): void {
        this.bonusCardStore.set(bonusCards);
    }

}
