import { Injectable } from '@angular/core';
import { EntityUIQuery, QueryEntity } from '@datorama/akita';
import { ProductListState, ProductListStore, ProductListUIState } from './product-list.store';
import { combineLatest, Observable } from 'rxjs';
import { distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { ProductListHelper } from '../../helpers/product-list.helper';
import { ListItem, ListTypeCounter, ProductList } from './product-list.interface';
import { isEqual as _isEqual } from 'lodash';
import { ProductSkuQuantity, SkuQuantity } from '../../interfaces/list-product/list-sku-quantity.interface';
import { SkuStocksQuery } from '../sku-stocks/sku-stocks.query';
import { ListType } from '../../pages/lists/list-type.enum';
import { queryCypressBinding } from '../e2e-store';
import { SkuQuantityHelper } from '../../helpers/sku-quantity.helper';

@Injectable({
    providedIn: 'root',
})
export class ProductListQuery extends QueryEntity<ProductListState> {
    public ui: EntityUIQuery<ProductListUIState>;

    constructor(
        protected store: ProductListStore,
        private skuStocksQuery: SkuStocksQuery,
    ) {
        super(store);
        this.createUIQuery();
        queryCypressBinding(this);
    }

    public selectListItem(listId: number, productHash: string): Observable<ListItem> {
        return this.selectEntity(listId)
            .pipe(map((productList: ProductList) => ProductListHelper.toListItem(productList, productHash)));
    }

    public getListItem(listId: number, productHash: string): ListItem {
        return ProductListHelper.toListItem(this.getEntity(listId), productHash);
    }

    public selectListItemSkuSizeId(listId: number, productHash: string): Observable<number> {
        return this.selectListItem(listId, productHash)
            .pipe(
                map((listItem: ListItem) => listItem && listItem.skuId),
                distinctUntilChanged(_isEqual),
            );
    }

    public selectProductListTitle(listId: number): Observable<string> {
        return this.selectEntity(listId).pipe(map(ProductListHelper.getProductListTitle));
    }

    /**
     * Количество доступных для выбора sku для товара для текущего списка
     * @param productId
     */
    public selectCurrentListProductAvailableSkuQuantity(productId: number): Observable<SkuQuantity> {
        return combineLatest([
            this.skuStocksQuery.selectProductSkuQuantity(productId),
            this.selectCurrentListProductSkuQuantity(productId),
        ])
            .pipe(map(([stocksSkuQuantity, selectedSkuQuantity]: SkuQuantity[]) =>
                this.calculateAvailableSkuQuantities(stocksSkuQuantity, selectedSkuQuantity))
            );
    }

    /**
     * Количество выбранных sku для товара в текущем списке
     * @param productId
     */
    public selectCurrentListProductSkuQuantity(productId: number): Observable<SkuQuantity> {
        return this.selectActiveId()
            .pipe(
                distinctUntilChanged(),
                switchMap((listId: number) => this.selectListProductSkuQuantity(listId, productId)),
            );
    }

    public selectListProductSkuQuantity(listId: number, productId: number): Observable<SkuQuantity> {
        return this.selectListSkuQuantity(listId)
            .pipe(map((listSkuQuantity: ProductSkuQuantity) => listSkuQuantity && listSkuQuantity.get(productId) || null));
    }

    public selectListSkuQuantity(listId: number): Observable<ProductSkuQuantity> {
        return this.selectEntity(listId).pipe(map(SkuQuantityHelper.fromProductListToProductSkuQuantity));
    }

    public selectActiveHashes(): Observable<string[]> {
        return this.select('activeHashes');
    }

    public getIsDraft(listId: number): boolean {
        const list: ProductList = this.getEntity(listId);
        return list && list.status === ListType.Draft;
    }

    public getIsSent(listId: number): boolean {
        const list: ProductList = this.getEntity(listId);
        return list && list.status === ListType.Sent;
    }

    private calculateAvailableSkuQuantities(stocks: SkuQuantity, selected: SkuQuantity): SkuQuantity {
        const result: SkuQuantity = new Map(stocks);

        if (selected && selected.size) {
            selected.forEach((quantity, skuId) => {
                result.set(skuId, stocks.get(skuId) - quantity);
            });
        }

        return result;
    }

    public getListItemsHashes(listId: number): string[] {
        const productList: ProductList = this.getEntity(listId);
        if (!productList) {
            return [];
        }

        return Object.keys(productList.items || []);
    }

    public getRecentlyEditedIds(): number[] {
        return this.mapToRecentlyEditedIds(this.ui.getAll());
    }

    public selectRecentlyEditedIds(): Observable<number[]> {
        return this.ui.selectAll()
            .pipe(
                map((listsState: ProductListUIState[]) => this.mapToRecentlyEditedIds(listsState)),
            );
    }

    public selectRecentlyEditedListsCounter(isLook: boolean): Observable<ListTypeCounter> {
        return this.selectRecentlyEditedLists()
            .pipe(
                map((lists: ProductList[]) =>
                    lists.reduce((counter: ListTypeCounter, list: ProductList) => {
                        if (list.isLook === isLook) {
                            counter[list.status]
                                ? counter[list.status]++
                                : counter[list.status] = 1;
                        }

                        return counter;
                    }, {})
                )
            );
    }

    public selectRecentlyEditedListIdsByType(type: ListType, isLook: boolean): Observable<number[]> {
        return this.selectRecentlyEditedLists()
            .pipe(
                map((lists: ProductList[]) => lists
                    .filter((list: ProductList) => list.status === type && list.isLook === isLook)
                    .map((list: ProductList) => list.id)
                ),
            );
    }

    public selectActiveListProductsCount(): Observable<number> {
        return this.selectActive()
            .pipe(
                map(ProductListHelper.toProductIds),
                map((ids: number[]) => (ids || []).length),
            );
    }

    private selectRecentlyEditedLists(): Observable<ProductList[]> {
        return this.selectRecentlyEditedIds()
            .pipe(
                switchMap((ids: number[]) => this.selectMany(ids)),
            );
    }

    private mapToRecentlyEditedIds(listsState: ProductListUIState[]): number[] {
        return listsState.flatMap((listUI: ProductListUIState) => listUI.recentlyEdited ? [listUI.id] : []);
    }

}
