import { Injectable } from '@angular/core';
import { ApiService } from '../../services/api/api.service';
import { Observable, throwError } from 'rxjs';
import { ListItem, ProductList, ProductListApi, ProductListPage, ReplaceListItem } from './product-list.interface';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { ProductListCreateLinkRequest, ProductListSaveRequest } from '../../interfaces/product-list.interface';
import { ListType } from '../../pages/lists/list-type.enum';
import { ProductListStore } from './product-list.store';
import { CcApiResponse } from '../../interfaces/cc-api-response.interface';
import { HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Params } from '@angular/router';
import { CcApiHelper } from '../../helpers/cc-api.helper';
import { ProductListHelper } from '../../helpers/product-list.helper';
import { Aura } from '../../helpers/aura.helper';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { NotificationService } from '../../services/notification.service';
import { ProductListQuery } from './product-list.query';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { PageLists } from '../../constants/routes/page.enum';
import { UiMathHelper } from '../../ui/helpers/ui-math.helper';
import { LookListProductsQuery } from '../look-list-products/look-list-products.query';
import { DEFAULT_FRAME_RATIO } from '../../pages/look/constants/look-edit-page.constant';

@Injectable({
    providedIn: 'root',
})
export class ProductListApiService {

    private baseUrl = 'product-lists';

    constructor(
        private apiService: ApiService,
        private productListStore: ProductListStore,
        private notificationService: NotificationService,
        private productListQuery: ProductListQuery,
        private lookListProductsQuery: LookListProductsQuery,
    ) {}

    public getProductListById(productListId: number | string): Observable<ProductList> {
        return this.apiService.get<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${productListId}`)
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    public addProductToList(listId: number, items: Partial<ListItem>[], silent: boolean = false): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(
            `${this.baseUrl}/add-item-to-list/bulk`,
            Aura.camelToSnake({ listId, items }),
        )
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
                tap(
                    (productList: ProductList) => {
                        if (!silent) {
                            this.notificationService.pushNotifications([{
                                title: 'Успешно добавлено',
                                type: UiNotificationType.Success,
                            }]);

                            if (!this.productListQuery.hasActive()) {
                                this.productListStore.setActive(productList.id);
                            }
                        }
                    },
                    () => {
                        if (!silent) {
                            this.notificationService.pushNotifications([{
                                title: 'Ошибка добавления',
                                type: UiNotificationType.Error,
                            }]);
                        }
                    }
                )
            );
    }

    public removeProductFromList(listId: number, productHash: string): Observable<ProductList> {
        return this.apiService.delete<object>(`${this.baseUrl}/${listId}/${productHash}`)
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
                tap(
                    () => this.notificationService.pushNotifications([{
                        title: 'Успешно удалено',
                        type: UiNotificationType.Success,
                    }]),
                    () => this.notificationService.pushNotifications([{
                        title: 'Ошибка удаления',
                        type: UiNotificationType.Error,
                    }]),
                )
            );
    }

    public changeProductInList(listId: number, productHash: string, listItem: ListItem): Observable<ProductList> {
        const url: string = `${this.baseUrl}/${listId}/${productHash}/change-item`;

        return this.apiService.post<CcApiResponse<ProductListApi>>(url, Aura.camelToSnake(listItem))
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
                catchError((errorResponse: HttpErrorResponse) => {
                    this.notificationService.pushNotifications([
                        {
                            type: UiNotificationType.Error,
                            title: 'Ошибка сохранения выбранного размера',
                            timeoutClose: TimeoutNotificationConstant.fast,
                        },
                    ]);

                    return throwError(errorResponse);
                }),
            );
    }

    public replaceProductsInList(listId: number, items: ReplaceListItem[], withoutStoreUpdate = false): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(
            `${this.baseUrl}/${listId}/replace-items`,
            Aura.camelToSnake({ items: this.mapToImagesParams(items) }),
        )
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => {
                    if (!withoutStoreUpdate) {
                        this.upsertProductListToStore(productList);
                    }
                }),
            );
    }

    private mapToImagesParams(items: ReplaceListItem[]): ReplaceListItem[] {
        return items.map((item: ReplaceListItem) => {
            const imageRatio = this.lookListProductsQuery.getListProductImageRatio(item.uuid);

            return UiMathHelper.transformPosition(DEFAULT_FRAME_RATIO, imageRatio, item);
        });
    }

    public saveProductList(
        listId: number,
        data: ProductListSaveRequest,
    ): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${listId}/save`, data)
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    public saveProductListAs(
        listId: number,
        typeList: ListType.Public | ListType.Private,
        data: ProductListSaveRequest,
    ): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${listId}/save-as-${typeList}`, data)
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    public copyProductListAs(
        listId: number,
        typeList: ListType.Public | ListType.Private,
        data: Partial<ProductListSaveRequest>,
    ): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${listId}/copy-as-${typeList}`, data)
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    public removeProductList(id: number): Observable<object> {
        return this.apiService.delete<object>(`${this.baseUrl}/${id}`)
            .pipe(
                tap(() => this.productListStore.remove(id)),
                tap(
                    () => {
                        this.notificationService.pushNotifications([{
                            title: 'Список удалён',
                            type: UiNotificationType.Success,
                        }]);
                    },
                    () => {
                        this.notificationService.pushNotifications([{
                            title: 'Ошибка удаления списка',
                            type: UiNotificationType.Error,
                        }]);
                    },
                ),
            );
    }

    public markAsSent(listId: number, linkParams: ProductListCreateLinkRequest): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${listId}/mark-as-sent`, Aura.camelToSnake(linkParams))
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    // TODO заменить на copyProductListAs (clone). Узнать насчет нотификаций
    public copyAsPrivate(listId: number): Observable<ProductList> {
        return this.copyProductListAs(listId, ListType.Private, {})
            .pipe(
                tap(
                    () => {
                        this.notificationService.pushNotifications([{
                            title: 'Успешно скопирован в личные',
                            type: UiNotificationType.Success,
                        }]);
                    },
                    () => {
                        this.notificationService.pushNotifications([{
                            title: 'Ошибка копирования списка',
                            type: UiNotificationType.Error,
                        }]);
                    },
                ),
            );
    }

    // TODO заменить на использование saveProductListAs
    public saveAsPublic(listId: number, list: ProductList): Observable<ProductList> {
        const params: Params = {
            title: list.listInfo.title || 'Сохранен',
            description: list.description || 'Без описания'
        };
        return this.apiService.post<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${listId}/save-as-public`, params)
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    public copyAsLook(listId: number): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(`${this.baseUrl}/${listId}/copy-as-look`, {})
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => this.upsertProductListToStore(productList)),
            );
    }

    public getListsPage(listType: PageLists, listStatus: ListType, params: HttpParams): Observable<ProductListPage> {
        const url: string = `${this.baseUrl}/${listType === PageLists.Looks ? 'looks/' : ''}${listStatus}`;

        return this.apiService.get(url, {params})
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toProductListPage),
                tap((productListPage: ProductListPage) => {
                    if (productListPage && productListPage.items) {
                        const items: ProductList[] = listType === PageLists.Looks
                            ? productListPage.items.map((list: ProductList) => this.mapToFrameParams(list))
                            : productListPage.items;

                        this.productListStore.add(items);
                    }
                }),
            );
    }

    private mapToFrameParams(list: ProductList): ProductList {
        return {
            ...list,
            items: Object.keys(list.items).reduce((items, hash) => {
                const item = list.items[hash];
                const imageRatio = item.width / item.height;

                items[hash] = UiMathHelper.transformPosition(DEFAULT_FRAME_RATIO, imageRatio, item, false);

                return items;
            }, {}),
        };
    }

    public partialCopy(listId: number, items: string[], withoutStoreUpdate: boolean = false): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(
            `${this.baseUrl}/${listId}/copy-batch`,
            Aura.camelToSnake({ items }),
        )
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => {
                    if (!withoutStoreUpdate) {
                        this.upsertProductListToStore(productList);
                    }
                }),
            );
    }

    public batchRemove(listId: number, items: string[], withoutStoreUpdate: boolean = false): Observable<ProductList> {
        return this.apiService.post<CcApiResponse<ProductListApi>>(
            `${this.baseUrl}/${listId}/remove-items`,
            Aura.camelToSnake({ items }),
        )
            .pipe(
                map(CcApiHelper.toResponseData),
                map(ProductListHelper.toList),
                tap((productList: ProductList) => {
                    if (!withoutStoreUpdate) {
                        this.upsertProductListToStore(productList);
                    }
                }),
            );
    }

    private upsertProductListToStore(productList: ProductList): void {
        if (!(productList && productList.id)) {
            return;
        }

        this.productListStore.upsert(productList.id, productList.isLook
            ? this.mapToFrameParams(productList)
            : productList
        );
    }

}
