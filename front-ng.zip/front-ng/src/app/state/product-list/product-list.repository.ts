import { Injectable } from '@angular/core';
import { ProductListQuery } from './product-list.query';
import { ProductListApiService } from './product-list-api.service';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { finalize, map, switchMap, switchMapTo } from 'rxjs/operators';
import { ProductList } from './product-list.interface';
import { Product } from '../products/product.interface';
import { ProductListHelper } from '../../helpers/product-list.helper';
import { ProductsRepository } from '../products/products.repository';
import { ListProductHelper } from '../../helpers/list-product.helper';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { uniq as _uniq } from 'lodash';

/**
 * Сервис отвечает за предоставление данных из разных источников (локального хранилища или api);
 *
 * Если есть данные в сторе, то данные берутся из неё.
 * Если нет - запрашиваются из API (внутри API сервиса - сохраняются в стору), а затем возвращаются из сторы.
 *
 * Процессы агрегированния данных в этом сервисе довольно ресурсоёмкие,
 * поэтому в случае нескольких подписок, необходимо кешировать ответ
 * pipe(shareReplay(1))
 *
 */
@Injectable({
    providedIn: 'root',
})
export class ProductListRepository {

    private loadingProductListsIdsSubject$ = new BehaviorSubject([]);

    public get loadingProductListsIds(): number[] {
        return this.loadingProductListsIdsSubject$.value;
    }

    constructor(
        private productListQuery: ProductListQuery,
        private productListApiService: ProductListApiService,
        private productsRepository: ProductsRepository,
    ) {}

    /**
     * Запросить список
     * @param listId
     */
    public selectProductList(listId: number): Observable<ProductList> {
        if (!listId) {
            return of(null);
        }

        if (this.isListLoading(listId) || this.productListQuery.hasEntity(listId)) {
            return this.productListQuery.selectEntity(listId);
        }

        this.addToLoadingList(listId);

        return this.productListApiService.getProductListById(listId)
            .pipe(
                finalize(() => this.removeFromLoadingList(listId)),
                switchMapTo(this.productListQuery.selectEntity(listId)),
            );
    }

    /**
     * Запросить товары в списке
     * @param listId
     */
    public selectListProducts(listId: number): Observable<ListProduct[]> {
        return this.selectProductList(listId)
            .pipe(
                switchMap((productList: ProductList) =>
                    this.productsRepository.selectProducts(ProductListHelper.toProductUniqueIds(productList))
                        .pipe(
                            map((products: Product[]) =>
                                ListProductHelper.toProductInList(productList, products)
                            ),
                        )
                ),
            );
    }

    /**
     * Загружается ли список
     * @param listId
     */
    public selectIsListLoading(listId: number): Observable<boolean> {
        return this.loadingProductListsIdsSubject$
            .pipe(
                map((loadingIds: number[]) => loadingIds.includes(listId)),
            );
    }

    /**
     * Загружаются ли сейчас товары в списке (если список еще не загружен, то считатся что товары тоже загружаются)
     * @param listId
     */
    public selectIsListProductsLoading(listId: number): Observable<boolean> {
        return this.productListQuery.selectEntity(listId)
            .pipe(
                switchMap((productList: ProductList) => productList
                    ? this.productsRepository.selectIsProductsLoading(ProductListHelper.toProductUniqueIds(productList))
                    : of(true),
                ),
            );
    }

    private isListLoading(listId: number): boolean {
        return this.loadingProductListsIds.includes(listId);
    }

    private addToLoadingList(listId: number): void {
        this.loadingProductListsIdsSubject$.next(_uniq([...this.loadingProductListsIds, listId]));
    }

    private removeFromLoadingList(removingListId: number): void {
        const newLoadingIds: number[] = this.loadingProductListsIds.filter((id: number) => id !== removingListId);
        this.loadingProductListsIdsSubject$.next(newLoadingIds);
    }

}
