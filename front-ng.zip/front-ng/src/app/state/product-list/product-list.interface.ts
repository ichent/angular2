import { ListPage } from '../../interfaces/list-page.interface';
import { ActionItem } from '../../ui/interfaces/table.interface';
import { ActionListsType } from '../../pages/lists/constants/action-list-type.enum';
import { ListType } from '../../pages/lists/list-type.enum';

export interface ProductListPage extends ListPage<ProductList> {}

export interface ListActions {
    listId: number;
    actions: ActionItem<ActionListsType>[];
}

export interface ProductListTableRow extends ProductList {
    actions: ListActions;
    photos: string[];
}

export interface ProductList {
    createdBy: {
        user: ListAuthor,
        date: string,
    };
    sentBy: {
        user: ListAuthor,
        date: string,
    };
    updatedBy: {
        user: ListAuthor,
        date: string,
    };
    listInfo: {
        title: string,
        id: number,
    };
    background: string;
    clientDr: string;
    clientEmail: string;
    clientPhone: string;
    clientTitle: string;
    copyCount: number;
    createdFromList: number;
    description: string;
    id: number;
    imageHeight: number;
    imageUrl: string;
    imageWidth: number;
    isDraft: boolean;
    isLook: boolean;
    isPublic: boolean;
    isSynchronized: boolean;
    isVisibleToClient: boolean;
    items: ListItems;
    status: ListType;
    url?: string; // Есть только у списков со сгенерированной ссылкой
}

export interface ProductListApi {
    author: ListAuthor;
    background: string;
    clientDr: string;
    clientEmail: string;
    clientPhone: string;
    clientTitle: string;
    copyCount: number;
    createdAt: string; // "2019-04-26 14:25:41" TimeZone - Moscow
    createdBy: number;
    createdFromList: number;
    description: string;
    id: number;
    imageHeight: number;
    imageUrl: string;
    imageWidth: number;
    isDraft: boolean;
    isLook: boolean;
    isPublic: boolean;
    isSynchronized: boolean;
    isVisibleToClient: boolean;
    items: ListItems;
    sentAt: string;
    sentBy: ListAuthor;
    title: string;
    updatedAt: string; // "2019-04-26 14:25:41" TimeZone - Moscow
    updatedBy: ListAuthor;
    status: ListType;
}

export interface ProductListErrorApi {
    fields: string[];
}

export interface ListAuthor {
    id: number;
    lastName: string;
    firstName: string;
}

export interface ListItems {
    [hash: string]: ListItem;
}

export interface ListItem {
    angle: number;
    height: number;
    itemId: number;
    layer: number;
    left: number;
    modelId: number;
    scaleX: number;
    scaleY: number;
    skuId: number;
    src: string;
    top: number;
    visibility: boolean;
    width: number;
}

// При реплейсе товаров лука бекенд ожидает также получение uuid (можно смапить в ListProductHelper)
export interface ReplaceListItem extends ListItem {
    uuid: string; // равен hash в ListItems
}

export interface ListTypeCounter {
    [key: string]: number
}
