import { Injectable } from '@angular/core';
import { ProductListStore } from './product-list.store';

@Injectable({
    providedIn: 'root',
})
export class ProductListService {

    constructor(
        private productListStore: ProductListStore,
    ) {}

    public setCurrentProductList(productListId: number): void {
        this.productListStore.setActive(productListId);
    }

    public setActiveHashes(hashes: string[]): void {
        this.productListStore.update({ activeHashes: hashes });
    }

    public resetActiveHashes(): void {
        this.productListStore.update({ activeHashes: [] });
    }

    public setIsSaving(isSaving: boolean): void {
        this.productListStore.update({ isSaving });
    }

    public setRecentlyEditedList(lastEditedListId: number | null): void {
        this.productListStore.ui.update(lastEditedListId, { recentlyEdited: true });
    }

    public clearRecentlyEditedList(listIds: number | number[]): void {
        this.productListStore.ui.update(listIds, { recentlyEdited: false });
    }

}
