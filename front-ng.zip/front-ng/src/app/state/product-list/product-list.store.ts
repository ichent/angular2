import { Injectable } from '@angular/core';
import { ActiveState, EntityState, EntityStore, EntityUIStore, StoreConfig } from '@datorama/akita';
import { ProductList } from './product-list.interface';

export interface ProductListState extends EntityState<ProductList>, ActiveState {
    /** Текущий список */
    active: number;

    /** Выбранные товары в списке */
    activeHashes: string[];

    /** Происходит сохранение лука через сайднав */
    isSaving: boolean;
}

const initialState: ProductListState = {
    active: null,
    activeHashes: [],
    isSaving: false,
};

export interface ProductListUI {
    recentlyEdited: boolean; // Для выделения в интерфейсе недавно редактированного списка
}

export interface ProductListUIState extends EntityState<ProductListUI> {}

const initialUIState: ProductListUIState = { recentlyEdited: false };

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'product-list',
})
export class ProductListStore extends EntityStore<ProductListState> {
    public ui: EntityUIStore<ProductListUIState>;

    constructor() {
        super(initialState);
        this.createUIStore().setInitialEntityState(initialUIState);
    }

}
