import { Query } from '@datorama/akita';

/**
 * Проксирование стейта из Akita Query в Cypress
 */
export function queryCypressBinding(query: Query<any>) {
    if (!window || !query) {
        return;
    }

    // @ts-ignore
    if (window.Cypress) {
        // @ts-ignore
        query.select().subscribe(_ => window[query.store.storeName] = query.getValue());
    }
}
