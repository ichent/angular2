import { Injectable } from '@angular/core';
import { NpApiService } from '../../services/api/np-api.service';
import { Observable, of } from 'rxjs';
import { Product } from './product.interface';
import { ListPage } from '../../interfaces/list-page.interface';
import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Params } from '@angular/router';
import { map, switchMap, tap } from 'rxjs/operators';
import { FullResponse } from '../../services/api/base-api.service';
import { BrandsApiService } from '../../services/dictionaries/brands-api.service';
import { ProductsStore } from './products.store';
import { CategoriesApiService } from '../../services/dictionaries/categories-api.service';

@Injectable({
    providedIn: 'root',
})
export class ProductApiService {

    constructor(
        private npApiService: NpApiService,
        private brandsApiService: BrandsApiService,
        private categoryApiService: CategoriesApiService,
        private productsStore: ProductsStore,
    ) {}

    public getProductsByIds(productIds: number[]): Observable<ListPage<Product>> {
        if (!(productIds && productIds.length > 0)) {
            return of(null);
        }

        return this.getProducts({ id: productIds.join(',') });
    }

    public getProduct(productId: number): Observable<Product> {
        if (!productId) {
            return of(null);
        }

        return this.getProductsByIds([ productId ])
            .pipe(
                map((listProducts: ListPage<Product>) => listProducts?.items[0]),
            );
    }

    private getProductsStraight(params: Params): Observable<FullResponse<Product[]>> {
        const httpParams = new HttpParams({ fromObject: {...(params || {}), ...{ checkAccess: '1' }}});

        return this.npApiService.getFullResponse<Product[]>('v2/catalog/search', {
            params: httpParams,
            observe: 'response',
        });
    }

    public getProducts(params: Params): Observable<ListPage<Product>> {
        return this.getProductsStraight(params)
            .pipe(
                this.repeatIfRedirect(params),
                map(this.toProductsListPage),
                tap((listPage: ListPage<Product>) => this.productsStore.add(listPage.items)),
            );
    }

    /**
     * NP возвращает redirect в случае запроса некоторых категорий или брендов
     * @param params
     */
    private repeatIfRedirect(params: Params): (source: Observable<FullResponse<Product[]>>) => Observable<FullResponse<Product[]>> {
        return source => source.pipe(
            switchMap((res: FullResponse<Product[]>) => {
                const link = res.data['redirect'] as string;

                if (link) {
                    interface RedirectItem { id: number; slug: string; }

                    const replaceMap: Record<string, { key: string, dictionary: Observable<any> }> = {
                        brand: { key: 'brand', dictionary: this.brandsApiService.getBrands() },
                        catalog: { key: 'section', dictionary: this.categoryApiService.getCategories() },
                    };

                    const matchArray: RegExpMatchArray = link.match(/^.*\/(.+?)\/(.+?)(\.html|\/)$/);

                    const redirectSlug: string = matchArray[2] || '';
                    const { key, dictionary } = replaceMap[matchArray[1]];

                    return dictionary.pipe(
                        map((dictionary: RedirectItem[]) => dictionary.find((item: RedirectItem) => item.slug === redirectSlug)),
                        map((item: RedirectItem) => {
                            const { q, ...newParams }: Params = params;

                            if (key && item) {
                                newParams[key] = item.id && item.id.toString();
                            }

                            return newParams;
                        }),
                        switchMap((params: Params) => this.getProductsStraight(params)),
                    );
                }

                return of(res);
            }),
        );
    }

    private toProductsListPage(res: FullResponse<Product[]>): ListPage<Product> {
        const headers: HttpHeaders = res.response.headers;
        const page: number = +headers.get('X-Pagination-Current-Page');
        const perPage: number = +headers.get('X-Pagination-Per-Page');
        const total: number = +headers.get('X-Pagination-Total-Count');

        return {
            items: res.data,
            page: page,
            perPage: perPage,
            total: total,
            orderBy: null,
            orderDirection: null,
        };
    }

}
