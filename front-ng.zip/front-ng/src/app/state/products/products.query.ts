import { Inject, Injectable } from '@angular/core';
import { EntityUIQuery, Order, QueryEntity } from '@datorama/akita';
import { ProductsState, ProductsStore, ProductUI, ProductUIState } from './products.store';
import { Observable, of } from 'rxjs';
import { Product } from './product.interface';
import { distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { CategoriesQuery } from '../dictionaries/categories/categories.query';
import { UserService } from '../../services/user.service';
import { ENDPOINTS_TOKEN, EndpointsConfigInterface } from '../../config/endpoints';
import { ProductHelper } from '../../helpers/product.helper';
import { ContextQuery } from '../context/context.query';
import { BrandsQuery } from '../dictionaries/brands/brands.query';
import { Brand } from '../../interfaces/brand.interface';

@Injectable({
    providedIn: 'root',
})
export class ProductsQuery extends QueryEntity<ProductsState> {
    public ui: EntityUIQuery<ProductUIState>;

    constructor(
        protected store: ProductsStore,
        private contextQuery: ContextQuery,
        private categoriesQuery: CategoriesQuery,
        private userService: UserService,
        @Inject(ENDPOINTS_TOKEN)
        private endpointsConfig: EndpointsConfigInterface,
        private brandsQuery: BrandsQuery,
    ) {
        super(store);
        this.createUIQuery();
    }

    public selectIds(): Observable<number[]> {
        return this.selectAll()
            .pipe(map(ProductHelper.toProductIds));
    }

    public getIds(): number[] {
        return ProductHelper.toProductIds(this.getAll());
    }

    public selectProductsByIds(productIds: number[]): Observable<Product[]> {
        return this.selectAll()
            .pipe(
                map((products: Product[]) => ProductHelper.filterProductsByIds(products, productIds)),
            );
    }

    public hasProductInStore(productIds: number[]): boolean {
        if (!productIds || productIds.length === 0) {
            return false;
        }

        return ProductHelper.filterProductsByIds(this.getAll(), productIds).length === productIds.length;
    }

    public selectProductLink(productId: number): Observable<string> {
        return this.selectEntity(productId)
            .pipe(
                map((product: Product) => ProductHelper.getItemLink(
                    this.endpointsConfig.NP_URL,
                    product.slug,
                    this.userService.user,
                )),
            );
    }

    public selectBrandNameByProduct(productId: number): Observable<string> {
        return this.selectEntity(productId)
            .pipe(
                switchMap((product: Product) => {
                    if (!product) {
                        return of(null);
                    } else if (product.brandName) {
                        return of(product.brandName);
                    } else {
                        return this.brandsQuery.selectEntity(product.brandId)
                            .pipe(
                                map((brand: Brand) => brand && brand.title),
                            );
                    }
                }),
                distinctUntilChanged(),
            );
    }

    public getMostOldAddedProducts(limit: number): Product[] {
        return this.getAll({
            sortBy: 'addedInStoreAt',
            sortByOrder: Order.ASC,
            limitTo: limit,
        });
    }

    public selectIsProductUiError(productId: number): Observable<boolean> {
        return this.ui.selectEntity(productId)
            .pipe(
                map((entity: ProductUI) => entity && entity.error)
            );
    }

}
