import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { finalize, map, switchMap, switchMapTo } from 'rxjs/operators';
import { ProductApiService } from './product-api.service';
import { Product } from './product.interface';
import { ProductsQuery } from './products.query';
import { uniq as _uniq } from 'lodash';
import { ProductAdditionalDataApiService } from '../products-additional-data/product-additional-data-api.service';
import { ProductsAdditionalDataQuery } from '../products-additional-data/products-additional-data.query';

@Injectable({
    providedIn: 'root',
})
export class ProductsRepository {

    private loadingProductsIdsSubject$ = new BehaviorSubject([]);

    public get loadingProductIds(): number[] {
        return this.loadingProductsIdsSubject$.value;
    }

    constructor(
        private productsQuery: ProductsQuery,
        private productApiService: ProductApiService,
        private productsAdditionalDataQuery: ProductsAdditionalDataQuery,
        private productAdditionalDataApiService: ProductAdditionalDataApiService,
    ) {}

    /**
     * Запросить товары
     * @param productIds id товаров на основном сайте (aka ТОЦ)
     */
    public selectProducts(productIds: number[]): Observable<Product[]> {
        // У некоторых товаров вместо itemId может быть null
        productIds = productIds.filter(Boolean);

        if (!Array.isArray(productIds) || productIds.length === 0) {
            return of([]);
        }

        if (this.isEveryProductsLoading(productIds) || this.productsQuery.hasProductInStore(productIds)) {
            return this.productsQuery.selectProductsByIds(productIds);
        }

        const idsNotInStore: number[] = productIds.filter((id: number) => !this.productsQuery.getIds().includes(id));

        this.addToLoading(idsNotInStore);

        return this.productApiService.getProductsByIds(idsNotInStore)
            .pipe(
                finalize(() => this.removeFromLoading(idsNotInStore)),
                switchMapTo(this.productsQuery.selectProductsByIds(productIds)),
            );
    }

    /**
     * Запросить товар c доп информацией
     * @param productId
     */
    public requestFullProduct(productId: number): Observable<Product> {
        if (!productId) {
            return of(null);
        }

        if (this.productsQuery.hasEntity(productId) && this.productsAdditionalDataQuery.hasEntity(productId)) {
            return this.productsQuery.selectEntity(productId);
        }

        return this.productAdditionalDataApiService.getProductAdditionalData(productId)
            .pipe(
                switchMapTo(this.productsQuery.selectEntity(productId)),
            );
    }

    /**
     * Проверить загружаются ли товары
     * @param listId
     */
    public selectIsProductsLoading(productIds: number[]): Observable<boolean> {
        return this.productsQuery.selectProductsByIds(productIds)
            .pipe(
                switchMap((products: Product[]) => products && products.length === productIds.length
                    ? of(false)
                    : this.loadingProductsIdsSubject$
                        .pipe(
                            map((loadingIds: number[]) =>
                                productIds.some((loadingId: number) => loadingIds.includes(loadingId))
                            ),
                        )
                )
            );
    }

    private isEveryProductsLoading(productIds: number[]): boolean {
        return productIds.every((id: number) => this.loadingProductIds.includes(id));
    }

    private addToLoading(productIds: number[]): void {
        this.loadingProductsIdsSubject$.next(_uniq([...this.loadingProductIds, ...productIds]));
    }

    private removeFromLoading(productIds: number[]): void {
        const newLoadingIds: number[] = this.loadingProductIds.filter((id: number) => !productIds.includes(id));
        this.loadingProductsIdsSubject$.next(newLoadingIds);
    }

}
