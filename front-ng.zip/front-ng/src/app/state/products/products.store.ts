import { Injectable } from '@angular/core';
import { ActiveState, EntityState, EntityStore, EntityUIStore, StoreConfig } from '@datorama/akita';
import { Product, ProductInStore } from './product.interface';

export interface ProductUI {
    id: number;
    error: boolean;
}

export interface ProductsState extends EntityState<ProductInStore>, ActiveState {
    active: number;
}

export interface ProductUIState extends EntityState<ProductUI> {}

const initialState: ProductsState = {
    active: null,
};


const initialUIState: ProductUIState =  { error: false };

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'products',
})
export class ProductsStore extends EntityStore<ProductsState> {
    public ui: EntityUIStore<ProductUIState>;

    constructor() {
        super(initialState);
        this.createUIStore().setInitialEntityState(initialUIState);
    }

    akitaPreAddEntity(product: Product): ProductInStore {
        return {
            ...product,
            addedInStoreAt: Date.now(),
        };
    }

}
