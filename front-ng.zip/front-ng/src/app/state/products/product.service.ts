import { Injectable } from '@angular/core';
import { ProductsStore, ProductUI } from './products.store';
import { ProductsQuery } from './products.query';
import { Product } from './product.interface';
import {
    catchError,
    debounceTime,
    map,
    retry,
    shareReplay,
    switchMap,
    takeUntil,
    tap,
} from 'rxjs/operators';
import { SizeLabelCodes } from '../../constants/size-label-codes.constant';
import { Observable, of, Subject } from 'rxjs';
import { SizeService } from '../sku-sizes/size.service';
import { SkuStocksService } from '../sku-stocks/sku-stocks.service';
import { ProductHelper } from '../../helpers/product.helper';
import { EntityActions } from '@datorama/akita';
import { SelectedSizesStore } from '../selected-sizes/selected-sizes.store';
import { SelectedSizesQuery } from '../selected-sizes/selected-sizes.query';
import { SelectedSizesService } from '../selected-sizes/selected-sizes.service';
import { SizeSelectionContext } from '../../features/size/constants/size-selection-context.enum';

const MAX_PRODUCTS_IN_STORE = 250;

@Injectable({
    providedIn: 'root',
})
export class ProductService {

    private destroyed$ = new Subject();

    constructor(
        private productsStore: ProductsStore,
        private productsQuery: ProductsQuery,
        private selectedSizesStore: SelectedSizesStore,
        private selectedSizesQuery: SelectedSizesQuery,
        private sizeService: SizeService,
        private skuStocksService: SkuStocksService,
        private selectedSizesService: SelectedSizesService,
    ) {
        // Очистка сторы от старых товаров
        this.productsQuery.selectEntityAction(EntityActions.Add)
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((newProductIds: number[]) => {
                const removedProducts: Product[] = this.clearOldProductCache(MAX_PRODUCTS_IN_STORE, newProductIds);
                this.sizeService.removeSizesByProductIds(ProductHelper.toProductIds(removedProducts));
                this.skuStocksService.removeSkuStocksByProducts(removedProducts);
            });

        const newProducts$: Observable<Product[]> = this.productsQuery.selectAll()
            .pipe(
                // Дожидаемся удаления старых товаров из сторы
                debounceTime(0),
                shareReplay({ refCount: true, bufferSize: 1 }),
            );

        // Запрашиваем данные по размерам для новых товаров
        newProducts$
            .pipe(
                map(ProductHelper.toProductIds),
                switchMap((ids: number[]) => this.sizeService.getNewSizes(ids)
                    .pipe(
                        retry(1),
                        catchError(() => of([])),
                    ),
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe();

        // Запрашиваем данные по наличию для новых товаров
        newProducts$
            .pipe(
                tap((products: Product[]) => {
                    const productsWithNoSizes: Product[] = products.filter((product: Product) => {
                        return product.skuList.length === 1 && product.skuList[0].size.title === SizeLabelCodes.NoSize;
                    });

                    const contextsForNoSizePresets: SizeSelectionContext[] = [
                        SizeSelectionContext.ProductList,
                        SizeSelectionContext.Cart,
                        SizeSelectionContext.OrderEdit
                    ];

                    productsWithNoSizes.forEach((product: Product) => {
                        contextsForNoSizePresets.forEach((context: SizeSelectionContext) => {
                            this.selectedSizesService.setSelectedSizes(
                                product.id,
                                [ product.skuList[0].id ],
                                context,
                            );
                        });
                    });
                }),
                switchMap((products: Product[]) => this.skuStocksService.getSkuStocksByProducts(products)
                    .pipe(
                        retry(1),
                        catchError(() => of([])),
                    ),
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    public setActiveProduct(productId: number): void {
        this.productsStore.setActive(productId);
    }

    public setProductUIError(id: number | number[]): void {
        this.productsStore.ui.update(id, { error: true });
    }

    public resetProductUIError(id: number | number[]): void {
        this.productsStore.ui.update(id, { error: false });
    }

    public clearProductUIErrors(): void {
        const ids: number[] = this.productsQuery.ui
            .getAll({ filterBy: ((entity: ProductUI) => entity.error)})
            .map((entity: ProductUI) => entity.id);

        this.resetProductUIError(ids);
    }

    /**
     * Удаляет старые товары из сторы, возвращает удаленные товары
     *
     * @param maxProductsInStore - максимальное рекоммендованное количество товаров, которое должно храниться в сторе
     * @param exceptProductIds - товары, которые не нужно удалять
     */
    private clearOldProductCache(maxProductsInStore: number, exceptProductIds: number[] = []): Product[] {
        const productsForRemoving: Product[] = this.getOldProductsForRemoving(maxProductsInStore)
            .filter((oldProduct: Product) => !exceptProductIds.includes(oldProduct.id));

        if (productsForRemoving.length > 0) {
            this.productsStore.remove(ProductHelper.toProductIds(productsForRemoving));
        }

        return productsForRemoving;
    }

    private getOldProductsForRemoving(maxProductsInStore: number): Product[] {
        const total: number = this.productsQuery.getCount();
        return total > maxProductsInStore
            ? this.productsQuery.getMostOldAddedProducts(total / 2)
            : [];
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
