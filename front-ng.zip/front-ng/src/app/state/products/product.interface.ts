import { ColorConcrete, CatalogPhoto, CatalogTag } from '../../interfaces/catalog.interface';
import { GenderConstant } from '../../constants/gender.constant';
import { SkuItem } from '../../interfaces/sku.interface';
import { PHPBoolean } from '../../types/php-boolean.type';
import { ProductSelection } from '../../interfaces/product/product-selection.interface';

export interface Product {
    brandId: number;
    categoryId: number;
    colorConcrete: ColorConcrete;
    colorCode: string;
    extId: string;
    gender: GenderConstant;
    hasSizeTable?: boolean;
    id: number;
    modelId: number;
    photos: CatalogPhoto[];
    season: string;
    skuList: SkuItem[];
    slug: string;
    tags: CatalogTag[];
    title: string;
    isBuyable?: PHPBoolean;
    selections?: ProductSelection[];
    brandName?: string;
}

export interface ProductInStore extends Product {
    addedInStoreAt?: number;
}
