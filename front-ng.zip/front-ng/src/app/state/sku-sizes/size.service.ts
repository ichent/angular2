import { Injectable } from '@angular/core';
import { Observable, of as observableOf } from 'rxjs';
import { NpBackendApiService } from '../../services/api/np-backend-api.service';
import { map, tap } from 'rxjs/operators';
import { SizeSkuListItem, SkuSizeApi, SkuSizeDictionaryApi, SkuSizeItem } from '../../features/size/interfaces/sku-size.interface';
import { SkuSizesStore } from './sku-sizes.store';
import { SkuSizesQuery } from './sku-sizes.query';
import { SizeAttributes } from '../../features/size/interfaces/size-attributes.interface';
import { StoreHelper } from '../../helpers/store.helper';
import { StoreError } from '../../interfaces/store-error.interface';

@Injectable({
    providedIn: 'root',
})
export class SizeService {

    private baseUrl = 'catalog/sizes';

    constructor(
        private npBackendApi: NpBackendApiService,
        private skuSizesQuery: SkuSizesQuery,
        private skuSizesStore: SkuSizesStore,
    ) {}

    public getNewSizes(productIds: number[]): Observable<SkuSizeItem[]> {
        const idsInStore: number[] = this.skuSizesQuery.getIds();
        const newIds = StoreHelper.getIdsThatNotInStore(idsInStore, productIds);

        if (newIds.length === 0) {
            return observableOf([]);
        }

        return this.npBackendApi.post<SkuSizeDictionaryApi>(this.baseUrl, { data: newIds })
            .pipe(
                map((res: SkuSizeDictionaryApi) => this.mapSkuSizesDictionaryApiToSkuSizes(res)),
                tap(
                    (skuSizes: SkuSizeItem[]) => this.skuSizesStore.add(skuSizes),
                    (error: Error) => this.skuSizesStore.setError<StoreError>(error),
                ),
            );
    }

    public removeSizesByProductIds(productIds: number[]): void {
        this.skuSizesStore.remove(productIds);
    }

    private mapSkuSizesDictionaryApiToSkuSizes(skuSizesDictionaryApi: SkuSizeDictionaryApi): SkuSizeItem[] {
        const skuSizes = new Set<SkuSizeItem>();

        for (const key in skuSizesDictionaryApi) {
            if (skuSizesDictionaryApi.hasOwnProperty(key)) {
                const skuSizeItemApi: SkuSizeApi = skuSizesDictionaryApi[key];
                const skuSizeItem: Partial<SkuSizeItem> = {};

                if (skuSizeItemApi && skuSizeItemApi.skuList) {
                    skuSizeItem.skuList = skuSizeItemApi.skuList
                        .map((sizeSkuListItem: SizeSkuListItem) => {
                            sizeSkuListItem.sizeAttributes = this.cleanSizeAttributes(sizeSkuListItem.sizeAttributes);
                            return sizeSkuListItem;
                        })
                        .sort(this.sortByTitle);
                }

                skuSizes.add(Object.assign(skuSizeItem, { productId: Number(key) }) as SkuSizeItem);
            }
        }

        return Array.from(skuSizes);
    }

    private cleanSizeAttributes(sizeAttributes: SizeAttributes): SizeAttributes {
        if (!sizeAttributes) {
            return null;
        }

        const cleaned: Partial<SizeAttributes> = {};

        for (const key in sizeAttributes) {
            if (sizeAttributes[key] && sizeAttributes.hasOwnProperty(key)) {
                cleaned[key] = sizeAttributes[key].replace(/"|'|^\s+$/, '').trim();
            }
        }

        return cleaned as SizeAttributes;
    }

    private sortByTitle(prevSku: SizeSkuListItem, nextSku: SizeSkuListItem): 1 | -1 {
        return prevSku.sizeAttributes.russianSize >= nextSku.sizeAttributes.russianSize ? 1 : -1;
    }

}
