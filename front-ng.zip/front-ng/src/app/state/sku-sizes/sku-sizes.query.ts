import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { SkuSizesState, SkuSizesStore } from './sku-sizes.store';
import { SkuSizeItem } from '../../features/size/interfaces/sku-size.interface';

@Injectable({
    providedIn: 'root',
})
export class SkuSizesQuery extends QueryEntity<SkuSizesState> {

    constructor(
        protected store: SkuSizesStore,
    ) {
        super(store);
    }

    public getIds(): number[] {
        return this.getAll().map((skuSizeItem: SkuSizeItem) => skuSizeItem.productId);
    }

}
