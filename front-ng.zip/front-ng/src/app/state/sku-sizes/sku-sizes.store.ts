import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { SkuSizeItem } from '../../features/size/interfaces/sku-size.interface';

export interface SkuSizesState extends EntityState<SkuSizeItem> {

}

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'sku-sizes',
    idKey: 'productId',
})
export class SkuSizesStore extends EntityStore<SkuSizesState> {

    constructor() {
        super();
    }

}
