import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Size } from './size.model';

export interface SizesState extends EntityState<Size> {}

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'sizes',
})
export class SizesStore extends EntityStore<SizesState> {

    constructor() {
        super();
    }

}
