export interface Size {
    id: number;
    title: string;
    title_vnd: string;
    visible: number;
}
