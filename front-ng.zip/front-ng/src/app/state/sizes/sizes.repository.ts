import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { concatMapTo, map, switchMap } from 'rxjs/operators';
import { Size } from './size.model';
import { StoreHelper } from '../../helpers/store.helper';
import { SizesQuery } from './sizes.query';
import { SizesApiService } from './sizes-api.service';
import { SizesState } from './sizes.store';

@Injectable({
    providedIn: 'root',
})
export class SizesRepository {

    constructor(
        private sizesQuery: SizesQuery,
        private sizesApiService: SizesApiService,
    ) {}

    public selectSizes(ids: number[]): Observable<Size[]> {
        return this.sizesQuery.select((state: SizesState) => state.ids)
            .pipe(
                map((idsInStore: number[]) => StoreHelper.getIdsThatNotInStore(idsInStore, ids)),
                switchMap((ids: number[]) => ids.length ? this.sizesApiService.getSizes(ids) : of(null)),
                concatMapTo(this.sizesQuery.selectMany(ids)),
            );
    }
}
