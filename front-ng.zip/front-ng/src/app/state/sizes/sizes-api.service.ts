import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SizesStore } from './sizes.store';
import { Size } from './size.model';
import { HttpParams } from '@angular/common/http';
import { NpApiService } from '../../services/api/np-api.service';

@Injectable({
    providedIn: 'root',
})
export class SizesApiService {

    constructor (
        private sizesStore: SizesStore,
        private npApiService: NpApiService,
    ) {}

    public getSizes(ids: number[]): Observable<Size[]> {
        const httpParams = new HttpParams({ fromObject: { id: ids.toString() } });

        return this.npApiService.get<Size[]>('catalog/size', { params: httpParams })
            .pipe(tap((data: Size[]) => this.sizesStore.add(data)));
    }

}
