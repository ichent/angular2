import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { SizesState, SizesStore } from './sizes.store';

@Injectable({
    providedIn: 'root',
})
export class SizesQuery extends QueryEntity<SizesState> {

    constructor(
        protected store: SizesStore,
    ) {
        super(store);
    }
}
