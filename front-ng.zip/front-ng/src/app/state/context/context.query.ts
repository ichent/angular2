import { Injectable } from '@angular/core';
import { Query } from '@datorama/akita';
import { ContextState, ContextStore } from './context.store';
import { Observable, of } from 'rxjs';
import { distinctUntilChanged, map, switchMap, take, tap } from 'rxjs/operators';
import { SelectedSizesHelper } from '../../features/size/helpers/selected-sizes.helper';
import { SizeSelectionContext } from '../../features/size/constants/size-selection-context.enum';
import { Page } from '../../constants/routes/page.enum';
import { CartPageContext } from '../../interfaces/contexts/cart-page-contexts.interface';
import { OrderPageContext } from '../../interfaces/contexts/order-page-contexts.interface';
import { ProductPageContext } from '../../interfaces/contexts/product-page-contexts.interface';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';
import { PageWithContext } from '../../interfaces/contexts/page-contexts.interface';

@Injectable({
    providedIn: 'root',
})
export class ContextQuery extends Query<ContextState> {

    constructor(
        protected store: ContextStore,
    ) {
        super(store);
    }

    public getCurrentPage(): Page {
        return this.getValue().currentPage;
    }

    public selectCurrentPage(): Observable<Page> {
        return this.select(((store: ContextState) => store.currentPage));
    }

    public getCatalogPageContext(): CatalogPageContext {
        return this.getValue().pages[Page.Catalog];
    }

    public selectCatalogPageContext(): Observable<CatalogPageContext> {
        return this.select((store: ContextState) => store.pages[Page.Catalog]);
    }

    public getProductPageContext(): ProductPageContext {
        return this.getValue().pages[Page.Product];
    }

    public selectProductPageContext(): Observable<ProductPageContext> {
        return this.select((store: ContextState) => store.pages[Page.Product]);
    }

    public getCartPageContext(): CartPageContext {
        return this.getValue().pages[Page.Cart];
    }

    public selectCartPageContext(): Observable<CartPageContext> {
        return this.select((store: ContextState) => store.pages[Page.Cart]);
    }

    public getOrderPageContext(): OrderPageContext {
        return this.getValue().pages[Page.Order];
    }

    public selectOrderPageContext(): Observable<OrderPageContext> {
        return this.select((store: ContextState) => store.pages[Page.Order]);
    }

    public selectPageWithContext(): Observable<PageWithContext> {
        return this.selectCurrentPage()
            .pipe(
                switchMap((page: Page) => {
                    switch (page) {
                        case Page.Order:
                            return this.selectOrderPageContext()
                                .pipe(
                                    map((context: OrderPageContext) => ({
                                        resource: Page.Order,
                                        context: context,
                                    })),
                                );
                        case Page.Catalog:
                            return this.selectCatalogPageContext()
                                .pipe(
                                    map((context: CatalogPageContext) => ({
                                        resource: Page.Catalog,
                                        context: context,
                                    })),
                                );
                        case Page.Cart:
                            return this.selectCartPageContext()
                                .pipe(
                                    map((context: CartPageContext) => ({
                                        resource: Page.Cart,
                                        context: context,
                                    })),
                                );
                        case Page.Product:
                            return this.selectProductPageContext()
                                .pipe(
                                    map((context: ProductPageContext) => ({
                                        resource: Page.Product,
                                        context: context,
                                    })),
                                );
                        default:
                            return of(null);
                    }
                }),
            );
    }

    /**
     * Текущий контекст выбора размеров
     */
    public selectSizeSelectionContext(): Observable<SizeSelectionContext> {
        return this.selectPageWithContext()
            .pipe(
                map(() => this.getSizeSelectionContext()),
                distinctUntilChanged(),
            );
    }

    public getSizeSelectionContext(): SizeSelectionContext {
        const currentPage: Page = this.getCurrentPage();
        return SelectedSizesHelper.calculateSizeSelectionContext({
            resource: currentPage,
            context: this.getValue().pages[currentPage]
        } as PageWithContext);
    }

}
