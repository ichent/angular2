import { Injectable } from '@angular/core';
import { Store, StoreConfig } from '@datorama/akita';
import { Page } from '../../constants/routes/page.enum';
import { CartPageContext } from '../../interfaces/contexts/cart-page-contexts.interface';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';
import { ProductPageContext } from '../../interfaces/contexts/product-page-contexts.interface';
import { OrderPageContext } from '../../interfaces/contexts/order-page-contexts.interface';

export interface AllPagesContexts {
    [Page.Catalog]: CatalogPageContext;
    [Page.Product]: ProductPageContext;
    [Page.Cart]: CartPageContext;
    [Page.Order]: OrderPageContext;
    [Page.Dashboard]: null;
    [Page.Oauth]: null;
    [Page.Lists]: null;
    [Page.Look]: null;
    [Page.ProductList]: null;
    [Page.Orders]: null;
    [Page.Tasks]: null;
    [Page.Clients]: null;
    [Page.Consulting]: null;
    [Page.NotFound]: null;
}

export interface ContextState {
    pages: AllPagesContexts;
    currentPage: Page;
    // TODO Добавить контексты для сайднавов
    //  (в сайднавах, соотвественно, нужно будет использовать их контексты, а не контексты страниц)
}

const initialState: ContextState = {
    pages: {
        [Page.Catalog]: CatalogPageContext.List,
        [Page.Product]: ProductPageContext.List,
        [Page.Cart]: CartPageContext.Cart,
        [Page.Order]: OrderPageContext.View,
        [Page.Dashboard]: null,
        [Page.Oauth]: null,
        [Page.Lists]: null,
        [Page.Look]: null,
        [Page.ProductList]: null,
        [Page.Orders]: null,
        [Page.Tasks]: null,
        [Page.Clients]: null,
        [Page.Consulting]: null,
        [Page.NotFound]: null,
    },
    currentPage: Page.Catalog,
};

@Injectable({
    providedIn: 'root',
})

@StoreConfig({
    name: 'context',
})

export class ContextStore extends Store<ContextState> {

    constructor() {
        super(initialState);
    }

}
