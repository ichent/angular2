import { Injectable, OnDestroy } from '@angular/core';
import { ContextState, ContextStore } from './context.store';
import { ContextQuery } from './context.query';
import { OrdersStore } from '../orders/orders.store';
import { PageWithContext } from '../../interfaces/contexts/page-contexts.interface';
import { Observable, Subject } from 'rxjs';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { distinctUntilChanged, filter, map, startWith, takeUntil } from 'rxjs/operators';
import { RouterHelper } from '../../helpers/router.helper';
import { Page } from '../../constants/routes/page.enum';

@Injectable({
    providedIn: 'root',
})
export class ContextService implements OnDestroy {

    public navigationEnd$: Observable<NavigationEnd> = this.router.events
        .pipe(filter((event: RouterEvent) => event instanceof NavigationEnd)) as Observable<NavigationEnd>;

    private destroyed$ = new Subject();

    constructor(
        private contextQuery: ContextQuery,
        private contextStore: ContextStore,
        private ordersStore: OrdersStore,
        private router: Router,
    ) {
        this.navigationEnd$
            .pipe(
                map((event: NavigationEnd) => event.url),
                startWith(this.router.url),
                map(RouterHelper.getPageByUrl),
                distinctUntilChanged(),
                takeUntil(this.destroyed$),
            )
            .subscribe((currentPage: Page) => this.contextStore.update({ currentPage }));
    }

    public setPageContext(pageContext: PageWithContext): void {
        this.contextStore.update({
            pages: {
                ...this.contextQuery.getValue().pages,
                [pageContext.resource]: pageContext.context,
            }
        });
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
