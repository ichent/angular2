import { Injectable } from '@angular/core';
import { LooksCatalogStore } from './looks-catalog.store';
import { Product } from '../products/product.interface';

@Injectable({
    providedIn: 'root',
})
export class LooksCatalogService {

    constructor(
        private looksCatalogStore: LooksCatalogStore,
    ) {}

    public addToSelected(product: Product): void {
        this.looksCatalogStore.addToSelected(product);
    }

    public removeFromSelected(product: Product): void {
        this.looksCatalogStore.removeFromSelected(product);
    }

    public removeAllFromSelected(): void {
        this.looksCatalogStore.removeAllFromSelected();
    }

    public resetLookCatalogStore(): void {
        this.looksCatalogStore.resetState();
        this.looksCatalogStore.resetEntities();
    }

}
