import { Size } from '../sizes/size.model';
import { Color } from '../dictionaries/colors/color.model';
import { UiRangeInput } from '../../ui/modules/range-input/range-input.namespace';

export namespace LooksCatalog {

    export interface CategoryInfo {
        sizes: Size[];
        colors: Color[];
    }

    export interface Filters {
        query: string;
        category: string;
        brand: number[];
        size: number[];
        color: number[];
        price: UiRangeInput.ValueType;
    }

    export interface Product {
        id: number;
    }
}
