import { Product } from '../products/product.interface';
import { LooksCatalog } from './looks-catalog.namespace';

export namespace LooksCatalogProductHelper {

    export function toLooksCatalogProducts(products: Product[]): LooksCatalog.Product[] {
        return (products || []).map((product: Product) => ({ id: product.id }));
    }

    export function toLooksCatalogProductIds(looksCatalogProducts: LooksCatalog.Product[]): number[] {
        return (looksCatalogProducts || []).map((looksCatalogProduct: LooksCatalog.Product) =>
            looksCatalogProduct.id
        );
    }
}
