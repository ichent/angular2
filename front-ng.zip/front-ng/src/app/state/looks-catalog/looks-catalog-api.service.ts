import { Injectable } from '@angular/core';
import { Observable, of, zip } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { Product } from '../products/product.interface';
import { Params } from '@angular/router';
import { LooksCatalogState, LooksCatalogStore } from './looks-catalog.store';
import { ProductApiService } from '../products/product-api.service';
import { ListPage } from '../../interfaces/list-page.interface';
import { LooksCatalogQuery } from './looks-catalog.query';
import { HttpParams } from '@angular/common/http';
import { NpApiService } from '../../services/api/np-api.service';
import { SizesRepository } from '../sizes/sizes.repository';
import { Size } from '../sizes/size.model';
import { ColorsQuery } from '../dictionaries/colors/colors.query';
import { Color } from '../dictionaries/colors/color.model';
import { LooksCatalog } from './looks-catalog.namespace';
import { Filters } from '../../interfaces/filters.interface';

@Injectable({
    providedIn: 'root',
})
export class LooksCatalogApiService {

    constructor(
        private productApiService: ProductApiService,
        private looksCatalogStore: LooksCatalogStore,
        private looksCatalogQuery: LooksCatalogQuery,
        private npApiService: NpApiService,
        private sizesRepository: SizesRepository,
        private colorsQuery: ColorsQuery,
    ) {}

    private getFiltersInfo(sectionIds: string): Observable<any> {
        const httpParams = new HttpParams({ fromObject: { section: sectionIds, checkAccess: '1' }});

        return this.npApiService.get('v2/catalog/search/filter', { params: httpParams });
    }

    public getCategoryInfo(sectionIds: string): Observable<LooksCatalog.CategoryInfo> {
        if (!sectionIds) {
            return of(null);
        }

        return this.getFiltersInfo(sectionIds).pipe(
            switchMap((filtersInfo: Filters.Info) => {
                const sizesIds: number[]  = filtersInfo.size.items.map((item: Filters.Filter.Item) => item.value);
                const colorsIds: number[] = filtersInfo.color.items.map((item: Filters.Filter.Item) => item.value);

                return zip(
                    this.sizesRepository.selectSizes(sizesIds)
                        .pipe(map((sizes: Size[]) => sizes.sort((a: Size, b: Size) => Number(a.title) - Number(b.title)))),
                    this.colorsQuery.selectMany(colorsIds)
                ).pipe(
                    map(([sizes, colors]: [Size[], Color[]]) => ({ sizes, colors }))
                );
            }),
        );
    }

    public addMoreProducts(): Observable<Product[]> {
        return this.productApiService.getProducts(this.getParamsForNewPage())
            .pipe(
                tap((list: ListPage<Product>) => this.looksCatalogStore.addNewPage(list)),
                map((list: ListPage<Product>) => list.items),
            );
    }

    public getProducts(): Observable<Product[]> {
        this.looksCatalogStore.update((state: LooksCatalogState) => ({
            paginator: {
                ...state.paginator,
                currentPage: 0,
            }
        }));
        this.looksCatalogStore.set([]);
        return this.addMoreProducts();
    }

    private getParamsForNewPage(): Params {
        const state: LooksCatalogState = this.looksCatalogQuery.getValue();

        const params: Params = {
            'per-page': state.paginator.perPage,
            'page': state.paginator.currentPage + 1,
        };

        const setParam = (name: string, value: string | number[]) => {
            if (value) {
                params[name] = value;
            }
        };

        const filters: LooksCatalog.Filters = state.filters;
        setParam('sort', state.sort);

        if (filters) {
            setParam('q', filters.query);
            setParam('section', filters.category);
            setParam('section', filters.category);
            setParam('brand', filters.brand);
            setParam('size', filters.size);
            setParam('color', filters.color);

            if (filters.price) {
                setParam('prfr', filters.price.from);
                setParam('prto', filters.price.to);
            }
        }

        return params;
    }
}
