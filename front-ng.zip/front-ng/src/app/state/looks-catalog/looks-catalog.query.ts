import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { LooksCatalogState, LooksCatalogStore } from './looks-catalog.store';
import { Observable } from 'rxjs';
import { Product } from '../products/product.interface';
import { Paginator } from '../../ui/interfaces/paginator.interface';
import { map, switchMap } from 'rxjs/operators';
import { ProductsQuery } from '../products/products.query';
import { LooksCatalogProductHelper } from './looks-catalog-product.helper';

@Injectable({
    providedIn: 'root',
})
export class LooksCatalogQuery extends QueryEntity<LooksCatalogState> {

    constructor(
        protected store: LooksCatalogStore,
        private productsQuery: ProductsQuery,
    ) {
        super(store);
    }

    public selectProducts(): Observable<Product[]> {
        return this.selectAll()
            .pipe(
                map(LooksCatalogProductHelper.toLooksCatalogProductIds),
                switchMap((productIds: number[]) => this.productsQuery.selectProductsByIds(productIds)),
            );
    }

    public getSelectedAsArray(): Product[] {
        return Object.values(this.getValue().selected);
    }

    public selectTotal(): Observable<number> {
        return this.select((state: LooksCatalogState) => state.total);
    }

    public selectSelected(): Observable<Record<number, Product>> {
        return this.select((state: LooksCatalogState) => state.selected);
    }

    public getPaginator(): Paginator {
        return this.getValue().paginator;
    }

}
