import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Product } from '../products/product.interface';
import { Paginator } from '../../ui/interfaces/paginator.interface';
import { ListPage } from '../../interfaces/list-page.interface';
import { LooksCatalog } from './looks-catalog.namespace';
import { LooksCatalogProductHelper } from './looks-catalog-product.helper';

export interface LooksCatalogState extends EntityState<LooksCatalog.Product> {
    filters: LooksCatalog.Filters;
    paginator: Paginator;
    sort: string;
    total: number;
    selected: Record<number, Product>;
}

const initialState = (): LooksCatalogState => ({
    filters: {
        query: null,
        category: null,
        brand: null,
        size: null,
        color: null,
        price: null,
    },
    paginator: {
        currentPage: 0,
        perPage: 50,
        totalCount: null,
    },
    sort: null,
    total: null,
    selected: {},
});

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'looks-catalog',
})
export class LooksCatalogStore extends EntityStore<LooksCatalogState> {

    constructor() {
        super(initialState());
    }

    public addNewPage(list: ListPage<Product>): void {
        this.add(LooksCatalogProductHelper.toLooksCatalogProducts(list.items));

        if (!list.page || list.page === 1) {
            this.update({
                total: list.total,
                paginator: {
                    currentPage: list.page,
                    perPage: 50,
                    totalCount: Math.ceil(list.total / list.perPage),
                },
            });
        } else if (list.page > 1) {
            this.update((state: LooksCatalogState) => ({
                paginator: {
                    ...state.paginator,
                    currentPage: list.page,
                },
            }));
        }
    }

    public addToSelected(product: Product): void {
        this.update((state: LooksCatalogState) => ({
            selected: {...state.selected, [product.id]: product}
        }));
    }

    public removeFromSelected(product: Product): void {
        this.update((state: LooksCatalogState) => {
            const newSelected = { ...state.selected };
            delete newSelected[product.id];

            return { selected: newSelected };
        });
    }

    public removeAllFromSelected(): void {
        this.update({ selected: {} });
    }

    public resetState(): void {
        this.update(initialState());
    }

    public resetEntities(): void {
        this.set([]);
    }

}
