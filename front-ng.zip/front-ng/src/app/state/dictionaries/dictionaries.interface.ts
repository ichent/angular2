export interface BaseDictionary {
    id: number;
    title: string;
}
