import { Injectable } from '@angular/core';
import { CrmApiService } from '../../services/api/crm-api.service';
import { BehaviorSubject, Observable } from 'rxjs';
import {
    CustomersIncomingParams,
    CustomersSearchParams,
    MainCustomerRequestParams,
    PreferredCommunicationAddressItemRequest,
    PreferredCommunicationAddressItemResponse,
} from '../../features/client-widget/interfaces/client-widget.interface';
import { BaseApiResponse } from '../../services/api/base-api.service';
import {
    ClientWidgetCustomerItem,
    ClientWidgetCustomers,
} from './customers/customers.model';
import { map, tap } from 'rxjs/operators';
import { ClientWidgetCustomersStore } from './customers/customers.store';
import { CcApiHelper } from '../../helpers/cc-api.helper';
import {
    ClientWidgetCreateEditCustomerParams,
} from '../../sidenavs/client-widget-create-edit-sidenav/client-widget-create-edit-sidenav.interface';
import { LogService } from '../../services/log/log.service';

@Injectable({
    providedIn: 'root',
})
export class ClientApiService {

    private communicationAddressesCustomerSubject$: BehaviorSubject<ClientWidgetCustomerItem> = new BehaviorSubject(null);
    public communicationAddressesCustomer$: Observable<ClientWidgetCustomerItem> =
        this.communicationAddressesCustomerSubject$.asObservable();

    constructor(
        private crmApiService: CrmApiService,
        private clientWidgetCustomersStore: ClientWidgetCustomersStore,
        private logService: LogService,
    ) {}

    public get communicationAddressesCustomer(): ClientWidgetCustomerItem {
        return this.communicationAddressesCustomerSubject$.value;
    }

    public set communicationAddressesCustomer(customer: ClientWidgetCustomerItem) {
        this.communicationAddressesCustomerSubject$.next(customer);
    }

    public findCustomersByIncomingParams(incomingParams: CustomersIncomingParams, initial = false): Observable<ClientWidgetCustomers> {
        return this.crmApiService
            .post<BaseApiResponse<ClientWidgetCustomers>>('search/by-communication', incomingParams)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((customersData: ClientWidgetCustomers) => this.setCustomers(customersData)),
                tap(() => {
                    if (initial) {
                        this.logService.handleStart();
                    }
                }),
            );
    }

    public findCustomersBySearchParams(searchParams: CustomersSearchParams): Observable<ClientWidgetCustomers> {
        return this.crmApiService
            .post<BaseApiResponse<ClientWidgetCustomers>>('search/by-client-property', searchParams)
            .pipe(
                map(CcApiHelper.toResponseData),
            );
    }

    public addCommunicationAddress(customerRequestParams: MainCustomerRequestParams): Observable<ClientWidgetCustomerItem> {
        const url = `client/add-communication-address/${customerRequestParams.cmiId}`;

        return this.crmApiService
            .post<BaseApiResponse<ClientWidgetCustomerItem>>(url, customerRequestParams)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((customer: ClientWidgetCustomerItem) => this.logService.handleContactChange(customer)),
            );
    }

    public syncCommunicationAddresses(
        cmiId: string,
        items: PreferredCommunicationAddressItemRequest[],
    ): Observable<PreferredCommunicationAddressItemResponse[]> {
        return this.crmApiService
            .post<BaseApiResponse<PreferredCommunicationAddressItemResponse[]>>(`client/sync-communications/${cmiId}`, { data: items })
            .pipe(
                map(CcApiHelper.toResponseData),
            );
    }

    public updateCustomer(cmiId: string, params: ClientWidgetCreateEditCustomerParams): Observable<ClientWidgetCustomerItem> {
        return this.crmApiService.patch<BaseApiResponse<ClientWidgetCustomerItem>>(`client/update/${cmiId}`, params)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((customer: ClientWidgetCustomerItem) => this.logService.handleContactEdition(customer)),
            );
    }

    public createCustomer(params: ClientWidgetCreateEditCustomerParams): Observable<ClientWidgetCustomerItem> {
        return this.crmApiService.post<BaseApiResponse<ClientWidgetCustomerItem>>('client/create', params)
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((customer: ClientWidgetCustomerItem) => this.logService.handleContactEdition(customer)),
            );
    }

    public setCustomers(customers: ClientWidgetCustomers): void {
        const { items, total, page, perPage }: ClientWidgetCustomers = customers;

        this.clientWidgetCustomersStore.update({
            items,
            total,
            page,
            perPage,
        });
    }
}
