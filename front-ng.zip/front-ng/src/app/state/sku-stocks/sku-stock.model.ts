export interface Stock {
    code: string;
    count: number;
    id: number;
    title: string;
}

export interface SkuStock {
    id: number; // SkuId
    stock: Stock[];
}
