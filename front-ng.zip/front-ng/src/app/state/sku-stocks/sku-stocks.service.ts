import { Injectable } from '@angular/core';
import { EMPTY, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { NpBackendApiService } from '../../services/api/np-backend-api.service';
import { SkuStocksStore } from './sku-stocks.store';
import { SkuStock } from './sku-stock.model';
import { Product } from '../products/product.interface';
import { SkuItem } from '../../interfaces/sku.interface';
import { ProductHelper } from '../../helpers/product.helper';

@Injectable({
    providedIn: 'root',
})
export class SkuStocksService {
    constructor (
        private npBackendApiService: NpBackendApiService,
        private skuStocksStore: SkuStocksStore,
    ) {}

    public getSkuStocksByProducts(products: Product[]): Observable<SkuStock[]> {
        if (!(Array.isArray(products) && products.length > 0)) {
            return EMPTY;
        }

        const skuIds: number[] = ProductHelper.toSkuIds(products);

        if (skuIds.length === 0) {
            return EMPTY;
        }

        return this.getSkuStocks(skuIds);
    }

    public getSkuStocks(skuIds: number[]): Observable<SkuStock[]> {
        if (!(Array.isArray(skuIds) && skuIds.length > 0)) {
            return EMPTY;
        }
        this.skuStocksStore.setLoading(true);

        return this.npBackendApiService.post<SkuStock[]>('stock/by-sku', { data: skuIds })
            .pipe(
                tap((data: SkuStock[]) => this.skuStocksStore.add(data)),
                tap(() => this.skuStocksStore.setLoading(false)),
            );
    }

    public removeSkuStocksByProducts(products: Product[]): void {
        const skuStockIds: number[] = ProductHelper.toSkuIds(products);
        this.skuStocksStore.remove(skuStockIds);
    }

}
