import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { SkuStock } from './sku-stock.model';

export interface SkuStocksState extends EntityState<SkuStock> {

}

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'sku-stocks',
})
export class SkuStocksStore extends EntityStore<SkuStocksState> {

    constructor() {
        super();
    }

}
