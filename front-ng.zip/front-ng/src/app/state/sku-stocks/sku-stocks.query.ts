import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { SkuStocksState, SkuStocksStore } from './sku-stocks.store';
import { Observable, of } from 'rxjs';
import { SkuStock } from './sku-stock.model';
import { Product } from '../products/product.interface';
import { SkuItem } from '../../interfaces/sku.interface';
import { SkuQuantity } from '../../interfaces/list-product/list-sku-quantity.interface';
import { filter, map, switchMap } from 'rxjs/operators';
import { SkuStockHelper } from '../../helpers/sku-stock.helper';
import { ProductsQuery } from '../products/products.query';
import { SkuQuantityHelper } from '../../helpers/sku-quantity.helper';

@Injectable({
    providedIn: 'root',
})
export class SkuStocksQuery extends QueryEntity<SkuStocksState> {

    constructor(
        protected store: SkuStocksStore,
        private productsQuery: ProductsQuery,
    ) {
        super(store);
    }

    public selectProductSkuQuantity(productId: number): Observable<SkuQuantity> {
        return this.selectProductSkuStocks(productId).pipe(map(SkuQuantityHelper.fromSkuStocks));
    }

    public selectProductSkuStocks(productId: number): Observable<SkuStock[]> {
        return this.productsQuery.selectEntity(productId)
            .pipe(
                map(this.toSkuIds),
                switchMap((skuIds: number[]) => this.selectSkuStocks(skuIds))
            );
    }

    public selectSkuStocks(skuIds: number[]): Observable<SkuStock[]> {
        if (!(Array.isArray(skuIds) && skuIds.length > 0)) {
            return of([]);
        }

        return this.selectAll({
            filterBy: (skuStock: SkuStock) => skuIds.includes(skuStock.id),
        });
    }

    public selectProductHasStocks(productId: number): Observable<boolean> {
        return this.selectProductSkuStocks(productId)
            .pipe(
                filter((skuStocks: SkuStock[]) => !!skuStocks.length),
                map((skuStocks: SkuStock[]) => skuStocks.some((skuStock: SkuStock) => skuStock.stock.length)),
            );
    }

    private toSkuIds(product: Product): number[] {
        return product && product.skuList
            ? product.skuList.map((skuItem: SkuItem) => skuItem.id)
            : [];
    }

}
