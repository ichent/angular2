import { Injectable } from '@angular/core';
import { EntityStore, StoreConfig } from '@datorama/akita';
import { Paginator } from '../../ui/interfaces/paginator.interface';
import { CatalogFilters } from './catalog-filters.interface';

export interface CatalogFiltersState {
    useFilters: boolean;
    filters: CatalogFilters;
    paginator: Paginator;
    total: number;
    sort: string;
}

export const initialFiltersState = () => ({
    brands: [],
    designCountry: [],
    vendorCountry: [],
    categories: [],
    colors: [],
    seasons: [], // тоже лейблы на сервере
    properties: [], // тоже лейблы на сервере
    availableInStocks: [],
    labels: [],
    fromPrice: '',
    toPrice: '',
    query: '',
});

export const initialPaginatorState = () => ({
    currentPage: 1,
    perPage: 30,
    totalCount: null, // используется лишь для совместимости
});

const initialState = () => ({
    useFilters: true,
    filters: initialFiltersState(),
    paginator: initialPaginatorState(),
    total: null,
    sort: '',
});

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'catalog-filters',
})
export class CatalogFiltersStore extends EntityStore<CatalogFiltersState> {

    constructor() {
        super(initialState());
    }

}
