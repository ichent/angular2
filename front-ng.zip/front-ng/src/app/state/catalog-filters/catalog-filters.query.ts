import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { CatalogFiltersState, CatalogFiltersStore } from './catalog-filters.store';
import { map } from 'rxjs/operators';
import { Paginator } from '../../ui/interfaces/paginator.interface';
import { Observable } from 'rxjs';
import { CatalogFilters } from './catalog-filters.interface';

@Injectable({
    providedIn: 'root',
})
export class CatalogFiltersQuery extends QueryEntity<CatalogFiltersState> {

    constructor(
        protected store: CatalogFiltersStore,
    ) {
        super(store);
    }

    public selectChangeByUser(): Observable<Partial<CatalogFiltersState>> {
        return this.select(['useFilters', 'filters', 'paginator', 'sort']);
    }

    public selectTopFilters(): Observable<Partial<CatalogFiltersState>> {
        return this.select(['filters', 'sort']);
    }

    public selectFilters(): Observable<CatalogFilters> {
        return this.select((state: CatalogFiltersState) => state.filters);
    }

    public getPaginator(): Paginator {
        return { ...this.getValue().paginator, totalCount: this.getValue().total };
    }

}
