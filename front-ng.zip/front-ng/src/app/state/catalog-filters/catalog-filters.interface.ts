export interface CatalogFilters {
    categories: number[];
    brands: number[];
    designCountry: number[];
    vendorCountry: number[];
    colors: number[];
    seasons: string[];
    properties: any;
    availableInStocks: number[];
    labels: string[];
    fromPrice: string;
    toPrice: string;
    query: string;
}
