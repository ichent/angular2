import { Injectable } from '@angular/core';
import { CatalogFiltersState, CatalogFiltersStore } from './catalog-filters.store';
import { CatalogFilters } from './catalog-filters.interface';
import { Paginator } from '../../ui/interfaces/paginator.interface';

@Injectable({
    providedIn: 'root',
})
export class CatalogFiltersService {

    constructor(
        private catalogFilterStore: CatalogFiltersStore,
    ) {}

    public setState({ filters, paginator, useFilters, total }: Partial<CatalogFiltersState>): void {
        this.catalogFilterStore.update((state: CatalogFiltersState) => ({
            filters: { ...state.filters, ...(filters || {}) },
            paginator: { ...state.paginator, ...(paginator || {}) },
            total: typeof total === 'number' ? total : state.total,
            useFilters: typeof useFilters === 'boolean' ? useFilters : state.useFilters,
        }));
    }

    public patchFilters(filters: Partial<CatalogFilters>): void {
        this.catalogFilterStore.update((state: CatalogFiltersState) => ({
            filters: { ...state.filters, ...filters },
            paginator: { ...state.paginator, currentPage: 1 },
        }));
    }

    public patchPaginator({ currentPage, perPage }: Paginator): void {
        this.catalogFilterStore.update((state: CatalogFiltersState) => ({
            paginator: { ...state.paginator, currentPage, perPage },
        }));
    }

    public setTotal(total: number): void {
        this.catalogFilterStore.update({ total });
    }

    public setSort(sort: string): void {
        this.catalogFilterStore.update({ sort });
    }

    public setUseFilters(useFilters: boolean): void {
        this.catalogFilterStore.update((state: CatalogFiltersState) => ({
            useFilters,
            paginator: { ...state.paginator, currentPage: 1 },
        }));
    }

}
