import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { DeliveryPlan } from '../../interfaces/delivery/delivery-plan.interface';
import { DEFAULT_DELIVERY_CITY } from './constants/delivery-city.constant';

export interface DeliveryPlanState extends EntityState<DeliveryPlan, number> {
    deliveryCity: string,
}

const initialState: DeliveryPlanState = {
    deliveryCity: DEFAULT_DELIVERY_CITY,
};

@Injectable({
    providedIn: 'root',
})
@StoreConfig({
    name: 'delivery-plans',
    idKey: 'productId',
})
export class DeliveryPlanStore extends EntityStore<DeliveryPlanState> {

    constructor() {
        super(initialState);
    }

    public setDefaultDeliveryCity(): void {
        this.update(initialState)
    }

}
