import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { Observable } from 'rxjs';
import { DeliveryPlanState, DeliveryPlanStore } from './delivery-plan.store';
import { DeliveryPlan } from '../../interfaces/delivery/delivery-plan.interface';
import { filter, map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root',
})
export class DeliveryPlanQuery extends QueryEntity<DeliveryPlanState> {

    private intervalSlice(deliveryPlan: Observable<DeliveryPlan>, limit: number): Observable<DeliveryPlan> {
        return deliveryPlan
            .pipe(
                filter(Boolean),
                map((deliveryPlan: DeliveryPlan) => {
                    if (!limit || deliveryPlan.error) {
                        return deliveryPlan;
                    }

                    const plan: DeliveryPlan = {...deliveryPlan};

                    plan.agents = deliveryPlan.agents.map(deliveryAgent => {
                        const agent = {...deliveryAgent};
                        agent.intervals = deliveryAgent.intervals.slice(0, limit);
                        return agent;
                    });

                    return plan;
                })
            );
    }

    constructor(
        protected store: DeliveryPlanStore,
    ) {
        super(store);
    }

    public selectDeliveryAgents(productId: number, slice: number = 0): Observable<DeliveryPlan> {
        return this.intervalSlice(this.selectEntity(productId), slice);
    }

    public getDeliveryCity(): string {
        return this.getValue().deliveryCity;
    }

}
