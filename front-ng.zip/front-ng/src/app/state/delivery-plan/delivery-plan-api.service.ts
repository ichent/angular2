import { Injectable, OnDestroy } from '@angular/core';
import { EMPTY, Observable, of, Subject } from 'rxjs';
import { DeliveryPlanQuery } from './delivery-plan.query';
import { DeliveryPlanService } from './delivery-plan.service';
import { WebsocketService } from '../../services/api/websocket.service';
import { CmiApiService } from '../../services/api/cmi-api.service';
import { DeliveryRequestParams } from '../../interfaces/delivery/delivery-request-params.interface';
import { CcApiResponse } from '../../interfaces/cc-api-response.interface';
import { Aura } from '../../helpers/aura.helper';
import { DeliveryAgent, DeliveryInterval } from '../../interfaces/delivery/delivery-interval.interface';
import { DeliveryMessageResponseApi } from '../../interfaces/delivery/delivery-message-response.interface';
import { switchMap, takeUntil } from 'rxjs/operators';
import { DeliveryPlan } from '../../interfaces/delivery/delivery-plan.interface';
import { Product } from '../products/product.interface';
import { SkuItem } from '../../interfaces/sku.interface';

@Injectable({
    providedIn: 'root',
})
export class DeliveryPlanApiService implements OnDestroy {

    private destroyed$ = new Subject<void>();

    constructor(
        private cmiService: CmiApiService,
        private websocketService: WebsocketService,
        private deliveryPlanService: DeliveryPlanService,
        private deliveryPlanQuery: DeliveryPlanQuery,
    ) {
        this.subscribeToDeliveryPlans();
    }

    private getDeliveryBatchPlan(deliveryParams: DeliveryRequestParams): Observable<any> {
        return this.cmiService.post<CcApiResponse<any>>('api/delivery/batch-plan', Aura.camelToSnake(deliveryParams));
    }

    private mapDeliveryPlansByAgent(plansResponse: string): DeliveryAgent[] {
        const deliveryIntervals: DeliveryInterval[] = Aura.snakeToCamel<DeliveryInterval[]>(JSON.parse(plansResponse));

        return deliveryIntervals.reduce((deliveryAgents: DeliveryAgent[], deliveryInterval: DeliveryInterval): DeliveryAgent[] => {
            const index: number = deliveryAgents.findIndex( item => item.agentCode === deliveryInterval.agentCode);

            if (index > -1) {
                deliveryAgents[index].intervals.push(deliveryInterval);
            } else {
                deliveryAgents.push({
                    agentCode: deliveryInterval.agentCode,
                    intervals: [deliveryInterval],
                });
            }

            return deliveryAgents;
        }, []);
    }

    private mapDeliveryResponse(message: DeliveryMessageResponseApi): Observable<DeliveryPlan> {
        if (message.statusCode === 424) {
            return of({
                productId: message.id,
                error: JSON.parse(message.response).short,
                agents: null,
            });
        }

        if (message.statusCode === 200) {
            return of({
                productId: message.id,
                error: null,
                agents: this.mapDeliveryPlansByAgent(message.response),
            });
        }

        return EMPTY;
    }

    private subscribeToDeliveryPlans(): void {
        this.websocketService.deliveryMessages$
            .pipe(
                takeUntil(this.destroyed$),
                switchMap((message: DeliveryMessageResponseApi) => this.mapDeliveryResponse(message)),
            )
            .subscribe((response: DeliveryPlan) => {
                this.deliveryPlanService.upsertDeliveryPlan(response);
            });
    }

    public requestDeliveryPlan(city: string, product: Product, forced: boolean = false): Observable<any> {
        if (!forced && this.deliveryPlanQuery.hasEntity(product.id)) {
            return EMPTY;
        }

        this.deliveryPlanService.removeDeliveryPlan(product.id);

        return this.getDeliveryBatchPlan({
            address: city || this.deliveryPlanQuery.getDeliveryCity(),
            positions: [{
                id: product.id,
                brand: product.brandName,
                category: product.categoryId,
                sku: product.skuList
                    .filter((sku: SkuItem) => sku.availabilityInStock)
                    .map((sku: SkuItem) => sku.id),
            }]
        });
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
