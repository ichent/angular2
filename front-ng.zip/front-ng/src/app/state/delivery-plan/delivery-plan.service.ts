import { Injectable } from '@angular/core';
import { DeliveryPlan } from '../../interfaces/delivery/delivery-plan.interface';
import { DeliveryPlanStore } from './delivery-plan.store';

@Injectable({
    providedIn: 'root',
})
export class DeliveryPlanService {
    constructor (
        private deliveryPlanStore: DeliveryPlanStore,
    ) {}

    public upsertDeliveryPlan(deliveryPlan: DeliveryPlan): void {
        this.deliveryPlanStore.upsert(deliveryPlan.productId, deliveryPlan);
    }

    public removeDeliveryPlan(productId: number): void {
        this.deliveryPlanStore.remove(productId);
    }

    public setDeliveryCity(deliveryCity: string): void {
        if (!deliveryCity) {
            this.deliveryPlanStore.setDefaultDeliveryCity();
        }
        this.deliveryPlanStore.update({ deliveryCity });
    }
}
