import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Look } from '../../interfaces/catalog.interface';

export interface ProductsLooksState extends EntityState<Look> {}

/**
 * Дизайнерские образы (не связано с луками, которые создают консультанты)
 */
@Injectable({
    providedIn: 'root'
})
@StoreConfig({
    name: 'products-looks'
})
export class ProductsLooksStore extends EntityStore<ProductsLooksState> {

    constructor() {
        super();
    }

}
