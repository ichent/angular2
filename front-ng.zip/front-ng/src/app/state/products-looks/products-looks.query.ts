import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { ProductsLooksStore, ProductsLooksState } from './products-looks.store';

/**
 * Дизайнерские образы (не связано с луками, которые создают консультанты)
 */
@Injectable({
    providedIn: 'root'
})
export class ProductsLooksQuery extends QueryEntity<ProductsLooksState> {

    constructor(protected store: ProductsLooksStore) {
        super(store);
    }

}
