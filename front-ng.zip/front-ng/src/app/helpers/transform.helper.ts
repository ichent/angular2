import { get as _get, omitBy as _omitBy, set as _set, isPlainObject as _isPlainObject } from 'lodash';

export interface TransformScheme {
    /** Текущий ключ переданного объекта для преобразования. Например, foo.bar.
     * При обратном преобразовании и незаданном keyTo заполняется значением null.
     **/
    keyFrom?: string;
    /** Требуемый ключ для объекта на выходе. Например, baz.
     * При прямом преобразовании и незаданном keyFrom заполняется значением null.
     **/
    keyTo?: string;
    /**
     * Если формат данных в исходном и требуемом объекте различаются, можно использвать функции маппинга.
     * Можно использовать для преобразования данных мапперы из TransformHelper
     */
    mappers?: {
        /** Функция преобразования данных из keyFrom в keyTo */
        to?: (value: any) => any;
        /** Функция преобразования данных из keyTo в keyFrom */
        from?: (value: any) => any;
    };
}

enum TransformDirection {
    To = 'to',
    From = 'from',
}

enum TransformKey {
    To = 'keyTo',
    From = 'keyFrom',
}

// Значение ключа keyFrom, обозначающее текущий объект целиком
const SELF = '.';

export namespace TransformHelper {

    export function to<T>(data: object, mappers: TransformScheme[]): T {
        return transform<T>(TransformDirection.To, data, mappers);
    }

    export function from<T>(data: object, mappers: TransformScheme[]): T {
        return transform<T>(TransformDirection.From, data, mappers);
    }

    /**
     * Преобразует из одной структуры данных в другую в заданном направлении.
     * Для трансформации используются правила, заданные в TransformScheme.
     * Поля, которые не указаны в схеме не попадают в возвращаемый объект.
     */
    function transform<T>(direction: TransformDirection, data: object, mappers: TransformScheme[]): T {
        const mapperGetKey: string = direction === TransformDirection.From ? TransformKey.To : TransformKey.From;
        const mapperSetKey: string = direction === TransformDirection.From ? TransformKey.From : TransformKey.To;

        return mappers.reduce((res: object, mapper: TransformScheme) => {
            const deepData: any = mapper[mapperGetKey] === SELF ? data : _get(data, mapper[mapperGetKey], null);

            const mappedData: any = deepData && mapper.mappers && mapper.mappers[direction]
                ? mapper.mappers[direction](deepData)
                : deepData;

            if (mapper[mapperSetKey] && mapper[mapperSetKey] !== SELF) {
                _set<T>(res, mapper[mapperSetKey], mappedData);
            }

            return res;
        }, {}) as T;
    }

    export function filterEmptyValues<T extends object>(object: T): Partial<T> {
        return _omitBy(object, (value: any) => {
            return value === null
                || value === undefined
                || value === ''
                || (Array.isArray(value) && value.length === 0)
                || (typeof value === 'object' && Object.keys(value).length === 0);
        }) as Partial<T>;
    }

    export function filterEmptyValuesRecursively<T extends object>(object: T): Partial<T> {
        return filterEmptyValues(
            Object.keys(object).reduce((newObject: Partial<T>, key: string) => {
                newObject[key] = _isPlainObject(object[key])
                    ? filterEmptyValuesRecursively(object[key])
                    : object[key];

                return newObject;
            }, {})
        );
    }

    export function stringToArray(joinedValues: string, separator: string = ','): string[] {
        return joinedValues
            ? joinedValues.split(separator).filter((value: string) => value !== '')
            : [];
    }

    export function stringToNumbersArray(joinedValues: string, separator: string = ','): number[] {
        return stringToArray(joinedValues, separator)
            .map((value: string) => stringToNumber(value))
            .filter((number: number | null) => number !== null);
    }

    export function stringToNumber(value: string): number | null {
        const result: number = parseFloat(value);
        return Number.isNaN(result) ? null : result;
    }

    export function arrayToString<T extends any>(array: T[], separator: string = ','): string {
        return array && array.length ? array.join(separator) : null;
    }

    export function numberToString(value: number): string | null {
        return typeof value === 'number' ? value.toString() : null;
    }

}
