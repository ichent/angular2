type FormStatus = 'VALID' | 'INVALID';

export namespace FormHelper {

    export const toIsInvalidStatus = function(status: FormStatus): boolean {
        return status === 'INVALID';
    };

}
