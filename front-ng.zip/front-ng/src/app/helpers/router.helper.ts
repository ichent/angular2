import { ActivatedRoute } from '@angular/router';
import { RouteDataConstant } from '../constants/common/route-data.constant';
import { Page } from '../constants/routes/page.enum';

export namespace RouterHelper {

    /**
     * Определить страницу по url
     */
    export function getPageByUrl(url: string): Page {
        return Object.values(Page).find((page: Page) => new RegExp(`^\/${page}((?!-))`).test(url));
    }

    /**
     * Страница списка товаров
     */
    export function isProductListPage(url: string): boolean {
        return getPageByUrl(url) === Page.ProductList;
    }

    /**
     * Страница корзины
     */
    export function isCartPage(url: string): boolean {
        return getPageByUrl(url) === Page.Cart;
    }

    export function hasKeyInRouteData(route: ActivatedRoute, key: RouteDataConstant): boolean {
        if (route.snapshot.data[key]) {
            return true;
        }

        let child: ActivatedRoute = route.firstChild;

        while (child) {
            if (child.firstChild) {
                child = child.firstChild;
            } else if (child.snapshot.data && child.snapshot.data[key]) {
                return child.snapshot.data[key];
            } else {
                return false;
            }
        }

        return false;
    }

}
