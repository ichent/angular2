export namespace Aura {
    export const snakeToCamel = function<T extends object>(obj: object): T {
        const newObj: object = Array.isArray(obj) ? [] : {};

        for (const k in obj) {
            if (obj.hasOwnProperty(k)) {
                let newKey: string = k;

                if (isUpperCase(newKey)) {
                    newKey = newKey.toLowerCase();
                }

                if (!isCamelCase(newKey)) {
                    newKey = toCamelCase(newKey);
                }

                const newValue: string = typeof obj[k] === 'string' ? replaceEmptyString(obj[k]) : obj[k];
                if (newValue !== null && typeof newValue === 'object') {
                    newObj[newKey] = snakeToCamel(newValue);
                } else {
                    newObj[newKey] = newValue;
                }
            }
        }
        return newObj as T;
    };

    export const camelCaseToKebab = (string: string): string => separateCamelCaseWithSymbol(string, '-');

    export const camelCaseToSnake = (string: string): string => separateCamelCaseWithSymbol(string, '_');

    export const separateCamelCaseWithSymbol = (string: string, char: string): string =>
        !string ? '' : string.replace(/([A-Z])/g, (g) => char + g[0].toLowerCase());

    const isUpperCase = (string: string): boolean => string && string === string.toUpperCase();

    const isCamelCase = (string: string): boolean => !isUpperCase(string) && !string.match(/(\_\w)/);

    export const toCamelCase = (string: string): string =>
        string.match(/(\_\w)/)
            ? string.toLowerCase().replace(/(\_\w)/g, k => k[1].toUpperCase()).trim() : string;

    const replaceEmptyString = (string: string, returnIsEmpty?: any): string | any =>
        isNotUndefined(returnIsEmpty) && (isEmptyString(string))
            ? returnIsEmpty
            : (isString(string) ? string.trim() : '');

    const isNotUndefined = (value: any): boolean => !isUndefined(value);

    const isUndefined = (value: any): boolean => typeof value === 'undefined';

    const isString = (value: any): boolean => typeof value === 'string';

    const isEmptyString = (value: string): boolean =>
        value ? safeDecodeURIComponent(value).match(/^[\s]+$/) !== null : true;

    const safeDecodeURIComponent = (value: string): string => isSafeDecodeURI(value) || value;

    const isSafeDecodeURI = (value: string): string => {
        try {
            return decodeURIComponent(value);
        } catch (e) {
            return ''; // false
        }
    };

    /**
     * Преобразует ключи у объекта из CamelCase в snake_case
     * дружит с вложенностью и ключами в любом регистре
     *
     * @param {object} obj Объект с ключами в camelCase
     * @returns T Объект с ключами в snake_case
     */
    export const camelToSnake = <T extends object>(obj: object): T => {
        const newObj: object = Array.isArray(obj) ? [] : {};
        for (const k in obj) {
            if (obj.hasOwnProperty(k)) {
                let newKey: string = k;
                if (isUpperCase(newKey)) {
                    newKey = newKey.toLowerCase();
                }
                if (isCamelCase(newKey)) {
                    newKey = camelCaseToSnake(newKey);
                }
                const newValue: string = typeof obj[k] === 'string' ? replaceEmptyString(obj[k]) : obj[k];
                if (newValue !== null && typeof newValue === 'object') {
                    newObj[newKey] = camelToSnake(newValue);
                } else {
                    newObj[newKey] = newValue;
                }
            }
        }
        return newObj as T;
    };
}
