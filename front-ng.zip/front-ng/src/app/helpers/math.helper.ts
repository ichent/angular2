export namespace MathHelper {

    export const randomNumber = (from: number, to: number): number => {
        const randomNumber: number = from + Math.random() * (to + 1 - from);

        return Math.floor(randomNumber);
    };

    export const getUniqueId = (): string => {
        return '_' + Math.random().toString(36).substr(2, 9);
    };
}
