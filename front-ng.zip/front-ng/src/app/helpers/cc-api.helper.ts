import { CcApiResponse } from '../interfaces/cc-api-response.interface';

export namespace CcApiHelper {

    export function toResponseData<T>(response: CcApiResponse<T>): T {
        return response && response.data;
    }

}
