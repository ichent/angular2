import { CommentInfo } from '../interfaces/comment-info.interface';

export namespace CommentsHelper {

    export const toSortedByDateComments = function(comments: CommentInfo[]): CommentInfo[] {
        return comments.sort((a: CommentInfo, b: CommentInfo) => b.created - a.created);
    };

}
