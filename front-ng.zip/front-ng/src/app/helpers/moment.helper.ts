import * as moment from 'moment';
import { Moment } from 'moment';

export namespace MomentHelper {

    export function millisecondsTimeToTimestamp(timestamp: number, format: string = 'Y-M-D HH:mm:ss'): string {
        if (!timestamp || Number.isNaN(timestamp)) {
            return null;
        }

        return moment(timestamp * 1000, 'x').format(format);
    }

    export function momentToTimestamp(fieldValue: Moment | number): number {
        return fieldValue ? fieldValue.valueOf() / 1000 : null;
    }

    export function momentToDayStartTimestamp(fieldValue: Moment): number {
        return momentToTimestamp(fieldValue.startOf('day'));
    }

    export function momentToDayEndTimestamp(fieldValue: Moment): number {
        return momentToTimestamp(fieldValue.endOf('day'));
    }

    export function timestampToMoment(fieldValue: number): Moment {
        return fieldValue ? moment.unix(fieldValue) : null;
    }

}
