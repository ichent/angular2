import { TransformHelper, TransformScheme } from '../transform.helper';
import { isEqual as _isEqual, cloneDeep as _cloneDeep } from 'lodash';

describe('Transform Helper', () => {

    describe('should transform object both ways', () => {
        const transformSchemas: TransformScheme[] = [
            { keyFrom: 'foo', keyTo: 'bar' },
            { keyFrom: 'client.fullName', keyTo: 'name'},
            { keyFrom: 'deliveryDate', keyTo: 'delivery.agent.date'},
            { keyFrom: 'sameArray', keyTo: 'sameArray'},
            {
                keyFrom: 'array',
                keyTo: 'stringFromArray',
                mappers: {
                    to: (array: number[]) => array.join(),
                    from: (string: string) => string.split(',').map((string: string) => parseInt(string)),
                },
            },
            { keyFrom: 'number', keyTo: 'number' },
            { keyFrom: 'boolean', keyTo: 'boolean' },
            { keyFrom: 'nulled', keyTo: 'nulled' },
            { keyFrom: 'zero', keyTo: 'zero' },
            { keyFrom: 'emptyObj', keyTo: 'emptyObj' },
            { keyFrom: 'objWithEmptyObj', keyTo: 'objWithEmptyObj' },
        ];

        const leftOriginal: object = {
            foo: 'foo',
            client: {
                fullName: 'Mr. Bug',
            },
            deliveryDate: 'soon',
            sameArray: [ 1, 2, 3 ],
            array: [ 4, 5, 6 ],
            number: 1,
            boolean: false,
            nulled: null,
            zero: 0,
            emptyObj: {},
            objWithEmptyObj: {
                obj: {},
            }
        };

        const rightOriginal: object = {
            bar: 'foo',
            name: 'Mr. Bug',
            delivery: {
                agent: {
                    date: 'soon',
                },
            },
            sameArray: [ 1, 2, 3 ],
            stringFromArray: '4,5,6',
            number: 1,
            boolean: false,
            nulled: null,
            zero: 0,
            emptyObj: {},
            objWithEmptyObj: {
                obj: {},
            }
        };

        const dataLeft: object = _cloneDeep(leftOriginal);
        const dataRight: object = _cloneDeep(rightOriginal);

        it('should create new object with transformed data', () => {
            expect(_isEqual(TransformHelper.to(dataLeft, transformSchemas), dataRight)).toBeTruthy();
            expect(_isEqual(TransformHelper.from(dataRight, transformSchemas), dataLeft)).toBeTruthy();

            expect(_isEqual(dataLeft, leftOriginal)).toBeTruthy();
            expect(_isEqual(dataRight, rightOriginal)).toBeTruthy();
        });

        it('should transform missing/undefined properties to null', () => {
            const originalData = {
                name: undefined,
            };

            const data = _cloneDeep(originalData);

            const expectedData = {
                bar: null,
                name: null,
                delivery: {
                    agent: {
                        date: null,
                    },
                },
                sameArray: null,
                stringFromArray: null,
                number: null,
                boolean: null,
                nulled: null,
                zero: null,
                emptyObj: null,
                objWithEmptyObj: null,
            };

            expect(_isEqual(TransformHelper.to(data, transformSchemas), expectedData)).toBeTruthy();
        });
    });

    it('should filter empty values', () => {
        const originalData = {
            array: [1, 2, 3, 4, 5],
            emptyArray: [],
            object: { a: 'b' },
            emptyObject: {},
            string: 'asd',
            emptyString: '',
            number: 1,
            zero: 0,
            checkNull: null,
            checkUndefined: undefined,
            objectWithEmptyValues: {
                array: [1, 2, 3, 4, 5],
                emptyArray: [],
                object: { a: 'b' },
                emptyObject: {},
                string: 'asd',
                emptyString: '',
                number: 1,
                zero: 0,
                checkNull: null,
                checkUndefined: undefined,
            }
        };

        const data = _cloneDeep(originalData);

        const expectedData1 = {
            array: [1, 2, 3, 4, 5],
            object: { a: 'b' },
            string: 'asd',
            number: 1,
            zero: 0,
            objectWithEmptyValues: {
                array: [1, 2, 3, 4, 5],
                emptyArray: [],
                object: { a: 'b' },
                emptyObject: {},
                string: 'asd',
                emptyString: '',
                number: 1,
                zero: 0,
                checkNull: null,
                checkUndefined: undefined,
            }
        };

        expect(_isEqual(TransformHelper.filterEmptyValues(data), expectedData1)).toBeTruthy();
        expect(_isEqual(data, originalData)).toBeTruthy();

        const expectedData2 = {
            array: [1, 2, 3, 4, 5],
            object: { a: 'b' },
            string: 'asd',
            number: 1,
            zero: 0,
            objectWithEmptyValues: {
                array: [1, 2, 3, 4, 5],
                object: { a: 'b' },
                string: 'asd',
                number: 1,
                zero: 0,
            }
        };

        expect(_isEqual(TransformHelper.filterEmptyValuesRecursively(data), expectedData2)).toBeTruthy();
        expect(_isEqual(data, originalData)).toBeTruthy();
    });

    it('should transform string to array', () => {
        const array: string[] = TransformHelper.stringToArray('1,2.5,3,,,,, 4,  ,asd,');

        expect(Array.isArray(array)).toBeTruthy();
        expect(array.length).toBe(6);
        expect(array[0]).toBe('1');
        expect(array[1]).toBe('2.5');
        expect(array[2]).toBe('3');
        expect(array[3]).toBe(' 4');
        expect(array[4]).toBe('  ');
        expect(array[5]).toBe('asd');
    });

    it('should transform string to numbers array', () => {
        const array: number[] = TransformHelper.stringToNumbersArray('1,2.5,3,,,,, 4,  ,asd,');

        expect(Array.isArray(array)).toBeTruthy();
        expect(array.length).toBe(4);
        expect(array[0]).toBe(1);
        expect(array[1]).toBe(2.5);
        expect(array[2]).toBe(3);
        expect(array[3]).toBe(4);
    });

    it('should transform string to number', () => {
        expect(TransformHelper.stringToNumber('1')).toBe(1);
        expect(TransformHelper.stringToNumber(' 10 ')).toBe(10);
        expect(TransformHelper.stringToNumber('1.2')).toBe(1.2);
        expect(TransformHelper.stringToNumber(null)).toBe(null);
        expect(TransformHelper.stringToNumber('0')).toBe(0);
        expect(TransformHelper.stringToNumber('')).toBe(null);
    });

    it('should transform array to string', () => {
        expect(TransformHelper.arrayToString([0, 1, 2, 3, 4])).toBe('0,1,2,3,4');
        expect(TransformHelper.arrayToString([])).toBe(null);
    });

    it('should transfrom number to string', () => {
        expect(TransformHelper.numberToString(1)).toBe('1');
        expect(TransformHelper.numberToString(0)).toBe('0');
        expect(TransformHelper.numberToString(null)).toBe(null);
    });

});
