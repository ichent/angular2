import { OrderStatusHelper } from '../order-status.helper';
import { OrderActionId } from '../../constants/order/order-action-id.enum';
import { OrderAction, OrderActionTitleGroup } from '../../interfaces/order/order-action.interface';

describe('Order Status Helper Tests', () => {

    it('should join order actions titles', () => {
        const actions: OrderAction[] = [
            { id: OrderActionId.Divide, title: 'Divide', isSupported: false },
            { id: OrderActionId.Duplicate, title: 'Duplicate', isSupported: false },
            { id: OrderActionId.Cancel, title: 'Cancel', isSupported: false },
            { id: OrderActionId.AddLoyaltyCard, title: 'AddLoyaltyCard', isSupported: false },
        ];

        const joinedTitle: string = "объединенный заголовок для группы действий";

        const rules: Map<OrderActionId[], string> = new Map([
            [
                [
                    OrderActionId.Divide,
                    OrderActionId.Duplicate,
                    OrderActionId.Cancel,
                ],
                joinedTitle,
            ],
        ]);

        const orderActionTitleGroups: OrderActionTitleGroup[] = OrderStatusHelper.joinOrderActionsTitles(actions, rules);

        expect(orderActionTitleGroups.length).toBe(2);
        expect(orderActionTitleGroups.some((group: OrderActionTitleGroup) => group.title === joinedTitle))
            .toBeTruthy();
    });

    it('should group actions', () => {
        const actions: OrderAction[] = [
            { id: OrderActionId.Divide, title: 'Divide', isSupported: false },
            { id: OrderActionId.Duplicate, title: 'Duplicate', isSupported: false },
            { id: OrderActionId.Cancel, title: 'Cancel', isSupported: false },
            { id: OrderActionId.AddLoyaltyCard, title: 'AddLoyaltyCard', isSupported: false },
        ];

        const groups: OrderActionId[][] = [
            [
                OrderActionId.Divide,
                OrderActionId.AddLoyaltyCard,
            ],
            [
                OrderActionId.Duplicate,
                OrderActionId.BonusWriteOff,
            ],
            [
                OrderActionId.Cancel,
            ],
        ];

        const groupedActions: OrderAction[][] = OrderStatusHelper.groupActions(actions, groups);

        expect(groupedActions.length).toBe(groups.length);

        expect(groupedActions[0]
            .every((grouped: OrderAction) => [OrderActionId.Divide, OrderActionId.AddLoyaltyCard].includes(grouped.id)))
            .toBeTruthy();

        expect(groupedActions[1]
            .every((grouped: OrderAction) => [OrderActionId.Duplicate, OrderActionId.BonusWriteOff].includes(grouped.id)))
            .toBeTruthy();

        expect(groupedActions[2]
            .every((grouped: OrderAction) => [OrderActionId.Cancel].includes(grouped.id)))
            .toBeTruthy();

        expect(groupedActions[2]
            .every((grouped: OrderAction) => [OrderActionId.DeliveryAgentModification].includes(grouped.id)))
            .toBeFalsy();
    });

});
