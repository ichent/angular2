import { Tag } from '../interfaces/tag.interface';

const COLOR_MAP: Record<string, string> = {
    prepay: 'orange',
};

export namespace TagsHelper {

    export function getSeasonableTags<T extends Tag>(tags: T[] = []): T[] {
        return tags.filter((tag: T) => tag.isSeasonable);
    }

    export function findTagsBySlug<T extends Tag>(tags: T[] = [], slugList: string[]): T[] {
        return tags.filter((tag: T) => slugList.includes(tag.slug));
    }

    export function getTagColor<T extends Tag>(tag: Tag): string {
        return COLOR_MAP[tag.slug];
    }
}
