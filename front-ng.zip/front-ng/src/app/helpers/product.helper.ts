import { Product } from 'src/app/state/products/product.interface';
import { User } from '../interfaces/user.interface';
import { SkuItem } from '../interfaces/sku.interface';

const USER_ROLE_FOR_LINK = 'tsum_cmi_cc';

export namespace ProductHelper {

    export function getItemLink(npUrl: string, slug: string, user: User): string {
        if (!npUrl || !slug) {
            return '';
        }

        return npUrl.replace(/\/$/m, '')
            + '/product/' + slug + '/'
            + '?utm_medium=' + USER_ROLE_FOR_LINK
            + '&utm_source=copy-paste'
            + (user ? '&utm_campaign=' + user.id : '');
    }

    export function toProductIds(products: Product[]): number[] {
        return (products || []).map((product: Product) => product.id);
    }

    export function toSkuIds(products: Product[]): number[] {
        return (products || []).reduce((skuStockIds: number[], product: Product) =>
            product ? skuStockIds.concat(product.skuList.map((sku: SkuItem) => sku.id)) : skuStockIds,
            []
        );
    }

    export function filterProductsByIds(products: Product[], productIds: number[]): Product[] {
        return products && products.length > 0 && productIds && productIds.length > 0
            ? products.filter((product: Product) => productIds.includes(product.id))
            : [];
    }

    /**
     * Артикул ЦУМ
     */
    export function skuExtId(product: Product): number {
        return (product?.skuList || [])[0]?.extId || null;
    }

    /**
     * Модель ЦУМ
     */
    export function modelExtId(product: Product): string {
        return product?.extId || null;
    }
}
