export namespace OrdersGuardHelper {
    export const ORDERS_ACCESS_KEY_NAME: string = 'ordersAccessKey';
    export const ORDERS_ACCESS_KEY_VALUE: string = 'phase2developer';

    export function isAccessAllowed(): boolean {
        if (window && window['Cypress']) {
            return true;
        }

        if (!isAccessValueValid(getSavedAccessValue())) {
            saveAccessValueFromUser();
        }

        return isAccessValueValid(getSavedAccessValue());
    }

    export function saveAccessValueFromUser(): void {
        const accessValue: string = (window.prompt('Введите пароль для доступа:') || '').trim();

        if (accessValue && isAccessValueValid(accessValue)) {
            localStorage.setItem(ORDERS_ACCESS_KEY_NAME, accessValue);
        }
    }

    export function isAccessValueValid(accessValue: string): boolean {
        return accessValue === ORDERS_ACCESS_KEY_VALUE;
    }

    export function getSavedAccessValue(): string {
        return localStorage.getItem(ORDERS_ACCESS_KEY_NAME);
    }
}
