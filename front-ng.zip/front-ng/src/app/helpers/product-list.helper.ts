import {
    ListItem,
    ListItems,
    ProductList,
    ProductListApi,
    ProductListPage,
} from '../state/product-list/product-list.interface';
import { ListPage } from '../interfaces/list-page.interface';
import { Aura } from './aura.helper';
import {
    pick as _pick,
    uniq as _uniq,
} from 'lodash';
import { ProductSkuQuantity, SkuQuantity } from '../interfaces/list-product/list-sku-quantity.interface';

const DEFAULT_PRODUCT_LIST_TITLE = 'Список товаров';
const WITHOUT_NAME_REGEXP = new RegExp(/без названия|^\s+$/, 'i');

export namespace ProductListHelper {

    export function toProductUniqueIds(productList: ProductList): number[] {
        return productList ? _uniq(ProductListHelper.toProductIds(productList)) : [];
    }

    export function toProductIds(productList: ProductList): number[] {
        return mapProductListTo<number>(productList, 'itemId');
    }

    export function toSkuIds(productList: ProductList): number[] {
        return mapProductListTo<number>(productList, 'skuId');
    }

    export function toProductListPage(listPage: ListPage<ProductListApi>): ProductListPage {
        if (!listPage) {
            return null;
        }

        return {
            items: listPage ? listPage.items.map(ProductListHelper.toList) : [],
            page: listPage.page,
            perPage: listPage['per-page'],
            total: listPage.total,
            orderBy: listPage.orderBy,
            orderDirection: listPage.orderDirection,
        };
    }

    export function toListItem(productList: ProductList, hash: string): ListItem {
        return productList && productList.items[hash];
    }

    export function toList(list: ProductListApi): ProductList {
        return {
            updatedBy: {
                user: list.updatedBy,
                date: list.updatedAt,
            },
            createdBy: {
                user: list.author,
                date: list.createdAt,
            },
            sentBy: {
                user: list.sentBy,
                date: list.sentAt,
            },
            listInfo: {
                title: list.title,
                id: list.id,
            },
            ..._pick(list, ['background', 'clientDr', 'clientEmail', 'clientPhone', 'clientTitle', 'copyCount', 'createdFromList',
                'description', 'id', 'imageHeight', 'imageUrl', 'imageWidth', 'isDraft', 'isLook', 'isexport function', 'isSynchronized',
                'isVisibleToClient', 'items', 'status', 'url'
            ]),
        } as ProductList;
    }

    export function getProductListTitle(productList: ProductList): string {
        const title: string = productList && productList.listInfo.title;
        return !title || WITHOUT_NAME_REGEXP.test(title) ? DEFAULT_PRODUCT_LIST_TITLE : title;
    }

    function mapProductListTo<T>(productList: ProductList, propKey: string): T[] {
        const productListItems: ListItems = productList && productList.items;
        const items: T[] = [];

        if (!(productList && productListItems)) {
            return [];
        }

        for (const key in productListItems) {
            if (productListItems.hasOwnProperty(key) && productListItems[key][propKey]) {
                items.push(productListItems[key][propKey]);
            }
        }

        return items;
    }
}
