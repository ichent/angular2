import { OrderLine } from '../state/orders/interfaces/order-line.interface';
import { OrderItem } from '../state/orders/interfaces/order-item.interface';

export namespace OrderLineHelper {

    export function toProductIds(orderLine: OrderLine[]): number[] {
        if (!orderLine) {
            return [];
        }

        return orderLine.map((line: OrderLine) => line.item.itemId);
    }

    export function toSkuIds(orderLine: OrderLine[]): number[] {
        if (!orderLine) {
            return [];
        }

        return orderLine.map((line: OrderLine) => line.item.id);
    }

    export function getSelectedOrderLine(orderLines: OrderLine[], productId: number): OrderLine {
        if (!orderLines) {
            return null;
        }

        return orderLines.find((line: OrderLine) => line.item.itemId === productId);
    }

    export function getSelectedOrderItem(orderLines: OrderLine[], productId: number): OrderItem {
        const currentLine: OrderLine = this.getSelectedOrderLine(orderLines, productId);

        return currentLine ? currentLine.item : null;
    }

    export function getSelectedSkuId(orderLine: OrderLine[], productId: number): number {
        const orderItem: OrderItem = OrderLineHelper.getSelectedOrderItem(orderLine, productId);
        return orderItem ? orderItem.id : null;
    }

}
