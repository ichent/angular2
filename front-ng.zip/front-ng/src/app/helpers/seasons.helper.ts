import { ProductAttribute } from '../state/dictionaries/product-attributes/product-attribute.model';

const SEASON_SLUG_REGEXP = new RegExp(/^(fw|ss)\d+/i);

export namespace SeasonsHelper {

    export function extractSeasonsFromLabels(attributes: ProductAttribute[]): ProductAttribute[][] {
        return attributes
            .reduce(([seasons, labels]: ProductAttribute[][], attribute: ProductAttribute) => {
                    (SEASON_SLUG_REGEXP.test(attribute.slug) ? seasons : labels).push(attribute);
                    return [seasons, labels];
                },
                [[], []]
            );
    }

}
