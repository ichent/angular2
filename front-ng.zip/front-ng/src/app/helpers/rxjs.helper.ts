import { Observable } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { switchMap } from 'rxjs/operators';
import { timer, throwError } from 'rxjs';
import { RetryStrategy } from '../interfaces/retry-strategy.interface';

/**
 * Функция конфигурации retryWhen
 *
 * @example
 * retryWhen(retryStrategy({
 *     scalingDuration: 300,
 *     excludedStatusCodes: [404],
 *     maxAttempts: 3
 * }))
 */
export function retryStrategy(strategy: RetryStrategy): (attempts: Observable<any>) => Observable<any> {
    const { maxAttempts = 3, scalingDuration = 300, excludedStatusCodes = [] } = strategy;

    return (attempt: Observable<any>) =>
        attempt
            .pipe(
                switchMap((error: HttpErrorResponse | Error, i: number) => {
                    const retryAttempt: number = i + 1;

                    if (error instanceof HttpErrorResponse
                        && !excludedStatusCodes.includes(error.status)
                        && retryAttempt <= maxAttempts
                    ) {
                        return timer(Math.pow(2, retryAttempt) * scalingDuration);
                    }

                    return throwError(error);
                })
            );
}
