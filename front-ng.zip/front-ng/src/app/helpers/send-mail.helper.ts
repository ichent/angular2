export namespace SendMailHelper {

    export function getMailLink(email: string, title: string, body: string): string {
        return `mailto:${email}?subject=${title}&body=${body}`;
    }
}
