import { ClientWidget } from '../constants/client-widget.constant';
import { ValidatorFn, Validators } from '@angular/forms';
import { emailValidator } from '../validators/email.validator';

export namespace ClientHelper {

    export function getContactValidators(incomingType: ClientWidget.IncomingType): ValidatorFn[] {
        switch (incomingType) {
            case ClientWidget.IncomingType.PhoneKey:
                return [
                    Validators.pattern(/^\d{11}$/),
                    Validators.required,
                ];

            case ClientWidget.IncomingType.EmailKey:
                return [
                    emailValidator,
                ];

            default:
                return [];
        }
    }

}
