import { Product } from '../state/products/product.interface';
import { ListItem, ListItems, ProductList, ReplaceListItem } from '../state/product-list/product-list.interface';
import { ListProduct } from '../interfaces/list-product/list-product.interface';
import { CatalogCard } from '../features/catalog-card/interfaces/catalog-card.interface';
import { MathHelper } from './math.helper';

export namespace ListProductHelper {

    export function toProducts(listProducts: (CatalogCard | ListProduct)[]): Product[] {
        return listProducts ? listProducts.map(ListProductHelper.toProduct) : [];
    }

    export function toProduct(listProduct: ListProduct | CatalogCard): Product {
        return listProduct && listProduct.product;
    }

    export function toProductInList(productList: ProductList, products: Product[]): ListProduct[] {
        if (!productList || ((products || []).length === 0)) {
            return [];
        }

        const productListItems: ListItems = productList && productList.items || {};
        const productInLists: ListProduct[] = [];

        for (const key in productListItems) {
            if (productListItems.hasOwnProperty(key)) {
                const listItem: ListItem = productListItems[key];

                if (listItem) {
                    const product: Product = products.find((product: Product) => product.id === listItem.itemId);

                    if (product) {
                        productInLists.push({
                            product: product,
                            productListHash: key,
                            listId: productList.id,
                            listItem: productListItems[key],
                        });
                    }
                }
            }
        }

        return productInLists;
    }

    export function toLocalListProduct(listId: number, products: Product[]): ListProduct[] {
        return products.map((product: Product) => {
            return {
                product: product,
                productListHash: MathHelper.getUniqueId(),
                listId,
                listItem: {
                    angle: null,
                    height: null,
                    itemId: product.id,
                    layer: null,
                    left: null,
                    modelId: product.modelId,
                    scaleX: null,
                    scaleY: null,
                    skuId: null,
                    src: null,
                    top: null,
                    visibility: false,
                    width: null,
                },
            };
        });
    }

    export function toReplaceListItems(listProducts: ListProduct[]): ReplaceListItem[] {
        return (listProducts || []).map(toReplaceListItem);
    }

    export function toReplaceListItem(listProduct: ListProduct): ReplaceListItem {
        return {
            ...listProduct.listItem,
            uuid: listProduct.productListHash,
        };
    }

    export function toListItems(listProducts: ListProduct[]): ListItems {
        const listItems: ListItems = {};

        (listProducts || []).forEach((listProduct: ListProduct) => {
            listItems[listProduct.productListHash] = listProduct.listItem;
        });

        return listItems;
    }

}
