import { ORDER_STATUS_GROUP, OrderStatusGroup } from '../constants/order/order-status-group.constant';
import { OrderStatus } from '../constants/order/order-status.enum';
import { ORDER_STATUS_ACTION } from '../constants/order/order-status-action.constant';
import { OrderActionId } from '../constants/order/order-action-id.enum';
import {
    GROUPED_ORDER_ACTIONS,
    JOINED_ORDER_ACTIONS_TITLES,
    ORDER_ACTION_DESCRIPTION,
} from '../constants/order/order-action-description.constant';
import { ORDER_STATUS_TITLE } from '../constants/order/order-status-title.constant';
import { OrderAction, OrderActionTitleGroup } from '../interfaces/order/order-action.interface';
import { SUPPORTED_ORDER_STATUSES } from '../constants/order/supported-order-statuses.constant';
import { SUPPORTED_ORDER_VIEW_ACTIONS } from '../constants/order/supported-order-view-actions.constant';
import { OrderPageContext } from '../interfaces/contexts/order-page-contexts.interface';

export namespace OrderStatusHelper {

    /**
     * Группы статусов, выводимые при текущем статусе заказа
     */
    export function getGroupsBy(statusId: OrderStatus): OrderStatusGroup[] {
        return ORDER_STATUS_GROUP.reduce((groups: OrderStatusGroup[], groupsEl: OrderStatusGroup | OrderStatusGroup[]) => {
            const group: OrderStatusGroup = findGroupByStatus(groupsEl, statusId);

            if (group) {
                groups.push(group);
            }

            return groups;
        }, []) as OrderStatusGroup[];
    }

    /**
     * Действия для статуса, выводимые при текущем статусе заказа
     */
    export function getActionsForInterfaceByStatus(statusId: OrderStatus): OrderActionTitleGroup[][] {
        const statusActions: OrderAction[] = OrderStatusHelper.getStatusActions(statusId);
        const grouped: OrderAction[][] = OrderStatusHelper.groupActions(statusActions, GROUPED_ORDER_ACTIONS);
        return grouped.map((actions: OrderAction[]) => joinOrderActionsTitles(actions, JOINED_ORDER_ACTIONS_TITLES));
    }

    function findGroupByStatus(groupsEl: OrderStatusGroup | OrderStatusGroup[], currentStatus): OrderStatusGroup {
        if (Array.isArray(groupsEl)) {
            const groupWithStatus: OrderStatusGroup = groupsEl.find((group: OrderStatusGroup) =>
                group.orderStatuses.includes(currentStatus)
            );

            return groupWithStatus || groupsEl[0];
        } else {
            return groupsEl;
        }
    }

    /**
     * Все действия для статуса
     */
    export function getStatusActions(status: OrderStatus): OrderAction[] {
        if (status == null) {
            return [];
        }

        const isSupported: boolean = SUPPORTED_ORDER_STATUSES.includes(status);
        return ORDER_STATUS_ACTION[status]
            .map((actionId: OrderActionId) => ({
                id: actionId,
                title: getActionTitle(actionId),
                isSupported,
            }));
    }

    /**
     * Доступно ли конкретное действие для статуса
     */
    export function isActionAvailable(statusId: OrderStatus, actionId: OrderActionId, context: OrderPageContext): boolean {
        return isActionAvailableInContext(actionId, context)
            && isStatusSupported(statusId)
            && ORDER_STATUS_ACTION[statusId].includes(actionId);
    }

    /**
     * Доступно ли действие в данном контексте
     */
    export function isActionAvailableInContext(actionId: OrderActionId, context: OrderPageContext): boolean {
        return context === OrderPageContext.Edit
            || (context === OrderPageContext.View && SUPPORTED_ORDER_VIEW_ACTIONS.includes(actionId));
    }

    /**
     * Доступен ли статус для редактирования/взятия в работу в данной фазе проекта
     */
    export function isStatusSupported(statusId: OrderStatus): boolean {
        return SUPPORTED_ORDER_STATUSES.includes(statusId);
    }

    /**
     * Название действия для вывода в интерфейс
     */
    export function getActionTitle(action: OrderActionId): string {
        return ORDER_ACTION_DESCRIPTION[action];
    }

    /**
     * Название конкретного статуса для вывода в интерфейс
     */
    export function getStatusTitle(status: OrderStatus): string {
        return ORDER_STATUS_TITLE[status] || `${status}`;
    }

    /**
     * Группировка действий по разным массивам, для визуального разделения в интерфейсе
     *
     * @param actions - действия для вывода в интерфейсе
     * @param actionIdGroups - правила группировки
     */
    export function groupActions(actions: OrderAction[], actionIdGroups: OrderActionId[][]): OrderAction[][] {
        return actionIdGroups
            .map((orderActionsIdGroup: OrderActionId[]) =>
                orderActionsIdGroup
                    .reduce((filtered: OrderAction[], actionIdInGroup: OrderActionId) => {
                        const actionInGroup: OrderAction = actions
                            .find((action: OrderAction) => action.id === actionIdInGroup);

                        return actionInGroup ? [ ...filtered, actionInGroup ] : filtered;
                    }, []),
            );
    }

    /**
     * Объединение действий под общим заголовком, для сокращения занимаемого месте в интерфейсе
     *
     * @param actions - действия для вывода в интерфейсе
     * @param joinRules - правила объединения
     */
    export function joinOrderActionsTitles(actions: OrderAction[], joinRules: Map<OrderActionId[], string>): OrderActionTitleGroup[] {
        const actionGroups: OrderActionTitleGroup[] = [];

        for (let action of actions) {
            let isActionInRules: boolean = false;

            joinRules.forEach((groupTitle: string, actionIdsInGroup: OrderActionId[]) => {
                if (actionIdsInGroup.includes(action.id)) {

                    const hasAllActionsForGroup: boolean = actionIdsInGroup
                        .every((actionIdInGroup: OrderActionId) => actions
                            .some((action: OrderAction) =>
                                action.id === actionIdInGroup
                            ),
                        );

                    if (!hasAllActionsForGroup) {
                        return;
                    }

                    isActionInRules = true;

                    const isExistInGroups: boolean = actionGroups
                        .some((existingGroup: OrderActionTitleGroup) =>
                            existingGroup.actions
                                .some((existingAction: OrderAction) =>
                                    existingAction.id === action.id)
                        );

                    const currentRuleGroup: OrderActionTitleGroup = actionGroups
                        .find((group: OrderActionTitleGroup) => group.title === groupTitle);

                    if (!currentRuleGroup && !isExistInGroups) {
                        actionGroups.push({ actions: [ action ], title: groupTitle });
                    } else {
                        if (!isExistInGroups) {
                            currentRuleGroup.actions.push(action);
                        }
                    }
                }
            });

            if (!isActionInRules) {
                const actionGroup: OrderActionTitleGroup = actionGroups
                    .find((group: OrderActionTitleGroup) => {
                        group.actions.some((groupedAction: OrderAction) => groupedAction.id === action.id)
                    });
                const isExistInCurrentGroup: boolean = actionGroup && actionGroup.title === action.title;

                if (!isExistInCurrentGroup) {
                    actionGroups.push({ actions: [ action ], title: action.title });
                }
            }
        }

        return actionGroups;
    }

}
