export namespace ValidatorsHelper {
    export const testEmail = function(email: string): boolean {
        const reg = new RegExp(
            '^(([^<>()\\[\\]\\\\.,;:\\s@"]+' +
            '(\\.[^<>()\\[\\]\\\\.,;:\\s@"]+)*)|' +
            '(".+"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|' +
            '(([a-zA-Zа-яА-Я\\-0-9]+\\.)+[a-zA-Zа-яА-Я]{2,}))$'
        );
        return reg.test(email);
    };
}
