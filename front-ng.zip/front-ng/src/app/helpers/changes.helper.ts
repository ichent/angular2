import { SimpleChanges } from '@angular/core';
import { isEqual as _isEqual } from 'lodash';

export namespace ChangesHelper {

    export function isChanged(changes: SimpleChanges, key: string): boolean {
        return changes[key] && !_isEqual(changes[key].currentValue, changes[key].previousValue);
    }

}
