export namespace StoreHelper {

    export function getIdsThatNotInStore(idsInStore: number[], checkIds: number[]): number[] {
        return checkIds.reduce(
            (acc: number[], id: number) => {
                if (!idsInStore.includes(id)) {
                    acc.push(id);
                }

                return acc;
            },
            []
        );
    }

}
