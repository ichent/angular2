import { SkuStock, Stock } from '../state/sku-stocks/sku-stock.model';
import { ProductSkuQuantity, SkuQuantity } from '../interfaces/list-product/list-sku-quantity.interface';
import { ListItem, ListItems, ProductList } from '../state/product-list/product-list.interface';
import { Order } from '../state/orders/interfaces/order.interface';
import { OrderLine } from '../state/orders/interfaces/order-line.interface';

/**
 * Преобразование различных сущностей к формату skuId: quantity
 * или к более полному формату productId: skuId: quantity
 */
export namespace SkuQuantityHelper {

    /**
     * Преобразования наличия товаров на складах к формату skuId: quantity
     * @param skuStocks - наличие товаров на складах
     */
    export function fromSkuStocks(skuStocks: SkuStock[]): SkuQuantity {
        const skuQuantities: SkuQuantity = new Map<number, number>();

        skuStocks.forEach((skuStock: SkuStock) => {
            const quantityInStocks: number =
                skuStock.stock.reduce((sum: number, stock: Stock) => sum + stock.count, 0) + (skuQuantities.get(skuStock.id) || 0);

            skuQuantities.set(skuStock.id, quantityInStocks);
        });

        return skuQuantities;
    }

    /**
     * Преобразования списка товаров к формату productId: skuId: quantity
     * @param productList - список товаров или лук
     */
    export function fromProductListToProductSkuQuantity(productList: ProductList): ProductSkuQuantity {
        const listProductSkuQuantity: ProductSkuQuantity = new Map<number, SkuQuantity>();

        if (productList && productList.items) {
            const listItems: ListItems = productList.items;


            for (const hash in listItems) {
                if (listItems.hasOwnProperty(hash)) {
                    const listItem: ListItem = listItems[hash];

                    if (!listItem.itemId || !listItem.skuId) {
                        continue;
                    }

                    const skuQuantity: SkuQuantity = listProductSkuQuantity.get(listItem.itemId) || new Map([[listItem.skuId, 0]]);

                    skuQuantity.set(listItem.skuId, (skuQuantity.get(listItem.skuId) || 0) + 1);
                    listProductSkuQuantity.set(listItem.itemId, skuQuantity);
                }
            }
        }

        return listProductSkuQuantity;
    }

    /**
     * Преобразования списка товаров к формату productId: skuId: quantity
     * @param productList - список товаров или лук
     * @param productId - id товара в каталоге (ТОЦ)
     */
    export function fromProductList(productList: ProductList, productId: number): SkuQuantity {
        return fromProductListToProductSkuQuantity(productList).get(productId);
    }

    /**
     * Преобразования заказа к формату skuId: quantity
     * @param order - заказ
     */
    export function fromOrder(order: Order): SkuQuantity {
        const skuQuantities: SkuQuantity = new Map<number, number>();

        (order?.lines || []).forEach((orderLine: OrderLine) => {
            skuQuantities.set(orderLine.item.id, (skuQuantities.get(orderLine.item.id) || 0) + 1);
        });

        return skuQuantities;
    }

}
