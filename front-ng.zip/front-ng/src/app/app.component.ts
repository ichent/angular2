import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, RouterEvent } from '@angular/router';
import { filter, map, tap } from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { CommonService } from './services/common.service';
import { RouteDataConstant } from './constants/common/route-data.constant';
import { environment } from '../environments/environment';
import { akitaDevtools } from '@datorama/akita';
import { ProductsQuery } from './state/products/products.query';
import { ProductService } from './state/products/product.service';
import { ContextQuery } from './state/context/context.query';
import { RouterHelper } from './helpers/router.helper';
import { AuthService } from './services/auth.service';
import { SessionStorageService } from './services/session-storage.service';
import { DictionaryService } from './services/dictionary.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent implements OnInit {

    public navigationEnd$: Observable<NavigationEnd> = this.router.events
        .pipe(filter((event: RouterEvent) => event instanceof NavigationEnd)) as Observable<NavigationEnd>;

    public isShowBackButton$: Observable<boolean> = this.navigationEnd$
        .pipe(map(() => RouterHelper.hasKeyInRouteData(this.route, RouteDataConstant.HasReturnBackButton)));

    public overlay$ = this.commonService.overlay$;

    public addSpaceFromTop: boolean;
    public addSpaceFromTop$: Observable<boolean> = this.commonService.clientWidgetBarExists$;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private contextQuery: ContextQuery,
        private domSanitizer: DomSanitizer,
        private commonService: CommonService,
        private ngZone: NgZone,
        private productsQuery: ProductsQuery,
        private productService: ProductService,
        private cd: ChangeDetectorRef,
        private authService: AuthService,
        private sessionStorageService: SessionStorageService,
        private dictionaryService: DictionaryService,
    ) {
        this.sessionStorageService.init();

        if (!environment.production) {
            akitaDevtools(ngZone);
        }
        this.dictionaryService.setDictionaries();
    }

    ngOnInit() {
        this.contextQuery.selectPageWithContext()
            .pipe(tap(() => this.productService.clearProductUIErrors()))
            .subscribe();

        this.addSpaceFromTop$.subscribe((value: boolean) => {
            this.addSpaceFromTop = value;
            this.cd.detectChanges();
        });
    }

    public back(): void {
        history.back();
    }

}
