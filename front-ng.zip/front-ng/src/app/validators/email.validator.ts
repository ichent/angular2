import { FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ValidatorsHelper } from '../helpers/validators.helper';

export const emailValidator: ValidatorFn = (control: FormControl): ValidationErrors => {
    if (!control.value) {
        return null; // позволяет полю быть опциональным
    }
    const valid: boolean = ValidatorsHelper.testEmail(control.value);
    return valid ? null : { email: true };
};
