import { FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const equalValidator: (value: any) => ValidatorFn = (value: any) => (control: FormControl): ValidationErrors => {
    return control.value === value ? { equal: true } : null;
}
