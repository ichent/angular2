import {
    FormGroup,
    ValidationErrors,
    ValidatorFn
} from '@angular/forms';

export const atLeastOneIsSetValidator: ValidatorFn = (formGroup: FormGroup): ValidationErrors | null => {
    const controlsValues = Object.values(formGroup.getRawValue());
    return controlsValues.some(Boolean) ? null : { atLeastOneIsSet: true };
};
