import { AsyncValidatorFn, FormControl, ValidationErrors } from '@angular/forms';
import IMask from 'imask';
import { IMaskHelper } from '../ui/modules/masks/helpers/imask.helper';
import { Observable, of } from 'rxjs';
import { first, map } from 'rxjs/operators';

export const asyncAmountValidator: (total$: Observable<number | string>, mask: IMask.MaskedNumber) => AsyncValidatorFn = (total$: Observable<number | string>, mask: IMask.MaskedNumber) => (control: FormControl): Observable<ValidationErrors> => {
    if (!control.value) {
        return of(null); // позволяет полю быть опциональным
    }

    return total$.pipe(
        first(),
        map((total: number | string) => {
            const balance: number = typeof total === 'string' ? parseInt(total, 10) : total;
            const amount: number = parseInt(IMaskHelper.unmaskValue(control.value, mask), 10);

            return !amount || !balance || amount <= balance
                ? null
                : { insufficientFunds: true };
        }),
    );

};
