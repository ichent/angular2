import { FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const emptyCmiIdValidator: ValidatorFn = (control: FormControl): ValidationErrors => !control.value ? null : { emptyCmiId: true };
