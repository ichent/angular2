import { InjectionToken } from '@angular/core';

const ENDPOINTS_NAME = 'ENDPOINTS';

export interface EndpointsConfigInterface {
    NP_API_URL: string;
    NP_BACKEND_API_URL: string;
    NP_URL: string;
    GEO_API_URL: string;
    BASE_API_URL: string;
    BASE_GATEWAY_API_URL: string;
    WEBSOCKET_URL: string;
    CENTRIFUGE_TOKEN: string;
}

export const ENDPOINTS_TOKEN = new InjectionToken<EndpointsConfigInterface>('ENDPOINTS_TOKEN');

export function getEndpointsConfig(): EndpointsConfigInterface {
    const config = window[ENDPOINTS_NAME] || {};

    Object.keys(config).forEach(key => config[key] = config[key].replace(/\/$/m, ''));

    return config;
}
