import {
    ApplicationRef,
    ComponentFactory,
    ComponentFactoryResolver,
    ComponentRef,
    EmbeddedViewRef,
    EventEmitter,
    Inject,
    Injectable,
    Injector,
    Renderer2,
    RendererFactory2,
    Type,
    ViewContainerRef,
} from '@angular/core';
import { DOCUMENT } from '@angular/common';

export interface DynamicComponentConfig {
    viewContainer?: ViewContainerRef;
    positionInBody?: 'before' | 'after';
}

@Injectable({
    providedIn: 'root',
})
export class DynamicComponentsService {

    private renderer: Renderer2;

    public constructor(
        protected resolver: ComponentFactoryResolver,
        @Inject(DOCUMENT) private document: any,
        protected appRef: ApplicationRef,
        protected injector: Injector,
        rendererFactory: RendererFactory2,
    ) {
        this.renderer = rendererFactory.createRenderer(null, null);
    }

    public createComponent<C extends any>(component: Type<C>, config?: DynamicComponentConfig): ComponentRef<C> {
        const componentFactory: ComponentFactory<C> = this.resolver.resolveComponentFactory(component);
        const viewContainerRef = config ? config.viewContainer : null;
        const insertBefore: boolean = config ? config.positionInBody === 'before' : false;

        let componentRef: ComponentRef<C>;

        if (viewContainerRef) {
            componentRef = viewContainerRef.createComponent(componentFactory);
        } else {
            componentRef = componentFactory.create(this.injector);
            const DOMElem: HTMLElement = (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;

            this.appRef.attachView(componentRef.hostView);

            if (!insertBefore) {
                this.document.body.appendChild(DOMElem);
            } else {
                this.document.body.insertBefore(DOMElem, this.document.body.firstChild);
            }
        }

        return componentRef;
    }

    public createChildComponent<C extends any>(component: Type<C>, viewContainer: ViewContainerRef): ComponentRef<C> {
        const componentRef: ComponentRef<C> = this.createComponent(component, { viewContainer });

        this.renderer.appendChild(viewContainer.element.nativeElement, componentRef.instance.el.nativeElement);

        return componentRef;
    }

    public deleteComponent<C extends any>(componentRef: ComponentRef<C>, viewContainerRef?: ViewContainerRef): void {
        if (componentRef) {
            this.unsubscribeFromComponent(componentRef);

            if (viewContainerRef) {
                const index: number = viewContainerRef.indexOf(componentRef.hostView);
                componentRef.destroy();
                viewContainerRef.remove(index);
            } else {
                componentRef.destroy();
                this.appRef.detachView(componentRef.hostView);
            }
        }
    }

    public unsubscribeFromComponent<C extends any>(componentRef: ComponentRef<C>): void {
        if (componentRef) {
            const instance = componentRef.instance;

            for (const key in instance) {
                if (instance[key] && instance.hasOwnProperty(key)) {
                    if (instance[key] as any instanceof EventEmitter) {
                        const eventEmitter: EventEmitter<any> = (instance[key] as EventEmitter<any>);
                        eventEmitter.complete();
                    }
                }
            }
        }
    }

}
