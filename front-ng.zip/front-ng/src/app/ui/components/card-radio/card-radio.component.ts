import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

type CheckableCardSize = 'small' | 'medium' | 'big';

@Component({
    selector: 'ui-card-radio',
    templateUrl: './card-radio.component.html',
    styleUrls: ['./card-radio.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class.small]': 'type === \'small\'',
    }
})
export class CardRadioComponent {

    @Input()
    public type: CheckableCardSize = 'small';

}
