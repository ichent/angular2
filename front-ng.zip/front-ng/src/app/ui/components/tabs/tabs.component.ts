import {
    AfterViewInit,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    ContentChildren,
    EventEmitter,
    forwardRef,
    OnDestroy,
    Output,
    QueryList,
    ViewChild,
} from '@angular/core';
import { TabComponent } from './tab/tab.component';
import { UiTab } from '../../interfaces/ui-tabs.interface';
import { Subject } from 'rxjs';
import { distinctUntilChanged, map, startWith, takeUntil, tap } from 'rxjs/operators';
import { ControlValueAccessor, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { UiSelectTypeDirective } from '../../modules/select/directives/ui-select-type.directive';

@Component({
    selector: 'ui-tabs',
    templateUrl: './tabs.component.html',
    styleUrls: ['./tabs.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => TabsComponent),
            multi: true,
        },
    ],
})
export class TabsComponent implements ControlValueAccessor, OnDestroy, AfterViewInit {

    @Output('userClickedTab')
    public onUserClickedTab$ = new EventEmitter<UiTab>();

    @ContentChildren(TabComponent)
    public optionList: QueryList<TabComponent>;

    @ViewChild(UiSelectTypeDirective)
    public uiSelectTypeDirective: UiSelectTypeDirective;

    public get tabs(): UiTab[] {
        return this.optionList ? this.optionList.map(this.optionListToTab) : [];
    }

    public get isOnlyOneTab(): boolean {
        return this.tabs.length === 1;
    }

    public tabsControl = new FormControl(null);

    private destroyed$ = new Subject<void>();

    constructor(private cd: ChangeDetectorRef) {}

    ngAfterViewInit() {

        this.optionList.changes
            .pipe(
                startWith(this.optionList),
                map((options: QueryList<TabComponent>) => options.toArray()),
                tap((tabComponent: TabComponent[]) =>
                    tabComponent.forEach((tab: TabComponent) => tab.onInputChanges = () => this.cd.detectChanges())
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.cd.detectChanges());

        this.tabsControl.valueChanges
            .pipe(
                startWith(this.tabsControl.value),
                distinctUntilChanged(),
                map((value: string) => this.tabs.find((tab: UiTab) => tab.value === value)),
                takeUntil(this.destroyed$),
            )
            .subscribe((tab: UiTab) => {
                this.setActiveTab(tab.value);
                this.onUserClickedTab$.emit(tab);
            });

        this.uiSelectTypeDirective.onChangeFormControlValue$
            .pipe(
                tap((value: string) => {
                    this.onChange(value);
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    private setActiveTab(tabValue: string): void {
        this.optionList.forEach((tab: TabComponent) => {
            tab.active = tab.value === tabValue;
        });
    }

    private optionListToTab(tab: TabComponent): UiTab {
        return {
            label: tab.label,
            active: tab.active,
            value: tab.value,
            badge: tab.badge,
            width: tab.width,
            disabled: tab.disabled,
        };
    }

    public trackByValue(index: number, tab: UiTab): string {
        return tab.value;
    }

    public writeValue(value: string): void {
        this.tabsControl.setValue(value, { emitEvent: false });
    }

    public registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    private onChange = (value: string) => {};
    private onTouched = () => {};

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
