import {
    AfterViewInit,
    Attribute,
    ChangeDetectionStrategy,
    Component,
    ElementRef,
    Inject,
    Input,
    OnDestroy,
    Renderer2,
} from '@angular/core';
import { fromEvent, Subject } from 'rxjs';
import { debounceTime, startWith, takeUntil } from 'rxjs/operators';
import { animationFrame } from 'rxjs/internal/scheduler/animationFrame';
import { DOCUMENT } from '@angular/common';

const SAFETY_OFFSET = 1;

@Component({
    selector: 'ui-popup',
    templateUrl: './popup.component.html',
    styleUrls: ['./popup.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PopupComponent implements AfterViewInit, OnDestroy {

    @Input()
    public parent: HTMLElement;

    public isHighest: boolean;
    private destroyed$ = new Subject<void>();

    constructor(
        private elRef: ElementRef,
        private renderer: Renderer2,
        @Inject(DOCUMENT) private document: Document,
        @Attribute('highest') isHighest: boolean
    ) {
        this.isHighest = isHighest !== null;
    }

    ngAfterViewInit() {
        fromEvent(window, 'scroll', { capture: true, passive: true })
            .pipe(
                debounceTime(0, animationFrame),
                startWith(null as Event),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.setPosition());

        if (this.isHighest || this.isFixed(this.parent)) {
            this.renderer.addClass(this.elRef.nativeElement, '_highest');
        }
    }

    private isFixed(element: HTMLElement): boolean {
        if (!element) {
            return false;
        }

        return getComputedStyle(element).position === 'fixed' || this.isFixed(element.parentElement);
    }

    private setPosition(): void {
        const parentRect: ClientRect = this.parent.getBoundingClientRect();
        const elRect: ClientRect = this.elRef.nativeElement.getBoundingClientRect();
        const documentWidth: number = this.document.documentElement.clientWidth;

        this.setStyle('top', parentRect.bottom + SAFETY_OFFSET);

        if (elRect.width <= documentWidth - parentRect.left) {
            this.setStyle('left', parentRect.left);
        } else {
            this.setStyle('left', parentRect.right - elRect.width);
        }
    }

    private setStyle(name: string, position: number): void {
        this.renderer.setStyle(this.elRef.nativeElement, name, position + 'px');
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
