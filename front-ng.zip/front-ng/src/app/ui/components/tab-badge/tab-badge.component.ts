import {
    Component,
    ChangeDetectionStrategy,
    Input,
} from '@angular/core';

@Component({
    selector: 'app-tab-badge',
    templateUrl: './tab-badge.component.html',
    styleUrls: ['./tab-badge.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TabBadgeComponent {

    @Input()
    public counter: number;
}
