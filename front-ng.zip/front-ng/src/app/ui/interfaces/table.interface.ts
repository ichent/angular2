import { TemplateRef } from '@angular/core';

export interface Column {
    title: string;
    baseWidth?: string;
    render?: (obj: object) => string | number | object;
    template?: TemplateRef<any>;
    orderBy?: string;
    tight?: boolean;
}

export interface ActionItem<T> {
    name: T;
    title: string;
    icon?: string;
}
