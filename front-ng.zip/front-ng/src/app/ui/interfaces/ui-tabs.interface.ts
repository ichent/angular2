export interface UiTab {
    label: string;
    value: string;
    active: boolean;
    disabled: boolean;
    badge?: number;
    width?: number;
}
