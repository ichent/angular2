export interface DropdownItem<T> {
    title: string;
    value: T;
    subItems?: DropdownItem<T>[];
}
