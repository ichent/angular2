export interface Paginator {
    currentPage: number;
    perPage: number;
    totalCount: number;
}
