import { Component, ChangeDetectionStrategy, HostBinding } from '@angular/core';

@Component({
    selector: 'ui-icon-definitions',
    templateUrl: './icon-definitions.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IconDefinitionsComponent {

    @HostBinding('style.display')
    private display = 'none';

}
