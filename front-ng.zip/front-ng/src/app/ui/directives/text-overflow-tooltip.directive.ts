import {
    Directive,
    ElementRef,
    Optional,
    Renderer2,
    Input,
    ChangeDetectorRef,
    OnInit,
    OnDestroy,
    ViewRef,
} from '@angular/core';
import { TooltipDirective } from '../modules/tooltip/tooltip.directive';
import { ResizeObserver } from 'resize-observer';

export type OverflowType = 'row' | 'column';

@Directive({
    selector: '[uiTextOverflowTooltip]'
})
export class TextOverflowTooltipDirective implements OnInit, OnDestroy {

    @Input('uiTextOverflowTooltip')
    public uiTextOverflowTooltip: OverflowType;

    private resizeObserver: ResizeObserver;

    constructor(
        private elRef: ElementRef,
        private renderer: Renderer2,
        private cd: ChangeDetectorRef,
        @Optional() private uiTooltipDirective: TooltipDirective,
    ) {}

    ngOnInit() {
        this.resizeObserver = new ResizeObserver(() =>
            requestAnimationFrame(() => this.setTooltip())
        );
        this.resizeObserver.observe(this.elRef.nativeElement);
    }

    private setTooltip(): void {
        if ((this.cd as ViewRef).destroyed) {
            return;
        }

        const nativeElement: HTMLElement = this.elRef.nativeElement;

        this.renderer.setStyle(nativeElement, 'overflow', 'hidden');

        if (!this.uiTextOverflowTooltip) {
            this.uiTextOverflowTooltip = 'row';
        }

        if (this.uiTextOverflowTooltip === 'row') {
            this.renderer.setStyle(nativeElement, 'text-overflow', 'ellipsis');
            this.renderer.setStyle(nativeElement, 'white-space', 'nowrap');
            this.cd.detectChanges();

            this.setTooltipParams(
                (element: HTMLElement) => element.innerText,
                (element: HTMLElement) => element.clientWidth < element.scrollWidth
            );
        }

        if (this.uiTextOverflowTooltip === 'column') {
            this.renderer.setStyle(nativeElement, 'word-break', 'break-word');
            this.cd.detectChanges();

            this.setTooltipParams(
                (element: HTMLElement) => element.innerText,
                (element: HTMLElement) => element.clientHeight < element.scrollHeight
            );
        }
    }

    private setTooltipParams(content: (element: HTMLElement) => string, checkIsShow: (element: HTMLElement) => boolean) {
        if (this.uiTooltipDirective) {
            this.uiTooltipDirective.delay = 200;
            this.uiTooltipDirective.uiTooltip = content;
            this.uiTooltipDirective.checkIsShow = checkIsShow;
        }
    }

    ngOnDestroy() {
        this.resizeObserver.unobserve(this.elRef.nativeElement);
        this.resizeObserver.disconnect();
    }

}
