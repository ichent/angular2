import { Directive, ElementRef, forwardRef, HostListener, Input, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

const DEFAULT_DEBOUNCE = 500;

const DEBOUNCE_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DebounceValueAccessorDirective),
    multi: true
};

@Directive({
    selector: 'input[uiDebounce],textarea[uiDebounce]',
    providers: [DEBOUNCE_VALUE_ACCESSOR],
})
export class DebounceValueAccessorDirective implements ControlValueAccessor, OnInit, OnDestroy {

    @Input('uiDebounce')
    public debounceTime: number;

    public registerOnChange(fn: (value: string) => void): void {
        this.onChange = fn;
    }

    public registerOnTouched(fn: () => void): void {
        this.onTouched = fn;
    }

    private valueChange$ = new Subject<string>();
    private destroyed$ = new Subject<void>();

    constructor(
        private renderer: Renderer2,
        private elRef: ElementRef,
    ) {}

    ngOnInit() {
        this.valueChange$
            .pipe(
                debounceTime(this.debounceTime || DEFAULT_DEBOUNCE),
                distinctUntilChanged(),
                takeUntil(this.destroyed$),
            )
            .subscribe((value: string) => this.onChange(value));
    }

    public writeValue(value: string = ''): void {
        this.renderer.setProperty(this.elRef.nativeElement, 'value', value);
    }

    private onChange = (value: string) => {};

    @HostListener('input', ['$event.target.value'])
    public onInput(value: string): void {
        this.valueChange$.next(value);
    }

    private onTouched = () => {};

    @HostListener('blur')
    private onBlur(): void {
        this.onTouched();
    }

    public setDisabledState(isDisabled: boolean): void {
        this.renderer.setProperty(this.elRef.nativeElement, 'disabled', isDisabled);
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
