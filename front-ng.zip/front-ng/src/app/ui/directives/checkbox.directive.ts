import { Directive, ElementRef, forwardRef, HostListener, Input, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { distinctUntilChanged, map, skip, takeUntil } from 'rxjs/operators';
import { UiHelper } from '../helpers/ui-helper.helper';

@Directive({
    exportAs: '[uiCheckbox]',
    selector: '[uiCheckbox]',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CheckboxDirective),
            multi: true,
        },
    ],
})
export class CheckboxDirective implements OnInit, ControlValueAccessor, OnDestroy {

    @Input()
    public set readonly(value: boolean) {
        this.isReadonly = UiHelper.isPropertyActive(value);
    }

    @Input()
    public activeCheckboxClass: string = 'active';

    private destroyed$ = new Subject<void>();

    private isCheckedSubject$ = new BehaviorSubject<boolean>(false);
    public isChecked$: Observable<boolean> = this.isCheckedSubject$.pipe(
        map(Boolean),
        takeUntil(this.destroyed$),
    );

    @HostListener('click')
    public onToggle(): void {
        if (this.isReadonly || this.isDisabledSubject$.value) {
            return;
        }
        this.isCheckedSubject$.next(!this.isCheckedSubject$.value);
    }

    private isDisabledSubject$ = new BehaviorSubject<boolean>(false);
    public isDisabled$: Observable<boolean> = this.isDisabledSubject$.asObservable();

    public isReadonly: boolean = false;

    constructor(
        private render: Renderer2,
        private el: ElementRef,
    ) {}

    ngOnInit() {
        this.isChecked$
            .pipe(
                skip(1),
                takeUntil(this.destroyed$),
                distinctUntilChanged(),
            )
            .subscribe((value: boolean) => {
                this.onChange(value);

                value
                    ? this.render.addClass(this.el.nativeElement, this.activeCheckboxClass)
                    : this.render.removeClass(this.el.nativeElement, this.activeCheckboxClass);
            });
    }

    public writeValue(isChecked: boolean): void {
        this.isCheckedSubject$.next(isChecked);
    }

    private onChange = (value: boolean) => {};
    private onTouched = () => {};

    public registerOnTouched(fn: () => void): void {
        this.onTouched = fn;
    }

    public registerOnChange(fn: () => void): void {
        this.onChange = fn;
    }

    public setDisabledState(isDisabled: boolean): void {
        this.isDisabledSubject$.next(isDisabled);
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
