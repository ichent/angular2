import { Directive, Optional } from '@angular/core';
import { FormControl, ValidationErrors } from '@angular/forms';
import { Moment } from 'moment';
import { TsumRangeComponent } from '@tsum/ui';

@Directive({
    selector: '[uiCompareMomentDates]',
})
export class CompareMomentDatesDirective {

    constructor(
        @Optional() private tsumRangeComponent: TsumRangeComponent,
    ) {
        if (this.tsumRangeComponent) {
            this.tsumRangeComponent.compareFunction = this.compare;
        }
    }

    private compare(from: FormControl, to: FormControl): ValidationErrors {
        const fromValue: Moment = from.value as Moment;
        const toValue: Moment = to.value as Moment;
        const errorObject: ValidationErrors = {};

        if (fromValue && toValue && fromValue.valueOf() > toValue.valueOf()) {
            errorObject.custom = { invalid: true };
        }

        return errorObject;
    }
}
