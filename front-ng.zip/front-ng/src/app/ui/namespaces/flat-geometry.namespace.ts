export namespace FlatGeometry {

    export interface Coordinates {
        top: number;
        left: number;
    }

}
