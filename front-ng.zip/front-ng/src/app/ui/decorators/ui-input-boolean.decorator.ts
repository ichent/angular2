/**
 * Используется для совместной работы с @Input(),
 * когда нужно устанавливать значения атрибутов через PropertyBinding [true/false] или указав нужный атрибут без передачи значения.
 */
export function UiInputBoolean(): PropertyDecorator {
    return function(target: Object, defaultKey: string): void {
        const privateKey = `_${defaultKey}`;

        // Для getter и setter this это конкрентный инстанс,
        // а методы getter и setter (как и их скоп) общие для всех инстансов
        function getter(): boolean {
            return this[privateKey];
        }

        function setter(value: boolean | string): void {
            this[privateKey] = (value === '' || value === true);
        }

        Object.defineProperty(
            target,
            defaultKey,
            {
                get: getter,
                set: setter,
                configurable: true,
                enumerable: true,
            }
        );
    };
}
