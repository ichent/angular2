import { Pipe, PipeTransform } from '@angular/core';

/*
* Example: {{ count | wordEndings: ['товар', 'товара', 'товаров'] }}
*/

@Pipe({
    name: 'wordEndings',
})
export class WordEndingsPipe implements PipeTransform {
    transform(count: string | number, wordForms: string[], withCounter = true): string {
        let number = 0;

        if (count == null) {
            return '';
        }

        if (typeof count === 'string') {
            number = Number(count.replace(/\D+/g, ''));
        } else if (typeof count === 'number') {
            number = count;
        }

        if (!isNaN(number) && wordForms && wordForms.length === 3) {
            return `${withCounter ? (count || 'нет') : ''} ${chooseWordForm(number, wordForms)}`.trim();
        }

        return `${count}`;
    }
}

function chooseWordForm(number: number, wordForms: string[]): string {
    const absNumber: number = Math.abs(number);
    const cases: number[] = [2, 0, 1, 1, 1, 2];

    return wordForms[
        (absNumber % 100 > 4 && absNumber % 100 < 20)
            ? 2
            : cases[(absNumber % 10 < 5) ? absNumber % 10 : 5]
        ];
}
