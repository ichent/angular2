export namespace Tag {

    export interface Interface {
        key: string;
        name: string;
        value: Value;
    }

    export type Value = (string | number) | (string | number)[] | Range;

    export type Map = Record<string | number, string> | {};

    export class Range {
        from: number;
        to: number;

        constructor(from: number = 0, to?: number) {
            this.from = from;
            this.to = to;
        }
    }

}
