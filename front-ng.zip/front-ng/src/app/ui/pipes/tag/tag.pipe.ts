import { Pipe, PipeTransform } from '@angular/core';
import { Tag } from './tag.namespace';

@Pipe({
    name: 'tag',
})
export class TagPipe implements PipeTransform {

    public transform(tag: Tag.Interface, map?: Record<string, string>): string {
        return `${tag.name}: ${this.getValue(tag.value, map)}`;
    }

    private getValue(value, map: Record<string, string>): string | number {
        switch (value.constructor) {
            case Tag.Range: {
                return value.to
                    ? `${value.from} - ${value.to}`
                    : `> ${value.from}`;
            }
            case Array: {
                return value.length === 1
                    ? map[value[0]]
                    : value.length;
            }
            default:
                return value;
        }
    }

}
