import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginatorComponent } from './components/paginator/paginator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../shared/material/material.module';
import { RouterModule } from '@angular/router';
import { LinkComponent } from './components/link/link.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { TabComponent } from './components/tabs/tab/tab.component';
import { ClickOutsideModule } from './modules/click-outside/click-outside.module';
import { WordEndingsPipe } from './pipes/word-endings.pipe';
import { UiInputModule } from './modules/input/ui-input.module';
import { TabBadgeComponent } from './components/tab-badge/tab-badge.component';
import { TooltipModule } from './modules/tooltip/tooltip.module';
import { DashComponent } from './components/dash/dash.component';
import { TextOverflowTooltipDirective } from './directives/text-overflow-tooltip.directive';
import { PhotoComponent } from './components/photo/photo.component';
import { DragAndDropModule } from './modules/drag-and-drop/drag-and-drop.module';
import { RangeInputModule } from './modules/range-input/range-input.module';
import { ResizeModule } from './modules/resize/resize.module';
import { TagComponent } from './components/tag/tag.component';
import { ConvertVerticalScrollDirective } from './modules/convertScroll/convert-vertical-scroll.directive';
import { SidenavModule } from './modules/sidenav/sidenav.module';
import { ClipboardModule } from './modules/clipboard/clipboard.module';
import { CompareMomentDatesDirective } from './directives/compare-moment-dates.directive';
import { CardCheckboxComponent } from './components/card-checkbox/card-checkbox.component';
import { CardRadioComponent } from './components/card-radio/card-radio.component';
import { MasksModule } from './modules/masks/masks.module';
import { TableModule } from './modules/table/table.module';
import { IntersectionModule } from './modules/Intersection/intersection.module';
import { IconDefinitionsComponent } from './icon-definitions/icon-definitions.component';
import { TsumIconsModule } from '@tsum/ui';
import { UiSpinnerModule } from './modules/spinner/ui-spinner.module';
import { TagPipe } from './pipes/tag/tag.pipe';
import { UiSelectModule } from './modules/select/ui-select.module';
import { CheckboxDirective } from './directives/checkbox.directive';
import { DebounceValueAccessorDirective } from './directives/debounce-value-accessor.directive';
import { ActiveTextModule } from './modules/active-text/active-text.module';

const COMPONENTS = [
    PaginatorComponent,
    LinkComponent,
    TabsComponent,
    TabComponent,
    TabBadgeComponent,
    DashComponent,
    PhotoComponent,
    TagComponent,
    CardCheckboxComponent,
    CardRadioComponent,
    IconDefinitionsComponent,
];

const PIPES = [
    WordEndingsPipe,
    TagPipe,
];

const DIRECTIVES = [
    TextOverflowTooltipDirective,
    ConvertVerticalScrollDirective,
    CompareMomentDatesDirective,
    CheckboxDirective,
    DebounceValueAccessorDirective,
];

const MODULES = [
    UiSelectModule,
    ClickOutsideModule,
    UiInputModule,
    TooltipModule,
    DragAndDropModule,
    RangeInputModule,
    ResizeModule,
    SidenavModule,
    ClipboardModule,
    MasksModule,
    TableModule,
    IntersectionModule,
    TsumIconsModule,
    UiSpinnerModule,
    ActiveTextModule,
];

@NgModule({
    declarations: [
        COMPONENTS,
        PIPES,
        DIRECTIVES,
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        RouterModule,
        MODULES,
    ],
    exports: [
        COMPONENTS,
        PIPES,
        MODULES,
        DIRECTIVES,
    ],
})
export class UiModule {}
