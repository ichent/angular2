import { FlatGeometry } from '../namespaces/flat-geometry.namespace';
import { UiMathHelper } from './ui-math.helper';

export interface Overflows {
    top: number;
    right: number;
    bottom: number;
    left: number;
}

export namespace OverflowHelper {

    /**
     * Считает заступы для каждой из сторон element в area
     *
     * @param fromArea - отсутпы element относительно area
     * @param area - область, для которой считаеся overflows
     * @param element - проверяемый элемент
     */
    export function calculateOverflow(
        fromArea: { top: number, left: number },
        area: { width: number, height: number },
        element: { width: number, height: number },
    ): Overflows {
        const offsetTop: number = fromArea.top;
        const offsetRight: number = area.width - (fromArea.left + element.width);
        const offsetBottom: number = area.height - (fromArea.top + element.height);
        const offsetLeft: number = fromArea.left;

        const normalizeOffset = (offset: number) => offset < 0 ? Math.abs(offset) : 0;

        return {
            top: normalizeOffset(offsetTop),
            right: normalizeOffset(offsetRight),
            bottom: normalizeOffset(offsetBottom),
            left: normalizeOffset(offsetLeft),
        };
    }

    export function isElementInArea(overflows: Overflows, maxOverflow?: Overflows): boolean {
        for (let key in overflows) {
            if (overflows.hasOwnProperty(key)) {
                if (overflows[key] > (maxOverflow && maxOverflow[key] || 0)) {
                    return false;
                }
            }
        }

        return true;
    }

    export function normalizeCoordinates(coordinates: FlatGeometry.Coordinates, overflows: Overflows): FlatGeometry.Coordinates {
        return {
            left: UiMathHelper.roundNumber(coordinates.left + overflows.left - overflows.right),
            top: UiMathHelper.roundNumber(coordinates.top + overflows.top - overflows.bottom),
        };
    }

}
