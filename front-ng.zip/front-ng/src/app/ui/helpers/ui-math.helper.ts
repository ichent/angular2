interface PositionParams {
    scaleX: number;
    scaleY: number;
    width: number;
    height: number;
    top: number;
    left: number;
}

export namespace UiMathHelper {

    export function roundNumber(value: number, digitsAfterComma = 2): number {
        return value ? Number(value.toFixed(digitsAfterComma)) : 0;
    }

    /**
     * @description Используется для преобразования координат товара на холсте, тк на стороне Back-End
     * позиционирование идет относительно фотографии
     */
    export function transformPosition<T extends PositionParams>(
        outerRatio: number,
        innerRatio: number,
        initialParams: T,
        inside = true
    ): T {

        let width: number;
        let height: number;
        let dx = 0;
        let dy = 0;

        if (innerRatio > outerRatio) {
            width = initialParams.width;
            height = width / (inside ? innerRatio : outerRatio);
            dy = (initialParams.height - height) * initialParams.scaleY / 2;
        } else {
            height = initialParams.height;
            width = height * (inside ? innerRatio : outerRatio);
            dx = (initialParams.width - width) * initialParams.scaleX / 2;
        }

        return {
            ...initialParams,
            width: roundNumber(width),
            height: roundNumber(height),
            top: roundNumber(initialParams.top + dy),
            left: roundNumber(initialParams.left + dx),
        };
    }

    export function lengthsSum(data: any[][]): number {
        return data.reduce((sum: number, next: any[]) => sum + (next || []).length, 0);
    }

}
