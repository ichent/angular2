export namespace UiHelper {

    // Для установки инпута через propertyBinding или просто указав атрибут без значения
    export function isPropertyActive(prop: string | boolean): boolean {
        return (prop === '' || prop === true);
    }

}
