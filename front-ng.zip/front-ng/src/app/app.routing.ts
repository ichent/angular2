import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Page } from './constants/routes/page.enum';
import { CoreModule } from './core/core.module';
import { OrdersAccessGuard } from './pages/orders/orders-access.guard';

export const routes: Routes = [
    {
        path: Page.Dashboard,
        loadChildren: () => import('./pages/dashboard/dashboard-page.module').then(m => m.DashboardPageModule),
    },
    {
        path: Page.Catalog,
        loadChildren: () => import('./pages/catalog/catalog-page.module').then(m => m.CatalogPageModule),
    },
    {
        path: Page.Oauth,
        redirectTo: `/${Page.Catalog}`,
    },
    {
        path: Page.Product,
        loadChildren: () => import('./pages/product/product-page.module').then(m => m.ProductPageModule),
    },
    {
        path: Page.Lists,
        loadChildren: () => import('./pages/lists/lists-page.module').then(m => m.ListsPageModule),
    },
    {
        path: Page.Look,
        loadChildren: () => import('./pages/look/look-page.module').then(m => m.LookPageModule),
    },
    {
        path: Page.ProductList,
        loadChildren: () => import('./pages/product-list/product-list-page.module').then(m => m.ProductListPageModule),
    },
    {
        path: Page.Cart,
        loadChildren: () => import('./pages/cart/cart-page.module').then(m => m.CartPageModule),
    },
    {
        path: Page.Orders,
        loadChildren: () => import('./pages/orders/orders.page.module').then(m => m.OrdersPageModule),
        canActivate: [OrdersAccessGuard],
    },
    {
        path: Page.Order,
        loadChildren: () => import('./pages/order/order-page.module').then(m => m.OrderPageModule),
        canActivate: [OrdersAccessGuard],
    },
    {
        path: Page.NotFound,
        loadChildren: () => import('./pages/not-found/not-found-page.module').then(m => m.NotFoundPageModule)
    },
    {
        path: '',
        redirectTo: Page.Catalog,
        pathMatch: 'full',
    },
    {
        path: '**',
        redirectTo: Page.NotFound,
    },
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' }),
        CoreModule,
    ],
    exports: [RouterModule],
    providers: [OrdersAccessGuard],
})
export class AppRoutingModule { }
