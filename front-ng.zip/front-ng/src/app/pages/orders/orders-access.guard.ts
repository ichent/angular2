import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserService } from '../../services/user.service';
import { UserRolesService } from '../../services/user-roles.service';
import { OrdersGuardHelper } from '../../helpers/orders-guard.helper';
import { Observable } from 'rxjs';
import { User } from '../../interfaces/user.interface';
import { filter, map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root',
})
export class OrdersAccessGuard implements CanActivate {

    constructor(
        private userService: UserService,
        private userRolesService: UserRolesService,
    ) {}

    canActivate(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean> {

        return this.userService.user$
            .pipe(
                filter(Boolean),
                map((user: User) => {
                    return this.userRolesService.canViewOrders(user) || OrdersGuardHelper.isAccessAllowed();
                })
            );
    }
}
