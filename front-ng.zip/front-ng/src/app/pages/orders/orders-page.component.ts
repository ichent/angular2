import { AfterViewInit, ChangeDetectionStrategy, Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Breadcrumb } from '../../features/markup/interfaces/breadcrumb.interface';
import { ORDERS_BREADCRUMBS } from './constants/orders-breadcrumbs.constant';
import { TabLink } from '../../interfaces/tab-link.interface';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ORDERS_TAB_LINKS } from './constants/orders-tab-links.constant';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { filter, switchMap, takeUntil, tap } from 'rxjs/operators';
import { ORDERS_PAGE_MODE_ROUTE_PARAM, Page, PageOrders } from '../../constants/routes/page.enum';
import { ORDERS_TITLE_WORDS } from './constants/orders-title-words.constant';
import { Column } from '../../ui/interfaces/table.interface';
import { OrdersPageService } from './services/orders-page.service';
import { OrdersPageQuery } from '../../state/pages/orders-page/orders-page.query';
import { Paginator } from '../../ui/interfaces/paginator.interface';
import { OrdersService } from '../../state/pages/orders-page/orders.service';
import { OrderClient } from '../../state/orders/interfaces/order-client.interface';
import { OrderDelivery } from '../../state/orders/interfaces/order-delivery.interface';
import { ListOrder } from '../../state/pages/orders-page/interfaces/list-order.interface';
import { ContextService } from '../../state/context/context.service';
import { OrderStatusHelper } from '../../helpers/order-status.helper';
import { OrderPageContext } from '../../interfaces/contexts/order-page-contexts.interface';
import { ID } from '@datorama/akita';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';

@Component({
    templateUrl: './orders-page.component.html',
    styleUrls: ['./orders-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        OrdersPageService,
    ],
})
export class OrdersPageComponent implements OnInit, AfterViewInit, OnDestroy {

    @ViewChild('orderTemplate', { static: true })
    public orderTemplate: TemplateRef<{ orderNo: string, created: number, status: number }>;

    @ViewChild('personTemplate', { static: true })
    public personTemplate: TemplateRef<{ person: OrderClient, isClient: boolean }>;

    @ViewChild('deliveryTemplate', { static: true })
    public deliveryTemplate: TemplateRef<OrderDelivery>;

    @ViewChild('totalTemplate', { static: true })
    public totalTemplate: TemplateRef<number>;

    @ViewChild('timeTemplate', { static: true })
    public timeTemplate: TemplateRef<void>;

    @ViewChild('actionsTemplate', { static: true })
    public actionsTemplate: TemplateRef<void>;

    public breadcrumbs: Breadcrumb[] = ORDERS_BREADCRUMBS;
    public tabLinks: TabLink[] = ORDERS_TAB_LINKS;
    public titleWords: string[] = ORDERS_TITLE_WORDS;
    public tabLinksControl = new FormControl(this.route.snapshot.params[ORDERS_PAGE_MODE_ROUTE_PARAM]);
    public paginatorControl = new FormControl();
    public isLoading$: Observable<boolean> = this.ordersPageQuery.selectLoading();
    public tableRows$: Observable<ListOrder[]> = this.ordersPageQuery.selectAll();
    public tableColumns: Column[];

    private isFixedFilterSubject$ = new BehaviorSubject<boolean>(true);
    public isFixedFilter$: Observable<boolean> = this.isFixedFilterSubject$.asObservable();

    public rowsCount$: Observable<number> = this.ordersPageQuery.selectOrdersCount();

    public isShowPaginator$: Observable<boolean> = this.ordersPageQuery.selectIsCurrentTabHasPaginator();

    public readonly sizeOptions: number[] = [10, 30, 50];
    private destroyed$ = new Subject();

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private ordersPageQuery: OrdersPageQuery,
        private ordersPageService: OrdersPageService,
        private ordersService: OrdersService,
        private contextService: ContextService,
    ) {}

    ngOnInit() {
        this.ordersPageService.init();

        this.tabLinksControl.valueChanges
            .pipe(
                tap((uri: PageOrders) => this.isFixedFilterSubject$.next(uri === PageOrders.All)),
                switchMap((uri: PageOrders) =>
                    this.router.navigate([Page.Orders, uri], { queryParams: this.route.snapshot.queryParams })
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe();

        this.ordersPageQuery.selectCurrentTabPaginator()
            .pipe(
                filter(Boolean),
                takeUntil(this.destroyed$),
            )
            .subscribe((paginator: Paginator) => this.paginatorControl.setValue(paginator, { emitEvent: false }));

        this.paginatorControl.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe((paginator: Paginator) => this.ordersService.setCurrentTabPaginator(paginator));
    }

    ngAfterViewInit() {
        this.tableColumns = [
        {
            title: 'Заказ',
            baseWidth: '140px',
            template: this.orderTemplate,
        },
        {
            title: 'Оформитель',
            baseWidth: '240px',
            template: this.personTemplate,
            render: (order: ListOrder) => ({
                person: order.client,
                isClient: true,
            }),
        },
        {
            title: 'Получатель',
            baseWidth: '240px',
            template: this.personTemplate,
            render: (order: ListOrder) => ({
                person: order.contact,
                isClient: false,
            }),
        },
        {
            title: 'Доставка',
            baseWidth: '140px',
            template: this.deliveryTemplate,
        },
        {
            title: 'Сумма заказа',
            baseWidth: '120px',
            template: this.totalTemplate,
        },
        {
            title: 'Время',
            baseWidth: '140px',
            template: this.timeTemplate,
        },
        {
            title: 'Действия',
            baseWidth: '176px',
            template: this.actionsTemplate,
            render: (order: ListOrder) => order,
        }];
    }

    public isAvailableForTakingToWork(listOrder: ListOrder): boolean {
        return listOrder
            && OrderStatusHelper.isStatusSupported(listOrder?.status)
            && !listOrder.callCenterConfirmed;
    }

    public onTakeToWork(listOrder: ListOrder): void {
        if (!listOrder) {
            return;
        }

        this.contextService.setPageContext({ resource: Page.Order, context: OrderPageContext.Edit });
        this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.OrderEdit });
        this.goToOrderPage(listOrder.uuid);
    }

    public onViewOrder(listOrder: ListOrder): void {
        if (!listOrder) {
            return;
        }

        this.contextService.setPageContext({ resource: Page.Order, context: OrderPageContext.View });
        this.goToOrderPage(listOrder.uuid);
    }

    private goToOrderPage(orderId: ID): void {
        this.router.navigate(['/', Page.Order, orderId]);
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
