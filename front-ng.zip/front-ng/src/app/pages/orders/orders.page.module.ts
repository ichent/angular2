import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { OrdersRouting } from './orders.routing';
import { OrdersPageComponent } from './orders-page.component';
import { MarkupFeatureModule } from '../../features/markup/markup-feature.module';
import { UiModule } from '../../ui/ui.module';
import { ReactiveFormsModule } from '@angular/forms';
import { OrdersFiltersComponent } from './components/orders-filters/orders-filters.component';
import { LayoutFeatureModule } from '../../features/layout/layout-feature.module';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { OrdersFilterSidenavModule } from '../../sidenavs/orders/orders-filter-sidenav/orders-filter-sidenav.module';
import { ClientWidgetFeatureModule } from '../../features/client-widget/client-widget-feature.module';
import { AssignOperatorSidenavModule } from '../../sidenavs/orders/assign-operator-sidenav/assign-operator-sidenav.module';
import { OrderFeatureModule } from '../../features/order/order-feature.module';
import { IMaskModule } from 'angular-imask';
import { TsumButtonModule, TsumIconsModule, TsumInputModule, TsumPopoverModule, TsumSelectorModule } from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        OrdersRouting,
        MarkupFeatureModule,
        ReactiveFormsModule,
        LayoutFeatureModule,
        OrdersFilterSidenavModule,
        ClientWidgetFeatureModule,
        AssignOperatorSidenavModule,
        OrderFeatureModule,
        TsumInputModule,
        TsumIconsModule,
        IMaskModule,
        TsumSelectorModule,
        TsumButtonModule,
        TsumPopoverModule,
    ],
    declarations: [
        OrdersPageComponent,
        OrdersFiltersComponent,
    ],
    providers: [
        SidenavService,
    ],
})
export class OrdersPageModule {}
