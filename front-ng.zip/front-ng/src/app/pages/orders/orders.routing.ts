import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrdersPageComponent } from './orders-page.component';
import { ORDERS_PAGE_MODE_ROUTE_PARAM, PageOrders } from '../../constants/routes/page.enum';

export const routes: Routes = [
    {
        path: `:${ORDERS_PAGE_MODE_ROUTE_PARAM}`,
        component: OrdersPageComponent,
        data: {
            hasScrollTopButton: true,
        },
    },
    {
        path: '',
        redirectTo: `${PageOrders.Queue}`,
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ],
})
export class OrdersRouting { }
