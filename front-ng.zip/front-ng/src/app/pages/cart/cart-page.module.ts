import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { UiModule } from '../../ui/ui.module';
import { SharedModule } from '../../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MarkupFeatureModule } from '../../features/markup/markup-feature.module';
import { ProductListFeatureModule } from '../../features/product-list/product-list-feature.module';
import { CartRouting } from './cart.routing';
import { CartPageComponent } from './cart-page.component';
import { CartProductModule } from './modules/cart-product/cart-product.module';
import { TsumButtonModule } from '@tsum/ui';
import { AddProductFeatureModule } from '../../features/add-product/add-product-feature.module';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        CartRouting,
        CatalogCardFeatureModule,
        ReactiveFormsModule,
        MarkupFeatureModule,
        ProductListFeatureModule,
        CartProductModule,
        TsumButtonModule,
        AddProductFeatureModule,
    ],
    declarations: [
        CartPageComponent,
    ],
})
export class CartPageModule {
}
