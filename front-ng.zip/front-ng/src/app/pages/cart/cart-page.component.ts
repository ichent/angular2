import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { defer, Observable, of, Subject } from 'rxjs';
import { delay, filter, map, take, takeUntil } from 'rxjs/operators';
import { ProductListRepository } from '../../state/product-list/product-list.repository';
import { CartService } from '../../state/cart/cart.service';
import { CartProduct } from '../../state/cart/interfaces/cart-product.interface';
import { CartQuery } from '../../state/cart/cart.query';
import { NotificationService } from '../../services/notification.service';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { Breadcrumb } from '../../features/markup/interfaces/breadcrumb.interface';
import { ORDER_BREADCRUMBS_BY_CONTEXT } from './constants/cart-breadcrumbs.constant';
import { Page } from '../../constants/routes/page.enum';
import { Router } from '@angular/router';
import { ContextService } from '../../state/context/context.service';
import { ContextQuery } from '../../state/context/context.query';
import { OrderCreationSidenavComponent } from '../../sidenavs/orders/order-create-edit-sidenav/order-creation-sidenav/order-creation-sidenav.component';
import { OrderApiService } from '../../state/orders/order-api.service';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { CART_CANCEL_TITLES, CART_TITLES } from '../../constants/cart.constant';
import { TsumConfirmService } from '@tsum/ui';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';
import { CartPageContext } from '../../interfaces/contexts/cart-page-contexts.interface';

@Component({
    selector: 'app-cart-page',
    templateUrl: './cart-page.component.html',
    styleUrls: ['./cart-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CartPageComponent implements OnInit, OnDestroy {

    private cartPageContext$: Observable<CartPageContext> = this.contextQuery.selectCartPageContext();

    public breadcrumbs$: Observable<Breadcrumb[]> = this.cartPageContext$
        .pipe(
            map((cartPageContext: CartPageContext) => ORDER_BREADCRUMBS_BY_CONTEXT[cartPageContext]),
        );

    public cartProducts$: Observable<CartProduct[]> = this.cartQuery.selectAll();
    public isLoading$: Observable<boolean> = this.cartQuery.selectLoading();

    public isCheckoutDisabled$: Observable<boolean> = this.cartProducts$
        .pipe(
            map((cartProducts: CartProduct[]) =>
                !cartProducts.length || cartProducts.some((cartProduct: CartProduct) => !cartProduct.skuId)
            ),
        );

    public title$: Observable<string> = this.cartPageContext$
        .pipe(
            map((cartPageContext: CartPageContext) => CART_TITLES[cartPageContext]),
        );

    public cancelButtonTitle$: Observable<string> = this.cartPageContext$
        .pipe(
            map((cartPageContext: CartPageContext) => CART_CANCEL_TITLES[cartPageContext]),
        );

    private cartProductsCount: number = this.cartQuery.getCount();

    private destroyed$ = new Subject<void>();

    constructor(
        private productListRepository: ProductListRepository,
        private notificationService: NotificationService,
        private cartService: CartService,
        private cartQuery: CartQuery,
        private contextService: ContextService,
        private contextQuery: ContextQuery,
        private confirmService: TsumConfirmService,
        private router: Router,
        private orderApiService: OrderApiService,
        private sidenavService: SidenavService,
    ) {
    }

    ngOnInit() {
        this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.Cart });

        this.isCheckoutDisabled$
            .pipe(
                filter((isDisabled: boolean) => isDisabled && !!this.cartProductsCount),
                take(1),
                delay(100),
                takeUntil(this.destroyed$),
            )
            .subscribe(() =>
                this.notificationService.pushNotifications([
                    {
                        type: UiNotificationType.Warning,
                        title: 'Не у всех товаров выбран размер!',
                        timeoutClose: TimeoutNotificationConstant.fast,
                    },
                ])
            );
    }

    public onCreateOrder(): void {
        this.orderApiService.createOrder()
            .subscribe(() => {
                this.contextService.setPageContext({ resource: Page.Cart, context: CartPageContext.OrderEdit });
                this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.OrderEdit });
                this.sidenavService.openSidenav(OrderCreationSidenavComponent)
            });
    }

    public onCancel(): void {
        const cartPageContext: CartPageContext = this.contextQuery.getCartPageContext();

        if (cartPageContext === CartPageContext.Cart) {
            this.confirmService.open({
                title: 'Отменить создание заказа?',
                type: 'error',
                description: 'Очистка приведет к удалению корзины и всех ее товаров',
                additionalDescription: 'Очистить?',
                buttonText: 'Очистить и удалить корзину',
                secondButtonText: 'Отменить',
                successMethod: defer(() => of(this.clearCart())),
            });
        } else if (cartPageContext === CartPageContext.OrderEdit) {
            this.cancelOrder();
        }
    }

    public clearCart(): void {
        this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.List });
        this.router.navigate(['/', Page.Catalog]);
    }

    public cancelOrder(): void {
        // TODO отправить запрос на отмену заказа
        this.clearCart();
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
