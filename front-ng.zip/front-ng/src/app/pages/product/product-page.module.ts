import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductPageComponent } from './product-page.component';
import { ProductRoutingModule } from './product.routing';
import { ProductPhotosComponent } from './components/product-photos/product-photos.component';
import { SharedModule } from '../../shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { ProductPhotoComponent } from './components/product-photos/product-photo/product-photo.component';
import { ProductPageDescriptionComponent } from './components/product-page-description/product-page-description.component';
import { ProductActionButtonsComponent } from './components/product-action-buttons/product-action-buttons.component';
import { RelativeScrollDirective } from './directives/relative-scroll.directive';
import { ProductListFeatureModule } from '../../features/product-list/product-list-feature.module';
import { ProductPageSeasonComponent } from './components/product-page-season/product-page-season.component';
import { FilterFeatureModule } from '../../features/filters/filter-feature.module';
import { ReactiveFormsModule } from '@angular/forms';
import { TsumButtonModule, TsumTabModule } from '@tsum/ui';
import { AddProductFeatureModule } from '../../features/add-product/add-product-feature.module';

@NgModule({
    declarations: [
        ProductPageComponent,
        ProductPhotosComponent,
        ProductPhotoComponent,
        ProductPageDescriptionComponent,
        ProductActionButtonsComponent,
        ProductPageSeasonComponent,
        RelativeScrollDirective,
    ],
    imports: [
        CommonModule,
        ProductRoutingModule,
        SharedModule,
        ReactiveFormsModule,
        UiModule,
        ProductFeatureModule,
        ProductListFeatureModule,
        FilterFeatureModule,
        TsumTabModule,
        TsumButtonModule,
        AddProductFeatureModule,
    ],
})
export class ProductPageModule {}
