import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductPageComponent } from './product-page.component';
import { Page } from '../../constants/routes/page.enum';

export const routes: Routes = [
    {
        path: ':id',
        component: ProductPageComponent,
        data: {
            hasReturnBackButton: true,
        },
    },
    {
        path: '**',
        redirectTo: `/${Page.NotFound}`,
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ]
})
export class ProductRoutingModule { }
