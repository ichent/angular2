import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { distinctUntilChanged, filter, map, shareReplay, startWith, switchMap, takeUntil } from 'rxjs/operators';
import { ProductsRepository } from '../../state/products/products.repository';
import { CatalogTag } from '../../interfaces/catalog.interface';
import { TagsHelper } from '../../helpers/tags.helper';
import { ProductAdditionalData } from '../../state/products-additional-data/product-additional-data.interface';
import { ProductAdditionalDataRepository } from '../../state/products-additional-data/product-additional-data.repository';
import { Product } from '../../state/products/product.interface';
import { ProductService } from '../../state/products/product.service';
import { FormControl } from '@angular/forms';
import { SkuStocksQuery } from '../../state/sku-stocks/sku-stocks.query';
import { DeliveryPlanQuery } from '../../state/delivery-plan/delivery-plan.query';

@Component({
    selector: 'app-product-page',
    templateUrl: './product-page.component.html',
    styleUrls: ['./product-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductPageComponent implements OnDestroy {

    public defaultDeliveryCity: string = this.deliveryPlanQuery.getDeliveryCity();
    public deliveryCityControl = new FormControl(this.defaultDeliveryCity);
    public chosenLocation$: Observable<string> = this.deliveryCityControl.valueChanges
        .pipe(
            startWith(this.deliveryCityControl.value),
            filter<string>(Boolean)
        );
    private destroyed$ = new Subject<void>();
    private productId$: Observable<number> = this.route.params
        .pipe(
            map((params: Params) => +params.id),
            distinctUntilChanged(),
            takeUntil(this.destroyed$),
        );

    public product$: Observable<Product> = this.productId$
        .pipe(
            filter(Boolean),
            switchMap((id: number) => this.productRepository.selectProducts([id])),
            map((products: Product[]) => products[0]),
            shareReplay({ refCount: true, bufferSize: 1 }),
        );

    public seasons$: Observable<string[]> = this.product$.pipe(map(this.toTagsTitles));

    public additionalTags$: Observable<CatalogTag[]> = this.product$.pipe(map(this.toAdditionalTags));

    public productAdditionalData$: Observable<ProductAdditionalData> = this.productId$
        .pipe(
            switchMap((id: number) => this.productAdditionalDataRepository.selectProductAdditionalData(id)),
        );

    public isInStock$: Observable<boolean> = this.productId$
        .pipe(
            switchMap((id: number) => this.skuStocksQuery.selectProductHasStocks(id)),
        );

    public isLoadingStocks$: Observable<boolean> = this.skuStocksQuery.selectLoading();

    constructor(
        private route: ActivatedRoute,
        private productService: ProductService,
        private deliveryPlanQuery: DeliveryPlanQuery,
        private productRepository: ProductsRepository,
        private productAdditionalDataRepository: ProductAdditionalDataRepository,
        private skuStocksQuery: SkuStocksQuery,
    ) {}

    public checkLocation(): void {
        if (!this.deliveryCityControl.value) {
            this.deliveryCityControl.setValue(this.defaultDeliveryCity);
        }
    }

    public getTagColor(tag: CatalogTag): string {
        return TagsHelper.getTagColor(tag);
    }

    private toTagsTitles(product: Product): string[] {
        return product
            ? product.tags.filter((tag: CatalogTag) => tag.isSeasonable).map((tag: CatalogTag) => tag.title)
            : [];
    }

    private toAdditionalTags(product: Product): CatalogTag[] {
        return product
            ? product.tags.filter((tag: CatalogTag) => tag.slug !== 'only' && !tag.isSeasonable)
            : [];
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
