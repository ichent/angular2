import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { LookEditPageComponent } from './look-edit-page.component';
import { CanDeactivateLookGuard } from '../../shared/can-deactivate-look-guard.service';
import { ProductListAccessGuard } from '../product-list/product-list-access.guard';

export const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'edit/',
                pathMatch: 'full',
            },
            {
                path: 'edit',
                redirectTo: 'edit/',
                pathMatch: 'full',
            },
            {
                path: 'edit/:id',
                component: LookEditPageComponent,
                canActivate: [ProductListAccessGuard],
                canDeactivate: [CanDeactivateLookGuard],
            },
        ],
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ],
})
export class LookRoutingModule {}
