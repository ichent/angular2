import { NgModule } from '@angular/core';
import { LookRoutingModule } from './look.routing';
import { SharedModule } from '../../shared/shared.module';
import { LookEditPageComponent } from './look-edit-page.component';
import { CommonModule } from '@angular/common';
import { UiModule } from '../../ui/ui.module';
import { LookAddNewProductComponent } from './components/look-add-new-product/look-add-new-product.component';
import { LookCanvasProductComponent } from './components/canvas/look-canvas-product/look-canvas-product.component';
import { LookProductComponent } from './components/look-product/look-product.component';
import { LookCanvasComponent } from './components/canvas/look-canvas/look-canvas.component';
import { LookProductsComponent } from './components/look-products/look-products.component';
import { SaveSidenavModule } from '../../sidenavs/save-sidenav/save-sidenav.module';
import { LookCanvasProductInfoComponent } from './components/canvas/look-canvas-product-info/look-canvas-product-info.component';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { LookProductPhotoSelectorComponent } from './components/canvas/look-product-photo-selector/look-product-photo-selector.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TsumButtonModule, TsumIconsModule, TsumScrollModule } from '@tsum/ui';

@NgModule({
    imports: [
        LookRoutingModule,
        SharedModule,
        CommonModule,
        UiModule,
        SaveSidenavModule,
        ProductFeatureModule,
        ReactiveFormsModule,
        TsumScrollModule,
        TsumIconsModule,
        TsumButtonModule,
    ],
    declarations: [
        LookEditPageComponent,
        LookProductComponent,
        LookAddNewProductComponent,
        LookCanvasProductComponent,
        LookCanvasComponent,
        LookProductsComponent,
        LookProductPhotoSelectorComponent,
        LookCanvasProductInfoComponent,
    ],
})
export class LookPageModule {
}
