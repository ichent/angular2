import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { Observable, defer } from 'rxjs';
import { LookEditPageService } from './services/look-edit-page.service';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { DnD } from '../../ui/modules/drag-and-drop/namespace/dnd.namespace';
import { LookListProductsQuery } from '../../state/look-list-products/look-list-products.query';
import { map } from 'rxjs/operators';
import { SaveSidenavComponent } from '../../sidenavs/save-sidenav/save-sidenav.component';
import { CartService } from '../../state/cart/cart.service';
import { ContextService } from '../../state/context/context.service';
import { Page } from '../../constants/routes/page.enum';
import { Router } from '@angular/router';
import { OrdersGuardHelper } from '../../helpers/orders-guard.helper';
import { CanComponentDeactivate } from '../../shared/can-deactivate-look-guard.service';
import { UserRolesService } from '../../services/user-roles.service';
import { UserService } from '../../services/user.service';
import { TsumConfirmService } from '@tsum/ui';
import {
    CONFIRM_ORDER_CREATION_DESCRIPTION_ENDINGS,
    CONFIRM_ORDER_CREATION_FROM_LOOK,
} from '../../constants/confirm-models/confirm-order-creation-from-look.constant';
import { LooksCatalogSidenavComponent } from '../../sidenavs/looks-catalog-sidenav/looks-catalog-sidenav.component';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { ProductList } from '../../state/product-list/product-list.interface';
import { LookListProductsService } from '../../state/look-list-products/look-list-products.service';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { LooksCatalogService } from '../../state/looks-catalog/looks-catalog.service';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';


@Component({
    selector: 'app-edit-look-page',
    templateUrl: './look-edit-page.component.html',
    styleUrls: ['./look-edit-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        LookEditPageService,
    ]
})
export class LookEditPageComponent implements OnDestroy, CanComponentDeactivate {

    public listProductsNotInCanvas$: Observable<ListProduct[]> = this.lookEditPageService.listProductsNotInCanvas$;
    public selectListProductsInCanvas: Observable<ListProduct[]> = this.lookEditPageService.listProductsInCanvas$;
    public isLoadingListProducts$: Observable<boolean> = this.lookEditPageService.isLoadingListProducts$;

    public lookListAreaId: string = 'look-product-list';

    public disableSaveLook$: Observable<boolean> = this.sidenavService.sidenavState(SaveSidenavComponent);
    public hasProductsOnCanvas$: Observable<boolean> = this.lookListProductsQuery.selectAll()
        .pipe(
            map((products: ListProduct[]) =>
                !!products.filter((product: ListProduct) => product.listItem.visibility).length
            )
        );

    public isMakingAction$: Observable<boolean> = this.lookListProductsQuery.selectLoading();

    constructor(
        private router: Router,
        private lookEditPageService: LookEditPageService,
        private lookListProductsQuery: LookListProductsQuery,
        private lookListProductsService: LookListProductsService,
        private productListQuery: ProductListQuery,
        private contextService: ContextService,
        private cartService: CartService,
        private userRolesService: UserRolesService,
        private userService: UserService,
        private confirmService: TsumConfirmService,
        private sidenavService: SidenavService,
        private looksCatalogService: LooksCatalogService,
    ) {}

    public openCreationConfirm(): void {
        const listId = this.lookListProductsQuery.getValue().id || this.productListQuery.getActiveId();
        const list: ProductList = this.productListQuery.getEntity(listId);
        const description: string = CONFIRM_ORDER_CREATION_FROM_LOOK.description
            + CONFIRM_ORDER_CREATION_DESCRIPTION_ENDINGS[list.status];

        this.confirmService.open({
            ...CONFIRM_ORDER_CREATION_FROM_LOOK,
            description,
            successMethod: defer(() => this.saveLook(listId))
        })
            .then(() => this.createOrder());
    }

    public onDropToArea(event: DnD.DropToAreaEvent): void {
        const isLookListArea: boolean = event.areas.main.id === this.lookListAreaId;
        this.lookEditPageService.moveLookProduct(event, !isLookListArea);
    }

    public saveLook(listId: number): Observable<ProductList> {
        return this.lookListProductsService.saveLookChanges(listId, true);
    }

    public createOrder(): void {
        if (this.userRolesService.canViewOrders(this.userService.user) || OrdersGuardHelper.isAccessAllowed()) {
            const listId = this.lookListProductsQuery.getValue().id || this.productListQuery.getActiveId();
            if (!listId) {
                return;
            }

            this.cartService.convertListToCart(listId);
            this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.Cart });

            this.router.navigate(['/', Page.Cart]);
        }
    }

    public openSavePopup(): void {
        this.sidenavService.openSidenav(SaveSidenavComponent, { type: 'look' });
    }

    canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
        return this.lookEditPageService.canLeave();
    }

    ngOnDestroy() {
        this.sidenavService.closeSidenav(SaveSidenavComponent);
        this.looksCatalogService.resetLookCatalogStore();
        this.sidenavService.destroySidenav(LooksCatalogSidenavComponent);
    }

}
