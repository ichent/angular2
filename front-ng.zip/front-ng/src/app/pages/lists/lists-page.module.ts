import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductListsPageComponent } from './pages/product-lists/product-lists-page.component';
import { LookListsPageComponent } from './pages/look-lists/look-lists-page.component';
import { ListsRoutingModule } from './lists.routing';
import { SharedModule } from '../../shared/shared.module';
import { ListTableComponent } from './components/list-table/list-table.component';
import { RouterModule } from '@angular/router';
import { ListTopFiltersComponent } from './components/list-top-filters/list-top-filters.component';
import { ListContainerComponent } from './components/list-container/list-container.component';
import { UiModule } from '../../ui/ui.module';
import { ListUserFullNamePipe } from './pipes/list-user-full-name.pipe';
import { ListsTabsComponent } from './components/lists-tabs/lists-tabs.component';
import { MarkupFeatureModule } from '../../features/markup/markup-feature.module';
import { LayoutFeatureModule } from '../../features/layout/layout-feature.module';
import { TsumButtonModule, TsumDatepickerModule, TsumIconsModule, TsumInputModule, TsumPopoverModule, TsumRangeModule } from '@tsum/ui';
import { IMaskModule } from 'angular-imask';

@NgModule({
    imports: [
        CommonModule,
        ListsRoutingModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        UiModule,
        MarkupFeatureModule,
        LayoutFeatureModule,
        TsumInputModule,
        IMaskModule,
        TsumRangeModule,
        TsumIconsModule,
        TsumDatepickerModule,
        TsumButtonModule,
        TsumPopoverModule,
    ],
    declarations: [
        ProductListsPageComponent,
        LookListsPageComponent,
        ListTableComponent,
        ListTopFiltersComponent,
        ListContainerComponent,
        ListUserFullNamePipe,
        ListsTabsComponent,
    ],
})
export class ListsPageModule {
}
