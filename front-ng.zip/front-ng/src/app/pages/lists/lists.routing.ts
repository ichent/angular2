import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListsPageComponent } from './pages/product-lists/product-lists-page.component';
import { LookListsPageComponent } from './pages/look-lists/look-lists-page.component';
import { LIST_PAGE_MODE_ROUTE_PARAM } from '../../constants/routes/page.enum';

export const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                redirectTo: 'products/draft'
            },
            {
                path: 'products',
                redirectTo: 'products/draft',
            },
            {
                path: `products/:${LIST_PAGE_MODE_ROUTE_PARAM}`,
                component: ProductListsPageComponent,
            },
            {
                path: 'looks',
                redirectTo: 'looks/draft',
            },
            {
                path: `looks/:${LIST_PAGE_MODE_ROUTE_PARAM}`,
                component: LookListsPageComponent,
            }
        ],
        data: {
            hasScrollTopButton: true,
        },
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule
    ]
})
export class ListsRoutingModule {}
