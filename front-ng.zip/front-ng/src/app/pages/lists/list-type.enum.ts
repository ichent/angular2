export enum ListType {
    Private = 'private',
    Public = 'public',
    Sent = 'sent',
    Draft = 'draft',
    AdminPrivate = 'admin-private',
}
