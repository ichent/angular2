import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotFoundPageComponent } from './not-found-page.component';
import { NotFoundRouting } from './not-found.routing';

@NgModule({
    imports: [
        CommonModule,
        NotFoundRouting,
    ],
    declarations: [
        NotFoundPageComponent,
        NotFoundPageComponent,
    ],
})
export class NotFoundPageModule {
}
