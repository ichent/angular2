import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { ProductListRepository } from '../../state/product-list/product-list.repository';
import { ProductList } from '../../state/product-list/product-list.interface';
import { Page } from '../../constants/routes/page.enum';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { NotificationService } from '../../services/notification.service';

@Injectable({
    providedIn: 'root',
})
export class ProductListAccessGuard implements CanActivate {

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private productListRepository: ProductListRepository,
        private productListQuery: ProductListQuery,
        private notificationService: NotificationService,
    ) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | boolean {
        const listId: number = route.params.id;

        if (!listId) {
            return true;
        }

        return this.productListRepository.selectProductList(listId)
            .pipe(
                map((list: ProductList) => {
                    if (!list) {
                        return false;
                    }

                    if (!this.productListQuery.getIsSent(list.id)) {
                        return true;
                    }

                    const errorMessage: string = `Запрещено редактировать отправленный ${list.isLook ? 'лук' : 'список'}`
                    this.notificationService.pushNotifications([
                        {
                            type: UiNotificationType.Error,
                            title: errorMessage,
                            timeoutClose: TimeoutNotificationConstant.fast,
                        },
                    ]);

                    return this.router.parseUrl(`/${Page.Catalog}`);
                }),
            )
    }
}
