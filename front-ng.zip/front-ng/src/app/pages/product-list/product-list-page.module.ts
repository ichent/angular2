import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListPageComponent } from './product-list-page.component';
import { ProductListRouting } from './product-list.routing';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { UiModule } from '../../ui/ui.module';
import { SharedModule } from '../../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MarkupFeatureModule } from '../../features/markup/markup-feature.module';
import { ProductListFeatureModule } from '../../features/product-list/product-list-feature.module';
import { TsumButtonModule } from '@tsum/ui';
import { AddProductFeatureModule } from '../../features/add-product/add-product-feature.module';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        ProductListRouting,
        CatalogCardFeatureModule,
        ReactiveFormsModule,
        MarkupFeatureModule,
        ProductListFeatureModule,
        TsumButtonModule,
        AddProductFeatureModule,
    ],
    declarations: [
        ProductListPageComponent,
    ],
})
export class ProductListPageModule {
}
