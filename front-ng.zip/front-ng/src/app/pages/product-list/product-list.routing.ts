import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListPageComponent } from './product-list-page.component';
import { ProductListAccessGuard } from './product-list-access.guard';

export const routes: Routes = [
    {
        path: ':id',
        component: ProductListPageComponent,
        canActivate: [ProductListAccessGuard],
    },
    {
        path: '**',
        redirectTo: '/404'
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [RouterModule]
})
export class ProductListRouting { }
