import { Component, ChangeDetectionStrategy, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Navigation, Router } from '@angular/router';
import { combineLatest, defer, Observable, of, Subject } from 'rxjs';
import {
    filter,
    finalize,
    map,
    shareReplay,
    switchMap,
    switchMapTo,
    take,
    takeUntil,
} from 'rxjs/operators';
import { ActionItem } from '../../ui/interfaces/table.interface';
import { Breadcrumb } from '../../features/markup/interfaces/breadcrumb.interface';
import { ProductListAction } from './constants/product-list-action.enum';
import { PRODUCT_LIST_ACTIONS } from './constants/product-list-actions.constant';
import { PRODUCT_LIST_BREADCRUMBS } from './constants/product-list-breadcrumbs.constant';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { ProductListRepository } from '../../state/product-list/product-list.repository';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { ProductListApiService } from '../../state/product-list/product-list-api.service';
import { AuthorizedActions } from './interfaces/authorized-actions.interface';
import { ProductList } from '../../state/product-list/product-list.interface';
import { User } from '../../interfaces/user.interface';
import { UserService } from '../../services/user.service';
import { Page } from '../../constants/routes/page.enum';
import { ProductListService } from '../../state/product-list/product-list.service';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { CreateLinkSidenavComponent } from '../../sidenavs/create-link-sidenav/create-link-sidenav.component';
import { SaveSidenavComponent } from '../../sidenavs/save-sidenav/save-sidenav.component';
import { CartService } from '../../state/cart/cart.service';
import { OrdersGuardHelper } from '../../helpers/orders-guard.helper';
import { UserRolesService } from '../../services/user-roles.service';
import { TsumConfirmService } from '@tsum/ui';
import { TsumConfirm } from '@tsum/ui/lib/ui/tsum-notifications/tsum-confirm/tsum-confirm.namespace';

@Component({
    selector: 'app-product-list-page',
    templateUrl: './product-list-page.component.html',
    styleUrls: ['./product-list-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductListPageComponent implements OnInit, OnDestroy {

    public get productListId(): number {
        return Number(this.route.snapshot.params.id);
    }

    public productList$: Observable<ProductList> = this.productListRepository.selectProductList(this.productListId)
        .pipe(shareReplay(1));

    public listProducts$: Observable<ListProduct[]> = this.productListRepository.selectListProducts(this.productListId)
        .pipe(shareReplay(1));

    public title$: Observable<string> = this.productListQuery.selectProductListTitle(this.productListId);

    public actions: ActionItem<ProductListAction>[] = PRODUCT_LIST_ACTIONS;

    public availableActions: ActionItem<ProductListAction>[] = [];

    public withPagination$: Observable<boolean> = this.listProducts$
        .pipe(
            switchMapTo(
                // TODO сделать проверку на количество товаров в списке при реализации пагинации
                of(false),
            ),
            shareReplay(1),
        );

    public isLoadingProducts$: Observable<boolean> = this.productListRepository.selectIsListProductsLoading(this.productListId);

    public breadcrumbs: Breadcrumb[] = Object.values(PRODUCT_LIST_BREADCRUMBS);

    private selectedHashes$: Observable<string[]> = this.productListQuery.selectActiveHashes();

    private destroyed$ = new Subject<void>();

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private productListService: ProductListService,
        private productListQuery: ProductListQuery,
        private productListApiService: ProductListApiService,
        private productListRepository: ProductListRepository,
        private confirmService: TsumConfirmService,
        private userService: UserService,
        private sidenavService: SidenavService,
        private cartService: CartService,
        private userRolesService: UserRolesService,
    ) {
        productListService.setCurrentProductList(+route.snapshot.params.id);
        this.initBreadcrumbs(this.router.getCurrentNavigation());
    }

    ngOnInit() {
        // Формируем массив действий со списком доступных пользователю
        combineLatest([
            this.productList$.pipe(filter(Boolean)),
            this.userService.user$.pipe(filter(Boolean)),
            this.selectedHashes$,
        ])
            .pipe(
                map(([list, user, hashes]: [ProductList, User, string[]]) => {
                    const authorizedActions: AuthorizedActions = {
                        [ProductListAction.Save]: true,
                        [ProductListAction.CreateLink]: this.userService.canSaveToClient(list, user, list.status),
                        [ProductListAction.CreateLook]: true,
                        [ProductListAction.Clear]: this.userService.canDeleteList(list, user, list.status),
                        [ProductListAction.Delete]: hashes && hashes.length > 0,
                    };
                    return authorizedActions;
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe((authorizedActions: AuthorizedActions) => {
                this.availableActions = this.actions
                    .filter((action: ActionItem<ProductListAction>) => authorizedActions[action.name]);
            });
    }

    public onListAction(action: ProductListAction): void {
        switch (action) {
            case ProductListAction.Save:
                this.saveProductList();
                break;
            case ProductListAction.CreateLink:
                this.createProductListLink();
                break;
            case ProductListAction.CreateLook:
                this.onCreateLook();
                break;
            case ProductListAction.Clear:
                this.removeProductList();
                break;
            case ProductListAction.Delete:
                this.deleteSelectedProductsFromList();
                break;
        }
    }

    private initBreadcrumbs(navigation: Navigation): void {
        if (!navigation) {
            return;
        }

        const link: string = navigation.extras.state ? navigation.extras.state.prevPath : null;
        if (!link) {
            return;
        }

        this.breadcrumbs = [
            PRODUCT_LIST_BREADCRUMBS.catalog,
            {...PRODUCT_LIST_BREADCRUMBS.lists, link},
            PRODUCT_LIST_BREADCRUMBS.edit,
        ];
    }

    public onSelectHashes(hashes: string[]): void {
        this.productListService.setActiveHashes(hashes);
    }

    public onCreateLook(): void {
        this.productListService.setCurrentProductList(this.productListId); // Обработка кейса прямого перехода по ссылке списка
        this.router.navigate(['/', Page.Look]);
    }

    private saveProductList(): void {
        this.sidenavService.openSidenav(SaveSidenavComponent, { type: 'list' });
    }

    private createProductListLink(): void {
        this.sidenavService.openSidenav(CreateLinkSidenavComponent, { type: 'list' });
    }

    public createOrder() {
        if (this.userRolesService.canViewOrders(this.userService.user) || OrdersGuardHelper.isAccessAllowed()) {
            this.cartService.convertCurrentListToCart();

            this.router.navigate(['/', Page.Cart]);
        }
    }

    private removeProductList(): void {
        this.confirmService.open({
            title: 'Хотите очистить список?',
            type: 'warning',
            description: 'Очистка приведет к удалению списка и всех товаров из этого списка',
            additionalDescription: 'Очистить?',
            buttonText: 'Очистить и удалить список',
            secondButtonText: 'Отменить',
            successMethod: defer(() => this.productListApiService.removeProductList(this.productListId)),
        }).then((response: TsumConfirm.Emit) => {
            if (response === 'success') {
                this.router.navigate(['/', Page.Catalog]);
            }
        });
    }

    private deleteSelectedProductsFromList(): void {
        this.selectedHashes$
            .pipe(
                take(1),
                filter((hashes: string[]) => !!hashes.length),
                switchMap((hashes: string[]) => this.productListApiService.batchRemove(this.productListId, hashes)),
                finalize(() => this.productListService.resetActiveHashes()),
            )
            .subscribe();
    }

    ngOnDestroy() {
        this.sidenavService.closeSidenav(SaveSidenavComponent);
        this.productListService.resetActiveHashes();
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
