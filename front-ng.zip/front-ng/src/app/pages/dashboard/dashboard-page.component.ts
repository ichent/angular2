import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'app-dashboard-page',
    templateUrl: './dashboard-page.component.html',
    styleUrls: ['./dashboard-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardPageComponent {

}
