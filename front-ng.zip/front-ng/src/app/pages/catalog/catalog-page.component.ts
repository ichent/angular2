import { Component, OnInit, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { takeUntil, map, tap, finalize, concatMap } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CatalogCard } from '../../features/catalog-card/interfaces/catalog-card.interface';
import { ProductFilterSidenavComponent } from '../../sidenavs/product-filter-sidenav/product-filter-sidenav.component';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { ProductCategoryFilterSidenavComponent } from '../../sidenavs/product-category-filter-sidenav/product-category-filter-sidenav.component';
import { Product } from '../../state/products/product.interface';
import { BuyGiftCardSidenavComponent } from '../../sidenavs/buy-gift-card-sidenav/buy-gift-card-sidenav.component';
import { CatalogFiltersQuery } from '../../state/catalog-filters/catalog-filters.query';
import { ProductApiService } from '../../state/products/product-api.service';
import { CatalogFiltersState } from '../../state/catalog-filters/catalog-filters.store';
import { TransformHelper } from '../../helpers/transform.helper';
import { ListPage } from '../../interfaces/list-page.interface';
import { PRODUCTS_TITLES } from '../../constants/common/products-titles.constant';
import { CatalogPaginator } from '../../constants/catalog-paginator.constant';
import { FormControl } from '@angular/forms';
import { Paginator } from '../../ui/interfaces/paginator.interface';
import { CatalogFiltersService } from '../../state/catalog-filters/catalog-filters.service';
import { CommonService } from '../../services/common.service';
import { CATALOG_FILTERS_TO_QUERY_PARAMS } from '../../state/catalog-filters/constants/catalog-filters-to-query-params.schema';
import { CATALOG_FILTERS_TO_API } from '../../state/catalog-filters/constants/catalog-filters-to-api.schema';
import { CatalogFilters } from '../../state/catalog-filters/catalog-filters.interface';

@Component({
    selector: 'app-catalog-page',
    templateUrl: './catalog-page.component.html',
    styleUrls: ['./catalog-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CatalogPageComponent implements OnInit, OnDestroy {

    public productsTitles: string[] = PRODUCTS_TITLES;
    public sizeOptions: number[] = CatalogPaginator.SizesOptions;

    public paginatorControl = new FormControl();

    private productsSubject$ = new Subject<Product[]>();
    public products$: Observable<Product[]> = this.productsSubject$.asObservable();

    public totalCount$: Observable<number> = this.catalogFiltersQuery.select('total');
    public catalogCards$: Observable<CatalogCard[]> = this.products$
        .pipe(map(this.toCatalogCards));

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private catalogFiltersQuery: CatalogFiltersQuery,
        private catalogFiltersService: CatalogFiltersService,
        private productApiService: ProductApiService,
        private route: ActivatedRoute,
        private router: Router,
        private commonService: CommonService,
    ) {}

    ngOnInit() {
        this.parseQueryParams();

        this.paginatorControl.valueChanges
            .pipe(takeUntil(this.destroyed$))
            .subscribe((paginator: Paginator) => {
                // выставляем значение второму пагинатору
                this.paginatorControl.setValue(paginator, { emitEvent: false });
                this.catalogFiltersService.patchPaginator(paginator);
            });

        this.catalogFiltersQuery.selectChangeByUser()
            .pipe(
                map((state: CatalogFiltersState) => ({
                    ...state,
                    filters: state.useFilters ? state.filters : null
                })),
                tap((state: Partial<CatalogFiltersState>) => this.changeQueryParams(state)),
                map(this.toParams),
                concatMap((params: Params) => {
                    this.commonService.toggleOverlay(true);
                    return this.productApiService.getProducts(params)
                        .pipe(finalize(() => this.commonService.toggleOverlay(false)));
                }),
                tap(({ total }: ListPage<Product>) => {
                    window.scrollTo(0, 0);
                    this.catalogFiltersService.setTotal(total);
                    this.paginatorControl.setValue(this.catalogFiltersQuery.getPaginator(), { emitEvent: false });
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe((list: ListPage<Product>) => this.productsSubject$.next(list.items));
    }

    private changeQueryParams(state: Partial<CatalogFiltersState>): void {
        const rawQueryParams: Params = TransformHelper.to(state, CATALOG_FILTERS_TO_QUERY_PARAMS);
        const queryParams: Params = TransformHelper.filterEmptyValues(rawQueryParams);

        this.router.navigate([], { relativeTo: this.route, queryParams });
    }

    private parseQueryParams(): void {
        const params = this.route.snapshot.queryParams;
        const state: CatalogFiltersState = TransformHelper.from(params, CATALOG_FILTERS_TO_QUERY_PARAMS);
        const filteredState: Partial<CatalogFiltersState> = TransformHelper.filterEmptyValuesRecursively(state);

        this.catalogFiltersService.setState(filteredState);
    }

    private toCatalogCards(products: Product[]): CatalogCard[] {
        return products.map((product: Product) => ({ product }));
    }

    private toParams(state: Partial<CatalogFiltersState>): Params {
        const params: Params = TransformHelper.to(correctState(state), CATALOG_FILTERS_TO_API);

        return TransformHelper.filterEmptyValues(params);
    }

    ngOnDestroy() {
        this.sidenavService.closeSidenav(ProductCategoryFilterSidenavComponent);
        this.sidenavService.closeSidenav(ProductFilterSidenavComponent);
        this.sidenavService.closeSidenav(BuyGiftCardSidenavComponent);

        this.destroyed$.next();
        this.destroyed$.complete();
    }

}

/**
 * api сервера принимает labels и seasons как один массив для сортировки
 * в качестве range сервер принимает только два значения
 */
function correctState(state: Partial<CatalogFiltersState>): Partial<CatalogFiltersState> {
    const filters: CatalogFilters = state.filters;

    if (filters) {
        const fromPrice = filters.fromPrice || (filters.toPrice ? '0' : null);
        const toPrice = filters.toPrice || (filters.fromPrice ? '9999999999' : null);

        return {
            ...state,
            filters: {
                ...filters,
                labels: [...filters.labels, ...filters.seasons, ...filters.properties],
                fromPrice,
                toPrice,
                seasons: null,
                properties: null,
            }
        };
    } else {
        return state;
    }
}
