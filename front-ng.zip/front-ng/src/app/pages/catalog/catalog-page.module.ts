import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CatalogPageComponent } from './catalog-page.component';
import { CatalogRoutingModule } from './catalog.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { UiModule } from 'src/app/ui/ui.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { ProductListFeatureModule } from '../../features/product-list/product-list-feature.module';
import { SizeFeatureModule } from '../../features/size/size-feature.module';
import { CatalogFiltersActiveStateComponent } from './components/catalog-filters-active-state/catalog-filters-active-state.component';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { MarkupFeatureModule } from '../../features/markup/markup-feature.module';
import { BuyGiftCardSidenavModule } from '../../sidenavs/buy-gift-card-sidenav/buy-gift-card-sidenav.module';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { TsumButtonModule, TsumInputModule, TsumSelectorModule, TsumTagModule } from '@tsum/ui';
import { TsumIconsModule } from '@tsum/ui';
import { CatalogTopFilterComponent } from './components/catalog-top-filter/catalog-top-filter.component';
import { CatalogFiltersTagsComponent } from './components/catalog-filters-tags/catalog-filters-tags.component';
import { FiltersPresetSidenavModule } from '../../sidenavs/filters-preset-sidenav/filters-preset-sidenav.module';
import { AddProductFeatureModule } from '../../features/add-product/add-product-feature.module';

@NgModule({
    imports: [
        CommonModule,
        CatalogRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        UiModule,
        ProductFeatureModule,
        ProductListFeatureModule,
        SizeFeatureModule,
        CatalogCardFeatureModule,
        MarkupFeatureModule,
        TsumButtonModule,
        BuyGiftCardSidenavModule,
        TsumButtonModule,
        TsumIconsModule,
        TsumInputModule,
        TsumSelectorModule,
        TsumTagModule,
        FiltersPresetSidenavModule,
        AddProductFeatureModule,
    ],
    declarations: [
        CatalogPageComponent,
        CatalogFiltersActiveStateComponent,
        CatalogTopFilterComponent,
        CatalogFiltersTagsComponent,
    ],
    providers: [
        SidenavService,
    ],
})
export class CatalogPageModule {}
