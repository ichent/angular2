import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';
import { OrderPageComponent } from './order-page.component';
import { Page } from '../../constants/routes/page.enum';

const routes: Route[] = [
    {
        path: ':orderId',
        component: OrderPageComponent,
    },
    {
        path: '**',
        redirectTo: `/${Page.NotFound}`,
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ]
})
export class OrderRouting {

}
