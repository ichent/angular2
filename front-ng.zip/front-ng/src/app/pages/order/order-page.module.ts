import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { OrderPageComponent } from './order-page.component';
import { OrderRouting } from './order.routing';
import { MarkupFeatureModule } from '../../features/markup/markup-feature.module';
import { UiModule } from '../../ui/ui.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { ReactiveFormsModule } from '@angular/forms';
import { SizeFeatureModule } from '../../features/size/size-feature.module';
import { OrderTabPipe } from './pipes/order-tab.pipe';
import { OrderAdvancedModule } from './modules/order-advanced/order-advanced.module';
import { ParticipantsInformationComponent } from './components/participants-information/participants-information.component';
import { ClientWidgetFeatureModule } from '../../features/client-widget/client-widget-feature.module';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { OrderEditSidenavModule } from '../../sidenavs/orders/order-create-edit-sidenav/order-edit-sidenav/order-edit-sidenav.module';
import { StickyOrderInfoComponent } from './components/sticky-order-info/sticky-order-info.component';
import { DivideOrderSidenavModule } from '../../sidenavs/orders/divide-order-sidenav/divide-order-sidenav.module';
import { OrderStatusComponent } from './components/order-status/order-status.component';
import { OrderStatusInfoComponent } from './components/order-status-info/order-status-info.component';
import { OrderCommentsSidenavModule } from '../../sidenavs/orders/order-comments-sidenav/order-comments-sidenav.module';
import { CombineOrdersSidenavModule } from '../../sidenavs/orders/combine-orders-sidenav/combine-orders-sidenav.module';
import {
    TsumButtonModule,
    TsumCopyToClipboardModule,
    TsumIconsModule,
    TsumInputModule,
    TsumPaneModule,
    TsumPopoverModule,
    TsumScrollModule,
} from '@tsum/ui';
import {
    OrderPackageAdditionsSidenavModule,
} from '../../sidenavs/orders/order-package-additions-sidenav/order-package-additions-sidenav.module';
import { DuplicateOrdersSidenavModule } from '../../sidenavs/orders/duplicate-orders-sidenav/duplicate-orders-sidenav.module';
import {
    OrderProductNomenclatureSidenavModule,
} from '../../sidenavs/order-product-nomenclature-sidenav/order-product-nomenclature-sidenav.module';
import { OrderCancelSidenavModule } from '../../sidenavs/orders/order-cancel-sidenav/order-cancel-sidenav.module';
import { PayByLinkSidenavModule } from '../../sidenavs/orders/pay-by-link-sidenav/pay-by-link-sidenav.module';
import { OrderFeatureModule } from '../../features/order/order-feature.module';
import { OrderLineCardModule } from './modules/order-line-card/order-line-card.module';
import { OrderPreviewModule } from './modules/order-preview/order-preview.module';
import { IMaskModule } from 'angular-imask';
import { OrderCustomerModule } from './modules/order-customer/order-customer.module';
import { OrderLineRejectionSidenavModule } from '../../sidenavs/order-line-rejection-sidenav/order-line-rejection-sidenav.module';
import { OrderHeaderComponent } from './components/order-header/order-header.component';
import { OrderMainButtonComponent } from './components/order-main-button/order-main-button.component';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        OrderRouting,
        MarkupFeatureModule,
        UiModule,
        ProductFeatureModule,
        CatalogCardFeatureModule,
        ReactiveFormsModule,
        OrderAdvancedModule,
        SizeFeatureModule,
        ClientWidgetFeatureModule,
        OrderEditSidenavModule,
        DivideOrderSidenavModule,
        OrderCommentsSidenavModule,
        CombineOrdersSidenavModule,
        DuplicateOrdersSidenavModule,
        OrderPackageAdditionsSidenavModule,
        TsumInputModule,
        OrderProductNomenclatureSidenavModule,
        OrderCancelSidenavModule,
        PayByLinkSidenavModule,
        OrderFeatureModule,
        TsumIconsModule,
        TsumScrollModule,
        TsumButtonModule,
        TsumPaneModule,
        TsumCopyToClipboardModule,
        IMaskModule,
        OrderCustomerModule,
        OrderLineCardModule,
        OrderPreviewModule,
        OrderLineRejectionSidenavModule,
        TsumPopoverModule,
    ],
    declarations: [
        OrderPageComponent,
        OrderTabPipe,
        ParticipantsInformationComponent,
        StickyOrderInfoComponent,
        OrderStatusComponent,
        OrderStatusInfoComponent,
        OrderHeaderComponent,
        OrderMainButtonComponent,
    ],
    providers: [
        SidenavService,
    ],
})

export class OrderPageModule {}
