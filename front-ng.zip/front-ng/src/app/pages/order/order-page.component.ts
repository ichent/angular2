import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
} from '@angular/core';
import { EMPTY, Observable, Subject } from 'rxjs';
import { FormControl } from '@angular/forms';
import { ORDER_PAGE_ID_ROUTE_PARAM, Page, PageOrders } from '../../constants/routes/page.enum';
import { ActivatedRoute, Params, Router } from '@angular/router';
import {
    catchError,
    distinctUntilChanged,
    filter,
    map,
    retryWhen,
    startWith,
    switchMap,
    takeUntil,
    tap,
} from 'rxjs/operators';
import { RelativeOrder } from '../../state/orders/interfaces/relative-order.interface';
import { Order } from '../../state/orders/interfaces/order.interface';
import { OrderApiService } from '../../state/orders/order-api.service';
import { OrderService } from '../../state/orders/order.service';
import { OrdersQuery } from '../../state/orders/orders.query';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { OrderCommentsSidenavComponent } from 'src/app/sidenavs/orders/order-comments-sidenav/order-comments-sidenav.component';
import { OrderLine } from '../../state/orders/interfaces/order-line.interface';
import { OrderLineHelper } from '../../helpers/order-line.helper';
import { SizeService } from '../../state/sku-sizes/size.service';
import { OrderPreviewService } from './services/order-preview.service';
import { OrderProductService } from './services/order-product.service';
import { PRODUCTS_TITLES } from '../../constants/common/products-titles.constant';
import { ProductsRepository } from '../../state/products/products.repository';
import { SkuStocksService } from '../../state/sku-stocks/sku-stocks.service';
import { isEqual as _isEqual } from 'lodash';
import { OrderActionId } from '../../constants/order/order-action-id.enum';
import { OrderLineRejectionSidenavComponent } from '../../sidenavs/order-line-rejection-sidenav/order-line-rejection-sidenav.component';
import { OrderCancelSidenavComponent } from '../../sidenavs/orders/order-cancel-sidenav/order-cancel-sidenav.component';
import { SendMailHelper } from '../../helpers/send-mail.helper';
import { retryStrategy } from '../../helpers/rxjs.helper';

@Component({
    selector: 'app-order-page',
    templateUrl: './order-page.component.html',
    styleUrls: ['./order-page.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [
        OrderPreviewService,
    ],
})
export class OrderPageComponent implements OnInit, OnDestroy {

    public tabWidth = 210;

    private get orderId(): string {
        return this.route.snapshot.params[ORDER_PAGE_ID_ROUTE_PARAM];
    }

    private get order(): Order {
        return this.ordersQuery.getEntity(this.orderId);
    }

    public get canWatchHistory(): boolean {
        return this.ordersQuery.getIsActionAvailable(this.orderId, OrderActionId.ShowHistory);
    }

    public get canCancelOrder(): boolean {
        return this.ordersQuery.getIsActionAvailable(this.orderId, OrderActionId.Cancel);
    }

    private orderId$: Observable<string> = this.route.params
        .pipe(
            map((params: Params) => params[ORDER_PAGE_ID_ROUTE_PARAM]),
            startWith(this.orderId),
            distinctUntilChanged(),
        );

    public tabsControl = new FormControl(this.orderId);

    public productsTitles: string[] = PRODUCTS_TITLES;

    public order$: Observable<Order> = this.orderId$
        .pipe(
            switchMap((orderId: string) => this.ordersQuery.selectEntity(orderId)),
        );

    public relativeOrders$: Observable<RelativeOrder[]> = this.ordersQuery.selectRelativeOrders();

    public orderLines$: Observable<OrderLine[]> = this.order$
        .pipe(map((order: Order) => order ? order.lines : []));

    public linesNumber$: Observable<number> = this.orderLines$
        .pipe(map((lines: OrderLine[]) => lines.filter((line: OrderLine) => !line.isDeleted).length));

    private destroyed$ = new Subject<void>();

    // Для случая когда не удалось получить заказ с бека
    public isOrderAvailable = true;

    public get sendMailLink(): string {
        const email: string = 'sitesupport@tsum.ru';
        const title: string = 'Не работает заказ в CMI';
        const body: string = `Заказ по ссылке ${location.href} с номером ${this.orderId} не открывается`;

        return SendMailHelper.getMailLink(email, title, body);
    }

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private orderApiService: OrderApiService,
        private orderService: OrderService,
        private ordersQuery: OrdersQuery,
        private sidenavService: SidenavService,
        private orderCommentsPreviewService: OrderPreviewService,
        private orderProductService: OrderProductService,
        private sizeService: SizeService,
        private productsRepository: ProductsRepository,
        private skuStocksService: SkuStocksService,
        private cd: ChangeDetectorRef,
    ) {}

    ngOnInit() {
        this.orderId$
            .pipe(
                switchMap((orderId: string) => this.orderApiService.getOrderById(orderId)
                    .pipe(
                        retryWhen(retryStrategy({
                            scalingDuration: 300,
                            excludedStatusCodes: [404],
                            maxAttempts: 3,
                        })),
                        catchError(() => {
                            this.isOrderAvailable = false;
                            this.cd.detectChanges();

                            return EMPTY;
                        }),
                    ),
                ),
                tap((order: Order) => this.orderService.setActiveOrder(order.uuid)),
                tap((order: Order) => this.orderCommentsPreviewService.createOrderCommentsPreview(order)),
                takeUntil(this.destroyed$),
            )
            .subscribe();

        this.tabsControl.valueChanges
            .pipe(
                distinctUntilChanged(),
                takeUntil(this.destroyed$),
            )
            .subscribe((orderId: string) => this.router.navigate([Page.Order, orderId]));

        const orderProductIds$: Observable<number[]> = this.orderId$
            .pipe(
                switchMap((orderId: string) => this.ordersQuery.selectEntity(orderId)),
                filter(Boolean),
                map((order: Order) => OrderLineHelper.toProductIds(order.lines)),
                distinctUntilChanged(_isEqual),
            );

        orderProductIds$
            .pipe(
                switchMap((ids: number[]) => this.sizeService.getNewSizes(ids)),
                takeUntil(this.destroyed$),
            )
            .subscribe();

        orderProductIds$
            .pipe(
                switchMap((ids: number[]) => this.productsRepository.selectProducts(ids)),
                takeUntil(this.destroyed$),
            )
            .subscribe();

        this.order$
            .pipe(
                filter(Boolean),
                map((order: Order) => OrderLineHelper.toSkuIds(order.lines)),
                distinctUntilChanged(_isEqual),
                switchMap((ids: number[]) => this.skuStocksService.getSkuStocks(ids)),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    public openOrderCommentsSidenav(): void {
        const order: Order = this.ordersQuery.getEntity(this.orderId);

        if (!order) {
            return;
        }

        this.sidenavService.openSidenav(OrderCommentsSidenavComponent, {
            orderId: order.uuid,
            clientId: order.client.id,
        });
    }

    public onCancelOrder(): void {
        this.sidenavService.openSidenav(OrderCancelSidenavComponent, { orderId: this.order.uuid });
    }

    public deleteOrderProduct(orderLine: OrderLine): void {
        this.sidenavService.openSidenav(OrderLineRejectionSidenavComponent, {
            orderUuid: this.orderId,
            orderLineUuid: orderLine.uuid,
            rejectionReason: orderLine.reject?.reason,
        });
    }

    public redirectToQueue(): void {
        this.orderService.setActiveOrder(null);
        this.router.navigate([Page.Orders, PageOrders.Queue]);
    }

    public trackByUuid(index: number, value: { uuid: string }): string {
        return value.uuid;
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
