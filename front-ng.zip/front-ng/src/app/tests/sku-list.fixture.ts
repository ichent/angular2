import { SizeSkuListItem } from '../features/size/interfaces/sku-size.interface';

export namespace SkuListFixture {

    export function getMediumDoubleSkuList(): SizeSkuListItem[] {
        return [
            {
                id: 10674899,
                sizeAttributes: {
                    russianLabel: 'RU',
                    russianSize: '46',
                    vendorLabel: 'FR',
                    vendorSize: '40',
                },
                availabilityInStock: true,
                isVisibleInCatalog: 1,
                isBuyable: 1,
            },
            {
                id: 10674900,
                sizeAttributes: {
                    russianLabel: 'RU',
                    russianSize: '48',
                    vendorLabel: 'FR',
                    vendorSize: '42',
                },
                availabilityInStock: true,
                isVisibleInCatalog: 1,
                isBuyable: 1,
            },
            {
                id: 10674902,
                sizeAttributes: {
                    russianLabel: 'RU',
                    russianSize: '52',
                    vendorLabel: 'FR',
                    vendorSize: '46',
                },
                availabilityInStock: true,
                isVisibleInCatalog: 1,
                isBuyable: 1,
            },
        ];
    }

    export function getNoSizeSkuList(): SizeSkuListItem[] {
        return [
            {
                id: 1470022,
                sizeAttributes: {
                    russianLabel: null,
                    russianSize: null,
                    vendorLabel: null,
                    vendorSize: null,
                },
                availabilityInStock: true,
                isVisibleInCatalog: 1,
                isBuyable: 1,
            },
        ]
    }
}
