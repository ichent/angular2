import { ProductStockSizes } from '../features/product/components/product-stocks-sizes/product-stock-sizes.namespace';

export namespace StockSizesFixture {

    export function getStockSizes(): ProductStockSizes.StockInfo {
        return {
            'TSUM': [
                {'count': 2, 'size': '46  S'},
                {'count': 2, 'size': '48  M'},
                {'count': 2, 'size': '50  L'},
                {'count': 2, 'size': '52  XL'},
                {'count': 2, 'size': '54  XXL'},
            ],
            'Koptevo': [
                {'count': 5, 'size': '48  M'},
                {'count': 7, 'size': '50  L'},
                {'count': 4, 'size': '52  XL'},
                {'count': 3, 'size': '54  XXL'},
            ],
        };
    }
}
