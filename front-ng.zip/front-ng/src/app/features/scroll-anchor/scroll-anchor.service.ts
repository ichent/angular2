import { ElementRef, Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ScrollAnchorService {

    private anchors: { [key: string]: ElementRef } = {};

    public registerAnchor(anchorName: string, anchor: ElementRef): void {
        this.anchors[anchorName] = anchor;
    }

    public unRegisterAnchor(anchorName: string): void {
        delete this.anchors[anchorName];
    }

    public scrollTo(anchorName: string): void {
        if (this.anchors[anchorName]) {
            this.scrollElementIntoView(this.anchors[anchorName]);
        }
    }

    public scrollElementIntoView(elem: ElementRef): void {
        elem.nativeElement.scrollIntoView({behavior: 'smooth'});
    }
}
