import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollAnchorDirective } from './scroll-anchor.directive';
import { ScrollAnchorService } from './scroll-anchor.service';

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        ScrollAnchorDirective,
    ],
    providers: [
        ScrollAnchorService,
    ],
    exports: [
        ScrollAnchorDirective,
    ]
})
export class ScrollAnchorFeatureModule { }
