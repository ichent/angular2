import { Directive, ElementRef, Input, OnDestroy } from '@angular/core';
import { ScrollAnchorService } from './scroll-anchor.service';

@Directive({
    selector: '[scrollAnchor]'
})
export class ScrollAnchorDirective implements OnDestroy {

    private _scrollAnchor: string;

    @Input()
    public set scrollAnchor(value: string) {
        if (this.scrollAnchor) {
            this.scrollAnchorService.unRegisterAnchor(this.scrollAnchor);
        }

        this._scrollAnchor = value;
        this.scrollAnchorService.registerAnchor(value, this.el);
    }

    public get scrollAnchor(): string {
        return this._scrollAnchor;
    }

    constructor(
        private el: ElementRef,
        private scrollAnchorService: ScrollAnchorService,
    ) {}

    ngOnDestroy() {
        this.scrollAnchorService.unRegisterAnchor(this.scrollAnchor);
    }

}
