import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CategoryFilterComponent } from './category-filter/category-filter.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from 'src/app/ui/ui.module';
import { StockFilterComponent } from './stock-filter/stock-filter.component';
import { IsSelectedPipe } from './pipes/is-selected.pipe';
import { DeliveryFilterComponent } from './delivery-filter/delivery-filter.component';
import { CheckboxGroupComponent } from './checkbox-group/checkbox-group.component';
import {
    TsumAutocompleteModule,
    TsumCheckboxModule,
    TsumInputModule,
    TsumRangeModule,
    TsumSecondarySidepanelSelectorModule,
} from '@tsum/ui';

const COMPONENTS = [
    CategoryFilterComponent,
    DeliveryFilterComponent,
    CheckboxGroupComponent,
    StockFilterComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        UiModule,
        TsumInputModule,
        TsumAutocompleteModule,
        TsumSecondarySidepanelSelectorModule,
        TsumCheckboxModule,
        TsumRangeModule,
    ],
    declarations: [
        ...COMPONENTS,
        IsSelectedPipe,
    ],
    exports: COMPONENTS
})
export class FilterFeatureModule {}
