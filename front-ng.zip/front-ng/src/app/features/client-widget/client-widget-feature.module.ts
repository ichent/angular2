import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientWidgetBarComponent } from './components/client-widget-bar/client-widget-bar.component';
import { ClientWidgetComponent } from './components/client-widget/client-widget.component';
import { ClientWidgetIncomingIconComponent } from './components/client-widget-incoming-icon/client-widget-incoming-icon.component';
import { MaterialModule } from '../../shared/material/material.module';
import { FlexModule } from '@angular/flex-layout';
import { UiModule } from '../../ui/ui.module';
import { ClientWidgetBoxComponent } from './components/client-widget-box/client-widget-box.component';
import { ClientWidgetCustomerNameComponent } from './components/client-widget-customer-name/client-widget-customer-name.component';
import { ClientWidgetIncomingTextComponent } from './components/client-widget-incoming-text/client-widget-incoming-text.component';
import { IncomingTypeTextPipe } from './pipes/incoming-type-text.pipe';
import { ClientWidgetAttributeComponent } from './components/client-widget-attribute/client-widget-attribute.component';
import { ClientWidgetBoxFooterComponent } from './components/client-widget-box-footer/client-widget-box-footer.component';
import {
    ClientWidgetLinkMoreCustomersComponent,
} from './components/client-widget-link-more-customers/client-widget-link-more-customers.component';
import { ClientWidgetCustomersComponent } from './components/client-widget-customers/client-widget-customers.component';
import { FullNamePipe } from './pipes/full-name.pipe';
import { ReactiveFormsModule } from '@angular/forms';
import { IconNameByIncomingType } from './pipes/icon-name-by-incoming-type.pipe';
import { TsumTextOverflowTooltipModule } from '@tsum/ui';
import { TsumButtonModule } from '@tsum/ui';

const COMPONENTS = [
    ClientWidgetComponent,
    ClientWidgetBarComponent,
    ClientWidgetBoxComponent,
    ClientWidgetIncomingIconComponent,
    ClientWidgetCustomerNameComponent,
    ClientWidgetIncomingTextComponent,
    ClientWidgetAttributeComponent,
    ClientWidgetBoxFooterComponent,
    ClientWidgetLinkMoreCustomersComponent,
    ClientWidgetCustomersComponent,
];

const PIPES = [
    IncomingTypeTextPipe,
    FullNamePipe,
    IconNameByIncomingType,
];

@NgModule({
    imports: [
        CommonModule,
        MaterialModule,
        FlexModule,
        UiModule,
        ReactiveFormsModule,
        TsumTextOverflowTooltipModule,
        TsumButtonModule,
    ],
    declarations: [
        ...COMPONENTS,
        ...PIPES,
    ],
    exports: [
        ...COMPONENTS,
        ...PIPES
    ],
})
export class ClientWidgetFeatureModule {}
