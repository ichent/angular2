import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TablePaginationLayoutComponent } from './components/table-pagination-layout/table-pagination-layout.component';
import { SharedModule } from '../../shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { HeaderComponent } from './components/header/header.component';
import { TsumLayoutHeaderModule, TsumProfileModule } from '@tsum/ui';

const COMPONENTS = [
    TablePaginationLayoutComponent,
    HeaderComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        TsumLayoutHeaderModule,
        TsumProfileModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class LayoutFeatureModule { }
