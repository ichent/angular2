import { NgModule } from '@angular/core';
import { LabelTitlePipe } from './pipes/label-title.pipe';
import { LabelColorPipe } from './pipes/label-color.pipe';
import { OrderStatusTitlePipe } from './pipes/order-status-title.pipe';

const PIPES = [
    LabelTitlePipe,
    LabelColorPipe,
    OrderStatusTitlePipe,
];

@NgModule({
    declarations: PIPES,
    imports: [],
    exports: PIPES,
})
export class OrderFeatureModule {
}
