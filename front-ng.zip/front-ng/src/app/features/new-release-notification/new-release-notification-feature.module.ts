import { NgModule } from '@angular/core';
import { NewReleaseNotificationComponent } from './new-release-notification/new-release-notification.component';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { NewReleaseNotificationDialogComponent } from './new-release-notification-dialog/new-release-notification-dialog.component';
import { TsumButtonModule, TsumIconsModule } from '@tsum/ui';

const COMPONENTS = [
    NewReleaseNotificationComponent,
    NewReleaseNotificationDialogComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        TsumButtonModule,
        TsumIconsModule,
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
    entryComponents: COMPONENTS,
})
export class NewReleaseNotificationFeatureModule {
}
