import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListCounterComponent } from './components/product-list-counter/product-list-counter.component';
import { UiModule } from '../../ui/ui.module';
import { SharedModule } from '../../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { RemoveFromListComponent } from './components/remove-from-list/remove-from-list.component';
import { TsumButtonModule } from '@tsum/ui';

const COMPONENTS = [
    RemoveFromListComponent,
    ProductListCounterComponent,
];

@NgModule({
    declarations: [
        COMPONENTS,
    ],
    imports: [
        CommonModule,
        UiModule,
        SharedModule,
        ReactiveFormsModule,
        TsumButtonModule,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class ProductListFeatureModule {
}
