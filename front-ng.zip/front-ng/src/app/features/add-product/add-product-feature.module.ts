import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { AddProductComponent } from './components/add-product/add-product.component';
import { TsumButtonModule } from '@tsum/ui';
import { UiModule } from '../../ui/ui.module';

const COMPONENTS = [
    AddProductComponent,
];

@NgModule({
    imports: [
        CommonModule,
        UiModule,
        SharedModule,
        TsumButtonModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class AddProductFeatureModule {}
