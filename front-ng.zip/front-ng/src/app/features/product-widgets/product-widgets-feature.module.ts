import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PriceWidgetComponent } from './price-widget/price-widget.component';
import { SharedModule } from '../../shared/shared.module';
import { DescriptionWidgetComponent } from './description-widget/description-widget.component';
import { UiModule } from '../../ui/ui.module';
import { RouterModule } from '@angular/router';
import { SoundWidgetComponent } from './sound-widget/sound-widget.component';
import { TsumIconsModule } from '@tsum/ui';
import { AdditionalDescriptionWidgetComponent } from './additional-description-widget/additional-description-widget.component';
import { WidgetFrameComponent } from './widget-frame/widget-frame.component';

const COMPONENTS = [
    PriceWidgetComponent,
    DescriptionWidgetComponent,
    SoundWidgetComponent,
    AdditionalDescriptionWidgetComponent,
    WidgetFrameComponent,
];

@NgModule({
    declarations: [
        ...COMPONENTS,
    ],
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        RouterModule,
        TsumIconsModule,
    ],
    exports: [
        ...COMPONENTS,
    ],
    providers: [],
})
export class ProductWidgetsFeature {}
