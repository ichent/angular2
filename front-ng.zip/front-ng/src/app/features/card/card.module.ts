import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardComponent } from './card.component';
import { TsumIconsModule } from '@tsum/ui';
import { UiSpinnerModule } from '../../ui/modules/spinner/ui-spinner.module';


@NgModule({
    imports: [
        CommonModule,
        TsumIconsModule,
        UiSpinnerModule,
    ],
    declarations: [
        CardComponent,
    ],
    providers: [],
    exports: [
        CardComponent,
    ],
})
export class CardModule {}
