import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { CatalogCardDescriptionComponent } from './components/catalog-card-description/catalog-card-description.component';
import { CatalogCardFooterComponent } from './components/catalog-card-footer/catalog-card-footer.component';
import { CatalogCardPhotoComponent } from './components/catalog-card-photo/catalog-card-photo.component';
import { CatalogCardComponent } from './components/catalog-card/catalog-card.component';
import { ProductFeatureModule } from '../product/product-feature.module';
import { ProductListFeatureModule } from '../product-list/product-list-feature.module';
import { RouterModule } from '@angular/router';
import { CatalogCardsComponent } from './components/catalog-cards/catalog-cards.component';
import { CatalogCardMediumComponent } from './components/catalog-card-medium/catalog-card-medium.component';
import { CatalogCardMediumFooterComponent } from './components/catalog-card-medium-footer/catalog-card-medium-footer.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CatalogCardSmallComponent } from './components/catalog-card-small/catalog-card-small.component';
import { SelectableSmallProductCardComponent } from './components/selectable-small-product-card/selectable-small-product-card.component';
import { TsumButtonModule } from '@tsum/ui';
import { AddProductFeatureModule } from '../add-product/add-product-feature.module';

const COMPONENTS = [
    CatalogCardDescriptionComponent,
    CatalogCardFooterComponent,
    CatalogCardPhotoComponent,
    CatalogCardComponent,
    CatalogCardsComponent,
    CatalogCardMediumComponent,
    CatalogCardMediumFooterComponent,
    CatalogCardSmallComponent,
    SelectableSmallProductCardComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        ProductFeatureModule,
        ProductListFeatureModule,
        RouterModule,
        ReactiveFormsModule,
        TsumButtonModule,
        AddProductFeatureModule,
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ],
})
export class CatalogCardFeatureModule {
}
