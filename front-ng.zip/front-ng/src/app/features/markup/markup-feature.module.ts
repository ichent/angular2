import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageHeaderComponent } from './components/page-header/page-header.component';
import { ObserversModule } from '@angular/cdk/observers';
import { FlexModule } from '@angular/flex-layout';
import { BreadcrumbsComponent } from './components/breadcrumbs/breadcrumbs.component';
import { UiModule } from '../../ui/ui.module';
import { RouterModule } from '@angular/router';
import { ScrollTopButtonComponent } from './components/scroll-top-button/scroll-top-button.component';
import { TsumIconsModule } from '@tsum/ui';

const COMPONENTS = [
    PageHeaderComponent,
    BreadcrumbsComponent,
    ScrollTopButtonComponent,
];

@NgModule({
    imports: [
        CommonModule,
        UiModule,
        ObserversModule,
        FlexModule,
        RouterModule,
        TsumIconsModule,
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
})
export class MarkupFeatureModule {
}
