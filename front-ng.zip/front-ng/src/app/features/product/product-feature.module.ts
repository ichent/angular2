import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProductPriceComponent } from './components/product-price/product-price.component';
import { UiModule } from 'src/app/ui/ui.module';
import { ProductTagComponent } from './components/product-tag/product-tag.component';
import { ProductDeliveryComponent } from './components/product-delivery/product-delivery.component';
import { ProductInfoComponent } from './components/product-info/product-info.component';
import { ProductSizesComponent } from './components/product-sizes/product-sizes.component';
import { ProductDescriptionComponent } from './components/product-description/product-description.component';
import { ProductColorsComponent } from './components/product-colors/product-colors.component';
import { SizeFeatureModule } from '../size/size-feature.module';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ProductStockSizesComponent } from './components/product-stocks-sizes/product-stock-sizes.component';
import { DeliveryTimePipe } from './pipes/delivery-times.pipe';
import { StockSizesComponent } from './components/stock-sizes/stock-sizes.component';
import { TsumButtonModule, TsumScrollModule } from '@tsum/ui';
import { CountRemainingPhotoPipe } from './pipes/count-remaining-photo.pipe';

const COMPONENTS = [
    ProductPriceComponent,
    ProductTagComponent,
    ProductDeliveryComponent,
    ProductInfoComponent,
    ProductSizesComponent,
    ProductDescriptionComponent,
    ProductColorsComponent,
    ProductStockSizesComponent,
    StockSizesComponent,
];

const PIPES = [
    DeliveryTimePipe,
    CountRemainingPhotoPipe,
];

@NgModule({
    declarations: [
        ...COMPONENTS,
        ...PIPES,
    ],
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        SizeFeatureModule,
        RouterModule,
        ReactiveFormsModule,
        TsumScrollModule,
        TsumButtonModule,
    ],
    exports: [
        ...COMPONENTS,
        ...PIPES,
    ],
    providers: [
        DeliveryTimePipe,
    ],
})
export class ProductFeatureModule {
}
