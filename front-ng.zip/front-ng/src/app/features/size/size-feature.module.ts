import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { SizeSelectComponent } from './components/size-select/size-select.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SizesComponent } from './components/sizes/sizes.component';
import { SizeValuePipe } from './pipes/size-value.pipe';
import { SizeTableLinkComponent } from './components/size-table-link/size-table-link.component';

const COMPONENTS = [
    SizeSelectComponent,
    SizesComponent,
    SizeTableLinkComponent,
];

@NgModule({
    declarations: [
        ...COMPONENTS,
        SizeValuePipe,
    ],
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        ReactiveFormsModule,
    ],
    exports: [
        ...COMPONENTS,
    ],
})
export class SizeFeatureModule {
}
