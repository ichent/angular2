import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FiltersPresetSidenavComponent } from './filters-preset-sidenav.component';
import { SharedModule } from '../../shared/shared.module';
import { ScrollAnchorFeatureModule } from '../../features/scroll-anchor/scroll-anchor-feature.module';
import { TsumButtonModule, TsumTagModule } from '@tsum/ui';
import { UiModule } from '../../ui/ui.module';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        ScrollAnchorFeatureModule,
        TsumTagModule,
        UiModule,
        TsumButtonModule,
    ],
    declarations: [FiltersPresetSidenavComponent],
    entryComponents: [FiltersPresetSidenavComponent],
    exports: [FiltersPresetSidenavComponent],
})
export class FiltersPresetSidenavModule {}
