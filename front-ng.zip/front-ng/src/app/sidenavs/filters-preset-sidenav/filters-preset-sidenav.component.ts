import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { first, takeUntil } from 'rxjs/operators';
import { CatalogFiltersTagsHelper } from '../../pages/catalog/components/catalog-filters-tags/helpers/catalog-filters-tags.helper';
import { Observable, Subject } from 'rxjs';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { Tag } from '../../ui/pipes/tag/tag.namespace';
import { CatalogFiltersTagsService } from '../../pages/catalog/components/catalog-filters-tags/services/catalog-filters-tags.service';

@Component({
    selector: 'app-filters-preset-sidenav',
    templateUrl: './filters-preset-sidenav.component.html',
    styleUrls: ['./filters-preset-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FiltersPresetSidenavComponent implements OnInit, OnDestroy {

    public tags$: Observable<Tag.Interface[]> = this.tagsService.tags$;

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private tagsService: CatalogFiltersTagsService,
    ) {}

    ngOnInit() {
        this.tags$
            .pipe(
                first((tags: Tag.Interface[]) => !tags.length),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.close());
    }

    public getValuesMap(key: string): Observable<Tag.Map> {
        return this.tagsService.getValuesMap(key);
    }

    public removeFilter(key: string): void {
        this.tagsService.removeFilter(key);
    }

    public removeFilterValue(filter: string, value: number | string): void {
        this.tagsService.removeFilterValue(filter, value);
    }

    public resetAll(): void {
        this.tagsService.resetAll();
    }

    public makeSubTags(parentTag: Tag.Interface): Tag.Interface[] {
        return CatalogFiltersTagsHelper.makeSubTags(parentTag);
    }

    public trackByKey(index: number, tag: Tag.Interface): string | number {
        return tag.key;
    }

    public close(): void {
        this.sidenavService.closeSidenav(FiltersPresetSidenavComponent);
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
