import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ClientWidgetCustomersSidenavComponent } from './client-widget-customers-sidenav.component';
import { ClientWidgetFeatureModule } from '../../features/client-widget/client-widget-feature.module';
import { TsumButtonModule } from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        RouterModule,
        ReactiveFormsModule,
        ClientWidgetFeatureModule,
        TsumButtonModule,
    ],
    declarations: [
        ClientWidgetCustomersSidenavComponent,
    ],
    entryComponents: [
        ClientWidgetCustomersSidenavComponent,
    ],
    exports: [
        ClientWidgetCustomersSidenavComponent,
    ],
})
export class ClientWidgetCustomersSidenavModule {
}
