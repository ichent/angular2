import { Component, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { finalize, map, switchMap, takeUntil } from 'rxjs/operators';
import { ClientWidgetCustomerItem, ClientWidgetCustomers } from '../../state/client/customers/customers.model';
import { ClientApiService } from '../../state/client/client-api.service';
import { ClientWidgetSearchQuery } from '../../state/client/search/search.query';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { ClientWidgetCustomersQuery } from '../../state/client/customers/customers.query';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';

@Component({
    selector: 'app-client-widget-customers-sidenav',
    templateUrl: './client-widget-customers-sidenav.component.html',
    styleUrls: ['./client-widget-customers-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClientWidgetCustomersSidenavComponent implements OnDestroy {

    public selectedCustomer: ClientWidgetCustomerItem;

    private isLoadingSubject$: BehaviorSubject<boolean> = new BehaviorSubject(false);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();

    public customers$: Observable<ClientWidgetCustomerItem[]> = this.clientWidgetCustomersQuery.select()
        .pipe(map((customers: ClientWidgetCustomers) => customers.items));

    public customer$: Observable<ClientWidgetCustomerItem> = this.clientWidgetCustomersQuery.selectMainCustomer();

    private destroyed$: Subject<void> = new Subject();

    constructor(
        protected sidenavService: SidenavService,
        private clientService: ClientApiService,
        private clientWidgetSearchQuery: ClientWidgetSearchQuery,
        private clientWidgetCustomersQuery: ClientWidgetCustomersQuery,
    ) {}

    public close(): void {
        this.sidenavService.closeSidenav(ClientWidgetCustomersSidenavComponent);
    }

    public save(): void {
        if (this.isLoadingSubject$.value) {
            return;
        }

        this.isLoadingSubject$.next(true);

        const clientWidgetSearch = this.clientWidgetSearchQuery.getValue();

        this.clientService.addCommunicationAddress({
            cmiId: this.selectedCustomer.cmiId,
            type: clientWidgetSearch.incomingType,
            address: clientWidgetSearch.incomingValue,
            mainContact: 1,
        })
            .pipe(
                switchMap(() => {
                    return this.clientService.findCustomersByIncomingParams({
                        address: clientWidgetSearch.incomingValue,
                        type: clientWidgetSearch.incomingType,
                    });
                }),
                finalize(() => {
                    this.isLoadingSubject$.next(false);
                    this.close();
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    public onSelectCustomer(customer: ClientWidgetCustomerItem): void {
        this.selectedCustomer = customer;
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
