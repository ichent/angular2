import { Injectable, OnDestroy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { PersistNgFormPlugin } from '@datorama/akita';
import { LooksCatalogQuery } from '../../state/looks-catalog/looks-catalog.query';

@Injectable()
export class LooksCatalogSidenavService implements OnDestroy {

    private form = new FormGroup({
        sort: new FormControl(),
        filters: new FormGroup({
            query: new FormControl(),
            category: new FormControl(),
            brand: new FormControl(),
            size: new FormControl(),
            color: new FormControl(),
            price: new FormControl(),
        }),
    });

    private persistForm: PersistNgFormPlugin;

    public get formGroup(): FormGroup {
        return this.form as FormGroup;
    }

    public get filters(): FormGroup {
        return this.form.controls.filters as FormGroup;
    }

    public get sort(): FormControl {
        return this.form.controls.sort as FormControl;
    }

    constructor(private looksCatalogQuery: LooksCatalogQuery) {
        this.persistForm = new PersistNgFormPlugin(this.looksCatalogQuery).setForm(this.form);
    }

    ngOnDestroy() {
        this.persistForm.destroy();
    }

}
