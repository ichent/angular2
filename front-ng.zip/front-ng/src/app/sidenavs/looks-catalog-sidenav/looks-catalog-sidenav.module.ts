import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UiModule } from '../../ui/ui.module';
import { LooksCatalogSidenavComponent } from './looks-catalog-sidenav.component';
import { LooksCatalogComponent } from './looks-catalog/looks-catalog.component';
import { LooksCatalogHeaderComponent } from './looks-catalog-header/looks-catalog-header.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { SharedModule } from '../../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { LooksCatalogFiltersComponent } from './looks-catalog-filters/looks-catalog-filters.component';
import { TsumButtonModule, TsumSelectorModule } from '@tsum/ui';
import { TsumIconsModule } from '@tsum/ui';

@NgModule({
    declarations: [
        LooksCatalogSidenavComponent,
        LooksCatalogComponent,
        LooksCatalogHeaderComponent,
        LooksCatalogFiltersComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        ReactiveFormsModule,
        UiModule,
        ScrollingModule,
        CatalogCardFeatureModule,
        TsumIconsModule,
        TsumSelectorModule,
        TsumButtonModule,
    ],
    entryComponents: [
        LooksCatalogSidenavComponent,
    ],
    exports: [
        LooksCatalogSidenavComponent,
    ],
})
export class LooksCatalogSidenavModule {}
