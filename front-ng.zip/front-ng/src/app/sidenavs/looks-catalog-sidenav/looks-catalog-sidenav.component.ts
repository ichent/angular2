import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { LooksCatalogQuery } from '../../state/looks-catalog/looks-catalog.query';
import { LooksCatalogService } from '../../state/looks-catalog/looks-catalog.service';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Page } from '../../constants/routes/page.enum';
import { ListItem, ProductList } from '../../state/product-list/product-list.interface';
import { takeUntil, tap } from 'rxjs/operators';
import { LookListProductsService } from '../../state/look-list-products/look-list-products.service';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { Product } from '../../state/products/product.interface';
import { LooksCatalogSidenavService } from './looks-catalog-sidenav.service';

@Component({
    selector: 'app-looks-catalog-sidenav',
    templateUrl: './looks-catalog-sidenav.component.html',
    styleUrls: ['./looks-catalog-sidenav.component.styl'],
    providers: [LooksCatalogSidenavService],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LooksCatalogSidenavComponent implements OnDestroy {

    private looksCatalogFormGroup: FormGroup = this.looksCatalogSidenavService.formGroup;
    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private looksCatalogService: LooksCatalogService,
        private looksCatalogQuery: LooksCatalogQuery,
        private lookListProductsService: LookListProductsService,
        private looksCatalogSidenavService: LooksCatalogSidenavService,
        private router: Router,
    ) {}

    public close(): void {
        this.sidenavService.closeSidenav(LooksCatalogSidenavComponent);
        this.looksCatalogService.removeAllFromSelected();
    }

    public reset(): void {
        this.looksCatalogFormGroup.reset();
    }

    public cancel(): void {
        this.looksCatalogService.removeAllFromSelected();
        this.close();
    }

    public apply(): void {
        const selected: Record<number, Product> = this.looksCatalogQuery.getValue().selected;

        if (Object.keys(selected).length) {
            this.addSelectedItemsToLook();
        }

        this.close();
    }

    private addSelectedItemsToLook(): void {
        const items: Partial<ListItem>[] = this.looksCatalogQuery.getSelectedAsArray().map((product: Product) => ({
            itemId: product.id,
            modelId: product.modelId
        }));

        this.lookListProductsService.addProductsToCurrentLook(items)
            .pipe(
                tap((look: ProductList) => {
                    if (look.isDraft) {
                        this.router.navigate([Page.Look, 'edit', look.id]);
                    }
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
