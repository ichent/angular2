import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CartSidenavComponent } from './cart-sidenav.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { RouterModule } from '@angular/router';
import { TsumButtonModule } from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        ProductFeatureModule,
        RouterModule,
        TsumButtonModule,
    ],
    declarations: [
        CartSidenavComponent,
    ],
    entryComponents: [
        CartSidenavComponent,
    ],
    exports: [
        CartSidenavComponent,
    ],
})
export class CartSidenavModule {
}
