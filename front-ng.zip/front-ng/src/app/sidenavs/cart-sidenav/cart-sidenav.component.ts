import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { combineLatest, defer, Observable, of, Subject } from 'rxjs';
import { filter, map, switchMap, takeUntil } from 'rxjs/operators';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { PRODUCTS_TITLES } from '../../constants/common/products-titles.constant';
import { ClipboardService } from 'ngx-clipboard';
import { NotificationService } from '../../services/notification.service';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { SUCCESS_COPIED } from '../../constants/notification/texts.constant';
import { animate, style, transition, trigger } from '@angular/animations';
import { UserService } from '../../services/user.service';
import { SaveSidenavComponent } from '../save-sidenav/save-sidenav.component';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { SkuItem } from '../../interfaces/sku.interface';
import { Page } from '../../constants/routes/page.enum';
import { Product } from '../../state/products/product.interface';
import { CartProduct } from '../../state/cart/interfaces/cart-product.interface';
import { CartQuery } from '../../state/cart/cart.query';
import { CartService } from '../../state/cart/cart.service';
import { ContextService } from '../../state/context/context.service';
import { OrderCreationSidenavComponent } from '../orders/order-create-edit-sidenav/order-creation-sidenav/order-creation-sidenav.component';
import { OrderApiService } from '../../state/orders/order-api.service';
import {
    CART_CANCEL_TITLES,
    REMOVE_PRODUCT_BUTTON_TITLES,
    SIDENAV_NAVIGATE_TITLE,
    SIDENAV_TITLE_PREFIXES,
} from '../../constants/cart.constant';
import { ContextQuery } from '../../state/context/context.query';
import { OrdersQuery } from '../../state/orders/orders.query';
import { TsumConfirmService } from '@tsum/ui';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';
import { CartPageContext } from '../../interfaces/contexts/cart-page-contexts.interface';
import { Order } from '../../state/orders/interfaces/order.interface';

@Component({
    selector: 'app-cart-sidenav',
    templateUrl: './cart-sidenav.component.html',
    styleUrls: ['./cart-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    animations: [
        trigger('slideInOut', [
            transition(':enter', [
                style({ 'transform': 'translateY(100%)' }),
                animate('.3s', style({ 'transform': 'translateY(0)' })),
            ]),
            transition(':leave', [
                style({ 'transform': 'translateY(0)' }),
                animate('.3s', style({ 'transform': 'translateY(100%)' })),
            ]),
        ]),
    ],
})
export class CartSidenavComponent implements OnInit, OnDestroy {

    public cartProducts$: Observable<CartProduct[]> = this.contextQuery.selectCatalogPageContext()
        .pipe(
            switchMap((context: CatalogPageContext) => {
                switch (context) {
                    case CatalogPageContext.Cart:
                        return this.cartQuery.selectAll();
                    case CatalogPageContext.OrderEdit:
                        return this.ordersQuery.selectActive()
                            .pipe(
                                map((order: Order) => this.cartService.mapOrderToCartProducts(order)),
                            );
                }
                return of(null);
            })
        );

    public isOrderContext$ = this.contextQuery.selectCatalogPageContext()
        .pipe(
            map((context: CatalogPageContext) => context === CatalogPageContext.Cart),
        );

    public activeOrderTitle$: Observable<string> = this.ordersQuery.selectActive()
        .pipe(
            map((order: Order) => order?.number),
        );

    public cartProductsCount$: Observable<number> = this.cartProducts$
        .pipe(
            map((cartProducts: CartProduct[]) => cartProducts.length)
        );

    public isMoreActionsAvailable$: Observable<boolean> = combineLatest([
        this.contextQuery.selectCatalogPageContext()
            .pipe(
                map((catalogPageContext: CatalogPageContext) => catalogPageContext === CatalogPageContext.OrderEdit),
            ),
        this.cartProductsCount$.pipe(map(Boolean)),
    ])
        .pipe(
            map(([isOrderContext, hasProducts]: boolean[]) => !isOrderContext && hasProducts),
        );

    public isCartValid$: Observable<boolean> = this.cartProducts$
        .pipe(
            map((cartProducts: CartProduct[]) => !cartProducts.some((cartProduct: CartProduct) => !cartProduct.skuId))
        );

    public isLoading$: Observable<boolean> = this.cartQuery.selectLoading();

    public productCountWordForms: string[] = PRODUCTS_TITLES;

    public titlePrefix$: Observable<string> = this.contextQuery.selectCatalogPageContext()
        .pipe(
            map((catalogPageContext: CatalogPageContext) => SIDENAV_TITLE_PREFIXES[catalogPageContext]),
        );

    public removeButtonTitle$: Observable<string> = this.contextQuery.selectCatalogPageContext()
        .pipe(
            map((catalogPageContext: CatalogPageContext) => REMOVE_PRODUCT_BUTTON_TITLES[catalogPageContext]),
        );

    public cancelButtonTitle$: Observable<string> = this.contextQuery.selectCatalogPageContext()
        .pipe(
            map((catalogPageContext: CatalogPageContext) => CART_CANCEL_TITLES[catalogPageContext]),
        );

    public navigateButtonTitle$: Observable<string> = this.contextQuery.selectCatalogPageContext()
        .pipe(
            map((catalogPageContext: CatalogPageContext) => SIDENAV_NAVIGATE_TITLE[catalogPageContext]),
        );

    public isWidgetActionsVisible = false;

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private contextService: ContextService,
        private contextQuery: ContextQuery,
        private cartQuery: CartQuery,
        private cartService: CartService,
        private router: Router,
        private clipboardService: ClipboardService,
        private notificationService: NotificationService,
        private confirmService: TsumConfirmService,
        private userService: UserService,
        private cd: ChangeDetectorRef,
        private orderApiService: OrderApiService,
        private ordersQuery: OrdersQuery,
    ) {}

    ngOnInit() {
        this.router.events
            .pipe(
                filter((event: RouterEvent) => event instanceof NavigationEnd),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.close());
    }

    public close(): void {
        this.sidenavService.closeSidenav(CartSidenavComponent);
    }

    public removeProduct(uuid: string): void {
        this.cartService.removeProductFromCart(uuid);
    }

    public copyArticle(article: string): void {
        this.clipboardService.copyFromContent(article);

        this.notificationService.pushNotifications([
            {
                type: UiNotificationType.Info,
                title: SUCCESS_COPIED,
                timeoutClose: TimeoutNotificationConstant.fast,
            },
        ]);
    }

    public toggleWidgetActionsVisibility(): void {
        this.isWidgetActionsVisible = !this.isWidgetActionsVisible;
        this.cd.detectChanges();
    }

    public getPhotoUrl(product: Product): string {
        return product && product.photos && product.photos[0]
            ? product.photos[0].middle
            : null;
    }

    public openCheckout(): void {
        this.toggleWidgetActionsVisibility();

        this.orderApiService.createOrder()
            .subscribe(() => {
                this.contextService.setPageContext({ resource: Page.Cart, context: CartPageContext.OrderEdit });
                this.sidenavService.openSidenav(OrderCreationSidenavComponent);
            });
    }

    public onCancel(): void {
        const catalogPageContext: CatalogPageContext = this.contextQuery.getCatalogPageContext();

        this.toggleWidgetActionsVisibility();

        if (catalogPageContext === CatalogPageContext.Cart) {
            this.confirmService.open({
                title: 'Отменить создание заказа?',
                type: 'error',
                description: 'Очистка приведет к удалению корзины и всех ее товаров',
                additionalDescription: 'Очистить?',
                buttonText: 'Очистить и удалить корзину',
                secondButtonText: 'Отменить',
                successMethod: defer(() => of(this.clearCart())),
            });
        }
    }

    public clearCart(): void {
        this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.List });
        this.close();
    }

    public onNavigate(): void {
        const catalogPageContext: CatalogPageContext = this.contextQuery.getCatalogPageContext();

        if (catalogPageContext === CatalogPageContext.Cart) {
            this.router.navigateByUrl(`/${Page.Cart}`);
        } else if (catalogPageContext === CatalogPageContext.OrderEdit) {
            this.router.navigate([`/${Page.Order}`, this.ordersQuery.getActiveId()]);
        }
    }

    public getSizeTitle(cartProduct: CartProduct): string {
        if (!cartProduct.skuId) {
            return 'не выбран';
        }

        return cartProduct.sizeAttributes && Object.entries(cartProduct.sizeAttributes).length
            ? cartProduct.sizeAttributes.russianSize || cartProduct.sizeAttributes.vendorSize
            : cartProduct.product.skuList.find((sku: SkuItem) => sku.id === cartProduct.skuId).size.title;
    }

    ngOnDestroy() {
        this.sidenavService.closeSidenav(SaveSidenavComponent);
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
