import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { FilterFeatureModule } from '../../features/filters/filter-feature.module';
import { ProductFilterSidenavComponent } from './product-filter-sidenav.component';
import { UiModule } from '../../ui/ui.module';
import { TsumButtonModule, TsumRangeModule } from '@tsum/ui';
import { IMaskModule } from 'angular-imask';

const COMPONENTS = [
    ProductFilterSidenavComponent,
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        FilterFeatureModule,
        UiModule,
        TsumRangeModule,
        TsumButtonModule,
        IMaskModule,
    ],
    declarations: COMPONENTS,
    entryComponents: COMPONENTS,
    exports: COMPONENTS,
})
export class ProductFilterSidenavModule { }
