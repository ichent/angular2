import { Country } from '../../state/dictionaries/countries/contry.model';
import { ColorInterface } from '../../pages/catalog/interfaces/color.interface';
import { Brand } from '../../interfaces/brand.interface';
import { FormControl } from '@angular/forms';
import { filter, map, takeUntil } from 'rxjs/operators';
import { FormGroup } from '@angular/forms';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { LabelInterface } from 'src/app/pages/catalog/interfaces/label.interface';
import { BrandsQuery } from '../../state/dictionaries/brands/brands.query';
import { ColorsQuery } from '../../state/dictionaries/colors/colors.query';
import { CountriesQuery } from '../../state/dictionaries/countries/countries.query';
import { SeasonsQuery } from '../../state/dictionaries/seasons/seasons.query';
import { Season } from '../../state/dictionaries/seasons/season.model';
import { ProductAttributesQuery } from '../../state/dictionaries/product-attributes/product-attributes.query';
import { Warehouse } from '../../state/dictionaries/warehouses/warehouse.model';
import { WarehousesQuery } from '../../state/dictionaries/warehouses/warehouses.query';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { CatalogFiltersQuery } from '../../state/catalog-filters/catalog-filters.query';
import { CatalogFiltersService } from '../../state/catalog-filters/catalog-filters.service';
import { initialFiltersState } from '../../state/catalog-filters/catalog-filters.store';
import { CatalogFilters } from '../../state/catalog-filters/catalog-filters.interface';
import { TransformHelper } from '../../helpers/transform.helper';
import IMask from 'imask';
import { DeliveryPlanService } from '../../state/delivery-plan/delivery-plan.service';
import { DeliveryPlanQuery } from '../../state/delivery-plan/delivery-plan.query';

const INITIAL_FILTERS_STATE = initialFiltersState();

@Component({
    selector: 'app-product-filter-sidenav',
    templateUrl: './product-filter-sidenav.component.html',
    styleUrls: ['./product-filter-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductFilterSidenavComponent implements OnInit, OnDestroy  {

    public filtersForm = new FormGroup({
        brands: new FormControl(),
        designCountry: new FormControl(),
        vendorCountry: new FormControl(),
        colors: new FormControl(),
        seasons: new FormControl(),
        availableInStocks: new FormControl(),
        labels: new FormControl(),
        fromPrice: new FormControl(),
        toPrice: new FormControl(),
    });

    public deliveryCityControl: FormControl = new FormControl(this.deliveryPlanQuery.getDeliveryCity());

    public seasons$: Observable<Season[]> = this.seasonsQuery.selectVisibleSeasons();
    public warehouses$: Observable<Warehouse[]> = this.warehousesQuery.selectAll();
    public labels$: Observable<LabelInterface[]> = this.labelsQuery.selectVisibleLabels();
    public brands$: Observable<Brand[]> = this.brandsQuery.selectAll();
    public colors$: Observable<ColorInterface[]> = this.colorsQuery.selectAll();
    public countries$: Observable<Country[]> = this.countriesQuery.selectAll();

    public fromPriceMask = new IMask.MaskedNumber({ mask: Number, thousandsSeparator: ' ', min: 0 });
    public toPriceMask = new IMask.MaskedNumber({ mask: Number, thousandsSeparator: ' ', min: 1 });

    private appliedFiltersSubject$ = new BehaviorSubject<Partial<CatalogFilters>>(null);
    private appliedFilters$: Observable<Partial<CatalogFilters>> = this.appliedFiltersSubject$.pipe(filter(Boolean));

    public filterCountBadge$: Observable<number> = this.appliedFilters$
        .pipe(
            map(({ labels, fromPrice, toPrice, availableInStocks, seasons }) =>
                ([!!labels, !!fromPrice || !!toPrice, !!availableInStocks, !!seasons])
            ),
            map((values: boolean[]) => values.filter(Boolean).length),
        );

    public brandsCountBadge$: Observable<number> = this.appliedFilters$
        .pipe(map(({ brands = [] }: Partial<CatalogFilters>) => brands.length));

    public colorsCountBadge$: Observable<number> = this.appliedFilters$
        .pipe(map(({ colors = [] }: Partial<CatalogFilters>) => colors.length));

    public countriesCountBadge$: Observable<number> = this.appliedFilters$
        .pipe(
            map(({ designCountry = [], vendorCountry = [] }: Partial<CatalogFilters>) => designCountry.length + vendorCountry.length),
        );

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private brandsQuery: BrandsQuery,
        private colorsQuery: ColorsQuery,
        private countriesQuery: CountriesQuery,
        private warehousesQuery: WarehousesQuery,
        private seasonsQuery: SeasonsQuery,
        private labelsQuery: ProductAttributesQuery,
        private deliveryPlanService: DeliveryPlanService,
        private deliveryPlanQuery: DeliveryPlanQuery,
        private catalogFiltersQuery: CatalogFiltersQuery,
        private catalogFiltersService: CatalogFiltersService,
    ) {}


    ngOnInit() {
        this.filtersForm.valueChanges
            .pipe(
                map(TransformHelper.filterEmptyValues),
                takeUntil(this.destroyed$),
            )
            .subscribe((filters: Partial<CatalogFilters>) => this.appliedFiltersSubject$.next(filters));

        const filters = this.catalogFiltersQuery.getValue().filters;
        this.filtersForm.patchValue(filters);
    }

    public close(): void {
        this.sidenavService.closeSidenav(ProductFilterSidenavComponent);
    }

    public resetFilter(): void {
        this.filtersForm.reset(INITIAL_FILTERS_STATE);
    }

    public applyFilter(): void {
        this.deliveryPlanService.setDeliveryCity(this.deliveryCityControl.value);
        this.catalogFiltersService.patchFilters(this.filtersForm.value);
        this.close();
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
