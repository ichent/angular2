import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { BuyGiftCardSidenavComponent } from './buy-gift-card-sidenav.component';
import { UiModule } from '../../ui/ui.module';
import { TsumButtonModule, TsumInputModule, TsumSecondarySidepanelSelectorModule, TsumSelectorModule } from '@tsum/ui';
import { ReactiveFormsModule } from '@angular/forms';
import { GiftCardCatalogFormComponent } from './components/gift-card-catalog-form/gift-card-catalog-form.component';
import { IMaskModule } from 'angular-imask';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        TsumButtonModule,
        ReactiveFormsModule,
        TsumInputModule,
        TsumSelectorModule,
        IMaskModule,
        TsumSecondarySidepanelSelectorModule,
    ],
    declarations: [
        BuyGiftCardSidenavComponent,
        GiftCardCatalogFormComponent,
    ],
    entryComponents: [
        BuyGiftCardSidenavComponent,
    ],
    exports: [
        BuyGiftCardSidenavComponent,
    ],
})
export class BuyGiftCardSidenavModule { }
