import { Component, ChangeDetectionStrategy, OnInit, OnDestroy } from '@angular/core';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { GiftCardType } from '../../state/gift-card/interfaces/gift-card.interface';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map, startWith, takeUntil } from 'rxjs/operators';
import { TsumSecondarySidepanelSelector } from '@tsum/ui';
import { GiftCardCatalog } from '../../interfaces/gift-card-product.interface';
import { GIFT_CARD_TYPE_OPTIONS } from '../../constants/gift-card.constant';

@Component({
    selector: 'app-buy-gift-card-sidenav',
    templateUrl: './buy-gift-card-sidenav.component.html',
    styleUrls: ['./buy-gift-card-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BuyGiftCardSidenavComponent implements OnInit, OnDestroy {

    public typeOptions: TsumSecondarySidepanelSelector.Option[] = GIFT_CARD_TYPE_OPTIONS;

    private initialGiftCardValue: GiftCardCatalog = {
        style: null,
        balance: null,
        customBalance: null,
        amount: null,
    };

    public giftCardsForm = new FormGroup({
        type: new FormControl([GiftCardType.Virtual]),
        cards: new FormArray([]),
    });

    private isVirtualSubject$ = new BehaviorSubject<boolean>(true);
    public isVirtual$: Observable<boolean> = this.isVirtualSubject$.asObservable();

    private controlsCount$: Observable<number> = this.giftCardArray.valueChanges
        .pipe(
            startWith(null),
            map(() => this.giftCardArray.controls.length),
        );
    public isTitleVisible$: Observable<boolean> = this.controlsCount$
        .pipe(
            map((count: number) => count > 1),
        );
    public isAddDisabled$: Observable<boolean> = this.controlsCount$
        .pipe(
            map((count: number) => count >= 10),
        );

    private isCheckoutDisabledSubject$ = new BehaviorSubject<boolean>(true);
    public isCheckoutDisabled$: Observable<boolean> = this.isCheckoutDisabledSubject$.asObservable();

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
    ) {}

    ngOnInit() {
        this.addGiftCard();

        this.giftCardTypeControl.valueChanges
            .pipe(
                map((value: GiftCardType) => value === GiftCardType.Virtual),
                takeUntil(this.destroyed$),
            )
            .subscribe((isVirtual: boolean) => this.isVirtualSubject$.next(isVirtual));


        this.giftCardArray.valueChanges
            .pipe(
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.isCheckoutDisabledSubject$.next(this.giftCardArray.invalid));

    }

    public get giftCardArray(): FormArray {
        return this.giftCardsForm.controls.cards as FormArray;
    }

    public get giftCardTypeControl(): FormControl {
        return this.giftCardsForm.controls.type as FormControl;
    }

    public removeGiftCard(index: number): void {
        this.giftCardArray.removeAt(index);
    }

    public addGiftCard(): void {
        this.giftCardArray.push(new FormControl(this.initialGiftCardValue));
        this.isCheckoutDisabledSubject$.next(true);
    }

    public close(): void {
        this.sidenavService.closeSidenav(BuyGiftCardSidenavComponent);
    }

    public clear(): void {
        this.giftCardArray.clear();
        this.addGiftCard();
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
