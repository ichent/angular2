import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProductCategoryFilterSidenavComponent } from './product-category-filter-sidenav.component';
import { FilterFeatureModule } from '../../features/filters/filter-feature.module';
import { UiModule } from 'src/app/ui/ui.module';
import { TsumButtonModule } from '@tsum/ui';

const COMPONENTS = [
    ProductCategoryFilterSidenavComponent,
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        FilterFeatureModule,
        UiModule,
        TsumButtonModule,
    ],
    declarations: COMPONENTS,
    entryComponents: COMPONENTS,
    exports: COMPONENTS,
})
export class ProductCategoryFilterSidenavModule { }
