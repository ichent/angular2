import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Category } from '../../state/dictionaries/categories/category.model';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { FormControl } from '@angular/forms';
import { CatalogFiltersService } from '../../state/catalog-filters/catalog-filters.service';
import { CatalogFiltersQuery } from '../../state/catalog-filters/catalog-filters.query';
import { CategoriesQuery } from '../../state/dictionaries/categories/categories.query';

@Component({
    selector: 'app-product-category-filter-sidenav',
    templateUrl: './product-category-filter-sidenav.component.html',
    styleUrls: ['./product-category-filter-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductCategoryFilterSidenavComponent implements OnInit, OnDestroy {

    public categoriesControl = new FormControl();
    public categories$: Observable<Category[]> = this.categoriesQuery.selectAll();

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private categoriesQuery: CategoriesQuery,
        private catalogFiltersQuery: CatalogFiltersQuery,
        private catalogFiltersService: CatalogFiltersService,
    ) {}

    ngOnInit() {
        this.setAppliedValue();

        this.sidenavService.sidenavState(ProductCategoryFilterSidenavComponent)
            .pipe(
                filter((opened: boolean) => !opened),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.setAppliedValue());
    }

    public close(): void {
        this.sidenavService.closeSidenav(ProductCategoryFilterSidenavComponent);
    }

    public resetCatalogFilter(): void {
        this.categoriesControl.setValue([]);
    }

    public applyCatalogFilter(): void {
        this.catalogFiltersService.patchFilters({ categories: this.categoriesControl.value });
        this.close();
    }

    private setAppliedValue(): void {
        const filters = this.catalogFiltersQuery.getValue().filters;
        this.categoriesControl.setValue(filters.categories);
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
