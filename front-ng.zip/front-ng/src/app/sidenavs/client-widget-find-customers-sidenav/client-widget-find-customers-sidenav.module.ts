import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { RouterModule } from '@angular/router';
import { ClientWidgetFindCustomersSidenavComponent } from './client-widget-find-customers-sidenav.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ClientWidgetFeatureModule } from '../../features/client-widget/client-widget-feature.module';
import { TsumButtonModule, TsumIconsModule, TsumInputModule } from '@tsum/ui';
import { IMaskModule } from 'angular-imask';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        RouterModule,
        ReactiveFormsModule,
        ClientWidgetFeatureModule,
        TsumInputModule,
        TsumIconsModule,
        IMaskModule,
        TsumIconsModule,
        TsumButtonModule,
    ],
    declarations: [
        ClientWidgetFindCustomersSidenavComponent,
    ],
    entryComponents: [
        ClientWidgetFindCustomersSidenavComponent,
    ],
    exports: [
        ClientWidgetFindCustomersSidenavComponent,
    ],
})
export class ClientWidgetFindCustomersSidenavModule {
}
