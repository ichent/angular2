import { ChangeDetectionStrategy, Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {
    catchError,
    distinctUntilChanged,
    filter,
    finalize,
    map,
    switchMap,
    takeUntil,
    tap,
} from 'rxjs/operators';
import { asyncScheduler, BehaviorSubject, Observable, of, scheduled, Subject } from 'rxjs';
import { CustomersSearchParams } from '../../features/client-widget/interfaces/client-widget.interface';
import { ClientApiService } from '../../state/client/client-api.service';
import { atLeastOneIsSetValidator } from '../../validators/at-least-one-is-set.valdiator';
import { ClientWidgetCustomerItem, ClientWidgetCustomers } from '../../state/client/customers/customers.model';
import { ClientWidgetSearchQuery } from '../../state/client/search/search.query';
import { ClientWidgetCustomersQuery } from '../../state/client/customers/customers.query';
import { isEqual as _isEqual } from 'lodash';
import { emailValidator } from '../../validators/email.validator';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { BaseApiResponse } from '../../services/api/base-api.service';
import IMask from 'imask';
import { LOYALTY_CARD_PATTERN_MASK } from '../../ui/modules/masks/constants/loyalty-card-mask.constant';

@Component({
    selector: 'app-client-widget-find-customers-sidenav',
    templateUrl: './client-widget-find-customers-sidenav.component.html',
    styleUrls: ['./client-widget-find-customers-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClientWidgetFindCustomersSidenavComponent implements OnInit, OnDestroy {

    public form: FormGroup;
    public bonusCardMask = new IMask.MaskedPattern({ mask: LOYALTY_CARD_PATTERN_MASK });

    public customer$: Observable<ClientWidgetCustomerItem> = this.clientWidgetCustomersQuery.selectMainCustomer();
    public selectedCustomer: ClientWidgetCustomerItem;

    private isSearchingSubject$: BehaviorSubject<boolean> = new BehaviorSubject(false);
    public isSearching$: Observable<boolean> = this.isSearchingSubject$.asObservable();

    public customersCounter = 0;
    private customersSubject$ = new BehaviorSubject<ClientWidgetCustomerItem[]>([]);
    public customers$: Observable<ClientWidgetCustomerItem[]> = this.customersSubject$.asObservable()
        .pipe(
            tap(() => this.customersCounter++),
        );
    public customersCount$: Observable<number> = this.customers$
        .pipe(
            map((customersItems: ClientWidgetCustomerItem[]) => customersItems.length),
        );

    private isLoadingSubject$: BehaviorSubject<boolean> = new BehaviorSubject(false);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();

    private destroyed$: Subject<void> = new Subject();
    private formValues$: Subject<CustomersSearchParams> = new Subject();

    public get isEmailControlInvalid(): boolean {
        const control = this.form.controls.email as FormControl;
        return control.errors !== null && control.dirty && control.touched;
    }

    public get isDiscCardHolderDiscCardInvalid(): boolean {
        const control = this.form.controls.discCardHolderDiscCard as FormControl;
        return control.errors !== null && control.dirty && control.touched;
    }

    constructor(
        protected sidenavService: SidenavService,
        private clientWidgetService: ClientApiService,
        private clientWidgetSearchQuery: ClientWidgetSearchQuery,
        private clientWidgetCustomersQuery: ClientWidgetCustomersQuery,
    ) {

        this.form = new FormGroup({
            fullName: new FormControl(''),
            order: new FormControl(''),
            discCardHolderId: new FormControl(''),
            phone: new FormControl(''),
            email: new FormControl('', emailValidator),
            discCardHolderDiscCard: new FormControl('', [
                Validators.minLength(16),
                Validators.maxLength(16)
            ]),
        }, { validators: atLeastOneIsSetValidator });
    }

    ngOnInit() {
        // дожидаемся пока отработают phone-mask и phone-prefix директивы
        scheduled(this.formValues$, asyncScheduler)
            .pipe(
                distinctUntilChanged(_isEqual),
                filter(() => this.form.valid),
                tap(() => this.isSearchingSubject$.next(true)),
                switchMap((searchParams: CustomersSearchParams) => {
                    return this.clientWidgetService.findCustomersBySearchParams(searchParams).pipe(
                        catchError(() => of({})),
                        finalize(() => this.isSearchingSubject$.next(false)),
                    );
                }),
                finalize(() => this.isSearchingSubject$.next(false)),
                takeUntil(this.destroyed$),
            )
            .subscribe((customersResponse: ClientWidgetCustomers) => this.customersSubject$.next(customersResponse.items));
    }

    public close(): void {
        this.sidenavService.closeSidenav(ClientWidgetFindCustomersSidenavComponent);
    }

    public search(): void {
        this.formValues$.next(this.form.value);
    }

    public clearForm(form: HTMLFormElement): void {
        form.reset();
        this.customersSubject$.next([]);
    }

    public onSelectCustomer(customer: ClientWidgetCustomerItem): void {
        this.selectedCustomer = customer;
    }

    public onKeyPress(event: KeyboardEvent) {
        if (event.key === 'Enter') {
            this.search();
        }
    }

    public save(): void {
        if (this.isLoadingSubject$.value || !this.selectedCustomer) {
            return;
        }

        this.isLoadingSubject$.next(true);

        const clientWidgetSearch = this.clientWidgetSearchQuery.getValue();

        this.clientWidgetService.addCommunicationAddress({
            cmiId: this.selectedCustomer.cmiId,
            type: clientWidgetSearch.incomingType,
            address: clientWidgetSearch.incomingValue,
            mainContact: 1,
        })
            .pipe(
                finalize(() => {
                    this.isLoadingSubject$.next(false);
                    this.close();
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe((data: ClientWidgetCustomerItem) => {
                this.clientWidgetService.setCustomers({
                    items: [data],
                    total: 1,
                    page: 1,
                    perPage: 50
                });
            });
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
