import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from 'src/app/ui/ui.module';
import { ProductLooksSidenavComponent } from './product-looks-sidenav.component';
import { ProductLooksSliderComponent } from './product-looks-slider/product-looks-slider.component';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { TsumButtonModule, TsumScrollModule } from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        CatalogCardFeatureModule,
        ProductFeatureModule,
        TsumScrollModule,
        TsumButtonModule,
    ],
    declarations: [
        ProductLooksSidenavComponent,
        ProductLooksSliderComponent,
    ],
    entryComponents: [
        ProductLooksSidenavComponent,
    ],
    exports: [
        ProductLooksSidenavComponent,
    ],
})
export class ProductLooksSidenavModule { }
