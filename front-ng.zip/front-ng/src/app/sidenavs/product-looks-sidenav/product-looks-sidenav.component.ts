import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { ProductsQuery } from '../../state/products/products.query';
import { BehaviorSubject, combineLatest, Observable, of, Subject } from 'rxjs';
import { distinctUntilChanged, finalize, map, switchMap, takeUntil } from 'rxjs/operators';
import { ProductListApiService } from '../../state/product-list/product-list-api.service';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { ProductLooksSliderComponent } from './product-looks-slider/product-looks-slider.component';
import { ListItem } from '../../state/product-list/product-list.interface';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { Look, LookItem } from '../../interfaces/catalog.interface';
import { ProductAdditionalData } from '../../state/products-additional-data/product-additional-data.interface';
import { ProductAdditionalDataRepository } from '../../state/products-additional-data/product-additional-data.repository';
import { Product } from '../../state/products/product.interface';
import { ContextQuery } from '../../state/context/context.query';
import { SelectedSizesQuery } from '../../state/selected-sizes/selected-sizes.query';
import { OrderApiService } from '../../state/orders/order-api.service';
import { ID } from '@datorama/akita';
import { OrdersQuery } from '../../state/orders/orders.query';
import { ProductSkuSizes } from '../../features/size/interfaces/product-sku-sizes.interface';
import { PageWithContext } from '../../interfaces/contexts/page-contexts.interface';
import { Page } from '../../constants/routes/page.enum';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';
import { OrderPageContext } from '../../interfaces/contexts/order-page-contexts.interface';

@Component({
    selector: 'app-product-looks-sidenav',
    templateUrl: './product-looks-sidenav.component.html',
    styleUrls: ['./product-looks-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductLooksSidenavComponent implements OnInit {

    @Input()
    public productId: number;

    @ViewChild(ProductLooksSliderComponent)
    private productLooksSliderComponent: ProductLooksSliderComponent;

    public productLooks$: Observable<Look[]>;

    public addAllProductsButtonText: string = null;

    private selectedLookSubject$ = new BehaviorSubject<Look>(null);
    private selectedLook$: Observable<Look> = this.selectedLookSubject$.asObservable();

    private isLookSelected$: Observable<boolean> = this.selectedLook$.pipe(map(Boolean));

    private isAllProductsHaveSelectedSizes$: Observable<boolean> = this.selectedLook$
        .pipe(
            map(this.getLookProductIds),
            switchMap((productIds: number[]) => this.selectedSizesQuery.selectIsAllSelected(productIds)),
        );

    private isAddAllOrderButtonActive$: Observable<boolean> = combineLatest([
        this.isLookSelected$,
        this.isAllProductsHaveSelectedSizes$,
    ]).pipe(map((conditions: boolean[]) => conditions.every(Boolean)));

    public isAddAllButtonActive$: Observable<boolean> = this.contextQuery.selectCatalogPageContext()
        .pipe(
            switchMap((catalogPageContext: CatalogPageContext) => {
                switch (catalogPageContext) {
                    case CatalogPageContext.List:
                        return of(true);
                    case CatalogPageContext.Cart:
                        return this.isAddAllOrderButtonActive$;
                    case CatalogPageContext.OrderEdit:
                        return this.isAddAllOrderButtonActive$;
                    default:
                        return of(false);
                }
            }),
        );

    private isAddingAllSubject$ = new BehaviorSubject(false);
    public isAddingAll$: Observable<boolean> = this.isAddingAllSubject$.asObservable();

    private destroyed$ = new Subject<void>();

    constructor(
        private productsQuery: ProductsQuery,
        private productListApiService: ProductListApiService,
        private orderApiService: OrderApiService,
        private ordersQuery: OrdersQuery,
        private productListQuery: ProductListQuery,
        private productAdditionalDataRepository: ProductAdditionalDataRepository,
        private sidenavService: SidenavService,
        private contextQuery: ContextQuery,
        private cd: ChangeDetectorRef,
        private selectedSizesQuery: SelectedSizesQuery,
    ) {}

    ngOnInit() {
        this.productLooks$ = this.productAdditionalDataRepository.selectProductAdditionalData(this.productId)
            .pipe(
                map((productAdditionalData: ProductAdditionalData) => productAdditionalData && productAdditionalData.looks),
                map((looks: Look[]) => looks.filter((look: Look) => {
                    const availableComponents: LookItem[] = look.components.filter((component: LookItem) =>
                        component.defaultSku.availabilityInStock
                    );

                    return availableComponents.length > 1;
                })),
            );

        this.contextQuery.selectPageWithContext()
            .pipe(
                distinctUntilChanged(),
                takeUntil(this.destroyed$),
            )
            .subscribe((pageWithContext: PageWithContext) => {
                this.addAllProductsButtonText = this.defineAddAllProductsButtonText(pageWithContext);
                this.cd.detectChanges();
            });
    }

    /**
     * Добавить все товары образа в список товаров или в заказ или куда-либо ещё
     */
    public onAddAllLookProducts(): void {
        if (this.isAddingAllSubject$.value) {
            return;
        }

        switch (this.contextQuery.getCurrentPage()) {
            case Page.Catalog:
                switch (this.contextQuery.getCatalogPageContext()) {
                    case CatalogPageContext.OrderEdit:
                        this.addLookToOrder(this.ordersQuery.getActiveId(), this.selectedLookSubject$.value);
                        break;

                    case CatalogPageContext.List:
                        this.addLookToList();
                        break;
                }
                break;
            case Page.Order:
                if (this.contextQuery.getOrderPageContext() === OrderPageContext.Edit) {
                    this.addLookToOrder(this.ordersQuery.getActiveId(), this.selectedLookSubject$.value);
                }
                break;
        }

        this.close();
    }

    public onSelectLook(look: Look): void {
        this.selectedLookSubject$.next(look);
    }

    private getLookProductIds(look: Look): number[] {
        if (!look?.components?.length) {
            return [];
        }

        return look.components
            .filter((product: LookItem) =>
                product?.defaultSku?.availabilityInStock && product?.id
            )
            .map((product: LookItem) => product.id);
    }

    public close(): void {
        this.sidenavService.closeSidenav(ProductLooksSidenavComponent);
    }

    private makeListItem(product: Product, sizeId: number = null): Partial<ListItem> {
        return {
            modelId: product.modelId,
            itemId: product.id,
            skuId: sizeId,
        };
    }

    /**
     * Добавить образ в текущий список товаров
     */
    private addLookToList(): void {
        const listItems: Partial<ListItem>[] = this.productLooksSliderComponent.lookProductsInStock
            .reduce((items: Partial<ListItem>[], product: Product) => {
                const selectedSizesIds: (number | string)[] = this.selectedSizesQuery.getBy(product.id);
                const listItems: Partial<ListItem>[] = selectedSizesIds.length
                    ? selectedSizesIds.map((sizeId: number) => this.makeListItem(product, sizeId))
                    : [this.makeListItem(product)];

                return items.concat(listItems);
            }, []);

        this.isAddingAllSubject$.next(true);

        this.productListApiService.addProductToList(this.productListQuery.getActiveId(), listItems)
            .pipe(
                finalize(() => this.isAddingAllSubject$.next(false)),
            )
            .subscribe();
    }

    /**
     * Добавить образ в заказ
     */
    private addLookToOrder(orderId: ID, look: Look): void {
        const productSkuSizes: ProductSkuSizes = this.selectedSizesQuery.getManyBy(this.getLookProductIds(look));
        this.isAddingAllSubject$.next(true);
        this.orderApiService.addProductsBySkuSizes(orderId, productSkuSizes)
            .pipe(
                finalize(() =>  this.isAddingAllSubject$.next(false)),
            )
            .subscribe();
    }

    private defineAddAllProductsButtonText(pageWithContext: PageWithContext): string {
        if (pageWithContext.resource === Page.Catalog) {
            switch (pageWithContext.context) {
                case CatalogPageContext.OrderEdit:
                    return 'Добавить в список весь образ';
                case CatalogPageContext.List:
                    return 'Добавить в заказ весь образ';
            }
        } else if (pageWithContext.resource === Page.Order) {
            if (pageWithContext.context === OrderPageContext.Edit) {
                return 'Добавить в список весь образ';
            }
        }

        return null;
    }

}
