import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UiModule } from '../../ui/ui.module';
import { ReactiveFormsModule } from '@angular/forms';
import { OrderProductNomenclatureSidenavComponent } from './order-product-nomenclature-sidenav.component';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { SidenavModule } from '../../ui/modules/sidenav/sidenav.module';
import { TsumButtonModule, TsumPaneModule } from '@tsum/ui';
import { SharedModule } from '../../shared/shared.module';

const COMPONENTS = [
    OrderProductNomenclatureSidenavComponent,
];

@NgModule({
    declarations: COMPONENTS,
    imports: [
        CommonModule,
        UiModule,
        ReactiveFormsModule,
        CatalogCardFeatureModule,
        ProductFeatureModule,
        SidenavModule,
        TsumButtonModule,
        TsumPaneModule,
        SharedModule,
    ],
    entryComponents: COMPONENTS,
})
export class OrderProductNomenclatureSidenavModule {}
