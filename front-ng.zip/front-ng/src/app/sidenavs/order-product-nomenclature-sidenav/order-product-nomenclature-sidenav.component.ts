import {
    ChangeDetectionStrategy,
    Component,
    Input,
    OnDestroy,
    OnInit,
    TemplateRef,
    ViewChild,
} from '@angular/core';
import { BehaviorSubject, combineLatest, Observable, Subject } from 'rxjs';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { Product } from '../../state/products/product.interface';
import { ProductsRepository } from '../../state/products/products.repository';
import { filter, finalize, map, switchMap, takeUntil } from 'rxjs/operators';
import { Column } from '../../ui/interfaces/table.interface';
import { ProductStock } from '../../state/orders/interfaces/order-product-stock.interface';
import { OrderApiService } from '../../state/orders/order-api.service';
import { OrdersQuery } from '../../state/orders/orders.query';
import { PRODUCTS_TITLES } from '../../constants/common/products-titles.constant';
import { Order } from '../../state/orders/interfaces/order.interface';
import { SkuSizesQuery } from '../../state/sku-sizes/sku-sizes.query';
import { SkuStock, Stock } from '../../state/sku-stocks/sku-stock.model';
import { SizeSkuListItem, SkuSizeItem } from '../../features/size/interfaces/sku-size.interface';
import { SkuStocksQuery } from '../../state/sku-stocks/sku-stocks.query';
import { SkuItem } from '../../interfaces/sku.interface';
import { SizeTableSidenavComponent } from '../size-table-sidenav/size-table-sidenav.component';
import { OrderDeliveryInterval } from '../orders/combine-orders-sidenav/interfaces/order-delivery-interval.interface';
import * as moment from 'moment';
import { DeliveryPlanQuery } from '../../state/delivery-plan/delivery-plan.query';
import { OrderValidationService } from '../../features/order/services/order-validation.service';

@Component({
    selector: 'app-order-product-nomenclature-sidenav',
    templateUrl: './order-product-nomenclature-sidenav.component.html',
    styleUrls: ['./order-product-nomenclature-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderProductNomenclatureSidenavComponent implements OnInit, OnDestroy {

    @Input()
    public productId: number;

    @ViewChild('selection', { static: true })
    public selectionTemplate: TemplateRef<number>;

    @ViewChild('delivery', { static: true })
    public deliveryTemplate: TemplateRef<number>;

    public productsTitles: string[] = PRODUCTS_TITLES;

    public selectedItemsSubject$ = new BehaviorSubject<number[]>([]);
    public selectedItems$: Observable<number[]> = this.selectedItemsSubject$.asObservable();

    public order: Order = this.orderQuery.getActive();

    private rowsSubject$ = new BehaviorSubject<ProductStock.Item[]>([]);
    public rows$: Observable<ProductStock.Item[]> = this.rowsSubject$.asObservable();

    public product$: Observable<Product>;

    private isSendingSubject$ = new BehaviorSubject<boolean>(false);
    public isSending$: Observable<boolean> = this.isSendingSubject$.asObservable();

    private columnsSubject$ = new BehaviorSubject<Column[]>(null);
    public columns$: Observable<Column[]> = this.columnsSubject$.asObservable();

    private deliveryIntervalsSubject$ = new BehaviorSubject<OrderDeliveryInterval[]>(null);
    public deliveryIntervals$: Observable<OrderDeliveryInterval[]> = this.deliveryIntervalsSubject$.asObservable();

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private orderApiService: OrderApiService,
        private orderQuery: OrdersQuery,
        private productsRepository: ProductsRepository,
        private skuStocksQuery: SkuStocksQuery,
        private skuSizesQuery: SkuSizesQuery,
        private deliveryPlanQuery: DeliveryPlanQuery,
        private orderValidationService: OrderValidationService,
    ) {}

    ngOnInit() {
        this.product$ = this.productsRepository.selectProducts([this.productId])
            .pipe(map((products: Product[]) => Array.isArray(products) && products[0] || null));

        combineLatest([
            this.skuStocksQuery.selectProductSkuStocks(this.productId),
            this.skuSizesQuery.selectEntity(this.productId).pipe(filter(Boolean)),
            this.product$.pipe(filter(Boolean)),
        ])
            .pipe(
                map(([skuStocks, skuSizeItem, product]: [SkuStock[], SkuSizeItem, Product]) =>
                    this.getProductStockItems(skuStocks, skuSizeItem, product)
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe((items: ProductStock.Item[]) => this.rowsSubject$.next(items));

        this.columnsSubject$.next(this.getColumns());

        this.selectedItems$
            .pipe(
                map((items: number[]) => this.getStockItemIds(items)),
                switchMap((itemIds: string[]) =>
                    this.orderApiService.getAddressDeliveryIntervalsBySku(
                        this.order.uuid,
                        this.deliveryPlanQuery.getDeliveryCity(),
                        itemIds,
                    )
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe((intervals: OrderDeliveryInterval[]) => this.deliveryIntervalsSubject$.next(intervals))
    }

    public get canAdd(): boolean {
        const { isValid } = this.orderValidationService.validateAddProduct(this.order, this.selectedItemsSubject$.value);

        return isValid;
    }

    public get selectedCount(): number {
        return this.selectedItemsSubject$.value.length;
    }

    public toggleItem(id: string): void {
        const selectedRows: Set<number> = new Set<number>(this.selectedItemsSubject$.value);
        const rowIndex: number = this.getRowIndex(id);
        if (rowIndex >= 0) {
            if (selectedRows.has(rowIndex)) {
                selectedRows.delete(rowIndex);
            } else {
                selectedRows.add(rowIndex);
            }
        }
        this.selectedItemsSubject$.next(Array.from(selectedRows));
    }

    public getDay(timestamp: number): string {
        return moment(timestamp).locale('ru').format('DD MMMM');
    }

    public isSelected(id: string): boolean {
        return this.selectedItemsSubject$.value.includes(this.getRowIndex(id));
    }

    public openSizeTable(product: Product): void {
        this.sidenavService.openSidenav(SizeTableSidenavComponent, { product });
    }

    public close(): void {
        this.sidenavService.closeSidenav(OrderProductNomenclatureSidenavComponent);
    }

    public addProducts(): void {
        if (this.isSendingSubject$.value) {
            return;
        }

        this.isSendingSubject$.next(true);
        const ids: string[] = this.selectedItemsSubject$.value
            .map((index: number) => `${this.rowsSubject$.value[index].id}`);

        this.orderApiService.addProductsBySkuExtIds(this.order.uuid, ids)
            .pipe(finalize(() => this.isSendingSubject$.next(false)))
            .subscribe(() => this.close());
    }

    private getProductStockItems(skuStocks: SkuStock[], skuSizeItem: SkuSizeItem, product: Product): ProductStock.Item[] {
        return skuStocks
            .filter((skuStock: SkuStock) => skuStock.stock.length > 0)
            .map((skuStock: SkuStock) => {
                const availableSkuListItem: SizeSkuListItem = skuSizeItem.skuList
                    .find((sizeSkuListItem: SizeSkuListItem) => skuStock.id === sizeSkuListItem.id);
                const skuItem: SkuItem = product.skuList.find((item: SkuItem) => item.id === availableSkuListItem.id);

                return {
                    id: skuItem.extGuid || skuItem.extId.toString(),
                    sizeName: availableSkuListItem.sizeAttributes.russianSize || availableSkuListItem.sizeAttributes.vendorSize,
                    quantity: skuStock.stock.reduce((count: number, stock: Stock) => count + stock.count, 0)
                };
            });
    }

    public getStockItemIds(items: number[]): string[] {
        return this.rowsSubject$.value
            .filter((stockItem: ProductStock.Item, index) => items.includes(index))
            .map((stockItem: ProductStock.Item) => stockItem.id);
    }

    private getRowIndex(id: string): number {
        return this.rowsSubject$.value.map((item: ProductStock.Item) => item.id).indexOf(id);
    }

    private getColumns(): Column[] {
        return [
            {
                title: 'Размер',
                baseWidth: '144px',
                render: (row: ProductStock.Item) => row.sizeName || '',
            },
            {
                title: 'Кол-во',
                baseWidth: '80px',
                render: (row: ProductStock.Item) => row.quantity || '',
            },
            {
                title: 'Добавить в заказ',
                baseWidth: '160px',
                template: this.selectionTemplate,
                render: (row: ProductStock.Item) => row.id || '',
            },
            {
                title: 'Доставка',
                baseWidth: '296px',
                template: this.deliveryTemplate,
                render: (row: ProductStock.Item) => row.id || '',
            },
        ];
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
