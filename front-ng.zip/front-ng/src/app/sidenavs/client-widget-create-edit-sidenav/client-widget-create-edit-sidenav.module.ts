import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ClientWidgetFeatureModule } from '../../features/client-widget/client-widget-feature.module';
import {
    ClientWidgetCreateEditSidenavComponent,
} from './components/client-widget-create-edit-sidenav/client-widget-create-edit-sidenav.component';
import {
    ClientWidgetCreateEditPreferredChannelsComponent,
} from './components/client-widget-create-edit-preferred-channels/client-widget-create-edit-preferred-channels.component';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { ClientWidgetCreateEditSidenavService } from './client-widget-create-edit-sidenav.service';
import { ClientWidgetCreateEditFormComponent } from './components/client-widget-create-edit-form/client-widget-create-edit-form.component';
import {
    ClientWidgetCreateEditFormArrayComponent,
} from './components/client-widget-create-edit-form-array/client-widget-create-edit-form-array.component';
import { TsumButtonModule, TsumCheckboxModule, TsumInputModule } from '@tsum/ui';
import { IMaskModule } from 'angular-imask';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        RouterModule,
        ReactiveFormsModule,
        ClientWidgetFeatureModule,
        CatalogCardFeatureModule,
        TsumInputModule,
        IMaskModule,
        TsumButtonModule,
        TsumCheckboxModule,
    ],
    declarations: [
        ClientWidgetCreateEditSidenavComponent,
        ClientWidgetCreateEditPreferredChannelsComponent,
        ClientWidgetCreateEditFormComponent,
        ClientWidgetCreateEditFormArrayComponent,
    ],
    entryComponents: [
        ClientWidgetCreateEditSidenavComponent,
    ],
    providers: [
        ClientWidgetCreateEditSidenavService,
    ],
    exports: [
        ClientWidgetCreateEditSidenavComponent,
    ],
})
export class ClientWidgetCreateEditSidenavModule {
}
