import { PHPBoolean } from '../../types/php-boolean.type';
import { CommunicationAddress } from '../../state/client/customers/customers.model';
import { FormControl } from '@angular/forms';
import { ClientWidget } from '../../constants/client-widget.constant';

export interface ClientWidgetCreateEditPreferredChannelsIcon {
    type: string;
    isInCRM: boolean;
    isPreferred: boolean;
}

export interface ClientWidgetCreateEditCustomer {
    fullName: string;
    isLinkedToIm: boolean;
    communicationAddresses: CommunicationAddress[];
}

export interface ClientWidgetCreateEditCustomerParams {
    lastName: string;
    firstName: string;
    middleName: string;
    forcedUnmarked: PHPBoolean;
}

export interface CreateEditFormValue {
    fullName: string;
    isLinkedToIm: boolean;
    preferred: Record<ClientWidget.IncomingType, string[]>;
    phone?: Record<string, string>;
    email?: Record<string, string>;
}
