import { Injectable } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ClientWidget } from '../../constants/client-widget.constant';
import { ClientWidgetCustomerItem, CommunicationAddress } from '../../state/client/customers/customers.model';
import { emailValidator } from '../../validators/email.validator';
import { MathHelper } from '../../helpers/math.helper';
import { ClientWidgetCustomersQuery } from '../../state/client/customers/customers.query';
import { ClientWidgetSearchQuery } from '../../state/client/search/search.query';
import { ClientWidgetHelper } from '../../features/client-widget/helpers/client-widget.helper';
import { ClientWidgetSearch } from '../../state/client/search/search.model';
import { CreateEditFormValue } from './client-widget-create-edit-sidenav.interface';

@Injectable({
    providedIn: 'root',
})
export class ClientWidgetCreateEditSidenavService {

    private types: ClientWidget.IncomingType[] = ClientWidget.ActiveIncomingTypes;
    public keysByType: Record<string, string[]> = {};
    private validators: Record<string, ValidatorFn[]> = {
        [ClientWidget.IncomingType.EmailKey]: [emailValidator],
        [ClientWidget.IncomingType.PhoneKey]: [Validators.pattern(/^\d{11}$/)],
    };
    private _addresses: CommunicationAddress[] = [];

    public get addresses(): CommunicationAddress[] {
        return this._addresses;
    }

    public createEditForm: FormGroup = new FormGroup({
        fullName: new FormControl('', Validators.required),
        isLinkedToIm: new FormControl(false),
        preferred: new FormControl({}),
    });

    constructor(
        private clientWidgetCustomersQuery: ClientWidgetCustomersQuery,
        private clientWidgetSearchQuery: ClientWidgetSearchQuery,
    ) {
        // TODO: fix in CMI-1106
        this.createEditForm.valueChanges.subscribe(() => this.setAddresses());
    }

    private setAddresses(): void {
        const value: CreateEditFormValue = this.createEditForm.getRawValue();
        const label = '';
        const weight = 0;

        this._addresses = this.types.reduce((addresses: CommunicationAddress[], type: ClientWidget.IncomingType) =>
            addresses.concat(Object.entries(value[type] || [])
                .filter(([_, address]: [string, string]) => !!address)
                .map(([uuid, address]: [string, string]) => {
                    const preferred = (value.preferred[type] && value.preferred[type].includes(uuid)) ? 1 : 0;

                    return { uuid, type, address, label, weight, preferred };
                })
            )
        , []);
    }

    public setForm(customer: ClientWidgetCustomerItem): void {
        const incoming: ClientWidgetSearch = this.clientWidgetSearchQuery.getValue();

        this.types.forEach((type: ClientWidget.IncomingType) => {
            const control = new FormGroup({});
            const typeKeys: string[] = [];
            const typeAddresses = customer && customer.communicationAddresses
                .filter((address: CommunicationAddress) => address.type === type);

            if (typeAddresses && typeAddresses.length) {
                typeAddresses.forEach((address: CommunicationAddress) => {
                    incoming.incomingValue === address.address
                        ? typeKeys.unshift(address.uuid)
                        : typeKeys.push(address.uuid);

                    control.addControl(address.uuid, new FormControl({
                        value: address.address,
                        disabled: incoming.incomingValue === address.address,
                    }, this.validators[type]));
                });
                this.setPreferredAddresses(customer.communicationAddresses);
            } else {
                const id: string = MathHelper.getUniqueId();
                const formState = incoming.incomingType === type
                    ? { value: incoming.incomingValue, disabled: true }
                    : null;

                typeKeys.push(id);
                control.addControl(id, new FormControl(formState, this.validators[type]));
            }

            this.keysByType[type] = typeKeys;
            this.createEditForm.removeControl(type);
            this.createEditForm.addControl(type, control);
        });

        this.createEditForm.patchValue({
            fullName: customer ? ClientWidgetHelper.getFullName(customer) : null,
            isLinkedToIm: customer ? Array.isArray(customer.propertyId) && customer.propertyId.includes('forced_unmarked') : false,
        });
    }

    private setPreferredAddresses(communicationAddresses: CommunicationAddress[]): void {
        this.createEditForm.controls.preferred.patchValue(communicationAddresses
            .reduce((types: Record<ClientWidget.IncomingType, string[]>, address: CommunicationAddress) => {
                if (address.preferred) {
                    if (!types[address.type]) {
                        types[address.type] = [];
                    }
                    types[address.type].push(address.uuid);
                }

                return types;
            }, {} as Record<ClientWidget.IncomingType, string[]>));
    }

    public addControl(type: ClientWidget.IncomingType): void {
        const control = this.createEditForm.get(type) as FormGroup;
        const id: string = MathHelper.getUniqueId();

        this.keysByType[type].push(id);
        control.addControl(id, new FormControl(null, this.validators[type]));
    }

    public removeControl(type: string, id: string): void {
        const control = this.createEditForm.get(type) as FormGroup;
        this.keysByType[type] = this.keysByType[type].filter((itemId: string) => itemId !== id);
        control.removeControl(id);
    }

}
