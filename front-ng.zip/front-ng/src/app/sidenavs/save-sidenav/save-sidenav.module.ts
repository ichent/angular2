import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from 'src/app/ui/ui.module';
import { ReactiveFormsModule } from '@angular/forms';
import { SaveSidenavComponent } from './save-sidenav.component';
import {
    TsumButtonModule,
    TsumInputModule,
    TsumPrimarySidepanelSelectorModule,
    TsumSecondarySidepanelSelectorModule
} from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        ReactiveFormsModule,
        TsumInputModule,
        TsumPrimarySidepanelSelectorModule,
        TsumSecondarySidepanelSelectorModule,
        TsumButtonModule,
    ],
    declarations: [
        SaveSidenavComponent,
    ],
    entryComponents: [
        SaveSidenavComponent,
    ],
    exports: [
        SaveSidenavComponent,
    ],
})
export class SaveSidenavModule { }
