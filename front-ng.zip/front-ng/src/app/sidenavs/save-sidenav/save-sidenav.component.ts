import { Component, OnInit, ChangeDetectionStrategy, OnDestroy, Input } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { finalize, switchMap, takeUntil, tap } from 'rxjs/operators';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { Router } from '@angular/router';
import { ProductListSaveRequest } from '../../interfaces/product-list.interface';
import { UserService } from '../../services/user.service';
import { User } from '../../interfaces/user.interface';
import { ProductList } from '../../state/product-list/product-list.interface';
import { ProductListApiService } from '../../state/product-list/product-list-api.service';
import { ListType } from '../../pages/lists/list-type.enum';
import * as moment from 'moment';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { NotificationService } from '../../services/notification.service';
import { LookListProductsQuery } from '../../state/look-list-products/look-list-products.query';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { PRODUCTS_TITLES } from '../../constants/common/products-titles.constant';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { CreateLinkSidenavComponent } from '../create-link-sidenav/create-link-sidenav.component';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { LookListProductsService } from '../../state/look-list-products/look-list-products.service';
import { Page, PageLists } from '../../constants/routes/page.enum';
import { ProductListService } from '../../state/product-list/product-list.service';
import { LooksCatalogService } from '../../state/looks-catalog/looks-catalog.service';
import { SUCCESS_SAVED } from '../../constants/notification/texts.constant';
import { TsumSecondarySidepanelSelector } from '@tsum/ui';

export type SaveSidenavType = 'list' | 'look';

export interface FormControlPlaceholder {
    valid: string;
    invalid: {
        [errorName: string]: string
    };
}

@Component({
    selector: 'app-save-sidenav',
    templateUrl: './save-sidenav.component.html',
    styleUrls: ['./save-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SaveSidenavComponent implements OnInit, OnDestroy {

    @Input()
    public type: SaveSidenavType;

    public form: FormGroup;
    private isLoadingSubject$: BehaviorSubject<boolean> = new BehaviorSubject(false);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();

    public visibleProductsCount: number;
    public invisibleProductsCount: number;
    public productCountWordForms: string[] = PRODUCTS_TITLES;
    public currentListType: string;
    public canSaveAsPrivateList: boolean;
    public canSaveAsPublicList: boolean;
    public canSaveAsCurrentListType: boolean;

    private isFirstSave: boolean = true;
    private destroyed$: Subject<void> = new Subject();

    public get isListChanged(): boolean {
        return (!this.form.value.listType || !this.form.value.listType.length)
            && (!this.isFirstSave
                || this.form.get('title').touched || this.form.get('title').dirty
                || this.form.get('description').touched || this.form.get('description').dirty);
    }

    public get isLook(): boolean {
        return this.type === 'look';
    }

    public get isList(): boolean {
        return this.type === 'list';
    }

    public get title(): string {
        if (this.isLook) {
            return 'Вы сохраняете в образе';
        } else if (this.isList) {
            return 'Сохранить список';
        }
    }

    public listTypeOptions: TsumSecondarySidepanelSelector.Option[] = [
        {
            key: ListType.Private,
            title: 'Личный',
        },
        {
            key: ListType.Public,
            title: 'Публичный',
        },
    ];


    private placeholders: { [controlName: string]: FormControlPlaceholder } = {
        title: {
            valid: 'Название образа',
            invalid: {
                minlength: 'Минимум 3 символа',
                maxlength: 'Не более 225 символов',
            }
        },
        description: {
            valid: 'Комментарий к образу',
            invalid: {
                minlength: 'Минимум 3 символа',
                maxlength: 'Не более 1000 символов',
            },
        },
    };

    constructor(
        private sidenavService: SidenavService,
        private productListApiService: ProductListApiService,
        private lookListProductsQuery: LookListProductsQuery,
        private lookListProductsService: LookListProductsService,
        private productListService: ProductListService,
        private productListQuery: ProductListQuery,
        private looksCatalogService: LooksCatalogService,
        private notificationService: NotificationService,
        private router: Router,
        private userService: UserService,
    ) {
        const formValidators: ValidatorFn[] = [
            Validators.required,
            Validators.minLength(3)
        ];

        this.form = new FormGroup({
            title: new FormControl('', [...formValidators, Validators.maxLength(255)]),
            description: new FormControl('', [...formValidators, Validators.maxLength(1000)]),
            listType: new FormControl([]),
        });
    }

    ngOnInit() {
        this.init();
    }

    private init(): void {
        const list: ProductList = this.getList();
        const user: User = this.userService.user;

        this.canSaveAsPrivateList = this.userService.canSaveAsPrivateList(list, user, list.status);
        this.canSaveAsPublicList = this.userService.canSaveAsPublicList(list, user, list.status);
        this.isFirstSave = !this.productListWasUpdated(list);
        this.currentListType = list.status;

        if (this.isLook) {
            const listProducts: ListProduct[] = this.lookListProductsQuery.getAll();
            [this.visibleProductsCount, this.invisibleProductsCount] = this.splitByVisibility(listProducts);
        }

        this.form.patchValue({
            title: list.listInfo.title,
            description: list.description,
            listType: list.status === 'draft' || list.status === null
                ? [ListType.Private]
                : [list.status]
        });

        this.canSaveAsCurrentListType = !(list.status === 'draft' || list.status === null);
    }

    public getFormControlPlaceholder(controlName: string): string {
        const formControl: AbstractControl = this.form.controls[controlName];

        if (!formControl || !this.placeholders[controlName]) {
            return;
        }

        const firstError: string = Object.keys(this.form.controls[controlName].errors || {})[0];

        return this.placeholders[controlName].invalid[firstError] || this.placeholders[controlName].valid;
    }

    public isInvalidFormControl(controlName: string): boolean {
        return this.form.controls[controlName].invalid;
    }

    public close(): Promise<void> {
        return this.sidenavService.closeSidenav(SaveSidenavComponent);
    }

    private getList(): ProductList {
        if (this.isLook) {
            return {items: null, ...this.lookListProductsQuery.getValue()} as ProductList;
        } else if (this.isList) {
            return this.productListQuery.getActive();
        }
    }

    private getListId(): number {
        if (this.isLook) {
            return this.lookListProductsQuery.getId();
        } else if (this.isList) {
            return this.productListQuery.getActiveId();
        }
    }

    private splitByVisibility(products: ListProduct[]): [number, number] {
        const visibleCount: number = products.filter((product: ListProduct) => product.listItem.visibility).length;
        return [visibleCount, products.length - visibleCount];
    }

    public submit(): void {
        if (this.form.invalid || this.isLoadingSubject$.getValue()) {
            return;
        }

        this.productListService.setIsSaving(true);
        this.isLoadingSubject$.next(true);

        const listType: ListType.Public | ListType.Private = this.form.value.listType;

        const redirectSegments: string[] = [
            '/',
            Page.Lists,
            this.isLook ? PageLists.Looks : PageLists.Products,
            listType || this.currentListType
        ];

        this.handleProductListRequest(listType)
            .pipe(
                switchMap((list: ProductList) => this.saveListByType(list)),
                tap((sentList: ProductList) => this.productListService.setRecentlyEditedList(sentList.id)),
                finalize(() => this.isLoadingSubject$.next(false)),
                switchMap(() => this.router.navigate(redirectSegments)),
                switchMap(() => this.close()),
                finalize(() => this.onLeave()),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    private saveListByType(list: ProductList): Observable<ProductList> {
        if (list.isLook) {
            return this.lookListProductsService.saveLookChanges(list.id);
        }

        return of(list)
            .pipe(
                tap(() => this.showNotification(SUCCESS_SAVED)),
            );
    }

    private handleProductListRequest(listType: ListType.Public | ListType.Private): Observable<ProductList> {
        const data: ProductListSaveRequest = {
            title: this.form.value.title,
            description: this.form.value.description,
        };

        if (!listType) {
            return this.productListApiService.saveProductList(this.getListId(), data);
        }

        if (this.copyProductListConditions(listType)) {
            return this.productListApiService.copyProductListAs(this.getListId(), listType, data);
        }

        return this.productListApiService.saveProductListAs(this.getListId(), listType, data);
    }

    private copyProductListConditions(listType: ListType.Public | ListType.Private): boolean {
        return this.currentListType === listType
            || (listType === ListType.Private && !this.canSaveAsPrivateList)
            || (listType === ListType.Public && !this.canSaveAsPublicList);
    }

    private showNotification(text: string): void {
        this.notificationService.pushNotifications([
            {
                type: UiNotificationType.Success,
                title: text,
                timeoutClose: TimeoutNotificationConstant.fast,
            },
        ]);
    }

    public clearForm(): void {
        this.form.reset();
    }

    public openCreateLinkSidenav(): void {
        this.sidenavService.openSidenav(CreateLinkSidenavComponent, { type: this.isLook ? 'look' : 'list' });
    }

    private productListWasUpdated (productList: ProductList): boolean {
        return moment(productList.updatedBy.date).isAfter(productList.createdBy.date);
    }

    private onLeave(): void {
        this.productListService.setCurrentProductList(null);
        if (this.isLook) {
            this.looksCatalogService.resetLookCatalogStore();
        }
    }

    ngOnDestroy() {
        this.productListService.setIsSaving(false);
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
