import { Component, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import {
    CommunicationAddressesByType,
    CommunicationAddressConfig,
} from '../../features/client-widget/interfaces/client-widget.interface';
import { ClientWidget } from '../../constants/client-widget.constant';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { filter, finalize, map, switchMap, takeUntil } from 'rxjs/operators';
import { ClientWidgetHelper } from '../../features/client-widget/helpers/client-widget.helper';
import { ClientWidgetCustomersQuery } from '../../state/client/customers/customers.query';
import {
    ClientWidgetCustomerItem,
    CommunicationAddress,
} from '../../state/client/customers/customers.model';
import { intersection as _intersection } from 'lodash';
import { ClientApiService } from '../../state/client/client-api.service';
import { ClientWidgetSearchQuery } from '../../state/client/search/search.query';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';

@Component({
    selector: 'app-client-widget-communication-addresses-sidenav',
    templateUrl: './client-widget-communication-addresses-sidenav.component.html',
    styleUrls: ['./client-widget-communication-addresses-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClientWidgetCommunicationAddressesSidenavComponent implements OnDestroy {

    private destroyed$ = new Subject<void>();

    private isLoadingSubject$: BehaviorSubject<boolean> = new BehaviorSubject(false);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();

    public communicationAddressesConfig: CommunicationAddressConfig[] = ClientWidget.CommunicationAddressesConfig;

    public saveButtonTitle$: Observable<string> = this.clientWidgetCustomersQuery.selectMainCustomer()
        .pipe(map((customer: ClientWidgetCustomerItem) => customer
            ? 'Сделать основным'
            : 'Выбрать'
        ));

    public customer$: Observable<ClientWidgetCustomerItem> = this.clientWidgetService.communicationAddressesCustomer$;

    public communicationAddresses$: Observable<CommunicationAddressesByType[]> = this.customer$
        .pipe(
            filter(Boolean),
            map((customer: ClientWidgetCustomerItem) => {
                return ClientWidgetHelper.getCommunicationAddressesByType(
                    customer.communicationAddresses,
                    this.communicationAddressesConfig,
                );
            }),
        );

    constructor(
        private clientWidgetCustomersQuery: ClientWidgetCustomersQuery,
        private clientWidgetService: ClientApiService,
        private clientWidgetSearchQuery: ClientWidgetSearchQuery,
        private sidenavService: SidenavService
    ) {}

    public close(): void {
        this.sidenavService.closeSidenav(ClientWidgetCommunicationAddressesSidenavComponent);
    }

    public isMainCommunicationAddressesGroup(communicationAddressType: string): boolean {
        const customer: ClientWidgetCustomerItem = this.clientWidgetService.communicationAddressesCustomer;
        const mainContacts: string[] = Object.keys(customer.mainContacts)
            .filter((contactKey: string) => customer.mainContacts[contactKey] === 1);
        const addressesByType: string[] = customer.communicationAddresses
            .filter((address: CommunicationAddress) => address.type === communicationAddressType)
            .map((address: CommunicationAddress) => address.uuid);


        return _intersection(mainContacts, addressesByType).length > 0;
    }

    public save(): void {
        if (this.isLoadingSubject$.value) {
            return;
        }

        this.isLoadingSubject$.next(true);

        const customer: ClientWidgetCustomerItem = this.clientWidgetService.communicationAddressesCustomer;
        const clientWidgetSearch = this.clientWidgetSearchQuery.getValue();

        this.clientWidgetService.addCommunicationAddress({
            cmiId: customer.cmiId,
            type: clientWidgetSearch.incomingType,
            address: clientWidgetSearch.incomingValue,
            mainContact: 1,
        })
            .pipe(
                switchMap(() => {
                    return this.clientWidgetService.findCustomersByIncomingParams({
                        address: clientWidgetSearch.incomingValue,
                        type: clientWidgetSearch.incomingType,
                    });
                }),
                finalize(() => {
                    this.isLoadingSubject$.next(false);
                    this.close();
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
