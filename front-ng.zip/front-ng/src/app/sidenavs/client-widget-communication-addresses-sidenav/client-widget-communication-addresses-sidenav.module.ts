import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { FilterFeatureModule } from '../../features/filters/filter-feature.module';
import { UiModule } from 'src/app/ui/ui.module';
import { ClientWidgetCommunicationAddressesSidenavComponent } from './client-widget-communication-addresses-sidenav.component';
import { ClientWidgetFeatureModule } from '../../features/client-widget/client-widget-feature.module';
import { TsumButtonModule } from '@tsum/ui';

const COMPONENTS = [
    ClientWidgetCommunicationAddressesSidenavComponent,
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        FilterFeatureModule,
        UiModule,
        ClientWidgetFeatureModule,
        TsumButtonModule,
    ],
    declarations: COMPONENTS,
    entryComponents: [
        ClientWidgetCommunicationAddressesSidenavComponent,
    ],
    exports: COMPONENTS,
})
export class ClientWidgetCommunicationAddressesSidenavModule {}
