import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SizeTableSidenavComponent } from './size-table-sidenav.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { TsumButtonModule } from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        TsumButtonModule,
    ],
    declarations: [
        SizeTableSidenavComponent,
    ],
    entryComponents: [
        SizeTableSidenavComponent,
    ],
    exports: [
        SizeTableSidenavComponent,
    ],
})
export class SizeTableSidenavModule { }
