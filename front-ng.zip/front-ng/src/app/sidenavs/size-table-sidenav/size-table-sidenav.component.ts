import { Subject } from 'rxjs';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { filter, takeUntil } from 'rxjs/operators';
import { Size } from '../../features/size/interfaces/size.interface';
import { range as _range } from 'lodash';
import { SizeLabel } from '../../features/size/interfaces/size-label.interface';
import { SizeTablesQuery } from '../../state/dictionaries/size-tables/size-tables.query';
import { SizeTable } from '../../state/dictionaries/size-tables/size-table.model';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { SizeTableService } from '../../state/dictionaries/size-tables/size-table.service';
import { Product } from '../../state/products/product.interface';
import { PreparedSizeTable, PreparedSizeTableColumn } from './prepared-size-table.interface';

@Component({
    selector: 'app-size-table-sidenav',
    templateUrl: './size-table-sidenav.component.html',
    styleUrls: ['./size-table-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SizeTableSidenavComponent implements OnInit, OnDestroy {

    @Input()
    public product: Product;

    public title: string;
    public sizeTableColumns: PreparedSizeTableColumn[];
    public rowsIndexes: number[];

    private destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private sizeTablesQuery: SizeTablesQuery,
        private sizeTableService: SizeTableService,
        private cd: ChangeDetectorRef,
    ) {}

    ngOnInit() {
        if (!this.sizeTablesQuery.hasEntity(this.product.id)) {
            this.sizeTableService.getSizeTable([this.product.categoryId]).subscribe();
        }

        this.sizeTablesQuery.selectEntity(this.product.categoryId)
            .pipe(
                filter(Boolean),
                takeUntil(this.destroyed$),
            )
            .subscribe((sizeTable: SizeTable) => {
                this.title = sizeTable.title;
                this.sizeTableColumns = this.getPreparedSizeData(sizeTable.mainLabel, sizeTable.sizes);

                const countRows: number = this.sizeTableColumns.length && this.sizeTableColumns[0].values.length;
                this.rowsIndexes = _range(countRows);
                this.cd.detectChanges();
            });
    }

    public close(): void {
        this.sidenavService.closeSidenav(SizeTableSidenavComponent);
    }

    public get rowWidth(): number {
        const rowsCount: number = this.sizeTableColumns.length;
        return rowsCount ? (100 / rowsCount) : 0;
    }

    private getPreparedSizeData(mainLabel: SizeLabel, sizes: Size[]): PreparedSizeTableColumn[] {
        if (!(mainLabel && sizes)) {
            return [];
        }

        const preparedSizeTable: PreparedSizeTable = {};
        const preparedSizeTableElements: PreparedSizeTableColumn[] = [];
        const mainLabelCode: string = mainLabel && mainLabel.code;

        sizes
            .filter((currentSize: Size) => this.filterByVisibleOrWithMainLabelCode(currentSize, mainLabelCode))
            .forEach((currentSize: Size) => {
                const currentLabel = currentSize.label;
                const currentLabelCode = currentLabel.code;

                if (preparedSizeTable[currentLabelCode] === undefined) {
                    preparedSizeTable[currentLabelCode] = {};
                    preparedSizeTable[currentLabelCode].values = [];
                }

                preparedSizeTable[currentLabelCode].labelText = currentLabel.title;
                preparedSizeTable[currentLabelCode].code = currentLabel.code;
                preparedSizeTable[currentLabelCode].values.push(currentSize.value);
            });

        Object.keys(preparedSizeTable).forEach((key: string) => {
            preparedSizeTableElements.push({
                labelText: preparedSizeTable[key].labelText,
                code: preparedSizeTable[key].code,
                values: preparedSizeTable[key].values,
            });
        });

        return preparedSizeTableElements.sort((a: PreparedSizeTableColumn) => a.code === mainLabelCode ? -1 : 1);
    }

    private filterByVisibleOrWithMainLabelCode(size: Size, mainLabelCode: string): boolean {
        return size.label.isVisible === true || (mainLabelCode && size.label.code === mainLabelCode);
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
