export interface PreparedSizeTableColumn {
    labelText?: string;
    code?: string;
    values?: string[];
}

export interface PreparedSizeTable {
    [key: string]: PreparedSizeTableColumn;
}
