import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, OnDestroy, TemplateRef, Input } from '@angular/core';
import { BehaviorSubject, combineLatest, defer, Observable, Subject } from 'rxjs';
import { distinctUntilChanged, filter, finalize, map, shareReplay, switchMap, takeUntil, tap } from 'rxjs/operators';
import { ListActions, ListItem, ProductList } from '../../state/product-list/product-list.interface';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { PRODUCTS_TITLES } from '../../constants/common/products-titles.constant';
import { ClipboardService } from 'ngx-clipboard';
import { NotificationService } from '../../services/notification.service';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { SUCCESS_COPIED } from '../../constants/notification/texts.constant';
import { animate, style, transition, trigger } from '@angular/animations';
import { UserService } from '../../services/user.service';
import { ProductListApiService } from '../../state/product-list/product-list-api.service';
import { ListProduct } from '../../interfaces/list-product/list-product.interface';
import { ProductListRepository } from '../../state/product-list/product-list.repository';
import { CreateLinkSidenavComponent } from '../create-link-sidenav/create-link-sidenav.component';
import { SaveSidenavComponent } from '../save-sidenav/save-sidenav.component';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { SkuItem } from '../../interfaces/sku.interface';
import { ListActionsService } from '../../pages/lists/services/list-actions.service';
import { Page } from '../../constants/routes/page.enum';
import { Product } from '../../state/products/product.interface';
import { User } from '../../interfaces/user.interface';
import { OrdersGuardHelper } from '../../helpers/orders-guard.helper';
import { ContextService } from '../../state/context/context.service';
import { CartService } from '../../state/cart/cart.service';
import { LookListProductsQuery } from '../../state/look-list-products/look-list-products.query';
import { CartSidenavComponent } from '../cart-sidenav/cart-sidenav.component';
import { UserRolesService } from '../../services/user-roles.service';
import { TsumConfirmService } from '@tsum/ui';
import { CatalogPageContext } from '../../interfaces/contexts/catalog-page-contexts.interface';

export type ProductListSidenavType = 'catalog' | 'preview';

@Component({
    selector: 'app-product-list-sidenav',
    templateUrl: './product-list-sidenav.component.html',
    styleUrls: ['./product-list-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    animations: [
        trigger('slideInOut', [
            transition(':enter', [
                style({ 'transform': 'translateY(100%)' }),
                animate('.3s', style({ 'transform': 'translateY(0)' })),
            ]),
            transition(':leave', [
                style({ 'transform': 'translateY(0)' }),
                animate('.3s', style({ 'transform': 'translateY(100%)' })),
            ]),
        ]),
    ],
})
export class ProductListSidenavComponent implements OnInit, OnDestroy {

    @Input()
    public id: number;

    @Input()
    public type: ProductListSidenavType;

    private listIdSubject$ = new BehaviorSubject<number>(null);

    public listProducts$: Observable<ListProduct[]> = this.listIdSubject$
        .pipe(
            distinctUntilChanged(),
            switchMap((listId: number) => this.productListRepository.selectListProducts(listId)),
            shareReplay(1),
        );

    public listProductCount$: Observable<number> = this.listProducts$
        .pipe(
            map((listProducts: ListProduct[]) => (listProducts || []).length),
            tap(() => this.isLoadingSubject$.next(false)),
        );

    public hasProducts$: Observable<boolean> = this.listProductCount$
        .pipe(map((count: number) => count > 0));

    private isLoadingSubject$ = new BehaviorSubject<boolean>(true);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();

    public isDoneButton$: Observable<boolean> = this.hasProducts$
        .pipe(map((hasProducts: boolean) => !hasProducts || this.isPreview));

    public productCountWordForms: string[] = PRODUCTS_TITLES;

    public isWidgetActionsVisible = false;

    public canClearList: boolean;
    public canSaveToClient: boolean;

    private destroyed$ = new Subject<void>();
    private isRemovingSubject$ = new BehaviorSubject(false);

    private get isRemoving(): boolean {
        return this.isRemovingSubject$.value;
    }

    private set isRemoving(value: boolean) {
        this.isRemovingSubject$.next(value);
    }

    public get isPreview(): boolean {
        return this.type === 'preview';
    }

    public get isCatalog(): boolean {
        return this.type === 'catalog';
    }

    public get previewActionTemplate(): TemplateRef<string> {
        return this.listActionsService.getActionsTemplate();
    }
    public get previewActions(): ListActions {
        return this.listActionsService.getActionsList();
    }

    constructor(
        private sidenavService: SidenavService,
        private productListRepository: ProductListRepository,
        private productListApiService: ProductListApiService,
        private router: Router,
        private clipboardService: ClipboardService,
        private notificationService: NotificationService,
        private userService: UserService,
        private cd: ChangeDetectorRef,
        private listActionsService: ListActionsService,
        private contextService: ContextService,
        private cartService: CartService,
        private lookListProductsQuery: LookListProductsQuery,
        private userRolesService: UserRolesService,
        private confirmService: TsumConfirmService,
    ) {}

    ngOnInit() {
        this.router.events
            .pipe(
                filter((event: RouterEvent) => event instanceof NavigationEnd),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.close());

        combineLatest([
            this.productListRepository.selectProductList(this.id).pipe(filter(Boolean)),
            this.userService.user$.pipe(filter(Boolean)),
        ])
            .pipe(
                takeUntil(this.destroyed$),
                tap(([list, user]: [ProductList, User]) => {
                    this.listIdSubject$.next(list.id);
                    this.isWidgetActionsVisible = false;

                    this.canClearList = this.userService.canDeleteList(list, user, list.status);
                    this.canSaveToClient = this.userService.canSaveToClient(list, user, list.status);

                    this.cd.detectChanges();
                }),
            )
            .subscribe();
    }

    public close(): void {
        this.sidenavService.closeSidenav(ProductListSidenavComponent);
    }

    public removeProduct(listProduct: ListProduct): void {
        if (this.isRemoving || !listProduct) {
            return;
        }

        this.isRemoving = true;
        this.isWidgetActionsVisible = false;

        this.productListApiService.removeProductFromList(this.id, listProduct.productListHash)
            .pipe(finalize(() => this.isRemoving = false))
            .subscribe();
    }

    public removeProductList(): Observable<object> {
        this.isRemoving = true;

        return this.productListApiService.removeProductList(this.id)
            .pipe(
                finalize(() => {
                    this.isRemoving = false;
                    this.close();
                }),
            );
    }

    public copyArticle(article: string): void {
        this.clipboardService.copyFromContent(article);

        this.notificationService.pushNotifications([
            {
                type: UiNotificationType.Info,
                title: SUCCESS_COPIED,
                timeoutClose: TimeoutNotificationConstant.fast,
            },
        ]);
    }

    public navigateToProductListPage(): void {
        this.router.navigate([Page.ProductList, this.id]);
    }

    public showProductListCreateLinkSidenav(): void {
        this.toggleWidgetActionsVisibility();
        this.sidenavService.openSidenav(CreateLinkSidenavComponent, { type: 'list' });
    }

    public showSaveProductListSidenav(): void {
        this.toggleWidgetActionsVisibility();
        this.sidenavService.openSidenav(SaveSidenavComponent, { type: 'list' });
    }

    public toggleWidgetActionsVisibility(): void {
        this.isWidgetActionsVisible = !this.isWidgetActionsVisible;
        this.cd.detectChanges();
    }

    public getPhotoUrl(product: Product): string | null {
        return product && product.photos && product.photos[0]
            ? product.photos[0].middle
            : null;
    }

    public openConfirmationDialog(): void {
        this.toggleWidgetActionsVisibility();

        this.confirmService.open({
            title: 'Хотите очистить список?',
            type: 'error',
            description: 'Очистка приведет к удалению списка и всех товаров из этого списка',
            additionalDescription: 'Очистить?',
            buttonText: 'Очистить и удалить список',
            secondButtonText: 'Отменить',
            successMethod: defer(() => this.removeProductList()),
        });
    }

    public onCreateLook(): void {
        this.router.navigateByUrl(`/${Page.Look}`);
    }

    public getSizeTitle(listProduct: ListProduct): string {
        const listItem: ListItem = listProduct.listItem;

        if (!listItem || !listItem.skuId) {
            return 'не выбран';
        }

        const skuList: SkuItem[] = listProduct.product.skuList;

        return skuList.find((sku: SkuItem) => sku.id === listItem.skuId).size.title;
    }

    public createCart(): void {
        if (this.userRolesService.canViewOrders(this.userService.user) || OrdersGuardHelper.isAccessAllowed()) {
            this.contextService.setPageContext({ resource: Page.Catalog, context: CatalogPageContext.Cart });
            this.cartService.convertCurrentListToCart();

            this.sidenavService.closeSidenav(ProductListSidenavComponent).then(() => this.sidenavService.openSidenav(CartSidenavComponent));
        }
    }

    ngOnDestroy() {
        this.sidenavService.closeSidenav(SaveSidenavComponent);
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
