export const SOURCES = [
    {
        value: 'phone',
        label: 'sms',
    },
    {
        value: 'email',
        label: 'email',
    },
    {
        value: 'whatsapp',
        label: 'whatsapp',
    },
    {
        value: 'viber',
        label: 'viber',
    },
    {
        value: 'facebook',
        label: 'facebook messenger',
    },
    {
        value: 'telegram',
        label: 'telegram',
    },
    {
        value: 'web_chat',
        label: 'чат на сайте',
    },
];
