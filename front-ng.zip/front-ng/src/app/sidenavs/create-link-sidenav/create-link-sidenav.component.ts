import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, Optional } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { BehaviorSubject, Observable, of, Subject } from 'rxjs';
import { map, switchMap, take, takeUntil, tap } from 'rxjs/operators';
import { ProductListCreateLinkRequest } from '../../interfaces/product-list.interface';
import { ClipboardService } from 'ngx-clipboard';
import { SOURCES } from './sources.constant';
import { Source } from './interfaces/sources.interface';
import { atLeastOneIsSetValidator } from '../../validators/at-least-one-is-set.valdiator';
import { ProductListApiService } from '../../state/product-list/product-list-api.service';
import { ProductList, ProductListErrorApi } from '../../state/product-list/product-list.interface';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { UiNotificationType } from '../../constants/notification/notification-type.constant';
import { TimeoutNotificationConstant } from '../../constants/notification/timeout-notification.constants';
import { NotificationService } from '../../services/notification.service';
import { LookListProductsQuery } from '../../state/look-list-products/look-list-products.query';
import { emailValidator } from '../../validators/email.validator';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { ListType } from '../../pages/lists/list-type.enum';
import { ProductListService } from '../../state/product-list/product-list.service';
import { Router } from '@angular/router';
import { Page, PageLists } from '../../constants/routes/page.enum';
import { ClientAttributes, CreateLinkForm } from './interfaces/create-link-form.interface';
import { SidenavComponent } from '../../ui/modules/sidenav/sidenav.component';
import { CcApiErrorResponse } from '../../interfaces/cc-api-response.interface';
import { emptyCmiIdValidator } from '../../validators/empty-cmi-id.validator';
import { LooksCatalogService } from '../../state/looks-catalog/looks-catalog.service';
import { LookListProductsService } from '../../state/look-list-products/look-list-products.service';

export type CreateLinkSidenavType = 'list' | 'look';
const DEFAULT_SOURCE_NAME = 'email';

const CLIENT_PHONE_FIELD_NAME = 'clientPhone';
const CLIENT_EMAIL_FIELD_NAME = 'clientEmail';

@Component({
    selector: 'app-create-link-sidenav',
    templateUrl: './create-link-sidenav.component.html',
    styleUrls: ['./create-link-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateLinkSidenavComponent implements OnInit, OnDestroy {

    @Input()
    public type: CreateLinkSidenavType;

    public form: FormGroup;
    public url: FormControl;
    private isLoadingSubject$ = new BehaviorSubject<boolean>(false);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();
    public sources: Source[] = SOURCES;
    private destroyed$ = new Subject<void>();
    private selectedProductHashes$: Observable<string[]> = this.productListQuery.selectActiveHashes();

    private get list(): ProductList {
        if (this.isLook) {
            return { items: null, ...this.lookListProductsQuery.getValue() } as ProductList;
        } else if (this.isProductList) {
            return this.productListQuery.getActive();
        }
    }

    private get clientAttributesGroup(): FormGroup {
        return this.form.controls.clientAttributes as FormGroup;
    }

    public get isLook(): boolean {
        return this.type === 'look';
    }

    public get isProductList(): boolean {
        return this.type === 'list';
    }

    constructor(
        private sidenavService: SidenavService,
        private productListApiService: ProductListApiService,
        private productListQuery: ProductListQuery,
        private lookListProductsQuery: LookListProductsQuery,
        private lookListProductsService: LookListProductsService,
        private cd: ChangeDetectorRef,
        private clipboardService: ClipboardService,
        private notificationService: NotificationService,
        private productListService: ProductListService,
        private router: Router,
        private looksCatalogService: LooksCatalogService,
        @Optional() private sidenav: SidenavComponent,
    ) {}

    ngOnInit() {
        this.initForm(this.list);
    }

    private initForm(list: ProductList): void {
        this.form = new FormGroup({
            clientTitle: new FormControl({ value: 'Индивидуальная подборка товаров', disabled: true }),
            clientAttributes: new FormGroup({
                [CLIENT_PHONE_FIELD_NAME]: new FormControl(list.clientPhone || null),
                [CLIENT_EMAIL_FIELD_NAME]: new FormControl(list.clientEmail || null),
                clientBirthday: new FormControl(list.clientDr || null),
                clientCmiId: new FormControl(null),
            }),
            communicationType: new FormControl(DEFAULT_SOURCE_NAME, Validators.required),
        });
        this.url = new FormControl(list.url || null);

        if (list.status === ListType.Sent) {
            this.form.disable();
        }
    }

    public setClientAttributesGroupValidators(event: Event = null) {
        const controls: {[key: string]: AbstractControl} = this.clientAttributesGroup.controls;
        const fields: string[] = Object.keys(controls);

        // TODO: это костыль, валидация срабатывает в этом кейсе только после blur
        // Во второй версии ui-kit должны это исправить
        if (event) {
            const inputElement: HTMLInputElement = event.target as HTMLInputElement;

            inputElement.setAttribute('tsum-touched', '');
        }

        fields.forEach((field: string) => {
            const validators = this.getClientAttributesGroupValidators(field);

            if (!atLeastOneIsSetValidator(this.clientAttributesGroup)) {
                if ([CLIENT_EMAIL_FIELD_NAME, CLIENT_PHONE_FIELD_NAME].includes(field) &&
                    this.clientAttributesGroup.controls[field].value
                ) {
                    controls[field].setValidators(validators);
                } else {
                    controls[field].clearValidators();
                }
            } else {
                controls[field].setValidators(validators);
            }

            controls[field].updateValueAndValidity();
        });
    }

    public close(): Promise<void> {
        return this.sidenav.close();
    }

    public generate(): void {
        this.setClientAttributesGroupValidators();

        if (this.form.invalid || this.isLoadingSubject$.value || !this.list || !this.list.id) {
            return;
        }

        this.isLoadingSubject$.next(true);
        this.productListService.setIsSaving(true);

        this.saveListChanges(this.list.id)
            .pipe(
                takeUntil(this.destroyed$),
                switchMap((listId: number) => this.sendList(listId)),
                tap(() => {
                    this.productListService.setCurrentProductList(null);

                    if (this.isLook) {
                        this.looksCatalogService.resetLookCatalogStore();
                    }
                }),
            )
            .subscribe({
                error: (errorResponse: CcApiErrorResponse<ProductListErrorApi>) => {
                    if (errorResponse.error.code === -1 && errorResponse.error.data.fields.includes('cmi_id')) {
                        this.isLoadingSubject$.next(false);
                        this.productListService.setIsSaving(false);

                        this.notificationService.pushNotifications([{
                            title: 'Такой CMI ID не найден',
                            type: UiNotificationType.Error,
                        }]);

                        this.clientAttributesGroup.controls['clientCmiId'].setValidators([emptyCmiIdValidator]);
                        this.clientAttributesGroup.controls['clientCmiId'].updateValueAndValidity();
                    }
                }
            });
    }

    public copyToClipboard(value: string): void {
        this.clipboardService.copyFromContent(value);
        this.notificationService.pushNotifications([
            {
                type: UiNotificationType.Info,
                title: 'Скопировано успешно',
                timeoutClose: TimeoutNotificationConstant.fast,
            },
        ]);
    }

    private saveListChanges(listId: number): Observable<number> {
        return this.isLook
            ? this.lookListProductsService.saveCurrentLookChanges(true).pipe(map((list: ProductList) => list.id))
            : this.selectedProductHashes$
                .pipe(
                    take(1),
                    switchMap((hashes: string[]) => !hashes.length
                        ? of(listId)
                        : this.productListApiService.partialCopy(listId, hashes, true)
                            .pipe(map((productList: ProductList) => productList.id))
                    )
                );
    }

    private sendList(listId: number): Observable<boolean> {
        const formValue: CreateLinkForm = this.form.getRawValue();
        const clientAttributes: ClientAttributes = formValue.clientAttributes;
        const clientPhone: string = clientAttributes.clientPhone;
        const data: ProductListCreateLinkRequest = {
            clientTitle: formValue.clientTitle,
            clientPhone: clientPhone ? clientPhone.toString().replace(/\D/g, '') : null,
            clientEmail: clientAttributes.clientEmail,
            clientDr: clientAttributes.clientBirthday,
            cmiId: clientAttributes.clientCmiId,
            communicationType: formValue.communicationType,
        };

        return this.productListApiService.markAsSent(listId, data)
            .pipe(
                tap((sentList: ProductList) => this.url.setValue(sentList.url)),
                tap(() => {
                    if (!this.destroyed$.isStopped) {
                        this.form.disable();
                        this.productListService.setIsSaving(false);
                        this.cd.detectChanges();
                    }
                }),
                tap((sentList: ProductList) => this.productListService.setRecentlyEditedList(sentList.id)),
                switchMap(() => this.sidenav.closed$),
                switchMap(() => {
                    return this.router.navigate([
                        Page.Lists,
                        this.isLook ? PageLists.Looks : PageLists.Products,
                        ListType.Sent,
                    ]);
                }),
            );
    }

    private getClientAttributesGroupValidators(fieldName): ValidatorFn[] {
        const validators = {
            [CLIENT_EMAIL_FIELD_NAME]: [Validators.required, emailValidator],
            [CLIENT_PHONE_FIELD_NAME]: [Validators.required, Validators.minLength(11), Validators.maxLength(11)],
        };

        return validators[fieldName] || [Validators.required];
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }
}
