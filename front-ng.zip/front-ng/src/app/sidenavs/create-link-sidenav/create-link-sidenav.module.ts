import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateLinkSidenavComponent } from './create-link-sidenav.component';
import { SharedModule } from '../../shared/shared.module';
import { UiModule } from '../../ui/ui.module';
import { ReactiveFormsModule } from '@angular/forms';
import { TsumButtonModule, TsumIconsModule, TsumInputModule, TsumSelectorModule } from '@tsum/ui';
import { IMaskModule } from 'angular-imask';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        ReactiveFormsModule,
        TsumSelectorModule,
        TsumInputModule,
        IMaskModule,
        TsumIconsModule,
        TsumButtonModule,
    ],
    declarations: [
        CreateLinkSidenavComponent,
    ],
    entryComponents: [
        CreateLinkSidenavComponent,
    ],
    exports: [
        CreateLinkSidenavComponent,
    ],
})
export class CreateLinkSidenavModule {
}
