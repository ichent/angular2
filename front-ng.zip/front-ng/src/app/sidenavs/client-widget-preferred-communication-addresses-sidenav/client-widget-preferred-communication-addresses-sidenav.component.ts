import { Component, ChangeDetectionStrategy } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { CommunicationAddressesByType, PreferredCommunicationAddresses } from '../../features/client-widget/interfaces/client-widget.interface';
import { ClientWidgetCreateEditSidenavService } from '../client-widget-create-edit-sidenav/client-widget-create-edit-sidenav.service';
import { ClientWidgetHelper } from '../../features/client-widget/helpers/client-widget.helper';
import { ClientWidget } from '../../constants/client-widget.constant';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';

@Component({
    selector: 'app-client-widget-preferred-communication-addresses-sidenav',
    templateUrl: './client-widget-preferred-communication-addresses-sidenav.component.html',
    styleUrls: ['./client-widget-preferred-communication-addresses-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClientWidgetPreferredCommunicationAddressesSidenavComponent {

    private isLoadingSubject$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    public isLoading$: Observable<boolean> = this.isLoadingSubject$.asObservable();
    public addresses: CommunicationAddressesByType[] = ClientWidgetHelper.getCommunicationAddressesByType(
        this.createEditSidenavService.addresses,
        ClientWidget.CommunicationAddressesConfig,
    );

    constructor(
        private sidenavService: SidenavService,
        private createEditSidenavService: ClientWidgetCreateEditSidenavService,
    ) {}

    public close(): void {
        this.sidenavService.closeSidenav(ClientWidgetPreferredCommunicationAddressesSidenavComponent);
    }

    public onChangeCommunicationAddresses(preferredAddresses: PreferredCommunicationAddresses): void {
        this.createEditSidenavService.createEditForm.controls.preferred.patchValue({
            ...this.createEditSidenavService.createEditForm.value.preferred,
            [preferredAddresses.type]: preferredAddresses.list
        });
    }
}
