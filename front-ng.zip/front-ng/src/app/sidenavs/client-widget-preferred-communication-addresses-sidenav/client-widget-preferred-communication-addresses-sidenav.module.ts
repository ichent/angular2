import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { FilterFeatureModule } from '../../features/filters/filter-feature.module';
import { UiModule } from 'src/app/ui/ui.module';
import {
    ClientWidgetPreferredCommunicationAddressesSidenavComponent,
} from './client-widget-preferred-communication-addresses-sidenav.component';
import {
    ClientWidgetCommunicationAddressesComponent,
} from './client-widget-communication-addresses/client-widget-communication-addresses.component';
import { TsumButtonModule } from '@tsum/ui';

const COMPONENTS = [
    ClientWidgetPreferredCommunicationAddressesSidenavComponent,
    ClientWidgetCommunicationAddressesComponent,
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        FilterFeatureModule,
        UiModule,
        TsumButtonModule,
    ],
    declarations: COMPONENTS,
    entryComponents: [
        ClientWidgetPreferredCommunicationAddressesSidenavComponent,
    ],
    exports: COMPONENTS,
})
export class ClientWidgetPreferredCommunicationAddressesSidenavModule {}
