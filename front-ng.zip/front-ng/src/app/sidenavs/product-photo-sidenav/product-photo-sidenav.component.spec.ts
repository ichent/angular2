import {
    createHostFactory,
    createServiceFactory,
    SpectatorHost,
    SpectatorService,
} from '@ngneat/spectator';
import { SidenavComponent } from '../../ui/modules/sidenav/sidenav.component';
import { ANALYZE_FOR_ENTRY_COMPONENTS, ComponentRef } from '@angular/core';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { ProductPhotoSidenavComponent } from './product-photo-sidenav.component';
import { SidenavModule } from '../../ui/modules/sidenav/sidenav.module';
import { MaterialModule } from '../../shared/material/material.module';
import { CatalogPhoto } from '../../interfaces/catalog.interface';
import { fakeAsync } from '@angular/core/testing';
import { TsumScrollModule } from '@tsum/ui';
import { UiSpinnerModule } from '../../ui/modules/spinner/ui-spinner.module';

describe('Product Photo Sidenav', () => {
    const title = 'Тестовый продукт';
    const brandName = 'Тестовый бренд';
    const photos: CatalogPhoto[] = [
        { small: 'test.jpg', middle: 'test_middle.jpg' },
        { small: 'other_photo.jpg', middle: 'other_photo_middle.jpg' },
    ];

    describe('via Sidenav Service', () => {
        let spectator: SpectatorService<SidenavService>;
        let sidenavComponent: SidenavComponent;
        let sidenavComponentHtmlElement: HTMLElement;

        const createService = createServiceFactory({
            service: SidenavService,
            imports: [
                TsumScrollModule,
                UiSpinnerModule,
                SidenavModule,
            ],
            declarations: [
                ProductPhotoSidenavComponent,
            ],
            entryComponents: [
                ProductPhotoSidenavComponent,
            ],
            providers: [
                {
                    provide: ANALYZE_FOR_ENTRY_COMPONENTS,
                    multi: true,
                    useValue: ProductPhotoSidenavComponent,
                },
            ],
        });

        beforeEach(() => {
            spectator = createService();
            spectator.service.openSidenav(ProductPhotoSidenavComponent, { title, brandName, photos });
            const sidenavComponentRef: ComponentRef<SidenavComponent> = spectator.service.getSidenav(ProductPhotoSidenavComponent);
            sidenavComponent = sidenavComponentRef.instance;
            sidenavComponentHtmlElement = sidenavComponentRef.location.nativeElement;
        });

        it('should has header', () => {
            expect(sidenavComponent.header).toBeTruthy();
        });

        it('should has product title C123550', () => {
            expect(sidenavComponentHtmlElement.innerHTML.includes(title)).toBeTruthy();
        });

        it('should has brand title C123552', () => {
            expect(sidenavComponentHtmlElement.innerHTML.includes(brandName)).toBeTruthy();
        });

        it('should close sidenav by method', () => {
            const service: SidenavService = spectator.service;
            expect(service.getSidenav(ProductPhotoSidenavComponent)).toBeTruthy();
            service.closeSidenav(ProductPhotoSidenavComponent)
                .then(() => {
                    expect(service.getSidenav(ProductPhotoSidenavComponent)).toBeFalsy();
                });
        });

        const photoOptionSelector: string = '.qa-selected-photo-pointer';
        const activePhotoOptionSelector: string = `${photoOptionSelector}._active`;

        it('should has 1 active selected photo pointer C116811', fakeAsync(() => {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = sidenavComponentHtmlElement.innerHTML;

            expect(tempDiv.querySelectorAll(activePhotoOptionSelector).length).toBe(1);
        }));

        it('should has the number of options equal to the number of photos', fakeAsync(() => {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = sidenavComponentHtmlElement.innerHTML;
            const allOptions: NodeListOf<Element> = tempDiv.querySelectorAll(photoOptionSelector);

            expect(allOptions.length).toBe(photos.length);
        }));
    });

    describe('via component', () => {
        let spectator: SpectatorHost<ProductPhotoSidenavComponent>;
        const createHost = createHostFactory({
            component: ProductPhotoSidenavComponent,
            imports: [
                MaterialModule,
                TsumScrollModule,
                UiSpinnerModule,
            ],
        });

        it('should has main photo C116808', fakeAsync(() => {
            spectator = createHost(`
                <app-product-photo-sidenav
                    [title]="title"
                    [brandName]="brandName"
                    [photos]="photos"
                ></app-product-photo-sidenav>
            `, {
                hostProps: { title, brandName, photos }
            });

            expect(spectator.query('.qa-current-photo').getAttribute('src')).toBe(photos[0].middle);
        }));
    });

});
