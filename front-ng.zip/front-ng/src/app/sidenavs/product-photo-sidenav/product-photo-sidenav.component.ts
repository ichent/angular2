import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { CatalogPhoto } from '../../interfaces/catalog.interface';
import { BehaviorSubject } from 'rxjs';

@Component({
    selector: 'app-product-photo-sidenav',
    templateUrl: './product-photo-sidenav.component.html',
    styleUrls: ['./product-photo-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductPhotoSidenavComponent implements OnInit {

    @Input()
    public title: string;

    @Input()
    public brandName: string;

    @Input()
    public photos: CatalogPhoto[] = [];

    public set currentPhoto(value: CatalogPhoto) {
        this.currentPhotoSubject$.next(value);
    }

    private currentPhotoSubject$ = new BehaviorSubject<CatalogPhoto>(null);
    public currentPhoto$ = this.currentPhotoSubject$.asObservable();

    constructor(private sidenavService: SidenavService) {}

    ngOnInit() {
        this.currentPhotoSubject$.next(this.photos?.[0]);
    }

    public close(): void {
        this.sidenavService.closeSidenav(ProductPhotoSidenavComponent);
    }

}
