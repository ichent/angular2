import { ProductPhotoSidenavComponent } from './product-photo-sidenav.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/shared/shared.module';
import { UiModule } from 'src/app/ui/ui.module';
import { TsumButtonModule, TsumScrollModule } from '@tsum/ui';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        UiModule,
        TsumScrollModule,
        TsumButtonModule,
    ],
    declarations: [
        ProductPhotoSidenavComponent,
    ],
    entryComponents: [
        ProductPhotoSidenavComponent,
    ],
    exports: [
        ProductPhotoSidenavComponent,
    ],
})
export class ProductPhotoSidenavModule { }
