import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Product } from '../../state/products/product.interface';
import { ProductsQuery } from '../../state/products/products.query';
import { ProductListApiService } from '../../state/product-list/product-list-api.service';
import { ListItem } from '../../state/product-list/product-list.interface';
import { ProductListQuery } from '../../state/product-list/product-list.query';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { SelectedSizesQuery } from '../../state/selected-sizes/selected-sizes.query';

@Component({
    selector: 'app-product-details-sidenav',
    templateUrl: './product-details-sidenav.component.html',
    styleUrls: ['./product-details-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProductDetailsSidenavComponent {

    @Input()
    public product: Product;

    constructor(
        private productApiService: ProductListApiService,
        private productsQuery: ProductsQuery,
        private productListQuery: ProductListQuery,
        private selectedSizesQuery: SelectedSizesQuery,
        protected sidenavService: SidenavService,
    ) {}

    public close(): void {
        this.sidenavService.closeSidenav(ProductDetailsSidenavComponent);
    }

    private makeListItem(product: Product, sizeId: number = null): Partial<ListItem> {
        return {
            modelId: product.modelId,
            itemId: product.id,
            skuId: sizeId,
        };
    }

    public addToList(): void {
        const selectedSizesIds: (number | string)[] = this.selectedSizesQuery.getBy(this.product.id);

        const listItems: Partial<ListItem>[] = selectedSizesIds.length
            ? selectedSizesIds.map((sizeId: number) => this.makeListItem(this.product, sizeId))
            : [this.makeListItem(this.product)];

        this.productApiService.addProductToList(this.productListQuery.getActiveId(), listItems)
            .subscribe();

        this.close();
    }

}
