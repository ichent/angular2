import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductDetailsSidenavComponent } from './product-details-sidenav.component';
import { UiModule } from '../../ui/ui.module';
import { CatalogCardFeatureModule } from '../../features/catalog-card/catalog-card-feature.module';
import { ProductFeatureModule } from '../../features/product/product-feature.module';
import { TsumButtonModule } from '@tsum/ui';

@NgModule({
    declarations: [
        ProductDetailsSidenavComponent,
    ],
    imports: [
        CommonModule,
        UiModule,
        CatalogCardFeatureModule,
        ProductFeatureModule,
        TsumButtonModule,
    ],
    entryComponents: [
        ProductDetailsSidenavComponent,
    ],
    exports: [
        ProductDetailsSidenavComponent,
    ],
})
export class ProductDetailsSidenavModule {}
