import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { OrderLineRejectionSidenavComponent } from './order-line-rejection-sidenav.component';
import { UiModule } from '../../ui/ui.module';
import { TsumButtonModule, TsumPrimarySidepanelSelectorModule, TsumPseudoLinkModule } from '@tsum/ui';
import { ReactiveFormsModule } from '@angular/forms';

const COMPONENTS = [
    OrderLineRejectionSidenavComponent,
];

@NgModule({
    imports: [
        CommonModule,
        UiModule,
        TsumButtonModule,
        TsumPrimarySidepanelSelectorModule,
        ReactiveFormsModule,
        TsumPseudoLinkModule,
    ],
    declarations: COMPONENTS,
    entryComponents: COMPONENTS,
    exports: COMPONENTS,
})
export class OrderLineRejectionSidenavModule {}
