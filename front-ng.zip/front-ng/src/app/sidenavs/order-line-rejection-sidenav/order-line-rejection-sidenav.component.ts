import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { TsumPrimarySidepanelSelector } from '@tsum/ui';
import { FormControl } from '@angular/forms';
import { finalize, map, startWith, takeUntil, tap } from 'rxjs/operators';
import { SidenavService } from '../../ui/modules/sidenav/sidenav.service';
import { OrderApiService } from '../../state/orders/order-api.service';
import { BehaviorSubject, combineLatest, Observable, Subject } from 'rxjs';
import { OrderLineRejection } from '../../pages/order/constants/order-line-rejection.namespace';

@Component({
    selector: 'app-order-line-rejection-sidenav',
    templateUrl: './order-line-rejection-sidenav.component.html',
    styleUrls: ['./order-line-rejection-sidenav.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderLineRejectionSidenavComponent implements OnInit, OnDestroy {

    @Input()
    public orderUuid: string;

    @Input()
    public orderLineUuid: string;

    @Input()
    public rejectionReason: OrderLineRejection.Reason;

    @ViewChild('emailButton', { static: true })
    public emailButtonTemplate: TemplateRef<void>;

    public reasonsList: TsumPrimarySidepanelSelector.Option[];
    public reasonControl = new FormControl();

    public set loading(value: boolean) {
        this.loadingSubject$.next(value);
    }

    public get loading() {
        return this.loadingSubject$.value;
    }

    private loadingSubject$ = new BehaviorSubject(false);
    public loading$: Observable<boolean> = this.loadingSubject$.asObservable();

    private reasons$ = new BehaviorSubject<OrderLineRejection.Reason[]>([]);

    public disabled$ = this.reasonControl.valueChanges
        .pipe(
            startWith(null),
            map((reason: string) => !reason),
        );

    public destroyed$ = new Subject<void>();

    constructor(
        private sidenavService: SidenavService,
        private orderApiService: OrderApiService,
        private cd: ChangeDetectorRef,
    ) {}

    ngOnInit(): void {
        this.rejectionReason
            ? this.reasons$.next([this.rejectionReason])
            : this.orderApiService.getOrderLineRejectionReasons()
                .pipe(takeUntil(this.destroyed$))
                .subscribe((reasons: OrderLineRejection.Reason[]) => this.reasons$.next(reasons));

        combineLatest([
            this.reasons$,
            this.reasonControl.valueChanges.pipe(startWith(this.reasonControl.value)),
        ])
            .pipe(takeUntil(this.destroyed$))
            .subscribe(([reasons, value]: [OrderLineRejection.Reason[], OrderLineRejection.Reason]) => {
                this.reasonsList = reasons.map((key: OrderLineRejection.Reason) => ({
                    key: key.toString(),
                    title: OrderLineRejection.ReasonTitleMap[key],
                    afterTemplate: +value === key ? this.emailButtonTemplate : null,
                }));
                this.cd.detectChanges();
            });
    }

    public cancel(): void {
        this.sidenavService.closeSidenav(OrderLineRejectionSidenavComponent);
    }

    public delete(): void {
        const reason: OrderLineRejection.Reason = +this.reasonControl.value;

        if (reason && !this.loading) {
            this.loading = true;

            this.orderApiService.deleteOrderProduct(this.orderUuid, this.orderLineUuid, reason)
                .pipe(
                    tap(() => this.sidenavService.closeSidenav(OrderLineRejectionSidenavComponent)),
                    finalize(() => this.loading = false),
                )
                .subscribe();
        }
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
