import { NgModule } from '@angular/core';
import { MaterialModule } from './material/material.module';
import { CurrencyRubPipe } from './pipes/currency-rub.pipe';
import { SplitNumberPipe } from './pipes/split-number.pipe';
import { TranslatePipe } from './pipes/translate.pipe';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SkuSizePipe } from './pipes/sku-size.pipe';
import { DecreaseFontSizeDirective } from './directives/decrease-font-size.directive';
import { ToFixedDirective } from './directives/to-fixed.directive';
import { HexPipe } from './pipes/hex.pipe';
import { PriceInputDirective } from './directives/price-input.directive';
import { NumericDirective } from './directives/numeric.directive';
import { ParseClientIdPipe } from './pipes/parse-client-id.pipe';
import { CommonModule } from '@angular/common';
import { ToFixedPipe } from './pipes/to-fixed.pipe';
import { PricePipe } from './pipes/price.pipe';
import { WithdrawalPipe } from './pipes/withdrawal.pipe';
import { SkuExtIdPipe } from './pipes/sku-ext-id.pipe';
import { ModelExtIdPipe } from './pipes/model-ext-id.pipe';

const SHARED_MODULES = [
    MaterialModule,
    FlexLayoutModule,
];

const SHARED_PIPES = [
    CurrencyRubPipe,
    PricePipe,
    TranslatePipe,
    SkuSizePipe,
    HexPipe,
    SplitNumberPipe,
    ToFixedPipe,
    WithdrawalPipe,
    SkuExtIdPipe,
    ModelExtIdPipe,
];

const SHARED_DIRECTIVES = [
    DecreaseFontSizeDirective,
    ToFixedDirective,
    PriceInputDirective,
    NumericDirective,
    ParseClientIdPipe,
];

@NgModule({
    imports: [
        CommonModule,
        ...SHARED_MODULES,
    ],
    declarations: [
        ...SHARED_PIPES,
        ...SHARED_DIRECTIVES,
    ],
    exports: [
        ...SHARED_MODULES,
        ...SHARED_PIPES,
        ...SHARED_DIRECTIVES,
    ],
    providers: [
        SplitNumberPipe,
        CurrencyRubPipe,
    ],
})
export class SharedModule {
}
