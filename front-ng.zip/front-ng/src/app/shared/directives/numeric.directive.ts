import { Directive, ElementRef, Input, OnDestroy, OnInit } from '@angular/core';
import { fromEvent, Observable, Subject } from 'rxjs';
import { map, pairwise, startWith, takeUntil, withLatestFrom } from 'rxjs/operators';

@Directive({
    selector: '[uiNumeric]',
})
export class NumericDirective implements OnInit, OnDestroy {

    @Input('uiNumericMaxLength')
    private maxLength: number | string;

    private destroyed$ = new Subject();

    constructor(
        private el: ElementRef
    ) {}

    ngOnInit() {
        const input$: Observable<Event> = fromEvent(this.el.nativeElement, 'input', { capture: true });

        input$
            .pipe(
                map((event: Event) => (event.target as HTMLInputElement).value),
                map((value: string) => value.replace(/\D+/g, '')),
                map((value: string) => this.maxLength ? value.slice(0, +this.maxLength) : value),
                startWith(this.el.nativeElement.value ?? ''),
                pairwise(),
                withLatestFrom(input$),
                takeUntil(this.destroyed$),
            )
            .subscribe(([[prevValue, value], event]: [[string, string], Event]) => {
                const input = event.target as HTMLInputElement;

                if (prevValue.length === value.length) {
                    const selection: number = input.selectionStart;

                    input.value = value;
                    input.selectionStart = selection;
                    input.selectionEnd = selection;
                    event.stopPropagation();
                }
            });
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

}
