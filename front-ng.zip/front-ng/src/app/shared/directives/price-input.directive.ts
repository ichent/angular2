import { Directive, HostListener } from '@angular/core';

@Directive({
    selector: '[priceInput]'
})
export class PriceInputDirective {

    private restrictedKeys: string[] = ['-', '+', '.', 'e'];

    @HostListener('keydown', ['$event'])
    public onKeyDown(event: KeyboardEvent) {
        if (this.restrictedKeys.includes(event.key)) {
            event.preventDefault();
        }
    }
}
