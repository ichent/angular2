import { Directive, ElementRef, OnDestroy, Renderer2, AfterViewInit } from '@angular/core';
import { fromEvent, Subject } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { takeUntil, distinctUntilChanged, map, startWith, skipWhile } from 'rxjs/operators';

@Directive({
    selector: '[toFixed]',
})
export class ToFixedDirective implements OnDestroy, AfterViewInit {

    private destroyed$: Subject<void> = new Subject<void>();

    private placeholder: HTMLElement;
    private elRect: ClientRect;

    private get element(): HTMLElement {
        return this.elementRef && this.elementRef.nativeElement || null;
    }

    constructor(
        protected elementRef: ElementRef,
        private commonService: CommonService,
        private renderer: Renderer2,
    ) {}

    ngAfterViewInit() {
        this.elRect = this.element.getBoundingClientRect();
        this.placeholder = this.createPlaceholder(this.elRect.height);
        const topOffset: number = this.elRect.top + window.scrollY;

        // TODO: need to be optimized
        this.commonService.clientWidgetTypeChanged$
            .pipe(takeUntil(this.destroyed$))
            .subscribe((height: number) => this.renderer.setStyle(this.element, 'top', `${height}px`));

        fromEvent(window, 'scroll')
            .pipe(
                startWith(null),
                map(() => window.scrollY > topOffset),
                skipWhile((next: boolean) => !next),
                distinctUntilChanged(),
                takeUntil(this.destroyed$),
            )
            .subscribe((next: boolean) => {
                if (next) {
                    this.renderer.addClass(this.element, '_fixed');
                    this.renderer.setStyle(this.element, 'position', 'fixed');
                    this.renderer.setStyle(this.element, 'top', `${this.commonService.fixedPanelsTotalHeight}px`);
                    this.renderer.setStyle(this.element, 'left', '0');
                    this.renderer.setStyle(this.element, 'right', '0');
                    // TODO переписать на использование глобального класса и переменной из variables.styl
                    //  или на использование глобальной css переменной (если к моменту фикса они будут использоваться в проекте для z-index)
                    this.renderer.setStyle(this.element, 'zIndex', '4001'); // см. в variables.styl
                    this.renderer.setStyle(this.placeholder, 'display', 'block');

                    this.commonService.addPanel(this.elementRef);
                } else {
                    this.renderer.removeClass(this.element, '_fixed');
                    this.renderer.setStyle(this.element, 'position', 'inherit');
                    this.renderer.setStyle(this.element, 'top', 'inherit');
                    this.renderer.setStyle(this.element, 'left', 'inherit');
                    this.renderer.setStyle(this.element, 'right', 'inherit');
                    this.renderer.setStyle(this.element, 'zIndex', 'inherit');
                    this.renderer.setStyle(this.placeholder, 'display', 'none');

                    this.commonService.removePanel(this.elementRef);
                }
            });
    }

    private createPlaceholder(height: number = 0): HTMLElement {
        const placeholder: HTMLElement = this.renderer.createElement('div');

        this.renderer.setStyle(placeholder, 'display', 'none');
        this.renderer.setStyle(placeholder, 'height', `${height}px`);
        this.renderer.insertBefore(this.element.parentElement, placeholder, this.element);

        return placeholder;
    }

    ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
        this.commonService.removePanel(this.elementRef);
    }
}
