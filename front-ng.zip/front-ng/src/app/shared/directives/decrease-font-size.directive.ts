import { Directive, ElementRef, Input, OnInit, AfterViewInit } from '@angular/core';

export interface DecreaseFontSizeInput {
    to: number;
    breakPoint: number;
}

const DEFAULT_DECREASE_DATA: DecreaseFontSizeInput = { to: 12, breakPoint: 9 };

@Directive({
    selector: '[decreaseFontSize]'
})
export class DecreaseFontSizeDirective implements AfterViewInit, OnInit {
    @Input() public decreaseFontSize: DecreaseFontSizeInput | string;

    constructor(
        private elRef: ElementRef,
    ) { }

    ngOnInit(): void {
        if (this.decreaseFontSize === '') {
            this.decreaseFontSize = DEFAULT_DECREASE_DATA;
        }
    }

    ngAfterViewInit(): void {
        if (typeof this.decreaseFontSize === 'object' && this.decreaseFontSize !== null) {
            const currentText: string = this.elRef.nativeElement.innerText;
            const breakPoint = !this.decreaseFontSize.breakPoint ? 9 : this.decreaseFontSize.breakPoint;
            const decreaseTo = !this.decreaseFontSize.to ? 12 : this.decreaseFontSize.to;

            if (currentText.length > breakPoint) {
                this.elRef.nativeElement.style.fontSize = `${decreaseTo}px`;
            }
        }
    }
}
