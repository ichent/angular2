import { NgModule } from '@angular/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { CdkTreeModule } from '@angular/cdk/tree';

const MATERIAL_MODULES = [
    MatDatepickerModule,
    CdkTreeModule,
];

@NgModule({
    exports: MATERIAL_MODULES,
})
export class MaterialModule {}
