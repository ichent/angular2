import { Pipe, PipeTransform } from '@angular/core';
import { ProductHelper } from '../../helpers/product.helper';
import { Product } from '../../state/products/product.interface';

@Pipe({
    name: 'skuExtId',
})
export class SkuExtIdPipe implements PipeTransform {

    public transform(product: Product): number | null {
        return ProductHelper.skuExtId(product);
    }

}
