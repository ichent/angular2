import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'hex',
})
export class HexPipe implements PipeTransform {

    public transform(value: string): string {
        return '#' + value;
    }

}
