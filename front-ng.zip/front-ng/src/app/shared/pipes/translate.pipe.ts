import { Pipe, PipeTransform } from '@angular/core';
import { TranslateConstant } from '../../constants/translate.constant';

@Pipe({
    name: 'translate',
})
export class TranslatePipe implements PipeTransform {

    public transform(key: string): string {
        return TranslateConstant[key] || key;
    }

}
