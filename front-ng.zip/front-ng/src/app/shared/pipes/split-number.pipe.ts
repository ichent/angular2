import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'splitNumber',
})
export class SplitNumberPipe implements PipeTransform {

    public transform(number: string | number, groupBy = 3): string {
        return number && String(number).replace(/(?=(\d{3})+(?!\d))/g, ' ') || '';
    }

}
