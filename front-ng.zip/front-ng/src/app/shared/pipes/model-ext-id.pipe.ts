import { Pipe, PipeTransform } from '@angular/core';
import { ProductHelper } from '../../helpers/product.helper';
import { Product } from '../../state/products/product.interface';

@Pipe({
    name: 'modelExtId',
})
export class ModelExtIdPipe implements PipeTransform {

    public transform(product: Product): string | null {
        return ProductHelper.modelExtId(product);
    }

}
