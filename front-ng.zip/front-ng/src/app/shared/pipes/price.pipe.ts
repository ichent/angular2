import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyRubPipe } from './currency-rub.pipe';

const FREE_OF_CHARGE = 'Бесплатно';

@Pipe({
    name: 'price',
})
export class PricePipe implements PipeTransform {

    public constructor(
        private currencyRubPipe: CurrencyRubPipe,
    ) {}

    public transform(value: string | number): string | null {
        return value && String(value) !== '0' ? this.currencyRubPipe.transform(value) : FREE_OF_CHARGE;
    }


}
