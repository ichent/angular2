import { Pipe, PipeTransform } from '@angular/core';
import { SplitNumberPipe } from './split-number.pipe';

@Pipe({
    name: 'withdrawal',
})
export class WithdrawalPipe implements PipeTransform {

    public constructor(
        private splitNumberPipe: SplitNumberPipe,
    ) {}

    public transform(value: string | number): string | null {
        return value && String(value) !== '0' ? `- ${this.splitNumberPipe.transform(value)}` : '0';
    }
}
