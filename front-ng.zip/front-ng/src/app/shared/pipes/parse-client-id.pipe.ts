import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'parseClientId',
})
export class ParseClientIdPipe implements PipeTransform {

    public transform(value: string): string {
        return value.replace(/^([А-Я]{2})(\d{3})(\d{3})(\d{2})$/, '$1 $2 $3 $4');
    }

}
