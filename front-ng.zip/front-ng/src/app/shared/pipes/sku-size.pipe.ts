import { Pipe, PipeTransform } from '@angular/core';
import { SizeAttributes } from '../../features/size/interfaces/size-attributes.interface';

@Pipe({
    name: 'skuSize',
})
export class SkuSizePipe implements PipeTransform {

    public transform(value: SizeAttributes): string {
        if (!value) {
            return null;
        }

        let { russianSize, vendorLabel, vendorSize } = value;
        const russianLabel = value.russianLabel;

        russianSize = russianSize ? russianSize.split(/(\d+)/).filter(Boolean).join(' ') : '';

        if (vendorSize === russianSize) {
            vendorSize = null;
            vendorLabel = null;
        }

        return this.joinSubstrings(
            [
                [vendorLabel, vendorSize],
                [russianLabel, russianSize],
            ]
                .map((substrings: string[]) => this.joinSubstrings(substrings)),
            ' | '
        );
    }

    private joinSubstrings(substrings: string[], divider: string = ' '): string {
        return substrings
            .filter(Boolean)
            .join(divider);
    }

}
