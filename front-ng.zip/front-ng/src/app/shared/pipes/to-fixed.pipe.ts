import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'toFixed'
})
export class ToFixedPipe implements PipeTransform {

  public transform(input: number, fractionDigitsCount = 2): string {
    return (input || 0).toFixed(fractionDigitsCount);
  }

}
