import { Pipe, PipeTransform } from '@angular/core';
import { SplitNumberPipe } from './split-number.pipe';

@Pipe({
    name: 'currencyRub',
})
export class CurrencyRubPipe implements PipeTransform {

    public constructor(
        private splitNumberPipe: SplitNumberPipe,
    ) {}

    public transform(value: string | number): string | null {
        return `${this.splitNumberPipe.transform(value)} ₽`;
    }

}
