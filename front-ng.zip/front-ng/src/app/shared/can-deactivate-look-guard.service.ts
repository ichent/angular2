import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';

export interface CanComponentDeactivate {
    canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable({
    providedIn: 'root',
})
export class CanDeactivateLookGuard implements CanDeactivate<CanComponentDeactivate> {
    canDeactivate(
        component: CanComponentDeactivate,
        currentRoute: ActivatedRouteSnapshot,
        currentState: RouterStateSnapshot,
        nextState?: RouterStateSnapshot
    ) {
        // В случае редиректа на ту же старинцу (при изменении типа лука, например)
        // позволяем этому редиректу случиться без отображения попапа
        if (nextState && /^\/look\/edit\/\d+$/.test(nextState.url)) {
            return true;
        }

        return component.canDeactivate && component.canDeactivate();
    }
}
