export type PHPBoolean = 0 | 1;
