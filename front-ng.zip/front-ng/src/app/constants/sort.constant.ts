export type SortDirection = 'asc' | 'desc';

export interface Sort {
    orderBy: string;
    orderDirection: SortDirection;
}

export interface SorterOption {
    title: string;
    value: SortDirection;
}
