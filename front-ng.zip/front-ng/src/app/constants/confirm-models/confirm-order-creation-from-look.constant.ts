import { TsumConfirm } from '@tsum/ui';

export const CONFIRM_ORDER_CREATION_DESCRIPTION_ENDINGS = {
    'draft': ' в Черновиках.',
    'private': ' в Личных.',
    'public': ' в Публичных.',
};

export const CONFIRM_ORDER_CREATION_FROM_LOOK: TsumConfirm.Window = {
    title: 'Хотите перейти в корзину?',
    type: 'error',
    description: 'Переход в корзину заказа приведет к сохранению этого образа и всех его товаров в списке образов',
    additionalDescription: 'Перейти в корзину?',
    buttonText: 'Сохранить и перейти в корзину',
    secondButtonText: 'Остаться на странице образа',
};
