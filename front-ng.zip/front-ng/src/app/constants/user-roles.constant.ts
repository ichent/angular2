export const enum UserRole {
    Admin = 'ROLE_CALL_CENTER_ADMIN',
    Head = 'ROLE_CALL_CENTER_HEAD',
    Apa = 'ROLE_CALL_CENTER_APA',
    Pa = 'ROLE_CALL_CENTER_PA',
    Supervisor = 'ROLE_CALL_CENTER_SUPERVISOR',
    Operator = 'ROLE_CALL_CENTER_OPERATOR',
    Hoperator = 'ROLE_CALL_CENTER_HOPERATOR',
    Trainee = 'ROLE_CALL_CENTER_TRAINEE',
    UserCallCenter = 'ROLE_CALL_CENTER_USER',
    User = 'ROLE_USER',
}

// Роли в порядке их веса
export const USER_ROLES: UserRole[] = [
    UserRole.Admin, // 8
    UserRole.Head, // 7
    UserRole.Apa, // 6
    UserRole.Pa, // 5
    UserRole.Supervisor, // 4
    UserRole.Operator, // 3
    UserRole.Hoperator, // 2
    UserRole.Trainee, // 1
];

// Названия ролей
export const USER_ROLES_TITLES = {
    [UserRole.Admin]: 'Администратор',
    [UserRole.Head]: 'Руководитель',
    [UserRole.Apa]: 'Помощник персонального ассистента',
    [UserRole.Pa]: 'Персональный ассистент',
    [UserRole.Supervisor]: 'Супервизор',
    [UserRole.Operator]: 'Консультант',
    [UserRole.Hoperator]: 'Консультант горячей линии',
    [UserRole.Trainee]: 'Стажер',
};
