export const TranslateConstant = {
    'female': 'женский',
    'male': 'мужской',
    'draft': 'черновик',
    'private': 'личный',
    'public': 'публичный',
    'sent': 'отправленный',
    'Preorder': 'Предзаказ',
};
