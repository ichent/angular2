export namespace CatalogPaginator {
    export const LowSizeOption = 10;

    export const MiddleSizeOption = 30;

    export const HighSizeOption = 50;

    export const SizesOptions = [LowSizeOption, MiddleSizeOption, HighSizeOption];

    export const DefaultSizeOption = MiddleSizeOption;

    export const DefaultCurrentPage = 1;
}
