import { TsumSecondarySidepanelSelector } from '@tsum/ui';
import { GiftCardType } from '../state/gift-card/interfaces/gift-card.interface';

export const GIFT_CARD_BALANCES: string[] = ['3000', '5000', '10000', '30000', '50000', '100000', '200000', '300000'];
export const GIFT_CARD_CUSTOM_BALANCE: string = 'custom';
export const GIFT_CARD_TYPE_OPTIONS: TsumSecondarySidepanelSelector.Option[] = [
    {
        key: GiftCardType.Virtual,
        title: 'Виртуальная',
    },
    {
        key: GiftCardType.Plastic,
        title: 'Пластиковая',
    },
];
