import { OrderStatus } from './order-status.enum';

/**
 * Статусы, с которыми можно совершать действия с заказом (изменение заказа) в первом релизе phase 2
 *
 * (остальные статусы только для чтения)
 */
export const SUPPORTED_ORDER_STATUSES: OrderStatus[] = [
    OrderStatus.Created,
    OrderStatus.InProcessing,
    OrderStatus.PendingArrival,
    OrderStatus.PendingPayment,
    OrderStatus.PendingBundling,
];
