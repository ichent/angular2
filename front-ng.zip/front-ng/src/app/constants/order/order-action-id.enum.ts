/**
 * Список всех возможных действий с заказом (есть ограничения по применению в зависимости от статуса заказа)
 */
export enum OrderActionId {
    Divide, // Разделить заказ
    Combine, // Объединить заказ (доставку)
    Duplicate, // Дублировать (Копировать заказ)
    AddProduct, // Добавление товара в заказ
    PartialCancellation, // Удаление товара из заказа
    AddLoyaltyCard, // Привязка карты лояльности
    BonusWriteOff, // Списание бонусов/ д.с. ПК
    Cancel, // Полная отмена заказа
    DeliveryAgentModification, // Корректировка агента доставки
    DeliveryAddressModification, // Корректировка адреса доставки
    DeliveryDateModification, // Корректировка даты доставки
    CustomerDataModification, // Корректировка данных оформителя/получателя
    View, // Доступен просмотр и чтение заказа
    PaymentMethodModification, // Смена способа оплаты
    SendingPaymentLink, // Отправка ссылки на оплату
    ReserveOrResetLoyaltyOrGiftCard, // Резерв/аннуляция кл/ПК
    PromoCodeApplication, // Применение купона
    PackageAndAdditionalInfoEditing, // Редактирование упаковки/доп. требования к заказу
    ShowHistory, // Посмотреть историю
    ReserveOrResetFixBonuses, // Резерв/аннуляция FB
}
