import { Property } from '../../interfaces/propery.interface';

export enum OrderPaymentMethod {
    Other = 0,
    Cash = 1,
    ByCard = 7, // Картой при получении
    Online = 8,
    Link = 9,
    Bill = 11,
}

export const ORDER_PAYMENT_METHODS_NAMES_MAP: Property<OrderPaymentMethod>[] = [
    {
        type: OrderPaymentMethod.Online,
        title: 'Онлайн',
    },
    {
        type: OrderPaymentMethod.Cash,
        title: 'Наличными',
    },
    {
        type: OrderPaymentMethod.Link,
        title: 'По ссылке',
    },
    {
        type: OrderPaymentMethod.Bill,
        title: 'По счету',
    },
    {
        type: OrderPaymentMethod.ByCard,
        title: 'Картой при получении',
    },
    {
        type: OrderPaymentMethod.Other,
        title: 'Другой вариант',
    },
];
