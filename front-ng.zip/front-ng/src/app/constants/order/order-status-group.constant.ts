import { OrderStatus } from './order-status.enum';

export interface OrderStatusGroup {
    id: OrderStatusGroupId;
    title: string;
    orderStatuses: OrderStatus[];
}

export enum OrderStatusGroupId {
    Created = 1,
    Assembling = 2,
    Packing = 3,
    SentToBranch = 4,
    InDelivery = 5,
    InPickupPoint = 6,
    Completed = 7,
}

export const ORDER_STATUS_GROUP: (OrderStatusGroup | OrderStatusGroup[])[] = [
    {
        id: OrderStatusGroupId.Created,
        title: 'Создан',
        orderStatuses: [
            OrderStatus.Empty,
            OrderStatus.Created,
            OrderStatus.InProcessing,
            OrderStatus.PendingArrival,
            OrderStatus.PendingPayment,
            OrderStatus.PendingBundling,
        ],
    },
    {
        id: OrderStatusGroupId.Assembling,
        title: 'Формируется',
        orderStatuses: [
            OrderStatus.Bundling,
            OrderStatus.PartiallyProcessed,
            OrderStatus.Approved,
            OrderStatus.Assembling,
        ],
    },
    {
        id: OrderStatusGroupId.Packing,
        title: 'Упаковка',
        orderStatuses: [
            OrderStatus.ReadyForPackaging,
            OrderStatus.Packaging,
        ],
    },
    {
        id: OrderStatusGroupId.SentToBranch,
        title: 'Отгружен',
        orderStatuses: [
            OrderStatus.ReadyForShipment,
            OrderStatus.SentToBranch,
            OrderStatus.OnRouteToBranch,
            OrderStatus.OnArrivedAtBranch,
        ],
    },
    [
        // Будет выбрана группа, которая содержит текущий статус заказа, иначе будет выбрана первая по счёту группа
        {
            id: OrderStatusGroupId.InDelivery,
            title: 'Передан на доставку',
            orderStatuses: [
                OrderStatus.Sent,
                OrderStatus.InDelivery,
            ],
        },
        {
            id: OrderStatusGroupId.InPickupPoint,
            title: 'ПВЗ',
            orderStatuses: [
                OrderStatus.ReadyForHandingOut,
                OrderStatus.DeliveredToFittingWoman,
                OrderStatus.DeliveredToFittingMan,
                OrderStatus.Pickup,
            ],
        },
    ],
    {
        id: OrderStatusGroupId.Completed,
        title: 'Завершён',
        orderStatuses: [
            OrderStatus.Delivered,
            OrderStatus.PartiallyDelivered,
            OrderStatus.CancellationFailedDelivery,
            OrderStatus.Canceled,
            OrderStatus.PartialReturn,
            OrderStatus.Return,
            OrderStatus.DeliveryError,
            OrderStatus.Cancellation,
            OrderStatus.FailedDelivery,
            OrderStatus.Lost,
            OrderStatus.ToBeReturnedFromBranch,
            OrderStatus.ReturningFromBranch,
        ],
    },
];
