import { OrderActionId } from './order-action-id.enum';

/**
 * Название доступных действий с заказом для отображения в пользовательском интерфейсе
 */
export const ORDER_ACTION_DESCRIPTION: { [key in OrderActionId]: string } = {
    [OrderActionId.Divide]: 'разделить заказ',
    [OrderActionId.Combine]: 'объединить заказы',
    [OrderActionId.Duplicate]: 'дублировать заказ',
    [OrderActionId.AddProduct]: 'добавить товар в заказ',
    [OrderActionId.PartialCancellation]: 'удалить товар из заказа',
    [OrderActionId.AddLoyaltyCard]: 'привязать КЛ',
    [OrderActionId.BonusWriteOff]: 'списать бонусы КЛ или средства с ПК',
    [OrderActionId.Cancel]: 'отменить заказ',
    [OrderActionId.DeliveryAgentModification]: 'корректировать агента доставки',
    [OrderActionId.DeliveryAddressModification]: 'корректировать адрес доставки',
    [OrderActionId.DeliveryDateModification]: 'корректировать дату доставки',
    [OrderActionId.CustomerDataModification]: 'корректировать данные оформителя и получателя',
    [OrderActionId.View]: '', // в интерфейсе списка действтий не выводится
    [OrderActionId.PaymentMethodModification]: 'редактировать способ оплаты',
    [OrderActionId.SendingPaymentLink]: 'отправить ссылку на оплату',
    [OrderActionId.ReserveOrResetLoyaltyOrGiftCard]: 'зарезервировать или обнулить ПК/КЛ',
    [OrderActionId.PromoCodeApplication]: 'применить купон',
    [OrderActionId.PackageAndAdditionalInfoEditing]: 'редактировать упаковку',
    [OrderActionId.ShowHistory]: '', // в интерфейсе списка действтий не выводится
    [OrderActionId.ReserveOrResetFixBonuses]: '', // в интерфейсе списка действтий не выводится
};

/**
 * Объединение действий по группам для визуального разделения по смыслу в интерфейсе пользователя.
 * Действия перечислены в требуемом порядке. Сортировка и группировка сохраняется в интерфейсе.
 *
 * Сначала применяется группировка GROUPED_ORDER_ACTIONS, затем объединение названий статусов JOINED_ORDER_ACTIONS_TITLES
 */
export const GROUPED_ORDER_ACTIONS: OrderActionId[][] = [
    [
        OrderActionId.Divide ,
        OrderActionId.Combine ,
        OrderActionId.Duplicate ,
        OrderActionId.Cancel,
    ],
    [
        OrderActionId.AddProduct,
        OrderActionId.CustomerDataModification,
        OrderActionId.DeliveryAgentModification,
        OrderActionId.DeliveryAddressModification,
        OrderActionId.DeliveryDateModification,
        OrderActionId.PackageAndAdditionalInfoEditing,
        OrderActionId.AddLoyaltyCard,
        OrderActionId.ReserveOrResetLoyaltyOrGiftCard,
        OrderActionId.BonusWriteOff,
        OrderActionId.PaymentMethodModification,
        OrderActionId.SendingPaymentLink,
        OrderActionId.PromoCodeApplication,
        OrderActionId.PartialCancellation,
    ],
];

/**
 * Объединение названий действий (для сокращения занимаемого места в интерфейсе пользователя)
 */
export const JOINED_ORDER_ACTIONS_TITLES = new Map<OrderActionId[], string>([
    [
        [
            OrderActionId.DeliveryAgentModification,
            OrderActionId.DeliveryAddressModification,
            OrderActionId.DeliveryDateModification,
        ],
        'корректировать агента, адрес и дату доставки',
    ],
    [
        [
            OrderActionId.DeliveryAgentModification,
            OrderActionId.DeliveryAddressModification,
        ],
        'корректировать агента и адрес доставки',
    ],
    [
        [
            OrderActionId.AddProduct,
            OrderActionId.PartialCancellation,
        ],
        'добавить или удалить товар',
    ],
]);
