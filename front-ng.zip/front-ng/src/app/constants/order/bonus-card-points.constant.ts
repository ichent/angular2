export const BONUS_CARD_POINTS_NOUNS = ['балл', 'балла', 'баллов'];
