/**
 * Все возможные причины отмены заказа
 */
export enum OrderCancelReason {
    // ИМ10
    Error = 0,
    // ИМ11
    PaymentOnlineNotPaid = 1,
    // ИМ19
    TestOrder = 2,
    // ИМ20
    DeliveryInCrimea = 3,
    // ИМ24
    FlammableProduct = 4,
    // ИМ26
    BoughtSimilarProductOnTsumSite = 5,
    // ИМ27
    BoughtSimilarProductOnDifferentSite = 6,
    // ИМ28
    BuyOfflineInTsum = 7,
    // ИМ29
    ChangedMind = 8,
    // ИМ3
    CancellationOfInternetOrder = 9,
    // ИМ30
    FinancialDifficulties = 10,
    // ИМ31
    LackOfAdditionalProductInformation = 11,
    // ИМ32
    NotSatisfiedWithDeliveryTime = 12,
    // ИМ33
    NotSatisfiedWithDeliveryPrice = 13,
    // ИМ34
    NotSatisfiedWithProductPrice = 14,
    // ИМ35
    NotSatisfiedWithDeliveryReturnConditions = 15,
    // ИМ37
    WronglyDuplicatedOrder = 16,
    // ИМ38
    CustomerHasNotPlacedTheOrder = 17,
    // ИМ39
    Fraud = 18,
    // ИМ40
    WrongPaymentType = 19,
    // ИМ42
    NoPossibilityToReceiveOrder = 20,
    // ИМ43
    NotSatisfiedWithPartialOrderCancellation = 21,
    // ИМ44
    MissedCall = 22,
    // ИМ45
    NotSatisfiedWithPostponedDelivery = 23,
    // ИМ48
    LossOfOrder = 24,
    // ИМ49
    DamageOfOrder = 25,
    // ИМ50
    DeliveryChangesExceeded = 26,
    // ИМ51
    StorageTimeExceeded = 27,
    // ИМ52
    DidntApplyPromo = 28,
    // ИМ54
    PradaRejection = 29,
    // ИМ55
    TransferredToAnotherOrder = 30,
    // ИМ56
    WrongSize = 31,
    // ИМ57
    DefectNotAgreed = 32,
    // ИМ65
    EmptyOrder = 33,
    // ИМ66
    RefusalOfInternetPurchase = 34,
    // ИМ67
    ClientFromBlackList = 35,
}

/**
 * Текст для вывода причины отмены заказа интерфейсе
 */
export const ORDER_CANCEL_REASON_TITLES: Partial<Record<OrderCancelReason, string>> = {
    [OrderCancelReason.Error]: 'Ошибка',
    [OrderCancelReason.PaymentOnlineNotPaid]: 'Оплата онлайн, не оплачен',
    [OrderCancelReason.TestOrder]: 'Тестовый заказ',
    [OrderCancelReason.DeliveryInCrimea]: 'Доставка в Крым',
    [OrderCancelReason.FlammableProduct]: 'Огнеопасный товар',
    [OrderCancelReason.BoughtSimilarProductOnTsumSite]: 'Купил подобный товар на сайте tsum.ru',
    [OrderCancelReason.BoughtSimilarProductOnDifferentSite]: 'Купил подобный товар на другом сайте/магазине',
    [OrderCancelReason.BuyOfflineInTsum]: 'Купил/куплю offline в ЦУМ',
    [OrderCancelReason.ChangedMind]: 'Передумал',
    [OrderCancelReason.CancellationOfInternetOrder]: 'Отмена интернет-заказа',
    [OrderCancelReason.FinancialDifficulties]: 'Финансовые сложности',
    [OrderCancelReason.LackOfAdditionalProductInformation]: 'Не устраивает отсутствие доп. информации по товару',
    [OrderCancelReason.NotSatisfiedWithDeliveryTime]: 'Не устраивают сроки доставки',
    [OrderCancelReason.NotSatisfiedWithDeliveryPrice]: 'Не устраивает стоимость доставки',
    [OrderCancelReason.NotSatisfiedWithProductPrice]: 'Не устраивает цена товара',
    [OrderCancelReason.NotSatisfiedWithDeliveryReturnConditions]: 'Не устраивают условия доставки/возврата',
    [OrderCancelReason.WronglyDuplicatedOrder]: 'Ошибочно продублировал заказ',
    [OrderCancelReason.CustomerHasNotPlacedTheOrder]: 'Клиент не оформлял заказ',
    [OrderCancelReason.Fraud]: 'Фрод, повторные заказы, не выкупает',
    [OrderCancelReason.WrongPaymentType]: 'Выбран неверный тип оплаты',
    [OrderCancelReason.NoPossibilityToReceiveOrder]: 'Нет возможности получить заказ',
    [OrderCancelReason.NotSatisfiedWithPartialOrderCancellation]: 'Не устраивает частичная отмена заказа',
    [OrderCancelReason.MissedCall]: 'Недозвон',
    [OrderCancelReason.NotSatisfiedWithPostponedDelivery]: 'Не устраивает перенос сроков доставки',
    [OrderCancelReason.LossOfOrder]: 'Потеря заказа',
    [OrderCancelReason.DamageOfOrder]: 'Повреждение заказа',
    [OrderCancelReason.DeliveryChangesExceeded]: 'Превышено количество переносов ПДД',
    [OrderCancelReason.StorageTimeExceeded]: 'Истек срок хранения',
    [OrderCancelReason.DidntApplyPromo]: 'Не применил промо-код',
    [OrderCancelReason.PradaRejection]: 'Отказ Prada',
    [OrderCancelReason.TransferredToAnotherOrder]: 'Перенос в другой заказ',
    [OrderCancelReason.WrongSize]: 'Неверно выбрал размер',
    [OrderCancelReason.DefectNotAgreed]: 'Дефект не согласован',
    [OrderCancelReason.EmptyOrder]: 'Отмена всех строк',
    [OrderCancelReason.RefusalOfInternetPurchase]: 'Отказ по закупке ИМ',
    [OrderCancelReason.ClientFromBlackList]: 'Заказ покупателя из black list не оплачен',
};
