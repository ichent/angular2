import { OrderActionId } from './order-action-id.enum';

export const ALL_ORDER_ACTIONS: OrderActionId[] = Object.values(OrderActionId) as OrderActionId[];
