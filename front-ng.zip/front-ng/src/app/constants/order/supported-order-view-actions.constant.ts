import { OrderActionId } from './order-action-id.enum';

/**
 * Действия, которые поддерживаются в контексте просмотра заказа
 *
 */
export const SUPPORTED_ORDER_VIEW_ACTIONS: OrderActionId[] = [
    OrderActionId.Duplicate,
];
