export enum DeliveryMethod {
    Courier = 'courier',
    Pickup = 'pickup'
}
