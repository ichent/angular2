import { CommunicationAddressConfig } from '../features/client-widget/interfaces/client-widget.interface';

export namespace ClientWidget {

    export enum IncomingType {
        PhoneKey = 'phone',
        EmailKey = 'email',
        WhatsappKey = 'whatsapp',
        TelegramKey = 'telegram',
        FacebookKey = 'facebook',
        VkontakteKey = 'vkontakte',
        OdnoklassnikiKey = 'odnoklassniki',
        ViberKey = 'viber',
        ChatKey = 'chat',
    }

    export const IncomingTypeIconsMap = {
        'phone': 'social-phone',
        'email': 'social-message',
        'whatsapp': 'social-whatsapp',
        'telegram': 'social-telegram',
        'fb_messanger': 'social-facebook',
        'vkontakte': 'social-vk',
        'odnoklassniki': 'social-one-class',
        'viber': 'social-viber',
        'web_chat': 'social-chat',
    };

    /**
     * Доступные в интерфейсе на данный момент способы связи
     */
    export const ActiveIncomingTypes: ClientWidget.IncomingType[] = [
        IncomingType.PhoneKey,
        IncomingType.EmailKey,
        IncomingType.TelegramKey,
        IncomingType.WhatsappKey,
    ];

    export const IncomingTypesMapper = {
        'phone': IncomingType.PhoneKey,
        'email': IncomingType.EmailKey,
        'whatsapp': IncomingType.WhatsappKey,
        'telegram': IncomingType.TelegramKey,
        'fb_messanger': IncomingType.FacebookKey,
        'vkontakte': IncomingType.VkontakteKey,
        'odnoklassniki': IncomingType.OdnoklassnikiKey,
        'viber': IncomingType.ViberKey,
        'web_chat': IncomingType.ChatKey,
    };

    export enum WidgetViewTypes {
        Bar = 'bar',
        Box = 'box',
    }

    export const CLIENTS_TITLES = ['клиент', 'клиента', 'клиентов'];

    export enum IncomingTypesTexts {
        Message = 'Входящее сообщение',
        Phone = 'Входящий звонок',
        Email = 'Входящее письмо',
    }

    export const CommunicationAddressesConfig: CommunicationAddressConfig[] = [
        {
            type: IncomingType.PhoneKey,
            title: 'Номер телефона',
        },
        {
            type: IncomingType.EmailKey,
            title: 'E-mail',
        },
        {
            type: IncomingType.WhatsappKey,
            title: 'WhatsApp',
        },
        {
            type: IncomingType.TelegramKey,
            title: 'Telegram',
        },
        {
            type: IncomingType.ViberKey,
            title: 'Viber',
        },
    ];
}
