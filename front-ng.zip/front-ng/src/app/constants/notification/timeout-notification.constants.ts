export enum TimeoutNotificationConstant {
    fast = 2000,
    medium = 5000,
    slow = 10000,
    endless = Infinity,
}
