export enum UiNotificationType {
    Error = 'error',
    Warning = 'warning',
    Info = 'info',
    Success = 'success',
}
