export const SUCCESS_COPIED: string = 'Скопировано успешно';
export const SUCCESS_SAVED: string = 'Успешно сохранено';
