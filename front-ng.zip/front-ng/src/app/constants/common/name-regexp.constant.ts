export const NAME_REGEXP = /^([а-яё\w]+\s?)*$/i;
