export const enum VisibleConstant {
    hide = 0,
    show = 1,
}
