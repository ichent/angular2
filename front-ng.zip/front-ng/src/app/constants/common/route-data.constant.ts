export enum RouteDataConstant {
    HasReturnBackButton = 'hasReturnBackButton',
    HasScrollTopButton = 'hasScrollTopButton',
}
