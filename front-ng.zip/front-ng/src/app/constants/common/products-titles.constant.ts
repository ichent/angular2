export const PRODUCTS_TITLES = ['товар', 'товара', 'товаров'];
