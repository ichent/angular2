export enum SpinnerConstant {
    SmallSize = 16,
    MediumSize = 24,
    LargeDiameter = 56,
}
