export enum Page {
    Dashboard = 'dashboard',
    Catalog = 'catalog',
    Oauth = 'oauth',
    Product = 'product',
    Lists = 'lists',
    Look = 'look',
    ProductList = 'product-list',
    Cart = 'cart',
    Orders = 'orders',
    Order = 'order',
    Tasks = 'tasks',
    Clients = 'clients',
    Consulting = 'consulting',
    NotFound = '404',
}

export const enum PageLists {
    Products = 'products',
    Looks = 'looks',
}

export const enum PageOrders {
    Queue = 'queue',
    InProgress = 'underway',
    All = 'all',
}

export const ORDERS_PAGE_MODE_ROUTE_PARAM = 'ordersMode';
export const ORDER_PAGE_ID_ROUTE_PARAM = 'orderId';
export const LIST_PAGE_MODE_ROUTE_PARAM = 'listType';
