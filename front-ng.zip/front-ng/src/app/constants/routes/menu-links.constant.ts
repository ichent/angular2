import { Page, PageLists } from './page.enum';
import { TsumLayoutHeader } from '@tsum/ui';

export const MENU_LINKS: TsumLayoutHeader.Route[] = [
    {
        title: 'Dashboard',
        route: `${Page.Dashboard}`,
    },
    {
        title: 'Заказы',
        route: `${Page.Orders}`,
    },
    {
        title: 'Задачи',
        route: `${Page.Tasks}`,
    },
    {
        title: 'Каталог',
        route: `${Page.Catalog}`,
    },
    {
        title: 'Списки',
        route: `${Page.Lists}`,
        isPopover: true,
        childs: [
            {
                title: 'Список товаров',
                route: `/${Page.Lists}/${PageLists.Products}`,
            },
            {
                title: 'Список образов',
                route: `/${Page.Lists}/${PageLists.Looks}`,
            }
        ],
    },
    {
        title: 'Клиенты',
        route: `${Page.Clients}`,
    },
    {
        title: 'Консультирование',
        route: `${Page.Consulting}`,
    },
];

export const CUSTOM_ACTIVE_ROUTE_MAP: Map<string, string> = new Map([
    [Page.Look, `/${Page.Lists}/${PageLists.Looks}`],
    [Page.ProductList, `/${Page.Lists}/${PageLists.Products}`],
    [Page.Order, `${Page.Orders}`],
]);
