import { SizeSelectionContext } from '../features/size/constants/size-selection-context.enum';
import { CatalogPageContext } from '../interfaces/contexts/catalog-page-contexts.interface';

export const ADD_FIRST = 'first';
export const ADD_MORE = 'more';

export type AddButtonTitles = {
    [key in SizeSelectionContext]: {
        [ADD_FIRST]: string;
        [ADD_MORE]: string;
    };
}

const BUTTON_ADD_MORE = 'Добавить ещё один';

export const ADD_BUTTON_TITLES: AddButtonTitles = {
    [SizeSelectionContext.Cart]: {
        [ADD_FIRST]: 'Добавить в корзину',
        [ADD_MORE]: BUTTON_ADD_MORE,
    },
    [SizeSelectionContext.CartPage]: {
        [ADD_FIRST]: 'Добавить в корзину',
        [ADD_MORE]: BUTTON_ADD_MORE,
    },
    [SizeSelectionContext.ProductList]: {
        [ADD_FIRST]: 'Добавить в список',
        [ADD_MORE]: BUTTON_ADD_MORE,
    },
    [SizeSelectionContext.ProductListPage]: {
        [ADD_FIRST]: 'Добавить в список',
        [ADD_MORE]: BUTTON_ADD_MORE,
    },
    [SizeSelectionContext.OrderEdit]: {
        [ADD_FIRST]: 'Добавить в заказ',
        [ADD_MORE]: BUTTON_ADD_MORE,
    },
};

export const COUNTER_BUTTON_TITLES: Record<CatalogPageContext, string> = {
    [CatalogPageContext.Cart]: 'Корзина',
    [CatalogPageContext.List]: 'Список товаров',
    [CatalogPageContext.OrderEdit]: 'Товаров в заказе',
};
