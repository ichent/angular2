export const CENTRIFUGAL_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIn0.JZHLINDjY09EvP3f7oc-TtNE3rlDs1C2BC0f9OiwwXQ';

export const enum WebsocketMessageType {
    Communication = 'communication_income',
    DeliveryPlan = 'delivery_plan',
    NewRelease = 'release',
}

export const enum WidgetMessageAction {
    Start = 'start',
    End = 'end',
}
