export enum GenderConstant {
    Male = 'male',
    Female = 'female',
}
