import { MatDateFormats } from '@angular/material/core';

export const DEFAULT_DATEPICKER_FORMATS: MatDateFormats = {
    parse: {
        dateInput: 'DD / MM / YY',
    },
    display: {
        dateInput: 'DD / MM / YY',
        monthYearLabel: 'MMM YYYY',
        dateA11yLabel: 'DD / MM / YY',
        monthYearA11yLabel: 'MM YYYY',
    },
};
