export enum SizeLabelCodes {
    Ru = 'RU',
    Int = 'INT',
    It = 'IT',
    Ge = 'GE',
    Fr = 'FR',
    Uk = 'UK',
    Us = 'US',
    Jeans = 'JEANS',
    Child = 'CHILD YEARS',
    NoSize = 'NS',
}
