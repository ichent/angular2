import { CartPageContext } from '../interfaces/contexts/cart-page-contexts.interface';
import { CatalogPageContext } from '../interfaces/contexts/catalog-page-contexts.interface';

export const CART_TITLES: Record<CartPageContext, string> = {
    [CartPageContext.Cart]: 'Корзина',
    [CartPageContext.OrderEdit]: 'Создание заказа',
};

export const REMOVE_PRODUCT_BUTTON_TITLES: Record<CatalogPageContext, string> = {
    [CatalogPageContext.List]: '', // отсутствует в данном контексте
    [CatalogPageContext.Cart]: 'Удалить из корзины',
    [CatalogPageContext.OrderEdit]: '', // отсутствует в данном контексте
};

export const SIDENAV_TITLE_PREFIXES: Record<CatalogPageContext, string> = {
    [CatalogPageContext.List]: '', // отсутствует в данном контексте
    [CatalogPageContext.Cart]: 'В корзине',
    [CatalogPageContext.OrderEdit]: 'В заказе',
};

export const SIDENAV_NAVIGATE_TITLE: Record<CatalogPageContext, string> = {
    [CatalogPageContext.List]: '', // отсутствует в данном контексте
    [CatalogPageContext.Cart]: 'На страницу корзины',
    [CatalogPageContext.OrderEdit]: 'Перейти в заказ',
};

export const CART_CANCEL_TITLES: Record<CartPageContext, string> = {
    [CartPageContext.Cart]: 'Очистить корзину',
    [CartPageContext.OrderEdit]: 'Отменить заказ',
};
