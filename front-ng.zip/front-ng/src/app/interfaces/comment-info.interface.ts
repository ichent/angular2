export interface CommentInfo {
    uuid: string;
    creator: string;
    fullName: string;
    comment: string;
    created: number;
    files?: string[];
}
