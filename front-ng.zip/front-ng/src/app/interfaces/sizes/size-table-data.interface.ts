import { SizeTableApi } from '../../state/dictionaries/size-tables/size-table.model';

export interface SizeTableApiData {
    [key: number]: SizeTableApi;
}
