import { PHPBoolean } from '../types/php-boolean.type';

export interface Tag {
    id: number;
    slug: string;
    sort: number;
    title: string;
    isSeasonable: PHPBoolean;
}
