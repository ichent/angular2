export interface StoreError {
    message: string;
}
