import { Operator } from '../sidenavs/orders/assign-operator-sidenav/operators.interface';

export interface OperatorsPage {
    items: Operator[];
    page: number;
    perPage: number;
    total: number;
}
