import { PHPBoolean } from '../types/php-boolean.type';
import { Brand } from '../state/dictionaries/brands/brand.model';

export interface CatalogPhoto {
    small: string;
    middle?: string;
}

export interface ColorConcrete {
    id: number;
    title: string;
    slug: string;
    hex: string;
    feminine: string;
    neutral: string;
    plural: string;
    parental: string;
    imageUrl: string;
}

export interface ItemByThisModel {
    byPreorder: boolean;
    colorConcrete: ColorConcrete;
    id: number;
    personalization: string;
    preorderDescription: string;
    slug: string;
}

export interface CatalogTag {
    id: number;
    title: string;
    slug: string;
    colorHex: string;
    sort: number;
    xmlId: number;
    onlyCardPayment: PHPBoolean;
    showInFilter: PHPBoolean;
    visible: PHPBoolean;
    seasonDiscount: PHPBoolean;
    applySeasonDiscount: PHPBoolean;
    isSeasonable: PHPBoolean;
    itemId: string;
}

export interface Season {
    color_hex: string;
    id: number;
    show_in_filter: PHPBoolean;
    slug: string;
    title: string;
    visible: PHPBoolean;
}

export interface Look {
    components: LookItem[];
    id: number;
    image: string;
    isActive: PHPBoolean;
    isIncomplete: PHPBoolean;
}

export interface LookItem {
    id: number;
    brand: string;
    brandId: number;
    brandModel: Brand;
    categorySlug: string;
    photos: CatalogPhoto[];
    prices: LookItemPrice;
    slug: string;
    title: string;
    defaultSku: {
        id: number;
        itemId: number;
        modelId: number;
        availabilityInStock: boolean;
    };
}

export interface LookItemPrice {
    maxPrice: number;
    minPrice: number;
}

export interface SortItem {
    title: string;
    value: string;
}
