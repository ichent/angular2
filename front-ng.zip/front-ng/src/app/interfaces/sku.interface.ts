import { PHPBoolean } from '../types/php-boolean.type';

export interface SkuItem {
    id: number;
    itemId: number;
    extId: number;
    extGuid: string;
    barcode: string;
    barcodeVnd: string;
    season: string;
    sizeId: number;
    sizeVendorName: string;
    priceOriginal: number;
    priceDiscount: number;
    visible: PHPBoolean;
    isBuyable: PHPBoolean;
    availabilityInStock: boolean;
    size: SkuSize;
}

export interface SkuSize {
    id: number;
    title: string;
    titleVnd: string;
    visible: PHPBoolean;
    isVisibleInCatalog: PHPBoolean;
}
