export interface GiftCardProduct {
    id: number;
    title: string;
    subtitle: string;
    isOnlyVirtual: boolean;
    isOnlyOnlinePay: boolean;
    itemExtId: string;
    itemSkuExtId: string;
    photos: GiftCardPhoto;
}
export interface GiftCardPhoto {
    x1: string;
    x2: string;
    x3: string;
}

export interface GiftCardCatalog {
    style: string;
    balance: string;
    customBalance: string;
    amount: string;
}

export interface GiftCardStyleOption {
    id: number;
    title: string;
    subtitle: string;
    photo: string;
}
