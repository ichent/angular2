import { OrderActionId } from '../../constants/order/order-action-id.enum';

/**
 * Действия, которые можно совершать с заказом
 */
export interface OrderAction {
    // Id действия на фронте
    id: OrderActionId;
    // Название действия для вывода в интерфейс
    title: string;
    // Поддерживается ли сейчас это действие (или ещё в разработке)
    // Определяется константой SUPPORTED_ORDER_STATUSES
    isSupported: boolean;
}

/**
 * Сгруппированные действия с общим заголовком для вывода в интерфейсе
 */
export interface OrderActionTitleGroup {
    // группа действий с общим заголовком
    actions: OrderAction[];
    // заголовок группы
    title: string;
}
