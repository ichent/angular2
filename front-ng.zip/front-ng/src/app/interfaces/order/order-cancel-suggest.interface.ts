import { OrderCancelReason } from '../../constants/order/order-cancel-reason.constant';

export interface OrderCancelSuggest {
    reason: OrderCancelReason;
    title: string;
}
