export interface DeliveryPhoto {
    x1: string;
    x2: string;
    x3: string;
}
