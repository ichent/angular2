export interface DeliveryMessageResponseApi {
    id: number;
    statusCode: number;
    response: string;
}
