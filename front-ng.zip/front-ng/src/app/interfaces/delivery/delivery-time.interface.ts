export interface DeliveryTime {
    id: string;
    isDefault: boolean;
    start: string;
    stop: string;
    timeStart: string;
    timeStop: string;
}
