import { DeliveryRequestPositionParam } from './delivery-request-position-param.interface';

export interface DeliveryRequestParams {
    address: string;
    positions: DeliveryRequestPositionParam[];
}
