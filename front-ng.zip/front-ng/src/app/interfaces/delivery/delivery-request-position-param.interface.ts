export interface DeliveryRequestPositionParam {
    brand: string;
    category: number;
    id: number;
    sku: number[];
}
