import { DeliveryTime } from './delivery-time.interface';
import { DeliveryPhoto } from './delivery-photo.interface';

export interface DeliveryAgent {
    agentCode: number;
    intervals: DeliveryInterval[];
}

export interface DeliveryInterval {
    agentCode: number;
    cost: number;
    date: string;
    datetime: string;
    operator: string;
    operatorDescription: string;
    operatorPhoto: DeliveryPhoto;
    paymentMethods: number[];
    pickupPointId: number;
    times: DeliveryTime[];
}
