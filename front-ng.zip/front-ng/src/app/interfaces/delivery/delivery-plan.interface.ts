import { DeliveryAgent } from './delivery-interval.interface';

export interface DeliveryPlan {
    productId: number;
    error: string;
    agents: DeliveryAgent[];
}
