export interface AuthTokens {
    cmi: string;
    np: string | null;
}
