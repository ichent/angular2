export interface Property<T> {
    type: T;
    title: string;
}
