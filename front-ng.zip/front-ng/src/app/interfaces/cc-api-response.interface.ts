export interface CcApiResponse<T> {
    code: number;
    message: string;
    data: T;
}

export interface CcApiErrorResponse<T> {
    error: CcApiResponse<T>;
}
