/**
 * productId: skuId: quantity
 */
export type ProductSkuQuantity = Map<number | string, SkuQuantity>;

/**
 * skuId: quantity
 */
export type SkuQuantity = Map<number, number>;
