import { Product } from '../../state/products/product.interface';
import { ListItem } from '../../state/product-list/product-list.interface';

export interface ListProduct {
    product: Product;
    productListHash: string;
    listId: number;
    listItem: ListItem;
}
