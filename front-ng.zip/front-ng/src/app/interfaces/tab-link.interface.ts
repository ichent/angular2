export interface TabLink {
    link: string;
    title: string;
    badge?: number;
}
