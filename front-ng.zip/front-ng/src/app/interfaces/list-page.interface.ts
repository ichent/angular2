import { SortDirection } from '../constants/sort.constant';

export interface ListPage<T> {
    items: T[];
    page: number;
    perPage: number;
    total: number;
    orderBy?: string;
    orderDirection?: SortDirection;
}
