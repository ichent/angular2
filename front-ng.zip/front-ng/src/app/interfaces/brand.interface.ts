import { PHPBoolean } from '../types/php-boolean.type';

export interface Brand {
    brandLogoUrl: string;
    id: number;
    isEnoughItemsToShow: PHPBoolean;
    isPrivileged: PHPBoolean;
    isTop: PHPBoolean;
    isVisibleInCatalog: PHPBoolean;
    showAlways: PHPBoolean;
    slug: string;
    sort: PHPBoolean;
    title: string;
    visible: PHPBoolean;
}
