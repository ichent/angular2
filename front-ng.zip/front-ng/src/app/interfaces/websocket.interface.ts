import { WidgetMessageAction, WebsocketMessageType } from '../constants/websocket.constant';

export interface WebsocketMessage {
    data: any;
    type: WebsocketMessageType;
}

export interface WidgetMessageData {
    action: WidgetMessageAction;
    identity: string;
    type: string;
}
