export interface ProductListSaveRequest {
    title: string;
    description: string;
}

export interface ProductListCreateLinkRequest {
    clientTitle: string;
    clientPhone: string;
    clientEmail: string;
    clientDr: string;
    communicationType: string;
    cmiId: string;
}
