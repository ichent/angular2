import { Page } from '../../constants/routes/page.enum';

export interface ProductListPageWithContext {
    resource: Page.ProductList;
    context: null;
}
