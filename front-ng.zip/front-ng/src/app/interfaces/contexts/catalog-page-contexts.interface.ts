import { Page } from '../../constants/routes/page.enum';

export enum CatalogPageContext {
    List = 'list',
    OrderEdit = 'order-edit',
    Cart = 'cart',
}

export interface CatalogPageWithContext {
    resource: Page.Catalog;
    context: CatalogPageContext;
}
