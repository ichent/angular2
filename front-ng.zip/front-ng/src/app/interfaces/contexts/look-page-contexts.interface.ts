import { Page } from '../../constants/routes/page.enum';

export interface LookPageWithContext {
    resource: Page.Look;
    context: null;
}
