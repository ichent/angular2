import { Page } from '../../constants/routes/page.enum';

export enum CartPageContext {
    // создание списка товаров для дальшейнего создания заказа
    Cart = 'cart',
    // заказ на основе списка создан, идёт заполнение его данными
    OrderEdit = 'order-edit',
}

export interface CartPageWithContext {
    resource: Page.Cart;
    context: CartPageContext;
}
