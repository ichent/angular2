import { Page } from '../../constants/routes/page.enum';

export enum OrderPageContext {
    View = 'view',
    Edit = 'edit',
}

export interface OrderPageWithContext {
    resource: Page.Order;
    context: OrderPageContext;
}
