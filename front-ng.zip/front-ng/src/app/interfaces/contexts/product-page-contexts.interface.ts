import { Page } from '../../constants/routes/page.enum';

export enum ProductPageContext {
    List = 'list',
    Cart = 'cart',
    OrderEdit = 'order-edit',
}

export interface ProductPageWithContext {
    resource: Page.Product;
    context: ProductPageContext;
}
