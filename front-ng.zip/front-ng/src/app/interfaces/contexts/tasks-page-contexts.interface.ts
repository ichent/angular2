import { Page } from '../../constants/routes/page.enum';

export interface TasksPageWithContext {
    resource: Page.Tasks;
    context: null;
}
