import { Page } from '../../constants/routes/page.enum';

export interface NotFoundPageWithContext {
    resource: Page.NotFound;
    context: null;
}
