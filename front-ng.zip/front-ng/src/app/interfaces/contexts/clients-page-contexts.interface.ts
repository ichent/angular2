import { Page } from '../../constants/routes/page.enum';

export interface ClientsPageWithContext {
    resource: Page.Clients;
    context: null;
}
