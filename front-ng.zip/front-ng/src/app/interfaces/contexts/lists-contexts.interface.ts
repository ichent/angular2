import { Page } from '../../constants/routes/page.enum';

export interface ListsPageWithContext {
    resource: Page.Lists;
    context: null;
}
