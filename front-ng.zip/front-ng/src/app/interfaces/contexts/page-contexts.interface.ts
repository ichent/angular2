import { CatalogPageWithContext } from './catalog-page-contexts.interface';
import { CartPageWithContext } from './cart-page-contexts.interface';
import { ClientsPageWithContext } from './clients-page-contexts.interface';
import { ConsultingPageWithContext } from './consulting-page-contexts.interface';
import { DashboardPageWithContext } from './dashboard-page-contexts.interface';
import { ListsPageWithContext } from './lists-contexts.interface';
import { LookPageWithContext } from './look-page-contexts.interface';
import { NotFoundPageWithContext } from './not-found-page-contexts.interface';
import { OrderPageWithContext } from './order-page-contexts.interface';
import { OrdersPageWithContext } from './orders-page-contexts.interface';
import { ProductListPageWithContext } from './product-list-page-contexts.interface';
import { ProductPageWithContext } from './product-page-contexts.interface';
import { TasksPageWithContext } from './tasks-page-contexts.interface';

export type PageWithContext = CartPageWithContext
    | CatalogPageWithContext
    | ClientsPageWithContext
    | ConsultingPageWithContext
    | DashboardPageWithContext
    | ListsPageWithContext
    | LookPageWithContext
    | NotFoundPageWithContext
    | OrderPageWithContext
    | OrdersPageWithContext
    | ProductListPageWithContext
    | ProductPageWithContext
    | TasksPageWithContext;
