import { Page } from '../../constants/routes/page.enum';

export interface OrdersPageWithContext {
    resource: Page.Orders;
    context: null;
}
