import { Page } from '../../constants/routes/page.enum';

export interface ConsultingPageWithContext {
    resource: Page.Consulting;
    context: null;
}
