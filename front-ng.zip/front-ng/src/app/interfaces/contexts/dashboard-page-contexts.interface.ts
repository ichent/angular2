import { Page } from '../../constants/routes/page.enum';

export interface DashboardPageWithContext {
    resource: Page.Dashboard;
    context: null;
}
