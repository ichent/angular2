export interface PersistentState {
    destroy(): void;
    clear(): void;
    clearStore(storeName?: string): void;
}
