export namespace Filters {

    export interface Info {
        additional: FilterItems;
        brand: FilterItems;
        category: FilterItems;
        color: FilterItems;
        country_built: FilterItems;
        country_design: FilterItems;
        size: FilterItems;
        tag: FilterItems;
        availability_in_stock: Filter.Info;
        total: Filter.Info;
        total_full: Filter.Info;
    }

    export interface FilterItems {
        items: Filter.Item[];
    }

    export namespace Filter {
        export interface Item {
            always_visible: boolean;
            count: number;
            inversed: boolean;
            items: [];
            key: string;
            value: number;
        }

        export interface Info {
            info: boolean;
            key: string;
            value: number;
        }
    }

}
