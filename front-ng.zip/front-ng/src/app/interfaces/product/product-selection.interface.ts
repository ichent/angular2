import { VisibleConstant } from 'src/app/constants/common/visible.constant';

export class ProductSelection {
    backUrl: string;
    detailPhotoId: string;
    id: number;
    itemId: string;
    previewPhotoId: number;
    slug: string;
    title: string;
    url: string;
    visible: VisibleConstant;
}
