import { UserRole } from '../constants/user-roles.constant';

export interface User {
    id: number;
    firstName: string;
    lastName: string;
    roles: UserRole[];
    channels: string[];
}
