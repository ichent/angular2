import { Inject, Injectable, OnDestroy } from '@angular/core';
import { UserService } from '../user.service';
import { ENDPOINTS_TOKEN, EndpointsConfigInterface } from '../../config/endpoints';
import * as Centrifuge from 'centrifuge';
import { filter, map, takeUntil, tap } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { User } from '../../interfaces/user.interface';
import { WidgetMessageData, WebsocketMessage } from '../../interfaces/websocket.interface';
import { CENTRIFUGAL_TOKEN, WebsocketMessageType } from '../../constants/websocket.constant';
import { DeliveryMessageResponseApi } from '../../interfaces/delivery/delivery-message-response.interface';

@Injectable({
    providedIn: 'root',
})
export class WebsocketService implements OnDestroy {

    private websocketUrl: string = this.endpointsConfig.WEBSOCKET_URL;

    private centrifuge = new Centrifuge(this.websocketUrl);

    private subscriptions: Centrifuge.Subscription[] = [];

    private userChannels$: Observable<string[]> = this.userService.user$
        .pipe(
            filter((user: User) => !!user),
            map((user: User) => user.channels),
        );

    private messagesSubject$ = new Subject<WebsocketMessage>();

    public widgetMessages$: Observable<WidgetMessageData> = this.messagesSubject$
        .pipe(
            filter(Boolean),
            filter((message: WebsocketMessage) => message.type === WebsocketMessageType.Communication),
            map((message: WebsocketMessage) => message.data),
        );

    public deliveryMessages$: Observable<DeliveryMessageResponseApi> = this.messagesSubject$
        .pipe(
            filter(Boolean),
            filter((message: WebsocketMessage) => message.type === WebsocketMessageType.DeliveryPlan),
            map((message: WebsocketMessage) => message.data),
        );

    public newReleaseMessages$: Observable<DeliveryMessageResponseApi> = this.messagesSubject$
        .pipe(
            filter(Boolean),
            filter((message: WebsocketMessage) => message.type === WebsocketMessageType.NewRelease),
            map((message: WebsocketMessage) => message.data),
        );

    private destroyed$ = new Subject<void>();

    constructor(
        private userService: UserService,
        @Inject(ENDPOINTS_TOKEN) private endpointsConfig: EndpointsConfigInterface,
    ) {
        this.connect();
    }

    private connect(): void {
        const token: string = this.endpointsConfig.CENTRIFUGE_TOKEN || CENTRIFUGAL_TOKEN;

        this.userChannels$
            .pipe(
                tap(() => this.centrifuge.setToken(token)),
                tap((channels: string[]) => {
                    this.unsubscribe();
                    channels.forEach((channel: string) => {
                        this.subscriptions.push(
                            this.centrifuge.subscribe(channel, (message: WebsocketMessage) =>
                                this.messagesSubject$.next(message.data))
                        );
                    });
                }),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.centrifuge.connect());
    }

    private unsubscribe() {
        this.subscriptions.forEach((subscription: Centrifuge.Subscription) => {
            subscription.unsubscribe();
            subscription.removeAllListeners();
        });
    }

    ngOnDestroy() {
        this.destroyed$.next();
        this.destroyed$.complete();
        this.unsubscribe();
        this.centrifuge.disconnect();
    }
}
