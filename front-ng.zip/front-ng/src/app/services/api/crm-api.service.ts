import { Injectable } from '@angular/core';
import { ApiService } from './api.service';

@Injectable({
    providedIn: 'root'
})
export class CrmApiService extends ApiService {
    protected baseUrl = `${this.endpointsConfig.BASE_GATEWAY_API_URL}/crm/v1/api`;
}
