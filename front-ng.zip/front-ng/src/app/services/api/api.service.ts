import { Injectable } from '@angular/core';
import { BaseApiService } from './base-api.service';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class ApiService extends BaseApiService {

    protected baseUrl = this.endpointsConfig.BASE_API_URL;

    protected mergeHeaders(headers: HttpHeaders) {
        return (headers || new HttpHeaders()).set('Authorization', `Bearer ${this.authService.accessToken}`);
    }

}
