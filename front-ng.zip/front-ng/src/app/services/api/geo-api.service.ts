import { Injectable } from '@angular/core';
import { BaseApiService } from './base-api.service';

@Injectable({
    providedIn: 'root'
})
export class GeoApiService extends BaseApiService {

    protected baseUrl = this.endpointsConfig.GEO_API_URL;

}
