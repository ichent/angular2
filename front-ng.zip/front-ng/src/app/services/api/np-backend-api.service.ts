import { Injectable } from '@angular/core';
import { BaseApiService } from './base-api.service';

@Injectable({
    providedIn: 'root'
})
export class NpBackendApiService extends BaseApiService {

    protected baseUrl = this.endpointsConfig.NP_BACKEND_API_URL;

}
