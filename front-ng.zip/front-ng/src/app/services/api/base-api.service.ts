import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { ENDPOINTS_TOKEN, EndpointsConfigInterface } from '../../config/endpoints';
import { AuthService } from '../auth.service';
import { map } from 'rxjs/operators';
import { Aura } from '../../helpers/aura.helper';
import { Observable } from 'rxjs';

export interface HttpOptionsBase {
    headers?: HttpHeaders;
    params?: HttpParams;
    reportProgress?: boolean;
    responseType?: 'json';
    withCredentials?: boolean;
}

export interface HttpOptions extends HttpOptionsBase {
    observe?: 'body';
}

export interface HttpOptionsResponse extends HttpOptionsBase {
    observe: 'response';
}

export interface BaseApiResponse<T> {
    data: T;
    code: number;
    message: string;
}

export interface FullResponse<T> {
    response: HttpResponse<T>;
    data: T;
}

@Injectable()
export abstract class BaseApiService {

    protected abstract baseUrl: string;

    constructor(
        private httpClient: HttpClient,
        protected authService: AuthService,
        @Inject(ENDPOINTS_TOKEN) protected endpointsConfig: EndpointsConfigInterface,
    ) {}

    protected mergeHeaders(headers: HttpHeaders): HttpHeaders {
        return headers;
    }

    public getFullResponse<T extends object>(url: string, options: HttpOptionsResponse): Observable<FullResponse<T>> {
        return this.httpClient
            .get<T>(`${this.baseUrl}/${url}`, {...options, headers: this.mergeHeaders(options.headers)})
            .pipe(
                map((data: HttpResponse<T>) => {
                    const body: T = Aura.snakeToCamel<T>(data.body);

                    return {
                        response: data,
                        data: body,
                    };
                })
            );
    }

    public get<T extends object>(url: string, options: HttpOptions = {}) {
        return this.httpClient
            .get<T>(`${this.baseUrl}/${url}`, {...options, headers: this.mergeHeaders(options.headers)})
            .pipe(
                map(data => Aura.snakeToCamel<T>(data))
            );
    }

    public delete<T extends object>(url: string, options: HttpOptions = {}) {
        return this.httpClient
            .delete<T>(`${this.baseUrl}/${url}`, {...options, headers: this.mergeHeaders(options.headers)})
            .pipe(
                map(data => Aura.snakeToCamel<T>(data))
            );
    }

    public post<T extends object>(url: string, body, options: HttpOptions = {}) {
        return this.httpClient
            .post<T>(`${this.baseUrl}/${url}`, body, {...options, headers: this.mergeHeaders(options.headers)})
            .pipe(
                map(data => Aura.snakeToCamel<T>(data))
            );
    }

    public put<T extends object>(url: string, body, options: HttpOptions = {}) {
        return this.httpClient
            .put<T>(`${this.baseUrl}/${url}`, {...options, headers: this.mergeHeaders(options.headers)})
            .pipe(
                map(data => Aura.snakeToCamel<T>(data))
            );
    }

    public patch<T extends object>(url: string, body, options: HttpOptions = {}) {
        return this.httpClient
            .patch<T>(`${this.baseUrl}/${url}`, body, {...options, headers: this.mergeHeaders(options.headers)})
            .pipe(
                map(data => Aura.snakeToCamel<T>(data))
            );
    }

}
