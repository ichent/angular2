import { Injectable } from '@angular/core';
import { merge } from 'rxjs';
import { CountriesApiService } from './dictionaries/countries-api.service';
import { ColorsApiService } from './dictionaries/colors-api.service';
import { BrandsApiService } from './dictionaries/brands-api.service';
import { SeasonsApiService } from './dictionaries/seasons-api.service';
import { LabelsApiService } from './dictionaries/labels-api.service';
import { WarehouseService } from '../state/dictionaries/warehouses/warehouse.service';
import { CategoriesApiService } from './dictionaries/categories-api.service';

@Injectable({
    providedIn: 'root'
})
export class DictionaryService {
    constructor(
        private countriesApiService: CountriesApiService,
        private colorsApiService: ColorsApiService,
        private brandsApiService: BrandsApiService,
        private warehouseService: WarehouseService,
        private seasonsApiService: SeasonsApiService,
        private labelsApiService: LabelsApiService,
        private categoriesApiService: CategoriesApiService,
    ) {}

    public setDictionaries(): void {
        merge(
            this.countriesApiService.getCountries(),
            this.colorsApiService.getColors(),
            this.brandsApiService.getBrands(),
            this.warehouseService.getWarehouses(),
            this.seasonsApiService.getSeasons(),
            this.labelsApiService.getLabels(),
            this.categoriesApiService.getCategories(),
        ).subscribe();
    }
}
