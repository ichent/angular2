export namespace Log {
    type WidgetType = 'uncertain' | 'certain' | 'certain with choice';
    type ActionType = 'start' | 'edit' | 'change main contact' | 'join' | 'create';
    type LabelType = 'forced' | 'unmarked' | 'online' | 'offline' | 'vip';

    interface Address {
        address: string;
        type: string;
    }

    interface Name {
        firstName: string;
        lastName: string;
        middleName?: string;
    }

    export interface Data {
        userId: number;
        cmiId: string;
        ccCommunicationId: string;
        label: LabelType;
        timestamp: number;
        communicationAddress: Address;
    }

    export interface SpecificData {
        action: ActionType;
        widgetType?: WidgetType;
        old?: Name;
        new?: Name;
        userId?: number;
        cmiId?: string;
        ccCommunicationId?: string;
        label?: LabelType;
        timestamp?: number;
        communicationAddress?: Address;
    }
}
