import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ENDPOINTS_TOKEN, EndpointsConfigInterface } from '../../config/endpoints';
import { ClientWidgetCustomerItem } from '../../state/client/customers/customers.model';
import { ClientWidgetCustomersQuery } from '../../state/client/customers/customers.query';
import { UserService } from '../user.service';
import { ClientWidgetSearchQuery } from '../../state/client/search/search.query';
import { Log } from './log.namespace';

/**
 * Для активации написать в консоли разработчика:
 * localStorage.setItem('logging', true);
 *
 * Для деактивации:
 * localStorage.removeItem('logging');
 */
@Injectable({
    providedIn: 'root'
})
export class LogService {

    private readonly baseUrl = this.endpointsConfig.BASE_API_URL;

    constructor(
        private httpClient: HttpClient,
        private clientWidgetCustomersQuery: ClientWidgetCustomersQuery,
        private clientWidgetSearchQuery: ClientWidgetSearchQuery,
        private userService: UserService,
        @Inject(ENDPOINTS_TOKEN) private endpointsConfig: EndpointsConfigInterface,
    ) {}

     public handleStart(): void {
        const customers: ClientWidgetCustomerItem[] = this.clientWidgetCustomersQuery.getValue().items || [];
        const data: Log.SpecificData = { action: 'start' };

        if (!customers || !customers.length) {
            data.widgetType = 'uncertain';
        } else if (customers.length === 1) {
            data.widgetType = 'certain';
        } else {
            data.widgetType = 'certain with choice';
        }

         this.logAction(data);
    }

    public handleContactChange(newClient: ClientWidgetCustomerItem): void {
        const { cmiId } = this.clientWidgetCustomersQuery.getMainCustomer() || {};

        this.logAction({
            action: cmiId ? 'change main contact' : 'join',
            cmiId: newClient.cmiId
        });
    }

    public handleContactEdition(newClient: ClientWidgetCustomerItem): void {
        const client: ClientWidgetCustomerItem = this.clientWidgetCustomersQuery.getMainCustomer();
        const {
            firstName: newFirstName = null,
            middleName: newMiddleName = null,
            lastName: newLastName = null,
            cmiId = null,
        } = newClient || {};

        if (client) {
            const { firstName = null, middleName = null, lastName = null } = client;

            if (newFirstName !== firstName || newMiddleName !== middleName || newLastName !== lastName) {
                this.logAction({
                    action: 'edit',
                    old: { firstName, middleName, lastName },
                    new: {
                        firstName: newFirstName,
                        middleName: newMiddleName,
                        lastName: newLastName,
                    }
                });
            }
        } else {
            this.logAction({ action: 'create', cmiId });
        }
    }

    private logAction(specificData: Log.SpecificData): void {
        if (window.localStorage.getItem('logging') !== 'true') {
            return;
        }

        const customer: ClientWidgetCustomerItem = this.clientWidgetCustomersQuery.getMainCustomer();
        const {
            incomingValue: address = null,
            incomingType: type = null,
        } = this.clientWidgetSearchQuery.getValue() || {};

        const data: Log.Data & Log.SpecificData = {
            userId: this.userService.user?.id ?? null,
            cmiId: customer?.cmiId ?? null,
            ccCommunicationId: null,
            label: null,
            timestamp: Date.now(),
            communicationAddress: { address, type },
            ...specificData
        };

        console.log(data);
        // return this.httpClient.post<void>(`${this.baseUrl}/log`, { data });
    }

}
