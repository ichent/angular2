import { Injectable } from '@angular/core';
import { ApiService } from './api/api.service';
import { BaseApiResponse } from './api/base-api.service';
import { User } from '../interfaces/user.interface';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, map, tap } from 'rxjs/operators';
import { ProductList } from '../state/product-list/product-list.interface';
import { ListType } from '../pages/lists/list-type.enum';
import { UserRolesService } from './user-roles.service';
import { CcApiHelper } from '../helpers/cc-api.helper';

@Injectable({
    providedIn: 'root'
})
export class UserService {

    public get user(): User {
        return this.userSubject$.value;
    }

    public userSubject$ = new BehaviorSubject<User>(null);
    public user$: Observable<User> = this.userSubject$.pipe(distinctUntilChanged());

    constructor(
        private apiService: ApiService,
        private userRolesService: UserRolesService,
    ) {}

    public getInfo(): Observable<User> {
        return this.apiService.get<BaseApiResponse<User>>('oauth/info')
            .pipe(
                map(CcApiHelper.toResponseData),
                tap((user: User) => {
                    this.userSubject$.next(user);
                }),
            );
    }

    public canViewList(list: ProductList, user: User, listType: ListType): boolean {
        return this.userRolesService.canViewList(list, user, listType);
    }

    public canCopyAsPrivateList(list: ProductList, user: User, listType: ListType): boolean {
        return this.userRolesService.canCopyAsPrivateList(list, user, listType);
    }

    public canSaveAsPublicList(list: ProductList, user: User, listType: ListType): boolean {
        return this.userRolesService.canSaveAsPublicList(list, user, listType);
    }

    public canSaveAsPrivateList(list: ProductList, user: User, listType: ListType): boolean {
        return this.userRolesService.canSaveAsPrivateList(list, user, listType);
    }

    public canDeleteList(list: ProductList, user: User, listType: ListType): boolean {
        return this.userRolesService.canDeleteList(list, user, listType);
    }

    public canSaveToClient(list: ProductList, user: User, listType: ListType): boolean {
        return this.userRolesService.canSaveToClient(list, user, listType);
    }
}
