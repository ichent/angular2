import { Injectable } from '@angular/core';
import { PersistentState } from '../interfaces/storage.interface';
import { persistState } from '@datorama/akita';

const PERSISTENT_STORES = [
    'client-widget-search',
    'product-list.active',
    'look-list-products.ui',
    'delivery-plans.deliveryCity',
];

@Injectable({
    providedIn: 'root'
})
export class SessionStorageService {

    private sessionStorage: PersistentState = null;

    public init(): void {
        this.sessionStorage = persistState({
            key: 'RestoreOnRefresh',
            include: PERSISTENT_STORES,
            storage: sessionStorage,
        });
    }

    public clearStore(storeName: string): void {
        if (this.sessionStorage) {
            this.sessionStorage.clearStore(storeName);
        }
    }

}
