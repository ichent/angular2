import { Injectable } from '@angular/core';
import { TsumNotification, TsumNotificationService } from '@tsum/ui';

@Injectable({
    providedIn: 'root',
})
export class NotificationService {

    constructor(
        private tsumNotificationService: TsumNotificationService,
    ) {}

    public pushNotifications(notifications: TsumNotification.Notification[]): void {
        this.tsumNotificationService.pushNotifications(notifications);
    }

    public closeNotification(id: string, notifications?: TsumNotification.Notification[]): void {
        this.tsumNotificationService.closeNotification(id, notifications);
    }

}
