import { Injectable } from '@angular/core';
import { NpBackendApiService } from '../api/np-backend-api.service';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { ColorsStore } from '../../state/dictionaries/colors/colors.store';
import { ColorsQuery } from '../../state/dictionaries/colors/colors.query';
import { Color } from '../../state/dictionaries/colors/color.model';

@Injectable({
    providedIn: 'root',
})
export class ColorsApiService {

    constructor(
        private npBackendApiService: NpBackendApiService,
        private colorsStore: ColorsStore,
        private colorsQuery: ColorsQuery,
    ) {
    }

    public getColors(force: boolean = false): Observable<Color[]> {
        if (force || !this.colorsQuery.getHasCache()) {
            return this.npBackendApiService.get<Color[]>(`catalog/color`).pipe(
                tap((colors: Color[]) => this.colorsStore.set(colors)),
            );
        } else {
            return of(this.colorsQuery.getAll());
        }
    }
}
