import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { SeasonsStore } from '../../state/dictionaries/seasons/seasons.store';
import { SeasonsQuery } from '../../state/dictionaries/seasons/seasons.query';
import { NpBackendApiService } from '../api/np-backend-api.service';
import { Season } from '../../state/dictionaries/seasons/season.model';

@Injectable({
    providedIn: 'root',
})
export class SeasonsApiService {

    constructor(
        private npBackendApiService: NpBackendApiService,
        private seasonsStore: SeasonsStore,
        private seasonsQuery: SeasonsQuery,
    ) {
    }

    public getSeasons(force: boolean = false): Observable<Season[]> {
        if (force || !this.seasonsQuery.getHasCache()) {
            return this.npBackendApiService.get<Season[]>('catalog/seasons').pipe(
                tap((seasons: Season[]) => this.seasonsStore.set(seasons)),
            );
        } else {
            return of(this.seasonsQuery.getAll());
        }
    }
}
