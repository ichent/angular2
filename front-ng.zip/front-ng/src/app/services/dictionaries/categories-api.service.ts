import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Category } from '../../state/dictionaries/categories/category.model';
import { NpBackendApiService } from '../api/np-backend-api.service';
import { CategoriesStore } from '../../state/dictionaries/categories/categories.store';
import { CategoriesQuery } from '../../state/dictionaries/categories/categories.query';

@Injectable({
    providedIn: 'root',
})
export class CategoriesApiService {

    constructor (
        private categoriesStore: CategoriesStore,
        private npBackendApiService: NpBackendApiService,
        private categoriesQuery: CategoriesQuery,
    ) {}

    public getCategories(force: boolean = false): Observable<Category[]> {
        if (force || !this.categoriesQuery.getHasCache()) {
            return this.npBackendApiService.get<Category[]>('catalog/category/plain-list')
                .pipe(tap((data: Category[]) => this.categoriesStore.set(data)));
        } else {
            return of(this.categoriesQuery.getAll());
        }
    }

}
