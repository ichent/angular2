import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Brand } from '../../state/dictionaries/brands/brand.model';
import { BrandsStore } from '../../state/dictionaries/brands/brands.store';
import { BrandsQuery } from '../../state/dictionaries/brands/brands.query';
import { NpApiService } from '../api/np-api.service';
import { HttpParams } from '@angular/common/http';

@Injectable({
    providedIn: 'root',
})
export class BrandsApiService {

    constructor(
        private npApiService: NpApiService,
        private brandsStore: BrandsStore,
        private brandsQuery: BrandsQuery,
    ) {
    }

    public getBrands(force: boolean = false): Observable<Brand[]> {
        const httpParams = new HttpParams({ fromObject: { checkAccess: '1' }});

        if (force || !this.brandsQuery.getHasCache()) {
            return this.npApiService.get<Brand[]>(`catalog/brand`, { params: httpParams }).pipe(
                tap((brands: Brand[]) => this.brandsStore.set(brands)),
            );
        } else {
            return of(this.brandsQuery.getAll());
        }
    }
}
