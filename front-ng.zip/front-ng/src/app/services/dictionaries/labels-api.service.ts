import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { NpBackendApiService } from '../api/np-backend-api.service';
import { Season } from '../../state/dictionaries/seasons/season.model';
import { ProductAttribute } from '../../state/dictionaries/product-attributes/product-attribute.model';
import { ProductAttributesStore } from '../../state/dictionaries/product-attributes/product-attributes.store';
import { ProductAttributesQuery } from '../../state/dictionaries/product-attributes/product-attributes.query';
import { SeasonsHelper } from '../../helpers/seasons.helper';
import { SeasonsStore } from '../../state/dictionaries/seasons/seasons.store';

@Injectable({
    providedIn: 'root',
})
export class LabelsApiService {

    constructor(
        private npBackendApiService: NpBackendApiService,
        private labelsStore: ProductAttributesStore,
        private labelsQuery: ProductAttributesQuery,
        private seasonsStore: SeasonsStore,
    ) {
    }

    public getLabels(force: boolean = false): Observable<ProductAttribute[]> {
        if (force || !this.labelsQuery.getHasCache()) {
            return this.npBackendApiService.get<Season[]>('catalog/labels').pipe(
                map((attributes: ProductAttribute[]) => SeasonsHelper.extractSeasonsFromLabels(attributes)),
                tap(([seasons, labels]: ProductAttribute[][]) => {
                    this.seasonsStore.add(seasons);
                    this.labelsStore.set(labels);
                }),
                map(([seasons, labels]: ProductAttribute[][]) => labels),
            );
        } else {
            return of(this.labelsQuery.getAll());
        }
    }
}
