import { Injectable } from '@angular/core';
import { NpBackendApiService } from '../api/np-backend-api.service';
import { Country } from '../../state/dictionaries/countries/contry.model';
import { Observable, of } from 'rxjs';
import { CountriesStore } from '../../state/dictionaries/countries/countries.store';
import { CountriesQuery } from '../../state/dictionaries/countries/countries.query';
import { tap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root',
})
export class CountriesApiService {

    constructor(
        private npBackendApiService: NpBackendApiService,
        private countriesStore: CountriesStore,
        private countriesQuery: CountriesQuery,
    ) {
    }

    public getCountries(force: boolean = false): Observable<Country[]> {
        if (force || !this.countriesQuery.getHasCache()) {
            return this.npBackendApiService.get<Country[]>('catalog/country/plain-list').pipe(
                tap((countries: Country[]) => this.countriesStore.set(countries)),
            );
        } else {
            return of(this.countriesQuery.getAll());
        }
    }
}
