import { Injectable } from '@angular/core';
import { ProductList } from '../state/product-list/product-list.interface';
import { User } from '../interfaces/user.interface';
import { ListType } from '../pages/lists/list-type.enum';
import { USER_ROLES, UserRole } from '../constants/user-roles.constant';

export interface UserRolesConfig {
    useOnlyMaxWeightRole: boolean;
}

const DEFAULT_USER_ROLES_CONFIG: UserRolesConfig = {
    useOnlyMaxWeightRole: true,
};

@Injectable({
    providedIn: 'root'
})
export class UserRolesService {

    public canViewList(list: ProductList, user: User, listType: ListType): boolean {
        if (listType === ListType.Sent) {
            return false;
        }

        return listType !== ListType.Private
            || this.hasRoleFromList(user, [UserRole.Admin, UserRole.Head, UserRole.Apa, UserRole.Supervisor])
            || this.isListAuthor(list, user);
    }

    public canCopyAsPrivateList(list: ProductList, user: User, listType: ListType): boolean {
        if ([ListType.AdminPrivate, ListType.Private].includes(listType)) {
            return this.hasRoleFromList(user, [UserRole.Admin, UserRole.Head, UserRole.Apa, UserRole.Supervisor])
                || this.isListAuthor(list, user);
        }

        return true;
    }

    public canSaveAsPublicList(list: ProductList, user: User, listType: ListType): boolean {
        if (listType === ListType.Draft) {
            return true;
        }

        if ([ListType.Sent, ListType.Public].includes(listType)) {
            return false;
        }

        if ([ListType.Private, ListType.AdminPrivate].includes(listType)) {
            const canSaveAsPublic: boolean = this.hasRoleFromList(user, [
                UserRole.Admin,
                UserRole.Head,
                UserRole.Supervisor,
                UserRole.Apa,
            ]);

            const canSaveAsPublicIfAuthor: boolean = this.hasRoleFromList(user, [
                UserRole.Operator,
                UserRole.Trainee,
                UserRole.Pa,
            ]);

            return canSaveAsPublic || (canSaveAsPublicIfAuthor && this.isListAuthor(list, user));
        }

        return false;
    }

    public canSaveAsPrivateList(list: ProductList, user: User, listType: ListType): boolean {
        if ([ListType.Sent, ListType.Public].includes(listType)) {
            return false;
        }

        if ([ListType.Draft, ListType.Private].includes(listType)) {
            return this.isListAuthor(list, user);
        }
    }

    public canDeleteList(list: ProductList, user: User, listType: ListType): boolean {
        if (listType === ListType.Draft) {
            const canDeleteIfAuthor: boolean = this.hasRoleFromList(user, [
                UserRole.Admin,
                UserRole.Head,
                UserRole.Supervisor,
                UserRole.Operator,
                UserRole.Trainee,
                UserRole.Apa,
                UserRole.Pa,
            ]);

            return canDeleteIfAuthor && this.isListAuthor(list, user);
        }

        if ([ListType.Private, ListType.AdminPrivate].includes(listType)) {
            const canDelete: boolean = this.hasRoleFromList(user, [
                UserRole.Admin,
                UserRole.Head,
                UserRole.Supervisor,
            ]);

            const canDeleteIfAuthor: boolean = this.hasRoleFromList(user, [
                UserRole.Operator,
                UserRole.Apa,
                UserRole.Pa,
            ]);

            return canDelete || (canDeleteIfAuthor && this.isListAuthor(list, user));
        }

        if (listType === ListType.Public) {
            const canDelete: boolean = this.hasRoleFromList(user, [
                UserRole.Admin,
                UserRole.Head,
                UserRole.Supervisor,
                UserRole.Apa,
            ]);

            const canDeleteIfAuthor: boolean = this.hasRoleFromList(user, [
                UserRole.Operator,
                UserRole.Trainee,
                UserRole.Pa,
            ]);

            return canDelete || (canDeleteIfAuthor && this.isListAuthor(list, user));
        }

        if (listType === ListType.Sent) {
            const canDelete: boolean = this.hasRoleFromList(user, [
                UserRole.Admin,
                UserRole.Head,
                UserRole.Supervisor,
            ]);

            return canDelete;
        }

        return false;
    }

    public canSaveToClient(list: ProductList, user: User, listType: ListType): boolean {
        if ([ListType.Draft, ListType.Public, ListType.Sent].includes(listType)) {
            return true;
        }

        if (listType === ListType.Private) {
            const canDelete: boolean = this.hasRoleFromList(user, [
                UserRole.Admin,
                UserRole.Head,
                UserRole.Apa,
                UserRole.Supervisor,
            ]);

            const canDeleteIfAuthor: boolean = this.hasRoleFromList(user, [
                UserRole.Operator,
                UserRole.Trainee,
                UserRole.Pa,
            ]);

            return canDelete || (canDeleteIfAuthor && this.isListAuthor(list, user));
        }
    }

    public canSeeExtendedOrdersFilters(user: User): boolean {
        return this.hasRoleFromList(user, [
            UserRole.Admin,
            UserRole.Head,
            UserRole.Apa,
            UserRole.Pa,
            UserRole.Supervisor,
        ]);
    }

    public shouldSeeVipOrdersByDefault(user: User): boolean {
        return this.hasRoleFromList(user, [
            UserRole.Admin,
            UserRole.Head,
            UserRole.Apa,
            UserRole.Pa,
            UserRole.Supervisor,
        ]);
    }

    public hasSubordinates(user: User): boolean {
        return this.hasRoleFromList(user, [
            UserRole.Admin,
            UserRole.Head,
            UserRole.Supervisor,
        ]);
    }

    public hasRoleFromList(user: User, roles: UserRole[], config = DEFAULT_USER_ROLES_CONFIG): boolean {
        let userRoles: UserRole[] = user.roles;

        if (config && config.useOnlyMaxWeightRole) {
            userRoles = [this.findMaxWeightRole(userRoles)];
        }

        return userRoles.some((role: UserRole) => roles.includes(role));
    }

    public isListAuthor(list: ProductList, user: User): boolean {
        return user && list && list.createdBy && list.createdBy.user && user.id === list.createdBy.user.id;
    }

    public isListSender(list: ProductList, user: User): boolean {
        return user && list && list.sentBy && list.sentBy.user && user.id === list.sentBy.user.id;
    }

    public findMaxWeightRole(roles: UserRole[]): UserRole {
        if (!(Array.isArray(roles) && roles.length)) {
            return UserRole.User;
        }

        return USER_ROLES.find((userRole: UserRole) => roles.includes(userRole));
    }

    public canViewOrders(user: User): boolean {
        return this.hasRoleFromList(user, [
            UserRole.Admin,
        ]);
    }

}
