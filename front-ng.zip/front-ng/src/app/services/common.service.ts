import { ElementRef, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class CommonService {

    private clientWidgetBarExistsSubject$ = new BehaviorSubject<boolean>(false);
    public clientWidgetBarExists$: Observable<boolean> = this.clientWidgetBarExistsSubject$.asObservable();

    private overlaySubject$: BehaviorSubject<boolean> = new BehaviorSubject(false);
    public overlay$: Observable<boolean> = this.overlaySubject$.asObservable();

    private fixedPanelsTotalHeightSubject$: BehaviorSubject<number> = new BehaviorSubject(0);
    public fixedPanelsTotalHeight$: Observable<number> = this.fixedPanelsTotalHeightSubject$.asObservable();

    private clientWidgetTypeChangedSubject$ = new BehaviorSubject<number>(0);
    public clientWidgetTypeChanged$: Observable<number> = this.clientWidgetTypeChangedSubject$.asObservable();

    private fixedPanels = new Set<ElementRef>();

    public get fixedPanelsTotalHeight(): number {
        return this.fixedPanelsTotalHeightSubject$.getValue();
    }

    public set fixedPanelsTotalHeight(height: number) {
        this.fixedPanelsTotalHeightSubject$.next(height);
    }

    public addPanel(elRef: ElementRef): void {
        if (!this.fixedPanels.has(elRef)) {
            this.fixedPanels.add(elRef);
            this.fixedPanelsTotalHeight += elRef.nativeElement.offsetHeight;
        }
    }

    public removePanel(elRef: ElementRef): void {
        if (this.fixedPanels.has(elRef)) {
            this.fixedPanels.delete(elRef);
            this.fixedPanelsTotalHeight -= elRef.nativeElement.offsetHeight;
        }
    }

    public clientWidgetChanged(height: number): void {
        this.clientWidgetTypeChangedSubject$.next(height);
    }

    public toggleOverlay(isVisible: boolean): void {
        this.overlaySubject$.next(isVisible);
    }

    public toggleClientWidgetBarExisting(value: boolean): void {
        this.clientWidgetBarExistsSubject$.next(value);
    }

}
