import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, concatMap, map, mapTo, tap } from 'rxjs/operators';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { ENDPOINTS_TOKEN, EndpointsConfigInterface } from '../config/endpoints';
import { BaseApiResponse } from './api/base-api.service';
import { DOCUMENT } from '@angular/common';
import { AuthTokens } from '../interfaces/auth-tokens.interface';
import { Aura } from '../helpers/aura.helper';
import { Params } from '@angular/router';

const AUTH_TOKEN_NAME = 'userAccessToken';
const NP_TOKEN_NAME = 'npAccessToken';

export interface OAuthData {
    accessToken: string;
    refreshToken: string;
}

export interface NpAuthData {
    npToken: string;
}

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    private _accessToken = localStorage.getItem(AUTH_TOKEN_NAME);
    public npToken = localStorage.getItem(NP_TOKEN_NAME);

    public set accessToken(value) {
        this._accessToken = value;
        this.isLogged$.next(!!value);
    }

    public get accessToken(): string {
        return this._accessToken;
    }

    public isLogged$ = new BehaviorSubject<boolean>(!!this.accessToken);

    private readonly baseUrl = this.endpointsConfig.BASE_API_URL;

    constructor(
        private httpClient: HttpClient,
        @Inject(DOCUMENT) private document: any,
        @Inject(ENDPOINTS_TOKEN) private endpointsConfig: EndpointsConfigInterface,
    ) {}

    public get isLogged(): boolean {
        return this.isLogged$.value;
    }

    public authenticate(code: string, redirectUrl: string): Observable<AuthTokens> {
        return this.httpClient.post(`${this.baseUrl}/oauth/code`, { code, redirect_url: redirectUrl })
            .pipe(
                map((oauthData: BaseApiResponse<OAuthData>) => Aura.snakeToCamel<BaseApiResponse<OAuthData>>(oauthData)),
                tap((oauthData: BaseApiResponse<OAuthData>) => this.setAccessToken(oauthData.data.accessToken)),
                // Авторизация в NP должна происходить после авторизации в CMI, по требованию от бекенд разработчиков CMI
                concatMap(() => this.httpClient.get(`${this.baseUrl}/oauth/np_token`)
                    .pipe(
                        // Если в NP не удалось авторизоваться все равно продолжаем рабту
                        catchError(() => of(null)),
                        map((npAuthData: BaseApiResponse<NpAuthData>) => Aura.snakeToCamel<BaseApiResponse<NpAuthData>>(npAuthData)),
                        tap((npAuthData: BaseApiResponse<NpAuthData>) =>
                            this.setNpToken(npAuthData && npAuthData.data && npAuthData.data.npToken || null),
                        ),
                    ),
                ),
                mapTo({ cmi: this.accessToken, np: this.npToken }),
            );
    }

    /**
     * Этот метод редиректит на внешнюю(!) страницу авторизации (за пределами SPA)
     */
    public redirectToLoginPage(): Observable<any> {
        const params: Params = { redirect_url: this.getRedirectUrl({ path: `${location.pathname}${location.search}` })};

        return this.httpClient
            .get(`${this.baseUrl}/oauth/authorize-url`, { params })
            .pipe(
                map((response: BaseApiResponse<{url: string}>) => response && response.data && response.data.url),
                tap((url: string) => this.document.location.href = url)
            );
    }

    /**
     * Бекенд OAUTH ожидает редирект url именно в таком формате (с oauth в пути), но могут быть переданы любые query параметры
     **/
    public getRedirectUrl(params: Params): string {
        return location.protocol + '//' + location.host + '/oauth' + (params.path ? `?path=${params.path}` : '');
    }

    public setAccessToken(token: string) {
        this.accessToken = token;
        localStorage.setItem(AUTH_TOKEN_NAME, token);
    }

    public setNpToken(token: string) {
        this.npToken = token;
        localStorage.setItem(NP_TOKEN_NAME, token);
    }

    public logout(): void {
        this.accessToken = null;
        this.npToken = null;
        localStorage.removeItem(AUTH_TOKEN_NAME);
        localStorage.removeItem(NP_TOKEN_NAME);
    }
}
