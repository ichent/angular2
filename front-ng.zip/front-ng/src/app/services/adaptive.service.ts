import { Injectable } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AdaptiveService {

    private mobileQuery = this.media.matchMedia('(max-width: 1024px)');

    private isMobileSubject$ = new BehaviorSubject<boolean>(this.mobileQuery.matches);

    public readonly isMobile$ = this.isMobileSubject$.asObservable();

    constructor(public media: MediaMatcher) {
        if (this.mobileQuery.addEventListener) {
            this.mobileQuery.addEventListener('change', (event: MediaQueryListEvent) => this.mobileQueryOnChange(event));
        }
    }

    private mobileQueryOnChange(event: MediaQueryListEvent): void {
        this.isMobileSubject$.next(event.matches);
    }

}
