import 'jest-preset-angular';
import "./test-extends/jest-array-matcher";

// Mock for document.execCommand
Object.defineProperty(document, 'execCommand', {
    value: () => {},
});

Object.defineProperty(window, 'DragEvent', {
    value: class DragEvent {}
});
Object.defineProperty(window, 'getComputedStyle', {
    value: () => ({
        getPropertyValue: (prop) => {
            return '';
        }
    })
});
Object.defineProperty(global, 'Promise', { writable: false, value: global.Promise });
