# CMI

To launch this project add line `127.0.0.1 api.frontend.test frontend.test` to your hosts file \
Run in console (macOS): `sudo nano /etc/hosts`

## Development server

Run `ng serve` or `npm start` for a dev server. 
Navigate to `http://frontend.test:4201/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build prod

Run `npm run build-prod` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests

## Running e2e tests in development mode

Run `ng serve` or `npm start` to start development server
Run `npm run e2e-local` to execute the e2e tests locally

## Running e2e tests in production mode

Run `npm run build-prod` to build production build to ./dist folder
Run `npm run e2e` to execute the e2e in headless mode. It use compiled files from ./dist folder.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
