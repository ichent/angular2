import * as expect from 'expect';
import { JestMatcherResult } from './jest-matcher-result.interface';

export {};

declare global {
    namespace jest {
        interface Matchers<R> {
            toBeArray(): R;
            toHaveLength(length: number): R;
        }
    }
}

expect.extend({
    toBeArray(received: any): JestMatcherResult {
        return {
            message: () => `expected ${JSON.stringify(received)} to be an array`,
            pass: Array.isArray(received),
        };
    },
    toHaveLength(received: any, length: number): JestMatcherResult {
        return {
            message: () => `expected ${JSON.stringify(received)} to have length ${length}`,
            pass: received?.length === length,
        };
    },
});
