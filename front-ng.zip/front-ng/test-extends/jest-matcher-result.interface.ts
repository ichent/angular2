export interface JestMatcherResult {
    message: () => string; // Сообщение для вывода в консоль
    pass: boolean; // Прошёл ли тест или нет
}
