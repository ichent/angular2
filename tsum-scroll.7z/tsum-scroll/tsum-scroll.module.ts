import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumScrollComponent } from './tsum-scroll.component';
import { TsumScrollbarComponent } from './tsum-scrollbar/tsum-scrollbar.component';

@NgModule({
    declarations: [
        TsumScrollComponent,
        TsumScrollbarComponent,
    ],
    imports: [
        CommonModule,
    ],
    exports: [
        TsumScrollComponent,
    ],
})
export class TsumScrollModule {}
