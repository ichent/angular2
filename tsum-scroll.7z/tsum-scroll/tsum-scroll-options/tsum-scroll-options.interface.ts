export interface TsumScrollOptions {
    expansionDebounceTime?: number;
    activenessDebounceTime?: number;
    hoverDelay?: number;
}
