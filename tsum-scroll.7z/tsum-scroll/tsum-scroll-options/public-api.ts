export * from './tsum-scroll-options.interface';
