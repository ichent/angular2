import { InjectionToken } from '@angular/core';
import { TsumScrollOptions } from './tsum-scroll-options.interface';

export const TSUM_SCROLL_OPTIONS = new InjectionToken<TsumScrollOptions>('TSUM_SCROLL_OPTIONS');
