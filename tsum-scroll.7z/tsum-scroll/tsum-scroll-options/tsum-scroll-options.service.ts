import { Inject, Injectable, Optional } from '@angular/core';
import { TsumScrollOptions } from './tsum-scroll-options.interface';
import { TSUM_SCROLL_OPTIONS } from './tsum-scroll-options.constant';

@Injectable({ providedIn: 'root' })
export class TsumScrollOptionsService {

    public readonly defaultOptions: Required<TsumScrollOptions> = {
        expansionDebounceTime: 1000,
        activenessDebounceTime: 800,
        hoverDelay: 800,
    };

    public globalOptions: TsumScrollOptions;

    constructor(@Optional() @Inject(TSUM_SCROLL_OPTIONS) options: any) {
        this.globalOptions = options
            ? { ...this.defaultOptions, ...options }
            : this.defaultOptions;
    }
}
