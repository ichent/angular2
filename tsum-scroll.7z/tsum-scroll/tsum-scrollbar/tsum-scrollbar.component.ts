import {
    AfterViewInit,
    ChangeDetectionStrategy,
    Component,
    ElementRef,
    EventEmitter,
    Inject,
    Input,
    OnChanges,
    OnDestroy,
    Output,
    Renderer2,
    SimpleChanges,
    ViewChild,
} from '@angular/core';
import { fromEvent, merge, Observable, of, Subject, timer, animationFrameScheduler } from 'rxjs';
import {
    auditTime,
    debounceTime,
    delayWhen,
    distinctUntilChanged,
    exhaustMap,
    filter,
    finalize,
    first,
    map,
    mapTo,
    skipWhile,
    startWith,
    switchMap,
    takeUntil,
    tap,
    throttleTime,
} from 'rxjs/operators';
import { TsumScrollOptionsService } from '../tsum-scroll-options/tsum-scroll-options.service';
import { TsumScrollOptions } from '../tsum-scroll-options/tsum-scroll-options.interface';
import { DOCUMENT } from '@angular/common';
import { TsumInputBoolean } from '@tsum/utils';

// 1px - добавочная ширина, во избежание вылезания нативного скрола при ресайзе
const ASSURANCE_DISTANCE = 1;

interface Offsets {
    dx: number;
    dy: number;
}

@Component({
    selector: 'tsum-scrollbar',
    templateUrl: './tsum-scrollbar.component.html',
    styleUrls: ['./tsum-scrollbar.component.styl'],
    host: {
        '[class._vertical]': '!isHorizontal',
        '[class._horizontal]': 'isHorizontal',
    },
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumScrollbarComponent implements AfterViewInit, OnChanges, OnDestroy {

    @Input()
    public scrolledRatio: number;

    @Input()
    public viewRatio: number;

    @TsumInputBoolean()
    @Input('horizontal')
    public isHorizontal: boolean;

    @Output('scrolled')
    public scrolled$ = new EventEmitter<number>();

    public isHovered$: Observable<boolean>;
    public isDragging$: Observable<boolean>;
    public isActive$: Observable<boolean>;

    @ViewChild('scrollbar', { static: true })
    private scrollbarRef: ElementRef;

    @ViewChild('thumb', { static: true })
    private thumbRef: ElementRef;

    private thumbLength: number;
    private thumbOffset: number;
    private scrollBarLength: number;
    private options: TsumScrollOptions = this.optionsService.globalOptions;

    private get scrollbarArea(): HTMLElement {
        return this.elRef.nativeElement;
    }

    private get scrollbar(): HTMLElement {
        return this.scrollbarRef.nativeElement;
    }

    private get thumb(): HTMLElement {
        return this.thumbRef.nativeElement;
    }

    private get hiddenLength(): number {
        return (this.scrollBarLength - this.thumbLength) || 0;
    }

    private changeSubject$ = new Subject<void>();

    private grab$ = new Subject<void>();
    private drop$ = new Subject<void>();
    private hover$ = new Subject<void>();
    private blur$ = new Subject<void>();
    private isHoveredAfterDelay$: Observable<boolean> = this.hover$.pipe(
        startWith(null as boolean),
        switchMap(() => this.blur$
            .pipe(
                debounceTime(this.options.expansionDebounceTime),
                mapTo(false),
            )),
        first(),
    );
    private destroyed$ = new Subject<void>();

    constructor(
        @Inject(DOCUMENT) private document: any,
        private optionsService: TsumScrollOptionsService,
        private renderer: Renderer2,
        private elRef: ElementRef,
    ) {
        this.isHovered$ = this.hover$
            .pipe(
                switchMap(() => timer(this.optionsService.globalOptions.hoverDelay).pipe(takeUntil(this.blur$))),
                exhaustMap(() => this.isHoveredAfterDelay$.pipe(startWith(true))),
            );

        this.isDragging$ = merge(
            this.grab$.pipe(mapTo(true)),
            this.drop$
                .pipe(
                    mapTo(false),
                    auditTime(this.options.expansionDebounceTime),
                ),
            )
            .pipe(distinctUntilChanged());

        this.isActive$ = merge(
            this.changeSubject$.pipe(mapTo(true)),
            this.changeSubject$
                .pipe(
                    mapTo(false),
                    auditTime(this.options.activenessDebounceTime),
                ),
            )
            .pipe(distinctUntilChanged());
    }

    public ngAfterViewInit(): void {
        this.setAllScrollBarParams();
        this.subscribeToDragAndDrop();
        this.subscribeToHover();
    }

    public ngOnChanges(changes: SimpleChanges): void {
        // только при повторных присваиваниях
        if (this.thumbLength !== undefined && changes.viewRatio) {
            this.setAllScrollBarParams();
            this.changeSubject$.next();
        }

        // только при повторных присваиваниях
        if (this.thumbOffset !== undefined && changes.scrolledRatio) {
            this.setThumbOffset();
            this.changeSubject$.next();
        }
    }

    public ngOnDestroy(): void {
        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private setAllScrollBarParams(): void {
        // порядок важен
        this.setScrollBarLength();
        this.setThumbLength();
        this.setThumbOffset();
    }

    private subscribeToHover(): void {
        fromEvent(this.scrollbarArea, 'mouseenter')
            .pipe(
                tap(() => this.hover$.next()),
                switchMap(() => fromEvent(this.scrollbarArea, 'mouseleave')),
                tap(() => this.blur$.next()),
                takeUntil(this.destroyed$),
            )
            .subscribe();
    }

    private subscribeToDragAndDrop(): void {
        fromEvent(this.scrollbarArea, 'mousedown')
            .pipe(
                filter((event: MouseEvent) => event.button === 0),
                tap((event: MouseEvent) => event.preventDefault()),
                this.moveToPointIf((event: MouseEvent) => event.target !== this.thumb),
                tap(() => this.grab$.next()),
                switchMap((event: MouseEvent) => this.fromDragEvent(event)
                    .pipe(
                        this.mapToRatio(this.scrolledRatio),
                        takeUntil(fromEvent(this.document, 'mouseup')),
                        finalize(() => this.drop$.next())
                    )
                ),
                takeUntil(this.destroyed$),
            )
            .subscribe((ratio: number) => this.scrolled$.emit(ratio));
    }

    private moveToPoint(event: MouseEvent): void {
        const thumbRect: ClientRect = this.thumb.getBoundingClientRect();
        const dx: number = event.x - (thumbRect.left + thumbRect.right) / 2;
        const dy: number = event.y - (thumbRect.top + thumbRect.bottom) / 2;

        const delta: number = this.getDelta({ dx, dy });

        this.scrolled$.emit(this.scrolledRatio + delta / this.hiddenLength);
    }

    private moveToPointIf(predicate: Function): (source: Observable<MouseEvent>) => Observable<MouseEvent> {
        return (source: Observable<MouseEvent>) => source
            .pipe(
                switchMap((event: MouseEvent) => predicate(event)
                    ? of(event).pipe(
                        tap(() => this.moveToPoint(event)),
                        delayWhen(() => this.changeSubject$),
                        takeUntil(fromEvent(this.document, 'mouseup')),
                    )
                    : of(event)
                )
            );
    }

    private mapToRatio(initialRatio: number): (source: Observable<Offsets>) => Observable<number> {
        return (source: Observable<Offsets>) => source
            .pipe(
                map((offsets: Offsets) => this.getDelta(offsets)),
                distinctUntilChanged(),
                map((delta: number) => initialRatio + delta / this.hiddenLength),
            );
    }

    private fromDragEvent(mouseDownEvent: MouseEvent): Observable<Offsets> {
        const x0: number = mouseDownEvent.x;
        const y0: number = mouseDownEvent.y;

        return fromEvent(this.document, 'mousemove')
            .pipe(
                throttleTime(0, animationFrameScheduler),
                tap((event: MouseEvent) => event.preventDefault()),
                map((event: MouseEvent) => ({ dx: event.x - x0, dy: event.y - y0 })),
                skipWhile(({ dx, dy }: Offsets) =>
                    Math.sqrt(dx * dx + dy * dy) <= ASSURANCE_DISTANCE
                ),
            );
    }

    private setScrollBarLength(): void {
        const scrollBarRect: ClientRect = this.scrollbar.getBoundingClientRect();

        this.scrollBarLength = this.isHorizontal ? scrollBarRect.width : scrollBarRect.height;
    }

    private setThumbLength(): void {
        this.thumbLength = this.scrollBarLength * this.viewRatio || 0;

        this.renderer.setStyle(this.thumb, this.isHorizontal ? 'width' : 'height', `${Math.round(this.thumbLength)}px`);
    }

    private setThumbOffset(): void {
        this.thumbOffset = this.hiddenLength * this.scrolledRatio || 0;

        this.renderer.setStyle(this.thumb, this.isHorizontal ? 'left' : 'top', `${Math.round(this.thumbOffset)}px`);
    }

    private getDelta({ dx, dy }: Offsets): number {
        return this.isHorizontal ? dx : dy;
    }
}
