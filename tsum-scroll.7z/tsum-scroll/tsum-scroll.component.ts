import {
    AfterViewInit,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    ElementRef,
    HostBinding,
    Input,
    OnChanges,
    OnDestroy,
    Renderer2,
    SimpleChanges,
    ViewChild,
} from '@angular/core';
import { fromEvent, Observable, of, Subject, animationFrameScheduler } from 'rxjs';
import { startWith, switchMap, takeUntil, tap, throttleTime } from 'rxjs/operators';
import { ResizeObserver } from 'resize-observer';
import { TsumInputBoolean } from '@tsum/utils';

/** @description 15px - ширина скролла в Mac OC (нельзя вычислить в режиме появления при прокрутке) */
const MAC_OC_SCROLL_WIDTH = 15;

/** @description 1px - добавочная ширина, во избежание вылезания нативного скрола при ресайзе */
const ASSURANCE_WIDTH = 1;

/**
 * @description Scroll component
 * Used to replace browser scroll by custom
 * @example <tsum-scroll>Content</tsum-scroll>
 * @description More info {@link http://uikit.alpha.int.tsum.com/?path=/story/common-scroll--default}
 */
@Component({
    selector: 'tsum-scroll',
    templateUrl: './tsum-scroll.component.html',
    styleUrls: ['./tsum-scroll.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    host: {
        '[class._small]': `sizeType === 'small'`,
        '[class._medium]': `sizeType === 'medium'`,
        '[class._big]': `sizeType === 'big'`
    },
})
export class TsumScrollComponent implements AfterViewInit, OnChanges, OnDestroy {

    /** @description  Sets overflow-x to hidden */
    @HostBinding('class._overflow-x-hidden')
    @TsumInputBoolean()
    @Input()
    public overflowXHidden = false;

    /** @description Sets overflow-y to hidden */
    @HostBinding('class._overflow-y-hidden')
    @TsumInputBoolean()
    @Input()
    public overflowYHidden = false;

    @Input()
    public sizeType: 'small' | 'medium' | 'big' = 'medium';

    public hasXScrollbar = false;
    public xScrolledRatio: number;
    public xViewRatio = 0;

    public hasYScrollbar = false;
    public yScrolledRatio: number;
    public yViewRatio = 0;

    @ViewChild('container', { static: true })
    private containerRef: ElementRef;

    @ViewChild('contentWrapper', { static: true })
    private contentWrapperRef: ElementRef;

    private resizeObserver: ResizeObserver;

    private get container(): HTMLElement {
        return this.containerRef.nativeElement;
    }

    private get contentWrapper(): HTMLElement {
        return this.contentWrapperRef.nativeElement;
    }

    private get xHiddenLength(): number {
        return this.container.scrollWidth - this.container.clientWidth;
    }

    private get yHiddenLength(): number {
        return this.container.scrollHeight - this.container.clientHeight;
    }

    private viewChanges$ = new Subject<void>();
    private destroyed$ = new Subject<void>();

    constructor(
        public elementRef: ElementRef,
        private renderer: Renderer2,
        private cd: ChangeDetectorRef,
    ) {}

    public ngAfterViewInit(): void {
        this.viewChanges$
            .pipe(
                tap(() => this.setScrollExistence()),
                tap(() => this.hideNativeScroll()),
                switchMap(() => this.hasXScrollbar || this.hasYScrollbar
                    ? this.fromScrollEvent().pipe(tap(() => this.setScrollPosition()))
                    : of(null)),
                takeUntil(this.destroyed$),
            )
            .subscribe(() => this.cd.detectChanges());

        this.resizeObserver = new ResizeObserver(() => this.viewChanges$.next());

        this.resizeObserver.observe(this.contentWrapper);
        this.resizeObserver.observe(this.container);
    }

    public ngOnChanges(changes: SimpleChanges): void {
        if (changes.overflowXHidden || changes.overflowYHidden) {
            this.viewChanges$.next();
        }
    }

    public onXScroll(ratio: number): void {
        this.renderer.setProperty(this.container, 'scrollLeft', Math.round(ratio * this.xHiddenLength));
    }

    public onYScroll(ratio: number): void {
        this.renderer.setProperty(this.container, 'scrollTop', Math.round(ratio * this.yHiddenLength));
    }

    public ngOnDestroy(): void {
        this.resizeObserver.unobserve(this.contentWrapper);
        this.resizeObserver.unobserve(this.container);
        this.resizeObserver.disconnect();

        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private fromScrollEvent(): Observable<Event> {
        return fromEvent(this.container, 'scroll', { passive: true })
            .pipe(
                throttleTime(0, animationFrameScheduler),
                startWith(null as Event),
            );
    }

    private setScrollExistence(): void {
        this.hasXScrollbar = !this.overflowXHidden && this.xHiddenLength > 0;
        this.hasYScrollbar = !this.overflowYHidden && this.yHiddenLength > 0;
    }

    private setScrollPosition(): void {
        if (this.hasXScrollbar) {
            this.xScrolledRatio = this.container.scrollLeft / this.xHiddenLength;
            this.xViewRatio = this.container.clientWidth / this.container.scrollWidth;
        }

        if (this.hasYScrollbar) {
            this.yScrolledRatio = this.container.scrollTop / this.yHiddenLength;
            this.yViewRatio = this.container.clientHeight / this.container.scrollHeight;
        }
    }

    private hideNativeScroll(): void {
        const staticVerticalScrollWidth: number = this.container.offsetWidth - this.container.clientWidth;
        const staticHorizontalScrollWidth: number = this.container.offsetHeight - this.container.clientHeight;
        const staticScrollWidth: number = staticVerticalScrollWidth || staticHorizontalScrollWidth;
        const scrollWidth: number = (staticScrollWidth || MAC_OC_SCROLL_WIDTH) + ASSURANCE_WIDTH;

        if (staticHorizontalScrollWidth) {
            this.setContainerStyle({ marginBottom: `-${scrollWidth}px`, paddingBottom: null });
        } else {
            if (this.hasXScrollbar) {
                this.setContainerStyle({ marginBottom: `-${scrollWidth}px`, paddingBottom: `${scrollWidth}px` });
            } else {
                this.setContainerStyle({ marginBottom: null, paddingBottom: null });
            }
        }

        if (staticVerticalScrollWidth) {
            this.setContainerStyle({ marginRight: `-${scrollWidth}px`, paddingRight: null });
        } else {
            if (this.hasYScrollbar) {
                this.setContainerStyle({ marginRight: `-${scrollWidth}px`, paddingRight: `${scrollWidth}px` });
            } else {
                this.setContainerStyle({ marginRight: null, paddingRight: null });
            }
        }

    }

    private setContainerStyle(styles: Record<string, string>): void {
        Object.keys(styles).forEach((key: string) =>
            this.renderer.setStyle(this.container, key, styles[key])
        );
    }
}
